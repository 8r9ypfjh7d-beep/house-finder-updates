"""``ThrottledClient`` — the only way source adapters make HTTP requests.

Wraps ``httpx.Client`` with (BRIEF N2, VISION "rate limits" default):

- a per-host minimum interval between requests (default 10 s),
- exponential back-off with jitter on 429 / 5xx / transport errors
  (max 3 retries, ``Retry-After`` honoured),
- realistic browser headers (``browser_headers=False`` for a third party
  such as the ntfy push),
- POST is sent at most once (never retried),
- detection of HTML captcha / bot pages where JSON was expected
  (``SourceBlocked``),
- an optional ``dump_dir`` that writes every raw response to disk (the hook
  behind ``house-finder collect --dump``).

Clock, sleep, jitter source and the httpx transport are injectable so tests
never touch the network or really sleep.
"""

from __future__ import annotations

import json
import logging
import random
import re
import threading
import time
from collections.abc import Callable, Mapping
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

import httpx

from house_finder.sources.base import SourceBlocked, SourceError

log = logging.getLogger(__name__)

DEFAULT_MIN_INTERVAL = 10.0
"""Seconds between two requests to the same host unless overridden."""

DEFAULT_MAX_RETRIES = 3
DEFAULT_BACKOFF_BASE = 2.0
DEFAULT_BACKOFF_MAX = 120.0
DEFAULT_RETRY_AFTER_MAX = 300.0
DEFAULT_TIMEOUT = 30.0

BROWSER_HEADERS: dict[str, str] = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36"
    ),
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7",
    "Sec-Ch-Ua": '"Google Chrome";v="129", "Not=A?Brand";v="8", "Chromium";v="129"',
    "Sec-Ch-Ua-Mobile": "?0",
    "Sec-Ch-Ua-Platform": '"Windows"',
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "same-site",
}

# Lower-cased substrings that mark a bot-protection / captcha page.
CAPTCHA_MARKERS: tuple[str, ...] = (
    "captcha",
    "radware",
    "perfdrive",
    "shieldsquare",
    "perimeterx",
    "px-captcha",
    "are you a robot",
    "are you human",
    "bot manager",
    "cf-challenge",
    "challenge-platform",
    "access denied",
    "request unsuccessful",
)

PLAIN_USER_AGENT = "house-finder (personal notifications)"

_RETRY_STATUSES = frozenset({429, 500, 502, 503, 504})
_UNSAFE_FILENAME = re.compile(r"[^A-Za-z0-9._-]+")


def looks_like_html(response: httpx.Response) -> bool:
    """True when the response is (or looks like) an HTML document."""
    ctype = response.headers.get("content-type", "").lower()
    if "html" in ctype:
        return True
    # JSON never starts with "<"; a mislabelled HTML/XML page does.
    return response.content[:512].lstrip().startswith(b"<")


# Hosts a bot manager redirects to for its challenge (Radware / ShieldSquare).
BOT_VALIDATOR_HOSTS: tuple[str, ...] = ("perfdrive.com", "shieldsquare.com")


def _api_message(response: httpx.Response) -> str:
    """`` — <message>`` from a JSON error body (yad2: "region is required"),
    else ""."""
    try:
        message = response.json().get("message")
    except (ValueError, AttributeError):
        return ""
    return f" — {str(message)[:200]}" if isinstance(message, str) and message else ""


def is_bot_response(response: httpx.Response) -> bool:
    """True when ``response`` (or a redirect on the way to it) is a
    bot-protection challenge, whatever its status code. Live yad2 answers its
    API with a 400/404 carrying the Radware captcha page (2026-10-20)."""
    for hop in (*response.history, response):
        host = (hop.url.host or "").lower()
        if any(host == h or host.endswith("." + h) for h in BOT_VALIDATOR_HOSTS):
            return True
        location = hop.headers.get("location", "").lower()
        if any(h in location for h in BOT_VALIDATOR_HOSTS):
            return True
    return looks_like_html(response) and is_captcha_page(response.text[:20000])


def is_captcha_page(text: str) -> bool:
    """True when ``text`` contains a known captcha / bot-protection marker."""
    lowered = text.lower()
    return any(marker in lowered for marker in CAPTCHA_MARKERS)


class ThrottledClient:
    """Throttled, retrying HTTP client shared by all source adapters.

    ``min_interval`` applies to every host; ``host_intervals`` overrides it
    per host name (e.g. ``{"gw.yad2.co.il": 10.0}``). Every attempt —
    retries included — waits for the host's interval. One lock serialises
    requests, so the scheduler thread and an on-demand run never interleave
    against the same host.
    """

    def __init__(
        self,
        *,
        min_interval: float = DEFAULT_MIN_INTERVAL,
        host_intervals: Mapping[str, float] | None = None,
        max_retries: int = DEFAULT_MAX_RETRIES,
        backoff_base: float = DEFAULT_BACKOFF_BASE,
        backoff_max: float = DEFAULT_BACKOFF_MAX,
        retry_after_max: float = DEFAULT_RETRY_AFTER_MAX,
        jitter: float = 0.25,
        timeout: float = DEFAULT_TIMEOUT,
        headers: Mapping[str, str] | None = None,
        transport: httpx.BaseTransport | None = None,
        clock: Callable[[], float] = time.monotonic,
        sleep: Callable[[float], None] = time.sleep,
        rng: Callable[[], float] = random.random,
        dump_dir: Path | str | None = None,
        browser_headers: bool = True,
    ) -> None:
        self.min_interval = float(min_interval)
        self.host_intervals = {h.lower(): float(v) for h, v in (host_intervals or {}).items()}
        self.max_retries = int(max_retries)
        self.backoff_base = float(backoff_base)
        self.backoff_max = float(backoff_max)
        self.retry_after_max = float(retry_after_max)
        self.jitter = float(jitter)
        self.dump_dir = Path(dump_dir) if dump_dir is not None else None
        self._clock = clock
        self._sleep = sleep
        self._rng = rng
        self._last_request: dict[str, float] = {}
        self._lock = threading.RLock()
        self._dump_seq = 0
        self.last_response: httpx.Response | None = None
        """The last response received (any status) — ``check-yad2`` reports its status and URL."""
        # A third party (the ntfy push) gets the tool's own name, never a
        # browser imitation: ``browser_headers=False``.
        merged = dict(BROWSER_HEADERS) if browser_headers else {"User-Agent": PLAIN_USER_AGENT}
        merged.update(headers or {})
        self._client = httpx.Client(
            headers=merged,
            timeout=timeout,
            transport=transport,
            follow_redirects=True,
        )

    # --------------------------------------------------------------- lifecycle

    def close(self) -> None:
        """Close the underlying ``httpx.Client``."""
        self._client.close()

    def __enter__(self) -> "ThrottledClient":
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    # ---------------------------------------------------------------- requests

    def interval_for(self, host: str) -> float:
        """Minimum seconds between two requests to ``host``."""
        return self.host_intervals.get(host.lower(), self.min_interval)

    def get(
        self,
        url: str,
        *,
        params: Mapping[str, Any] | None = None,
        headers: Mapping[str, str] | None = None,
    ) -> httpx.Response:
        """GET ``url`` with throttling and back-off; return a 2xx response.

        Raises ``SourceBlocked`` on 403, or on 429 after the last retry;
        ``SourceError`` on other 4xx, on 5xx / transport errors after the
        last retry.
        """
        return self._request("GET", url, params=params, headers=headers)

    def post(
        self,
        url: str,
        *,
        content: bytes | str | None = None,
        headers: Mapping[str, str] | None = None,
    ) -> httpx.Response:
        """POST ``content`` to ``url`` ONCE: the same throttling and errors as
        ``get`` but **never retried** — not on 5xx, 429 or a network error —
        because a POST that reached the server may have been delivered (the
        ntfy push: one push, at most once)."""
        return self._request("POST", url, content=content, headers=headers, retries=0)

    def _request(
        self,
        method: str,
        url: str,
        *,
        params: Mapping[str, Any] | None = None,
        content: bytes | str | None = None,
        headers: Mapping[str, str] | None = None,
        retries: int | None = None,
    ) -> httpx.Response:
        host = (urlsplit(url).hostname or "").lower()
        max_retries = self.max_retries if retries is None else int(retries)
        with self._lock:
            attempt = 0
            while True:
                self._wait_for_host(host)
                try:
                    response = self._client.request(
                        method, url, params=params, content=content, headers=headers
                    )
                except httpx.TransportError as exc:
                    if attempt >= max_retries:
                        raise SourceError(
                            f"{host}: {type(exc).__name__}: {exc} "
                            f"(after {max_retries} retries)"
                        ) from exc
                    delay = self._backoff(attempt)
                    log.warning("%s: %s, retry %d in %.1fs", host, exc, attempt + 1, delay)
                    self._sleep(delay)
                    attempt += 1
                    continue

                self.last_response = response
                self._dump(host, response)
                status = response.status_code
                if 200 <= status < 300:
                    return response
                if is_bot_response(response):
                    raise SourceBlocked(
                        f"{host}: HTTP {status} — bot-protection challenge (captcha); "
                        "the site is refusing automated requests"
                    )
                if status == 403:
                    raise SourceBlocked(f"{host}: HTTP 403 (blocked by the site)")
                if status in _RETRY_STATUSES:
                    if attempt >= max_retries:
                        msg = f"{host}: HTTP {status} after {max_retries} retries"
                        if status == 429:
                            raise SourceBlocked(msg + " (rate limited)")
                        raise SourceError(msg)
                    delay = max(self._backoff(attempt), self._retry_after(response))
                    log.warning("%s: HTTP %d, retry %d in %.1fs", host, status, attempt + 1, delay)
                    self._sleep(delay)
                    attempt += 1
                    continue
                raise SourceError(f"{host}: HTTP {status}{_api_message(response)}")

    def get_json(
        self,
        url: str,
        *,
        params: Mapping[str, Any] | None = None,
        headers: Mapping[str, str] | None = None,
    ) -> Any:
        """GET ``url`` and decode JSON.

        An HTML captcha / bot page raises ``SourceBlocked``; any other
        non-JSON body raises ``SourceError`` — never an empty result.
        """
        response = self.get(url, params=params, headers=headers)
        host = (urlsplit(url).hostname or "").lower()
        if looks_like_html(response):
            if is_captcha_page(response.text):
                raise SourceBlocked(f"{host}: captcha / bot-protection page instead of JSON")
            raise SourceError(f"{host}: expected JSON, got HTML ({len(response.content)} bytes)")
        try:
            return response.json()
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            raise SourceError(f"{host}: invalid JSON: {exc}") from exc

    # ---------------------------------------------------------------- internals

    def _wait_for_host(self, host: str) -> None:
        interval = self.interval_for(host)
        last = self._last_request.get(host)
        if last is not None:
            remaining = interval - (self._clock() - last)
            if remaining > 0:
                self._sleep(remaining)
        self._last_request[host] = self._clock()

    def _backoff(self, attempt: int) -> float:
        base = min(self.backoff_max, self.backoff_base * (2**attempt))
        return base * (1.0 + self.jitter * self._rng())

    def _retry_after(self, response: httpx.Response) -> float:
        raw = response.headers.get("retry-after", "").strip()
        if raw.isdigit():
            return min(float(raw), self.retry_after_max)
        return 0.0

    def _dump(self, host: str, response: httpx.Response) -> None:
        if self.dump_dir is None:
            return
        self._dump_seq += 1
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        ext = "html" if looks_like_html(response) else "json"
        name = _UNSAFE_FILENAME.sub("_", f"{stamp}_{self._dump_seq:03d}_{host}_{response.status_code}")
        self.dump_dir.mkdir(parents=True, exist_ok=True)
        (self.dump_dir / f"{name}.{ext}").write_bytes(response.content)
        meta = {"url": str(response.request.url), "status": response.status_code,
                "headers": dict(response.headers)}
        (self.dump_dir / f"{name}.meta.json").write_text(
            json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8"
        )

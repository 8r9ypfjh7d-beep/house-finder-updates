"""``Store`` — the app's single SQLite database (stdlib ``sqlite3``).

Schema is built by an ordered list of migrations; ``schema_version`` records
how many have been applied. **Later plans append to ``MIGRATIONS``; an
existing migration is never edited.** All timestamps are UTC ISO-8601 strings.
"""

from __future__ import annotations

import hashlib
import json
import sqlite3
import threading
from collections.abc import Iterable, Iterator
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Literal

from house_finder.models import Listing

DecisionAction = Literal["skip", "save", "interested"]
HealthStatus = Literal["ok", "error", "empty"]
DECISION_ACTIONS: tuple[str, ...] = ("skip", "save", "interested")
HEALTH_STATUSES: tuple[str, ...] = ("ok", "error", "empty")
HEALTH_ERROR_KINDS: tuple[str, ...] = ("blocked",)
ALERT_KINDS: tuple[str, ...] = ("zero_unexpected", "consecutive_errors", "blocked")
MESSAGE_STATUSES: tuple[str, ...] = ("draft", "approved", "sent", "failed", "cancelled")
OPEN_MESSAGE_STATUSES: tuple[str, ...] = ("draft", "approved")
FB_GROUP_STATUSES: tuple[str, ...] = ("candidate", "approved", "rejected", "joined", "pending_join")

# Index i holds the script that takes the schema from version i to i + 1.
# APPEND ONLY — never edit or reorder an existing entry.
MIGRATIONS: list[str] = [
    # 1 — foundation
    """
    CREATE TABLE listings (
        id          TEXT PRIMARY KEY,
        source      TEXT NOT NULL,
        source_id   TEXT NOT NULL,
        json        TEXT NOT NULL,
        first_seen  TEXT NOT NULL,
        last_seen   TEXT NOT NULL
    );
    CREATE INDEX listings_source ON listings(source);
    CREATE TABLE decisions (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        listing_id  TEXT NOT NULL,
        action      TEXT NOT NULL CHECK (action IN ('skip', 'save', 'interested')),
        reason      TEXT,
        at          TEXT NOT NULL
    );
    CREATE INDEX decisions_listing ON decisions(listing_id);
    CREATE TABLE events (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        at          TEXT NOT NULL,
        kind        TEXT NOT NULL,
        listing_id  TEXT,
        data        TEXT NOT NULL
    );
    CREATE TABLE source_health (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        source      TEXT NOT NULL,
        at          TEXT NOT NULL,
        status      TEXT NOT NULL CHECK (status IN ('ok', 'error', 'empty')),
        count       INTEGER NOT NULL DEFAULT 0,
        message     TEXT NOT NULL DEFAULT ''
    );
    CREATE INDEX source_health_source ON source_health(source);
    """,
    # 2 — messaging: drafts and approval records (VISION hard constraint 1).
    # text_sha256 is the APPROVAL: sha256 of the text the owner approved; it is
    # NULL while a message is a draft. The triggers make the database itself
    # refuse the unsafe transitions, whatever the calling code does.
    """
    CREATE TABLE messages (
        id                INTEGER PRIMARY KEY AUTOINCREMENT,
        listing_id        TEXT NOT NULL,
        channel           TEXT NOT NULL,
        text              TEXT NOT NULL,
        language          TEXT NOT NULL,
        status            TEXT NOT NULL
                          CHECK (status IN ('draft', 'approved', 'sent', 'failed', 'cancelled')),
        text_sha256       TEXT,
        created_at        TEXT NOT NULL,
        approved_at       TEXT,
        sent_at           TEXT,
        error             TEXT,
        reply_received_at TEXT,
        reply_note        TEXT,
        CHECK (status NOT IN ('approved', 'sent')
               OR (text_sha256 IS NOT NULL AND approved_at IS NOT NULL))
    );
    CREATE INDEX messages_listing ON messages(listing_id);
    CREATE TRIGGER messages_born_draft BEFORE INSERT ON messages
        WHEN NEW.status != 'draft' OR NEW.text_sha256 IS NOT NULL
        BEGIN SELECT RAISE(ABORT, 'a message is created as an unapproved draft'); END;
    CREATE TRIGGER messages_sent_needs_approval BEFORE UPDATE OF status ON messages
        WHEN NEW.status = 'sent' AND OLD.status != 'approved'
        BEGIN SELECT RAISE(ABORT, 'a message can only be sent from approved'); END;
    CREATE TRIGGER messages_text_edit_is_draft BEFORE UPDATE OF text ON messages
        WHEN NEW.text != OLD.text AND (NEW.status != 'draft' OR NEW.text_sha256 IS NOT NULL)
        BEGIN SELECT RAISE(ABORT, 'editing a message text returns it to an unapproved draft'); END;
    """,
    # 3 — notifications: one row per listing that has been notified as a new
    # match (the PRIMARY KEY makes "notify once" hold across restarts and
    # concurrent runs). seen_at is set when the owner views the review page;
    # rows with seen_at NULL are the dashboard's "N new matches" badge.
    """
    CREATE TABLE notified (
        listing_id  TEXT PRIMARY KEY,
        at          TEXT NOT NULL,
        seen_at     TEXT
    );
    """,
    # 4 — Facebook groups (facebook plan, stage 2). Discovery stores a group
    # as a `candidate`; the owner approves or rejects it; only the joiner
    # (secure-sessions) moves it to pending_join / joined. The triggers make
    # the database refuse a group born in any other status and a join of a
    # group the owner has not approved (VISION priority 1, BRIEF §9).
    """
    CREATE TABLE fb_groups (
        group_id          TEXT PRIMARY KEY,
        name              TEXT NOT NULL,
        url               TEXT NOT NULL DEFAULT '',
        member_count      INTEGER,
        privacy           TEXT,
        status            TEXT NOT NULL DEFAULT 'candidate'
                          CHECK (status IN ('candidate', 'approved', 'rejected', 'joined', 'pending_join')),
        last_listing_at   TEXT,
        listing_ratio     REAL,
        posts_sampled     INTEGER NOT NULL DEFAULT 0,
        discovered_query  TEXT,
        questions         TEXT NOT NULL DEFAULT '[]',
        updated_at        TEXT NOT NULL
    );
    CREATE INDEX fb_groups_status ON fb_groups(status);
    CREATE TRIGGER fb_groups_born_candidate BEFORE INSERT ON fb_groups
        WHEN NEW.status != 'candidate'
        BEGIN SELECT RAISE(ABORT, 'a Facebook group is stored as a candidate'); END;
    CREATE TRIGGER fb_groups_join_needs_approval BEFORE UPDATE OF status ON fb_groups
        WHEN NEW.status IN ('pending_join', 'joined')
             AND OLD.status NOT IN ('approved', 'pending_join', 'joined')
        BEGIN SELECT RAISE(ABORT, 'only an approved Facebook group can be joined'); END;
    """,
    # 5 — Facebook group entry answers (facebook plan, stage 3). One row per
    # group: the answers to its entry questions and the APPROVAL —
    # answers_sha256 = sha256 of the canonical (group_id, [(question,
    # answer)...]) serialisation the owner approved (NULL while unapproved).
    # The triggers make the database refuse: a row born approved; an answer
    # edit that keeps the approval; approving answers of a group that is not
    # `approved`; and joining a group that has entry questions without
    # approved answers. A change to a group's questions deletes its answers
    # (they answered other questions). VISION hard constraint 1.
    """
    CREATE TABLE fb_group_answers (
        group_id        TEXT PRIMARY KEY REFERENCES fb_groups(group_id),
        answers         TEXT NOT NULL,
        answers_sha256  TEXT,
        approved_at     TEXT,
        updated_at      TEXT NOT NULL,
        CHECK ((answers_sha256 IS NULL) = (approved_at IS NULL))
    );
    CREATE TRIGGER fb_answers_born_unapproved BEFORE INSERT ON fb_group_answers
        WHEN NEW.answers_sha256 IS NOT NULL
        BEGIN SELECT RAISE(ABORT, 'entry answers are stored unapproved'); END;
    CREATE TRIGGER fb_answers_edit_clears_approval BEFORE UPDATE OF answers ON fb_group_answers
        WHEN NEW.answers != OLD.answers AND NEW.answers_sha256 IS NOT NULL
        BEGIN SELECT RAISE(ABORT, 'editing entry answers clears their approval'); END;
    CREATE TRIGGER fb_answers_approval_needs_approved_group BEFORE UPDATE OF answers_sha256 ON fb_group_answers
        WHEN NEW.answers_sha256 IS NOT NULL
             AND (SELECT status FROM fb_groups WHERE group_id = NEW.group_id) IS NOT 'approved'
        BEGIN SELECT RAISE(ABORT, 'only an approved group gets approved entry answers'); END;
    CREATE TRIGGER fb_groups_questions_reset_answers AFTER UPDATE OF questions ON fb_groups
        WHEN NEW.questions != OLD.questions
        BEGIN DELETE FROM fb_group_answers WHERE group_id = NEW.group_id; END;
    CREATE TRIGGER fb_groups_join_needs_answers BEFORE UPDATE OF status ON fb_groups
        WHEN NEW.status IN ('pending_join', 'joined') AND OLD.status = 'approved'
             AND NEW.questions != '[]'
             AND NOT EXISTS (SELECT 1 FROM fb_group_answers a
                             WHERE a.group_id = NEW.group_id AND a.answers_sha256 IS NOT NULL)
        BEGIN SELECT RAISE(ABORT, 'a group with entry questions needs approved answers before joining'); END;
    """,
    # 6 — cross-source duplicates (hardening plan, stage 1). One row per
    # listing that is the same apartment as an EARLIER listing: listing_id ->
    # canonical_id + the reason. The canonical is never itself a duplicate
    # and a duplicate is never a canonical (no chains: A -> B -> C cannot
    # exist), a listing is never its own duplicate, both ids must exist, and
    # a link is never edited (quality/dedup.py decides; VISION priority 2).
    """
    CREATE TABLE duplicates (
        listing_id    TEXT PRIMARY KEY REFERENCES listings(id),
        canonical_id  TEXT NOT NULL REFERENCES listings(id),
        reason        TEXT NOT NULL,
        at            TEXT NOT NULL,
        CHECK (listing_id != canonical_id)
    );
    CREATE INDEX duplicates_canonical ON duplicates(canonical_id);
    CREATE TRIGGER duplicates_known_listings BEFORE INSERT ON duplicates
        WHEN NOT EXISTS (SELECT 1 FROM listings WHERE id = NEW.listing_id)
          OR NOT EXISTS (SELECT 1 FROM listings WHERE id = NEW.canonical_id)
        BEGIN SELECT RAISE(ABORT, 'a duplicate link needs two stored listings'); END;
    CREATE TRIGGER duplicates_no_chain BEFORE INSERT ON duplicates
        WHEN EXISTS (SELECT 1 FROM duplicates WHERE listing_id = NEW.canonical_id)
          OR EXISTS (SELECT 1 FROM duplicates WHERE canonical_id = NEW.listing_id)
        BEGIN SELECT RAISE(ABORT, 'a duplicate points at a canonical listing: no chains'); END;
    CREATE TRIGGER duplicates_never_edited BEFORE UPDATE ON duplicates
        BEGIN SELECT RAISE(ABORT, 'a duplicate link is never edited'); END;
    """,
    # 7 — source health alerts (hardening plan, stage 3). `error_kind` makes a
    # SourceBlocked run identifiable without matching message text ('blocked';
    # NULL for any other row); rows recorded before this migration are
    # back-filled from the collector's `blocked: ` message prefix.
    # `source_alerts` holds one row per INCIDENT: at most one open (cleared_at
    # NULL) per source — the partial unique index — and `notified_at` is the
    # claim that makes "one incident = one notification" hold across runs,
    # restarts and two processes.
    """
    ALTER TABLE source_health ADD COLUMN error_kind TEXT
        CHECK (error_kind IS NULL OR error_kind IN ('blocked'));
    UPDATE source_health SET error_kind = 'blocked'
        WHERE status = 'error' AND message LIKE 'blocked: %';
    CREATE INDEX source_health_source_id ON source_health(source, id);
    CREATE TABLE source_alerts (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        source       TEXT NOT NULL,
        kind         TEXT NOT NULL CHECK (kind IN ('zero_unexpected', 'consecutive_errors', 'blocked')),
        reason       TEXT NOT NULL,
        opened_at    TEXT NOT NULL,
        updated_at   TEXT NOT NULL,
        notified_at  TEXT,
        cleared_at   TEXT
    );
    CREATE UNIQUE INDEX source_alerts_one_open ON source_alerts(source) WHERE cleared_at IS NULL;
    """,
    # 8 — cross-run cooldown after a block (secure-sessions plan, stage 2).
    # One row per source that was blocked: the collector skips it until
    # `until`; `level` counts blocks since the source's last healthy run
    # (1 -> 6 h, 2+ -> 24 h). The owner's "Clear" on /health sets
    # `cleared_at` (the level is kept: another block escalates); a healthy
    # run deletes the row (escalation starts over).
    """
    CREATE TABLE source_cooldowns (
        source      TEXT PRIMARY KEY,
        level       INTEGER NOT NULL CHECK (level >= 1),
        until       TEXT NOT NULL,
        reason      TEXT NOT NULL,
        started_at  TEXT NOT NULL,
        cleared_at  TEXT
    );
    """,
]

# Cooldown after the n-th block in a row (secure-sessions stage 2); the last
# step repeats.
COOLDOWN_STEPS: tuple[timedelta, ...] = (timedelta(hours=6), timedelta(hours=24))


def utc_now_iso() -> str:
    """Current time as a UTC ISO-8601 string with microseconds
    (fixed width, so string order equals time order)."""
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")


def text_sha256(text: str) -> str:
    """Hex sha256 of ``text`` encoded as UTF-8 — the hash an approval binds."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


class MessageStateError(ValueError):
    """A message operation that its current status does not allow."""


class StaleApprovalError(MessageStateError):
    """An approval whose hash does not match the message's CURRENT text."""


class ConcurrentChangeError(MessageStateError):
    """A guarded UPDATE changed no row: the message changed between the check
    and the write (e.g. another process). Nothing was changed or logged."""


# Only ``Store.approval_for`` holds this, so only it can build a token.
_TOKEN_KEY = object()


class ApprovalToken:
    """Proof that message ``message_id`` was approved for the text whose
    sha256 is ``text_sha256``.

    Built only by ``Store.approval_for()`` from a row whose status is
    ``approved`` and whose approval hash matches its current text (any other
    construction raises ``TypeError``). Immutable. A token is not trusted on
    its own: every sender and ``Store.mark_sent`` re-check it against the
    CURRENT row and text before doing anything (``check_approval``).
    """

    __slots__ = ("message_id", "text_sha256")
    message_id: int
    text_sha256: str

    def __init__(self, message_id: int, text_sha256: str, *, _key: object = None) -> None:
        if _key is not _TOKEN_KEY:
            raise TypeError("an ApprovalToken is issued only by Store.approval_for()")
        object.__setattr__(self, "message_id", message_id)
        object.__setattr__(self, "text_sha256", text_sha256)

    def __setattr__(self, name: str, value: object) -> None:
        raise AttributeError("ApprovalToken is immutable")

    def __delattr__(self, name: str) -> None:
        raise AttributeError("ApprovalToken is immutable")

    def __reduce__(self) -> object:
        raise TypeError("an ApprovalToken cannot be pickled or copied")

    def __repr__(self) -> str:
        return f"ApprovalToken(message_id={self.message_id}, text_sha256={self.text_sha256[:12]}...)"

    def __eq__(self, other: object) -> bool:
        return (isinstance(other, ApprovalToken) and other.message_id == self.message_id
                and other.text_sha256 == self.text_sha256)

    def __hash__(self) -> int:
        return hash((self.message_id, self.text_sha256))


APPROVAL_MISMATCH = "approval does not match text"


def check_approval(message: "Message | None", approval: object) -> str | None:
    """``None`` when ``approval`` is a real ``ApprovalToken`` for ``message``,
    the message is ``approved``, and the token hash, the stored approval hash
    and ``sha256(message.text)`` are all equal; else the refusal reason
    (``APPROVAL_MISMATCH`` ...). The first check of every sender and of
    ``Store.mark_sent`` — the single approval gate (VISION hard constraint 1).
    """
    if not isinstance(approval, ApprovalToken):
        return f"{APPROVAL_MISMATCH}: no approval token"
    if message is None or approval.message_id != message.id:
        return f"{APPROVAL_MISMATCH}: token is for another message"
    if message.status != "approved":
        return f"{APPROVAL_MISMATCH}: message is {message.status}, not approved"
    current = text_sha256(message.text)
    if approval.text_sha256 != current or message.text_sha256 != current:
        return APPROVAL_MISMATCH
    return None


@dataclass(frozen=True)
class Message:
    """One row of ``messages``. ``text_sha256`` is the approval hash (None
    while a draft)."""

    id: int
    listing_id: str
    channel: str
    text: str
    language: str
    status: str
    text_sha256: str | None
    created_at: str
    approved_at: str | None
    sent_at: str | None
    error: str | None
    reply_received_at: str | None
    reply_note: str | None

    @property
    def approval_matches_text(self) -> bool:
        """True when the message is approved and the approval hash is the
        hash of its current text."""
        return (
            self.status == "approved"
            and self.text_sha256 is not None
            and self.text_sha256 == text_sha256(self.text)
        )


_MESSAGE_COLUMNS = (
    "id, listing_id, channel, text, language, status, text_sha256, created_at,"
    " approved_at, sent_at, error, reply_received_at, reply_note"
)


@dataclass(frozen=True)
class Decision:
    """One row of ``decisions``."""

    listing_id: str
    action: str
    reason: str | None
    at: str


@dataclass(frozen=True)
class Event:
    """One row of the append-only ``events`` log."""

    id: int
    at: str
    kind: str
    listing_id: str | None
    data: dict[str, Any]


@dataclass(frozen=True)
class FbGroup:
    """One row of ``fb_groups``. ``listing_ratio`` is None until posts were
    sampled; ``questions`` are the group's entry questions (captured by the
    browser layer; empty until then)."""

    group_id: str
    name: str
    url: str
    member_count: int | None
    privacy: str | None
    status: str
    last_listing_at: str | None
    listing_ratio: float | None
    posts_sampled: int
    discovered_query: str | None
    questions: list[str]
    updated_at: str


_FB_GROUP_COLUMNS = (
    "group_id, name, url, member_count, privacy, status, last_listing_at, listing_ratio,"
    " posts_sampled, discovered_query, questions, updated_at"
)


def _fb_group(row: sqlite3.Row) -> FbGroup:
    data = dict(row)
    data["questions"] = json.loads(data["questions"] or "[]")
    return FbGroup(**data)


@dataclass(frozen=True)
class HealthRow:
    """One row of ``source_health``: the outcome of one source's run."""

    source: str
    at: str
    status: str
    count: int
    message: str
    error_kind: str | None = None  # 'blocked' for a SourceBlocked run (migration 7)


@dataclass(frozen=True)
class SourceAlert:
    """One source-health incident (``source_alerts``): open while
    ``cleared_at`` is None; ``notified_at`` set once it was announced."""

    id: int
    source: str
    kind: str
    reason: str
    opened_at: str
    updated_at: str
    notified_at: str | None
    cleared_at: str | None

    @property
    def is_open(self) -> bool:
        return self.cleared_at is None


_HEALTH_COLUMNS = "source, at, status, count, message, error_kind"
_ALERT_COLUMNS = "id, source, kind, reason, opened_at, updated_at, notified_at, cleared_at"


@dataclass(frozen=True)
class Cooldown:
    """A source skipped by the collector after a block until ``until``
    (UTC ISO); ``level`` = blocks in a row; ``cleared_at`` = the owner's Clear."""

    source: str
    level: int
    until: str
    reason: str
    started_at: str
    cleared_at: str | None

    def active(self, now: datetime | None = None) -> bool:
        """True while the source must be skipped (not cleared, not expired)."""
        moment = now or datetime.now(timezone.utc)
        return self.cleared_at is None and datetime.fromisoformat(self.until) > moment


_COOLDOWN_COLUMNS = "source, level, until, reason, started_at, cleared_at"


class Store:
    """SQLite-backed store. ``path`` may be a file path or ``":memory:"``.

    One connection is shared across threads (the scheduler thread and the web
    server's worker threads) and every operation holds an internal lock.
    Opening runs any migrations not yet applied.
    """

    def __init__(self, path: Path | str) -> None:
        target = str(path)
        if target != ":memory:":
            Path(target).parent.mkdir(parents=True, exist_ok=True)
        self.path = target
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(target, check_same_thread=False, isolation_level=None)
        self._conn.row_factory = sqlite3.Row
        self._migrate()

    # ------------------------------------------------------------------ setup

    def _migrate(self) -> None:
        with self._lock:
            self._conn.execute("CREATE TABLE IF NOT EXISTS schema_version (version INTEGER NOT NULL)")
            row = self._conn.execute("SELECT version FROM schema_version").fetchone()
            if row is None:
                self._conn.execute("INSERT INTO schema_version (version) VALUES (0)")
                current = 0
            else:
                current = int(row["version"])
            for version in range(current + 1, len(MIGRATIONS) + 1):
                script = MIGRATIONS[version - 1]
                # executescript commits any open transaction first; wrap each
                # migration and its version bump in one explicit transaction.
                self._conn.executescript(
                    f"BEGIN;\n{script}\nUPDATE schema_version SET version = {version};\nCOMMIT;"
                )

    @property
    def schema_version(self) -> int:
        """Number of migrations applied."""
        with self._lock:
            return int(self._conn.execute("SELECT version FROM schema_version").fetchone()[0])

    def close(self) -> None:
        """Close the connection."""
        with self._lock:
            self._conn.close()

    def __enter__(self) -> "Store":
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    # --------------------------------------------------------------- listings

    def upsert_listing(self, listing: Listing) -> bool:
        """Insert or update a listing. Returns True when it was new.

        An existing listing gets its JSON and ``last_seen`` refreshed;
        ``first_seen`` is kept.
        """
        now = utc_now_iso()
        payload = listing.model_dump_json()
        with self._lock:
            exists = self._conn.execute(
                "SELECT 1 FROM listings WHERE id = ?", (listing.id,)
            ).fetchone()
            if exists:
                self._conn.execute(
                    "UPDATE listings SET json = ?, last_seen = ? WHERE id = ?",
                    (payload, now, listing.id),
                )
                return False
            self._conn.execute(
                "INSERT INTO listings (id, source, source_id, json, first_seen, last_seen)"
                " VALUES (?, ?, ?, ?, ?, ?)",
                (listing.id, listing.source, listing.source_id, payload, now, now),
            )
            return True

    def get_listing(self, listing_id: str) -> Listing | None:
        """The listing with this id, or None."""
        with self._lock:
            row = self._conn.execute(
                "SELECT json FROM listings WHERE id = ?", (listing_id,)
            ).fetchone()
        return Listing.model_validate_json(row["json"]) if row else None

    def iter_listings(self) -> Iterator[Listing]:
        """All stored listings, oldest ``first_seen`` first."""
        with self._lock:
            rows = self._conn.execute(
                "SELECT json FROM listings ORDER BY first_seen, id"
            ).fetchall()
        for row in rows:
            yield Listing.model_validate_json(row["json"])

    def undecided_listings(self) -> list[Listing]:
        """Canonical listings whose cluster has no decision, oldest
        ``first_seen`` first. A duplicate (``duplicates`` row) is never
        listed itself, and a decision on ANY member of a cluster (the
        canonical or a duplicate) decides the whole cluster."""
        with self._lock:
            rows = self._conn.execute(
                "SELECT json FROM listings l"
                " WHERE NOT EXISTS (SELECT 1 FROM duplicates x WHERE x.listing_id = l.id)"
                " AND NOT EXISTS (SELECT 1 FROM decisions d WHERE d.listing_id = l.id)"
                " AND NOT EXISTS (SELECT 1 FROM decisions d JOIN duplicates x"
                "   ON d.listing_id = x.listing_id WHERE x.canonical_id = l.id)"
                " ORDER BY first_seen, id"
            ).fetchall()
        return [Listing.model_validate_json(r["json"]) for r in rows]

    def recent_listings(self, since: str) -> list[tuple[Listing, str]]:
        """``(listing, first_seen)`` for every listing last seen at or after
        ``since`` (UTC ISO), oldest ``first_seen`` first (ties by id)."""
        with self._lock:
            rows = self._conn.execute(
                "SELECT json, first_seen FROM listings WHERE last_seen >= ? ORDER BY first_seen, id",
                (since,),
            ).fetchall()
        return [(Listing.model_validate_json(r["json"]), r["first_seen"]) for r in rows]

    # ------------------------------------------------------------- duplicates
    #
    # quality/dedup.py decides; the store holds the links. Canonical = the
    # earliest seen listing of a cluster; the DB refuses chains, self-links
    # and edits (migration 6).

    def link_duplicate(self, listing_id: str, canonical_id: str, reason: str) -> bool:
        """Record ``listing_id`` as a duplicate of ``canonical_id``. False
        (nothing written) when ``listing_id`` is already linked; ``ValueError``
        for a self-link, a chain (either side already on the other side of a
        link) or an unknown listing. Logs ``duplicate_linked``."""
        if listing_id == canonical_id:
            raise ValueError("a listing is never its own duplicate")
        with self._lock:
            if self._conn.execute(
                "SELECT 1 FROM duplicates WHERE listing_id = ?", (listing_id,)
            ).fetchone():
                return False
            try:
                self._conn.execute(
                    "INSERT INTO duplicates (listing_id, canonical_id, reason, at) VALUES (?, ?, ?, ?)",
                    (listing_id, canonical_id, reason, utc_now_iso()),
                )
            except sqlite3.IntegrityError as exc:
                raise ValueError(str(exc)) from exc
            self.log_event("duplicate_linked", listing_id, canonical_id=canonical_id, reason=reason)
            return True

    def duplicate_links(self) -> dict[str, tuple[str, str]]:
        """Every link: duplicate id -> ``(canonical_id, reason)``."""
        with self._lock:
            rows = self._conn.execute(
                "SELECT listing_id, canonical_id, reason FROM duplicates"
            ).fetchall()
        return {r["listing_id"]: (r["canonical_id"], r["reason"]) for r in rows}

    def canonical_of(self, listing_id: str) -> str:
        """The canonical id of the listing's cluster (the id itself when it
        is not a duplicate)."""
        with self._lock:
            row = self._conn.execute(
                "SELECT canonical_id FROM duplicates WHERE listing_id = ?", (listing_id,)
            ).fetchone()
        return row["canonical_id"] if row else listing_id

    def cluster_ids(self, listing_id: str) -> list[str]:
        """Every id in the listing's cluster: the canonical first, then its
        duplicates in link order."""
        canonical = self.canonical_of(listing_id)
        with self._lock:
            rows = self._conn.execute(
                "SELECT listing_id FROM duplicates WHERE canonical_id = ? ORDER BY rowid",
                (canonical,),
            ).fetchall()
        return [canonical] + [r["listing_id"] for r in rows]

    def duplicates_of(self, canonical_id: str) -> list[tuple[Listing, str]]:
        """``(duplicate listing, reason)`` for a canonical, in link order."""
        with self._lock:
            rows = self._conn.execute(
                "SELECT l.json, x.reason FROM duplicates x JOIN listings l ON l.id = x.listing_id"
                " WHERE x.canonical_id = ? ORDER BY x.rowid",
                (canonical_id,),
            ).fetchall()
        return [(Listing.model_validate_json(r["json"]), r["reason"]) for r in rows]

    # -------------------------------------------------------------- decisions

    def record_decision(
        self, listing_id: str, action: DecisionAction, reason: str | None = None
    ) -> Decision:
        """Append a decision (``skip`` / ``save`` / ``interested``) for a listing.

        Raises ``ValueError`` for an unknown action. Decisions are history:
        the latest one per listing is the current state.
        """
        if action not in DECISION_ACTIONS:
            raise ValueError(f"unknown decision action: {action!r}")
        at = utc_now_iso()
        with self._lock:
            self._conn.execute(
                "INSERT INTO decisions (listing_id, action, reason, at) VALUES (?, ?, ?, ?)",
                (listing_id, action, reason, at),
            )
        return Decision(listing_id=listing_id, action=action, reason=reason, at=at)

    def latest_decision(self, listing_id: str) -> Decision | None:
        """The most recent decision for a listing, or None."""
        with self._lock:
            row = self._conn.execute(
                "SELECT listing_id, action, reason, at FROM decisions"
                " WHERE listing_id = ? ORDER BY id DESC LIMIT 1",
                (listing_id,),
            ).fetchone()
        return Decision(**dict(row)) if row else None

    def decision_count(self) -> int:
        """How many decisions were ever recorded (Home: "reviewed a listing")."""
        with self._lock:
            return int(self._conn.execute("SELECT COUNT(*) FROM decisions").fetchone()[0])

    def shortlist(self) -> list[Listing]:
        """Listings whose latest decision is ``save``, most recently saved first."""
        with self._lock:
            rows = self._conn.execute(
                "SELECT l.json FROM listings l"
                " JOIN decisions d ON d.listing_id = l.id"
                " WHERE d.id = (SELECT MAX(id) FROM decisions WHERE listing_id = l.id)"
                " AND d.action = 'save'"
                " ORDER BY d.id DESC"
            ).fetchall()
        return [Listing.model_validate_json(r["json"]) for r in rows]

    # ----------------------------------------------------------------- events

    def log_event(self, kind: str, listing_id: str | None = None, **data: Any) -> Event:
        """Append an event to the log. ``data`` must be JSON-serialisable."""
        at = utc_now_iso()
        payload = json.dumps(data, ensure_ascii=False, default=str)
        with self._lock:
            cur = self._conn.execute(
                "INSERT INTO events (at, kind, listing_id, data) VALUES (?, ?, ?, ?)",
                (at, kind, listing_id, payload),
            )
            event_id = int(cur.lastrowid or 0)
        return Event(id=event_id, at=at, kind=kind, listing_id=listing_id, data=json.loads(payload))

    def events(self, limit: int = 100) -> list[Event]:
        """The most recent ``limit`` events, newest first."""
        with self._lock:
            rows = self._conn.execute(
                "SELECT id, at, kind, listing_id, data FROM events ORDER BY id DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [
            Event(
                id=r["id"],
                at=r["at"],
                kind=r["kind"],
                listing_id=r["listing_id"],
                data=json.loads(r["data"]),
            )
            for r in rows
        ]

    # ----------------------------------------------------------- source health

    def record_health(
        self, source: str, status: HealthStatus, count: int = 0, message: str = "",
        *, error_kind: str | None = None,
    ) -> HealthRow:
        """Record one source run's outcome: ``ok`` (with count), ``empty``
        (zero listings) or ``error`` (with message; ``error_kind="blocked"``
        for a ``SourceBlocked`` run). Raises ``ValueError`` for an unknown
        status or error kind, or an error kind on a non-error row."""
        if status not in HEALTH_STATUSES:
            raise ValueError(f"unknown health status: {status!r}")
        if error_kind is not None and (error_kind not in HEALTH_ERROR_KINDS or status != "error"):
            raise ValueError(f"bad error kind {error_kind!r} for status {status!r}")
        at = utc_now_iso()
        with self._lock:
            self._conn.execute(
                "INSERT INTO source_health (source, at, status, count, message, error_kind)"
                " VALUES (?, ?, ?, ?, ?, ?)",
                (source, at, status, count, message, error_kind),
            )
        return HealthRow(source=source, at=at, status=status, count=count, message=message,
                         error_kind=error_kind)

    def latest_health(self) -> dict[str, HealthRow]:
        """The latest health row per source, keyed by source name."""
        with self._lock:
            rows = self._conn.execute(
                f"SELECT {_HEALTH_COLUMNS} FROM source_health h"
                " WHERE id = (SELECT MAX(id) FROM source_health WHERE source = h.source)"
                " ORDER BY source"
            ).fetchall()
        return {r["source"]: HealthRow(**dict(r)) for r in rows}

    def health_history(self, source: str, limit: int = 10) -> list[HealthRow]:
        """The last ``limit`` health rows of ``source``, newest first."""
        with self._lock:
            rows = self._conn.execute(
                f"SELECT {_HEALTH_COLUMNS} FROM source_health WHERE source = ? ORDER BY id DESC LIMIT ?",
                (source, max(0, int(limit))),
            ).fetchall()
        return [HealthRow(**dict(r)) for r in rows]

    def health_histories(self, limit: int = 10) -> dict[str, list[HealthRow]]:
        """The last ``limit`` health rows of every source (newest first),
        keyed by source name — one query, for ``/health``."""
        with self._lock:
            rows = self._conn.execute(
                f"SELECT {_HEALTH_COLUMNS} FROM (SELECT *, ROW_NUMBER() OVER"
                " (PARTITION BY source ORDER BY id DESC) AS n FROM source_health)"
                " WHERE n <= ? ORDER BY source, id DESC",
                (max(0, int(limit)),),
            ).fetchall()
        out: dict[str, list[HealthRow]] = {}
        for r in rows:
            out.setdefault(r["source"], []).append(HealthRow(**dict(r)))
        return out

    # ---------------------------------------------------------- source alerts

    def _alert_row(self, where: str, params: tuple[Any, ...]) -> SourceAlert | None:
        row = self._conn.execute(f"SELECT {_ALERT_COLUMNS} FROM source_alerts WHERE {where}", params).fetchone()
        return SourceAlert(**dict(row)) if row is not None else None

    def open_alert(self, source: str) -> SourceAlert | None:
        """The open incident of ``source``, if any."""
        with self._lock:
            return self._alert_row("source = ? AND cleared_at IS NULL", (source,))

    def open_alerts(self) -> list[SourceAlert]:
        """Every open incident, by source name."""
        with self._lock:
            rows = self._conn.execute(
                f"SELECT {_ALERT_COLUMNS} FROM source_alerts WHERE cleared_at IS NULL ORDER BY source"
            ).fetchall()
        return [SourceAlert(**dict(r)) for r in rows]

    def raise_alert(self, source: str, kind: str, reason: str) -> tuple[SourceAlert, bool]:
        """Open an incident for ``source`` or, when one is open, refresh its
        kind and reason (the same incident: not announced again). Returns
        ``(alert, opened)``; logs ``source_alert_opened`` for a new one."""
        if kind not in ALERT_KINDS:
            raise ValueError(f"unknown alert kind: {kind!r}")
        now = utc_now_iso()
        with self._lock:
            current = self._alert_row("source = ? AND cleared_at IS NULL", (source,))
            if current is not None:
                self._conn.execute(
                    "UPDATE source_alerts SET kind = ?, reason = ?, updated_at = ? WHERE id = ?",
                    (kind, reason, now, current.id),
                )
                return self._alert_row("id = ?", (current.id,)), False  # type: ignore[return-value]
            cur = self._conn.execute(
                "INSERT INTO source_alerts (source, kind, reason, opened_at, updated_at)"
                " VALUES (?, ?, ?, ?, ?)",
                (source, kind, reason, now, now),
            )
            alert = self._alert_row("id = ?", (cur.lastrowid,))
            self.log_event("source_alert_opened", source=source, alert_kind=kind, reason=reason)
        return alert, True  # type: ignore[return-value]

    def clear_alert(self, source: str, *, by_owner: bool = False) -> SourceAlert | None:
        """Close the open incident of ``source`` (a healthy run, or the owner's
        Dismiss on /health when ``by_owner``); returns it, or None when none
        was open. Logs ``source_alert_cleared`` / ``source_alert_dismissed``."""
        now = utc_now_iso()
        with self._lock:
            current = self._alert_row("source = ? AND cleared_at IS NULL", (source,))
            if current is None:
                return None
            self._conn.execute("UPDATE source_alerts SET cleared_at = ? WHERE id = ?", (now, current.id))
            self.log_event("source_alert_dismissed" if by_owner else "source_alert_cleared",
                           source=source, alert_kind=current.kind)
            return self._alert_row("id = ?", (current.id,))

    def claim_alert_notifications(self) -> list[SourceAlert]:
        """Mark every open, not yet announced incident as notified and return
        them: each incident is claimed once, ever (guarded UPDATE)."""
        now = utc_now_iso()
        claimed: list[SourceAlert] = []
        with self._lock:
            for alert in self.open_alerts():
                if alert.notified_at is not None:
                    continue
                cur = self._conn.execute(
                    "UPDATE source_alerts SET notified_at = ? WHERE id = ? AND notified_at IS NULL",
                    (now, alert.id),
                )
                if cur.rowcount == 1:
                    claimed.append(self._alert_row("id = ?", (alert.id,)))  # type: ignore[arg-type]
        return claimed

    # -------------------------------------------------------- source cooldowns

    def _cooldown_row(self, source: str) -> Cooldown | None:
        row = self._conn.execute(
            f"SELECT {_COOLDOWN_COLUMNS} FROM source_cooldowns WHERE source = ?", (source,)
        ).fetchone()
        return Cooldown(**dict(row)) if row is not None else None

    def get_cooldown(self, source: str) -> Cooldown | None:
        """The cooldown row of ``source`` (active or not), or None."""
        with self._lock:
            return self._cooldown_row(source)

    def active_cooldown(self, source: str, *, now: datetime | None = None) -> Cooldown | None:
        """The cooldown that makes the collector skip ``source`` now, or None."""
        cooldown = self.get_cooldown(source)
        return cooldown if cooldown is not None and cooldown.active(now) else None

    def cooldowns(self) -> list[Cooldown]:
        """Every cooldown row (active, expired or cleared), by source."""
        with self._lock:
            rows = self._conn.execute(
                f"SELECT {_COOLDOWN_COLUMNS} FROM source_cooldowns ORDER BY source"
            ).fetchall()
        return [Cooldown(**dict(r)) for r in rows]

    def start_cooldown(self, source: str, reason: str, *, now: datetime | None = None) -> Cooldown:
        """Record a block of ``source``: one level up from the current row
        (``COOLDOWN_STEPS``: 6 h, then 24 h), skip until now + that step.
        A block during an active cooldown keeps its level (no double count).
        Logs ``source_cooldown_started``."""
        moment = now or datetime.now(timezone.utc)
        with self._lock:
            current = self._cooldown_row(source)
            if current is not None and current.active(moment):
                return current
            level = current.level + 1 if current is not None else 1
            step = COOLDOWN_STEPS[min(level, len(COOLDOWN_STEPS)) - 1]
            until = (moment + step).isoformat(timespec="microseconds")
            started = moment.isoformat(timespec="microseconds")
            self._conn.execute(
                "INSERT INTO source_cooldowns (source, level, until, reason, started_at, cleared_at)"
                " VALUES (?, ?, ?, ?, ?, NULL) ON CONFLICT(source) DO UPDATE SET level = excluded.level,"
                " until = excluded.until, reason = excluded.reason, started_at = excluded.started_at,"
                " cleared_at = NULL",
                (source, level, until, reason[:1000], started),
            )
            self.log_event("source_cooldown_started", source=source, level=level, until=until)
            return self._cooldown_row(source)  # type: ignore[return-value]

    def clear_cooldown(self, source: str) -> Cooldown | None:
        """The owner's Clear on /health: the source runs again at the next
        collection; the level is kept (a new block escalates). None when no
        active cooldown. Logs ``source_cooldown_cleared``."""
        with self._lock:
            current = self._cooldown_row(source)
            if current is None or not current.active():
                return None
            self._conn.execute("UPDATE source_cooldowns SET cleared_at = ? WHERE source = ?",
                               (utc_now_iso(), source))
            self.log_event("source_cooldown_cleared", source=source, level=current.level)
            return self._cooldown_row(source)

    def reset_cooldown(self, source: str) -> bool:
        """A healthy run of ``source``: forget its cooldown (escalation starts
        over). True when a row was removed (logs ``source_cooldown_reset``)."""
        with self._lock:
            cur = self._conn.execute("DELETE FROM source_cooldowns WHERE source = ?", (source,))
            if cur.rowcount:
                self.log_event("source_cooldown_reset", source=source)
            return bool(cur.rowcount)

    # ---------------------------------------------------------- notifications

    def claim_notifications(self, listing_ids: Iterable[str]) -> list[str]:
        """Record each listing as notified; return only the ids that were not
        notified before (in the given order). A listing is claimed once,
        ever — the ``notified`` primary key — so a second run, a restart or a
        concurrent run never notifies it again."""
        now = utc_now_iso()
        claimed: list[str] = []
        with self._lock:
            for listing_id in dict.fromkeys(listing_ids):
                cur = self._conn.execute(
                    "INSERT OR IGNORE INTO notified (listing_id, at) VALUES (?, ?)", (listing_id, now)
                )
                if cur.rowcount == 1:
                    claimed.append(listing_id)
        return claimed

    def is_notified(self, listing_id: str) -> bool:
        """True when the listing has been notified as a new match."""
        with self._lock:
            return self._conn.execute(
                "SELECT 1 FROM notified WHERE listing_id = ?", (listing_id,)
            ).fetchone() is not None

    def unseen_match_count(self) -> int:
        """Notified matches the owner has not viewed yet (the dashboard badge)."""
        with self._lock:
            return int(self._conn.execute(
                "SELECT COUNT(*) FROM notified WHERE seen_at IS NULL"
            ).fetchone()[0])

    def mark_matches_seen(self) -> int:
        """Clear the badge: mark every unseen notified match as seen; returns
        how many were unseen."""
        with self._lock:
            cur = self._conn.execute(
                "UPDATE notified SET seen_at = ? WHERE seen_at IS NULL", (utc_now_iso(),)
            )
            return int(cur.rowcount)

    # -------------------------------------------------------- facebook groups
    #
    # Status: candidate -> approved | rejected (owner); approved ->
    # pending_join -> joined (the joiner, secure-sessions, after an approval
    # record). upsert never touches status; the DB refuses a group born in a
    # status other than candidate and a join of an unapproved group.

    def upsert_fb_group(
        self,
        group_id: str,
        *,
        name: str,
        url: str = "",
        member_count: int | None = None,
        privacy: str | None = None,
        discovered_query: str | None = None,
        last_listing_at: str | None = None,
        listing_ratio: float | None = None,
        posts_sampled: int | None = None,
    ) -> bool:
        """Insert a group as a ``candidate`` or refresh an existing one's
        metadata. Returns True when new. Never changes ``status``; keeps the
        first ``discovered_query``; stats (``last_listing_at``,
        ``listing_ratio``, ``posts_sampled``) and ``member_count`` /
        ``privacy`` are replaced only when given (``posts_sampled`` not None)."""
        if not group_id or not name:
            raise ValueError("a Facebook group needs a group_id and a name")
        now = utc_now_iso()
        with self._lock:
            exists = self._conn.execute(
                "SELECT 1 FROM fb_groups WHERE group_id = ?", (group_id,)
            ).fetchone()
            if exists is None:
                self._conn.execute(
                    f"INSERT INTO fb_groups ({_FB_GROUP_COLUMNS}) VALUES"
                    " (?, ?, ?, ?, ?, 'candidate', ?, ?, ?, ?, '[]', ?)",
                    (group_id, name, url, member_count, privacy, last_listing_at,
                     listing_ratio, posts_sampled or 0, discovered_query, now),
                )
                self.log_event("fb_group_discovered", group_id=group_id, name=name,
                               query=discovered_query)
                return True
            self._conn.execute(
                "UPDATE fb_groups SET name = ?, url = CASE WHEN ? != '' THEN ? ELSE url END,"
                " member_count = COALESCE(?, member_count), privacy = COALESCE(?, privacy),"
                " discovered_query = COALESCE(discovered_query, ?), updated_at = ?"
                " WHERE group_id = ?",
                (name, url, url, member_count, privacy, discovered_query, now, group_id),
            )
            if posts_sampled is not None:
                self._conn.execute(
                    "UPDATE fb_groups SET last_listing_at = ?, listing_ratio = ?, posts_sampled = ?"
                    " WHERE group_id = ?",
                    (last_listing_at, listing_ratio, posts_sampled, group_id),
                )
            return False

    def get_fb_group(self, group_id: str) -> FbGroup | None:
        """The group with this id, or None."""
        with self._lock:
            row = self._conn.execute(
                f"SELECT {_FB_GROUP_COLUMNS} FROM fb_groups WHERE group_id = ?", (group_id,)
            ).fetchone()
        return _fb_group(row) if row else None

    def fb_groups(self, status: str | None = None) -> list[FbGroup]:
        """Every group (or those with ``status``), by name then id."""
        if status is not None and status not in FB_GROUP_STATUSES:
            raise ValueError(f"unknown Facebook group status: {status!r}")
        query = f"SELECT {_FB_GROUP_COLUMNS} FROM fb_groups"
        args: tuple[Any, ...] = ()
        if status is not None:
            query += " WHERE status = ?"
            args = (status,)
        with self._lock:
            rows = self._conn.execute(query + " ORDER BY name, group_id", args).fetchall()
        return [_fb_group(r) for r in rows]

    def set_fb_group_status(self, group_id: str, status: str) -> FbGroup:
        """Change a group's status and log ``fb_group_status``. ``KeyError``
        for an unknown group, ``ValueError`` for an unknown status; the
        database refuses ``pending_join`` / ``joined`` unless the group was
        ``approved`` (``sqlite3.IntegrityError``). Discovery never calls this."""
        if status not in FB_GROUP_STATUSES:
            raise ValueError(f"unknown Facebook group status: {status!r}")
        with self._lock:
            group = self.get_fb_group(group_id)
            if group is None:
                raise KeyError(group_id)
            if group.status != status:
                self._conn.execute(
                    "UPDATE fb_groups SET status = ?, updated_at = ? WHERE group_id = ?",
                    (status, utc_now_iso(), group_id),
                )
                self.log_event("fb_group_status", group_id=group_id, old=group.status, new=status)
            return self.get_fb_group(group_id)  # type: ignore[return-value]

    # --------------------------------------------------------------- messages
    #
    # Life cycle: draft -> approved -> sent | failed; draft/approved ->
    # cancelled; editing an approved message's text returns it to draft and
    # clears the approval. Every change logs an event (BRIEF F8 / §8 "Logged").

    def _message_row(self, message_id: int) -> Message | None:
        row = self._conn.execute(
            f"SELECT {_MESSAGE_COLUMNS} FROM messages WHERE id = ?", (message_id,)
        ).fetchone()
        return Message(**dict(row)) if row else None

    def _require_message(self, message_id: int) -> Message:
        msg = self._message_row(message_id)
        if msg is None:
            raise KeyError(f"no message {message_id}")
        return msg

    def get_message(self, message_id: int) -> Message | None:
        """The message with this id, or None."""
        with self._lock:
            return self._message_row(message_id)

    def create_draft(self, listing_id: str, channel: str, text: str, language: str) -> Message:
        """Store a new unapproved draft for a stored listing; logs ``message_drafted``.

        Raises ``KeyError`` for an unknown listing, ``ValueError`` for empty text.
        """
        if not text.strip():
            raise ValueError("a message needs text")
        now = utc_now_iso()
        with self._lock:
            if self._conn.execute("SELECT 1 FROM listings WHERE id = ?", (listing_id,)).fetchone() is None:
                raise KeyError(f"no listing {listing_id!r}")
            cur = self._conn.execute(
                "INSERT INTO messages (listing_id, channel, text, language, status, created_at)"
                " VALUES (?, ?, ?, ?, 'draft', ?)",
                (listing_id, channel, text, language, now),
            )
            msg = self._require_message(int(cur.lastrowid or 0))
            self.log_event("message_drafted", listing_id, message_id=msg.id, channel=channel,
                           language=language, text=text)
        return msg

    def update_draft_text(self, message_id: int, text: str) -> Message:
        """Replace a message's text. Allowed while ``draft`` or ``approved``;
        a real change to an approved message returns it to ``draft`` and
        clears the approval. Unchanged text is a no-op. Logs ``message_edited``.

        Raises ``MessageStateError`` for any other status, ``ValueError`` for
        empty text.
        """
        if not text.strip():
            raise ValueError("a message needs text")
        with self._lock:
            msg = self._require_message(message_id)
            if msg.status not in OPEN_MESSAGE_STATUSES:
                raise MessageStateError(f"message {message_id} is {msg.status}; only a draft can be edited")
            if text == msg.text:
                return msg
            self._conn.execute(
                "UPDATE messages SET text = ?, status = 'draft', text_sha256 = NULL,"
                " approved_at = NULL WHERE id = ?",
                (text, message_id),
            )
            self.log_event("message_edited", msg.listing_id, message_id=message_id,
                           was=msg.status, approval_cleared=msg.status == "approved", text=text)
            return self._require_message(message_id)

    def approve(self, message_id: int, approved_sha256: str) -> Message:
        """Record the owner's approval of the message's CURRENT text.

        ``approved_sha256`` is the hash of the text the owner approved; it
        must equal ``text_sha256(current text)`` or ``StaleApprovalError`` is
        raised and nothing changes. Only a ``draft`` can be approved
        (re-approving the same text of an ``approved`` message is a no-op).
        Logs ``message_approved``.
        """
        with self._lock:
            msg = self._require_message(message_id)
            current = text_sha256(msg.text)
            if approved_sha256 != current:
                raise StaleApprovalError(
                    f"approval for message {message_id} does not match its current text"
                )
            if msg.status == "approved":
                return msg
            if msg.status != "draft":
                raise MessageStateError(f"message {message_id} is {msg.status}; only a draft can be approved")
            now = utc_now_iso()
            cur = self._conn.execute(
                "UPDATE messages SET status = 'approved', text_sha256 = ?, approved_at = ?"
                " WHERE id = ? AND status = 'draft' AND text = ?",
                (current, now, message_id, msg.text),
            )
            if cur.rowcount != 1:  # changed under us (another process): not approved
                raise ConcurrentChangeError(
                    f"message {message_id} changed while it was being approved; nothing approved"
                )
            self.log_event("message_approved", msg.listing_id, message_id=message_id,
                           text_sha256=current)
            return self._require_message(message_id)

    def approval_for(self, message_id: int) -> ApprovalToken | None:
        """The ``ApprovalToken`` for an ``approved`` message whose approval
        hash matches its current text; ``None`` for anything else (draft,
        edited, sent, failed, cancelled, unknown). The only way to get a token.
        """
        with self._lock:
            msg = self._message_row(message_id)
        if msg is None or not msg.approval_matches_text or msg.text_sha256 is None:
            return None
        return ApprovalToken(msg.id, msg.text_sha256, _key=_TOKEN_KEY)

    def mark_sent(self, message_id: int, approval: ApprovalToken, *, assisted: bool = False) -> Message:
        """Mark an approved message sent. ``approval`` must be the token from
        ``approval_for`` and still match the CURRENT row and text, or
        ``MessageStateError`` and nothing changes. ``assisted`` = the owner
        sent it by hand and confirmed ("I sent it"). If the guarded UPDATE
        changes no row (changed by another process) -> ``ConcurrentChangeError``,
        no event. Logs ``message_sent`` with the text and listing link."""
        with self._lock:
            msg = self._message_row(message_id)
            refusal = check_approval(msg, approval)  # first: the approval gate
            if refusal is not None or msg is None:
                if msg is None:
                    raise KeyError(f"no message {message_id}")
                raise MessageStateError(f"message {message_id}: {refusal}; not sent")
            now = utc_now_iso()
            cur = self._conn.execute(
                "UPDATE messages SET status = 'sent', sent_at = ?, error = NULL"
                " WHERE id = ? AND status = 'approved' AND text_sha256 = ? AND text = ?",
                (now, message_id, approval.text_sha256, msg.text),
            )
            if cur.rowcount != 1:
                raise ConcurrentChangeError(
                    f"message {message_id} changed while it was being marked sent; not marked"
                )
            row = self._conn.execute("SELECT json FROM listings WHERE id = ?", (msg.listing_id,)).fetchone()
            url = Listing.model_validate_json(row["json"]).url if row else None
            self.log_event("message_sent", msg.listing_id, message_id=message_id,
                           channel=msg.channel, url=url, text=msg.text, assisted=assisted)
            return self._require_message(message_id)

    def mark_failed(self, message_id: int, error: str) -> Message:
        """Record that sending an approved message failed. Logs ``message_failed``."""
        with self._lock:
            msg = self._require_message(message_id)
            if msg.status != "approved":
                raise MessageStateError(f"message {message_id} is {msg.status}; only an approved message can fail")
            cur = self._conn.execute(
                "UPDATE messages SET status = 'failed', error = ? WHERE id = ? AND status = 'approved'",
                (error, message_id),
            )
            if cur.rowcount != 1:
                raise ConcurrentChangeError(
                    f"message {message_id} changed while it was being marked failed; not marked"
                )
            self.log_event("message_failed", msg.listing_id, message_id=message_id,
                           channel=msg.channel, error=error)
            return self._require_message(message_id)

    def cancel_message(self, message_id: int) -> Message:
        """Cancel a ``draft`` or ``approved`` message. Logs ``message_cancelled``."""
        with self._lock:
            msg = self._require_message(message_id)
            if msg.status not in OPEN_MESSAGE_STATUSES:
                raise MessageStateError(f"message {message_id} is {msg.status}; it cannot be cancelled")
            self._conn.execute("UPDATE messages SET status = 'cancelled' WHERE id = ?", (message_id,))
            self.log_event("message_cancelled", msg.listing_id, message_id=message_id, was=msg.status)
            return self._require_message(message_id)

    def record_reply(self, message_id: int, note: str = "") -> Message:
        """Record that the landlord replied to a sent message (manual, BRIEF
        §7 "Track"). Logs ``reply_recorded``."""
        with self._lock:
            msg = self._require_message(message_id)
            if msg.status != "sent":
                raise MessageStateError(f"message {message_id} is {msg.status}; only a sent message gets replies")
            now = utc_now_iso()
            self._conn.execute(
                "UPDATE messages SET reply_received_at = ?, reply_note = ? WHERE id = ?",
                (now, note, message_id),
            )
            self.log_event("reply_recorded", msg.listing_id, message_id=message_id, note=note)
            return self._require_message(message_id)

    def messages_for(self, listing_id: str) -> list[Message]:
        """Every message for a listing, newest first."""
        with self._lock:
            rows = self._conn.execute(
                f"SELECT {_MESSAGE_COLUMNS} FROM messages WHERE listing_id = ? ORDER BY id DESC",
                (listing_id,),
            ).fetchall()
        return [Message(**dict(r)) for r in rows]

    def open_message_for(self, listing_id: str) -> Message | None:
        """The newest ``draft`` / ``approved`` message for a listing, or None."""
        return next((m for m in self.messages_for(listing_id) if m.status in OPEN_MESSAGE_STATUSES), None)

    def contacted(self) -> list[tuple[Listing, Message]]:
        """Every sent message with its listing, most recently sent first."""
        with self._lock:
            rows = self._conn.execute(
                f"SELECT l.json AS listing_json, {', '.join('m.' + c.strip() for c in _MESSAGE_COLUMNS.split(','))}"
                " FROM messages m JOIN listings l ON l.id = m.listing_id"
                " WHERE m.status = 'sent' ORDER BY m.sent_at DESC, m.id DESC"
            ).fetchall()
        out = []
        for r in rows:
            data = dict(r)
            listing = Listing.model_validate_json(data.pop("listing_json"))
            out.append((listing, Message(**data)))
        return out

    # ------------------------------------------------- facebook entry answers
    #
    # (migration 5, facebook plan stage 3). One row per group: the answers to
    # its entry questions; ``answers_sha256`` is the APPROVAL — the
    # ``answers_sha256()`` of (group_id, [(question, answer)...]) the owner
    # approved. Any answer change clears it; a change of the group's
    # questions deletes the row; the joiner (secure-sessions) needs
    # ``answers_approval_for`` + ``check_group_answers``.

    def set_fb_group_questions(self, group_id: str, questions: Iterable[str]) -> FbGroup:
        """Store a group's entry questions (captured by the browser layer):
        stripped, blanks dropped, duplicates removed, order kept. A real
        change deletes the group's saved answers (database trigger) and logs
        ``fb_group_questions``. ``KeyError`` for an unknown group."""
        clean = list(dict.fromkeys(q.strip() for q in questions if q and q.strip()))
        payload = json.dumps(clean, ensure_ascii=False)
        with self._lock:
            group = self.get_fb_group(group_id)
            if group is None:
                raise KeyError(group_id)
            if group.questions != clean:
                had_answers = self.group_answers(group_id) is not None
                self._conn.execute(
                    "UPDATE fb_groups SET questions = ?, updated_at = ? WHERE group_id = ?",
                    (payload, utc_now_iso(), group_id),
                )
                self.log_event("fb_group_questions", group_id=group_id, count=len(clean),
                               answers_reset=had_answers)
            return self.get_fb_group(group_id)  # type: ignore[return-value]

    def group_answers(self, group_id: str) -> "GroupAnswers | None":
        """The saved entry answers of a group, or None."""
        with self._lock:
            row = self._conn.execute(
                "SELECT group_id, answers, answers_sha256, approved_at, updated_at"
                " FROM fb_group_answers WHERE group_id = ?", (group_id,)
            ).fetchone()
        return _group_answers(row) if row else None

    def _approved_group_with_questions(self, group_id: str) -> FbGroup:
        group = self.get_fb_group(group_id)
        if group is None:
            raise KeyError(group_id)
        if group.status != "approved":
            raise AnswersStateError(f"group {group_id} is {group.status}; only an approved group's answers are kept")
        if not group.questions:
            raise AnswersStateError(f"group {group_id} has no entry questions")
        return group

    def save_group_answers(self, group_id: str, items: Iterable["AnswerItem"]) -> "GroupAnswers":
        """Save the answers (one ``AnswerItem`` per entry question, in the
        group's question order; answers are stripped, blank allowed). The
        group must be ``approved`` and the questions must be its CURRENT
        questions, else ``AnswersStateError``. Identical answers are a no-op
        (an approval stays); any change clears the approval. Logs
        ``fb_answers_saved`` (count + whether an approval was cleared — never
        the answer text, which may be sensitive)."""
        clean = tuple(AnswerItem(i.question, i.answer.strip(), i.source) for i in items)
        with self._lock:
            group = self._approved_group_with_questions(group_id)
            if [i.question for i in clean] != group.questions:
                raise AnswersStateError(f"the questions of group {group_id} changed; review the answers again")
            payload = _answers_json(clean)
            existing = self.group_answers(group_id)
            now = utc_now_iso()
            if existing is None:
                self._conn.execute(
                    "INSERT INTO fb_group_answers (group_id, answers, updated_at) VALUES (?, ?, ?)",
                    (group_id, payload, now),
                )
            elif _answers_json(existing.items) == payload:
                return existing
            else:
                self._conn.execute(
                    "UPDATE fb_group_answers SET answers = ?, answers_sha256 = NULL, approved_at = NULL,"
                    " updated_at = ? WHERE group_id = ?",
                    (payload, now, group_id),
                )
            self.log_event("fb_answers_saved", group_id=group_id, count=len(clean),
                           approval_cleared=bool(existing and existing.approved))
            return self.group_answers(group_id)  # type: ignore[return-value]

    def approve_group_answers(self, group_id: str, approved_sha256: str) -> "GroupAnswers":
        """Record the owner's approval of a group's CURRENT saved answers.

        ``approved_sha256`` must equal ``answers_sha256(group_id, current
        pairs)`` or ``StaleAnswersApprovalError``; the group must be
        ``approved`` with unchanged questions and every answer non-blank,
        else ``AnswersStateError``. Re-approving the same answers is a no-op.
        The guarded UPDATE repeats the answers: 0 rows -> ``AnswersStateError``
        (changed meanwhile), nothing logged. Logs ``fb_answers_approved``."""
        with self._lock:
            group = self._approved_group_with_questions(group_id)
            saved = self.group_answers(group_id)
            if saved is None:
                raise AnswersStateError(f"group {group_id} has no saved answers")
            if [i.question for i in saved.items] != group.questions:
                raise AnswersStateError(f"the questions of group {group_id} changed; review the answers again")
            if not saved.complete:
                raise AnswersStateError("every entry question needs an answer before approval")
            current = answers_sha256(group_id, saved.pairs)
            if approved_sha256 != current:
                raise StaleAnswersApprovalError(
                    f"approval for group {group_id} does not match its current answers")
            if saved.answers_sha256 == current:
                return saved
            cur = self._conn.execute(
                "UPDATE fb_group_answers SET answers_sha256 = ?, approved_at = ?"
                " WHERE group_id = ? AND answers = ? AND answers_sha256 IS NULL",
                (current, utc_now_iso(), group_id, _answers_json(saved.items)),
            )
            if cur.rowcount != 1:
                raise AnswersStateError(f"the answers of group {group_id} changed while being approved; not approved")
            self.log_event("fb_answers_approved", group_id=group_id, answers_sha256=current)
            return self.group_answers(group_id)  # type: ignore[return-value]

    def answers_approval_for(self, group_id: str) -> "AnswersApprovalToken | None":
        """The ``AnswersApprovalToken`` for a group whose saved answers are
        approved and still valid (``check_answers_approval`` passes); None
        otherwise. The only way to get one."""
        with self._lock:
            group = self.get_fb_group(group_id)
            saved = self.group_answers(group_id)
        if group is None or saved is None or saved.answers_sha256 is None:
            return None
        token = AnswersApprovalToken(group_id, saved.answers_sha256, _key=_ANSWERS_TOKEN_KEY)
        return token if check_answers_approval(group, saved, token) is None else None

    def check_group_answers(self, group_id: str, approval: object) -> str | None:
        """``check_answers_approval`` against the CURRENT rows: None when
        ``approval`` still covers exactly the group's current answers, else
        the refusal reason. The joiner's first check."""
        with self._lock:
            return check_answers_approval(self.get_fb_group(group_id), self.group_answers(group_id), approval)


# ------------------------------------------------- facebook entry answers


class AnswersStateError(ValueError):
    """An entry-answers operation the group's or the answers' state forbids."""


class StaleAnswersApprovalError(AnswersStateError):
    """An approval hash that does not match the group's CURRENT answers."""


@dataclass(frozen=True)
class AnswerItem:
    """One entry question with its answer. ``source``: ``fact`` /
    ``remembered`` / ``needs_input`` (drafted) or ``owner`` (typed/edited)."""

    question: str
    answer: str
    source: str = "owner"


@dataclass(frozen=True)
class GroupAnswers:
    """One row of ``fb_group_answers``. ``answers_sha256`` is the approval
    (None while unapproved)."""

    group_id: str
    items: tuple[AnswerItem, ...]
    answers_sha256: str | None
    approved_at: str | None
    updated_at: str

    @property
    def pairs(self) -> list[tuple[str, str]]:
        return [(i.question, i.answer) for i in self.items]

    @property
    def complete(self) -> bool:
        """Every question has a non-blank answer."""
        return bool(self.items) and all(i.answer.strip() for i in self.items)

    @property
    def approved(self) -> bool:
        return self.answers_sha256 is not None


ANSWERS_HASH_VERSION = "house-finder/fb-entry-answers/v1"


def answers_sha256(group_id: str, pairs: Iterable[tuple[str, str]]) -> str:
    """The hash an entry-answers approval binds: sha256 of the canonical
    JSON ``[version, group_id, [[question, answer], ...]]`` (UTF-8, no
    whitespace, order kept). Any change to the group, a question, an answer
    or their order changes it."""
    payload = json.dumps([ANSWERS_HASH_VERSION, group_id, [[q, a] for q, a in pairs]],
                         ensure_ascii=False, separators=(",", ":"))
    return text_sha256(payload)


def _answers_json(items: Iterable[AnswerItem]) -> str:
    return json.dumps([{"question": i.question, "answer": i.answer, "source": i.source} for i in items],
                      ensure_ascii=False, sort_keys=True)


def _group_answers(row: sqlite3.Row) -> GroupAnswers:
    data = dict(row)
    items = tuple(AnswerItem(str(d["question"]), str(d["answer"]), str(d.get("source", "owner")))
                  for d in json.loads(data.pop("answers")))
    return GroupAnswers(items=items, **data)


# Only ``Store.answers_approval_for`` holds this, so only it can build a token.
_ANSWERS_TOKEN_KEY = object()


class AnswersApprovalToken:
    """Proof that group ``group_id``'s entry answers whose
    ``answers_sha256`` is ``answers_sha256`` were approved by the owner.

    Built only by ``Store.answers_approval_for()`` (any other construction
    raises ``TypeError``); immutable; cannot be copied or pickled. Never
    trusted alone: the joiner re-checks it with ``Store.check_group_answers``
    right before submitting, and submits exactly ``GroupAnswers.pairs``."""

    __slots__ = ("group_id", "answers_sha256")
    group_id: str
    answers_sha256: str

    def __init__(self, group_id: str, answers_sha256: str, *, _key: object = None) -> None:
        if _key is not _ANSWERS_TOKEN_KEY:
            raise TypeError("an AnswersApprovalToken is issued only by Store.answers_approval_for()")
        object.__setattr__(self, "group_id", group_id)
        object.__setattr__(self, "answers_sha256", answers_sha256)

    def __setattr__(self, name: str, value: object) -> None:
        raise AttributeError("AnswersApprovalToken is immutable")

    def __delattr__(self, name: str) -> None:
        raise AttributeError("AnswersApprovalToken is immutable")

    def __reduce__(self) -> object:
        raise TypeError("an AnswersApprovalToken cannot be pickled or copied")

    def __repr__(self) -> str:
        return f"AnswersApprovalToken(group_id={self.group_id!r}, answers_sha256={self.answers_sha256[:12]}...)"

    def __eq__(self, other: object) -> bool:
        return (isinstance(other, AnswersApprovalToken) and other.group_id == self.group_id
                and other.answers_sha256 == self.answers_sha256)

    def __hash__(self) -> int:
        return hash((self.group_id, self.answers_sha256))


def check_answers_approval(group: FbGroup | None, answers: GroupAnswers | None, approval: object) -> str | None:
    """None when ``approval`` is a real ``AnswersApprovalToken`` for this
    group, the group is ``approved``, the saved answers answer exactly its
    current questions, none is blank, and the token hash, the stored
    approval hash and ``answers_sha256(current pairs)`` are all equal; else
    the refusal reason (starting with ``APPROVAL_MISMATCH``)."""
    if not isinstance(approval, AnswersApprovalToken):
        return f"{APPROVAL_MISMATCH}: no answers approval token"
    if group is None or answers is None or approval.group_id != group.group_id or answers.group_id != group.group_id:
        return f"{APPROVAL_MISMATCH}: token is for another group"
    if group.status != "approved":
        return f"{APPROVAL_MISMATCH}: group is {group.status}, not approved"
    if answers.answers_sha256 is None:
        return f"{APPROVAL_MISMATCH}: answers are not approved"
    if [i.question for i in answers.items] != group.questions:
        return f"{APPROVAL_MISMATCH}: the group's questions changed"
    if not answers.complete:
        return f"{APPROVAL_MISMATCH}: an answer is blank"
    current = answers_sha256(group.group_id, answers.pairs)
    if approval.answers_sha256 != current or answers.answers_sha256 != current:
        return APPROVAL_MISMATCH
    return None

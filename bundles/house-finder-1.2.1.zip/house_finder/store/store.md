# store — SQLite store

One SQLite file (`config.db_path()`, under the data dir) holding listings,
decisions, the append-only event log, source health and messages with their
approval records, Facebook groups with their entry answers + approval
records, and cross-source duplicate links. Stdlib `sqlite3`.

## Code Files

- `db.py` — `Store`, `MIGRATIONS`, `Cooldown`, `COOLDOWN_STEPS`, `HEALTH_ERROR_KINDS`, `ALERT_KINDS`, row types `SourceAlert` / `Decision` / `Event` / `HealthRow` / `Message` / `FbGroup` / `GroupAnswers` / `AnswerItem`, `AnswersApprovalToken`, `check_answers_approval()`, `answers_sha256()`, `ANSWERS_HASH_VERSION`, `AnswersStateError`, `StaleAnswersApprovalError`, `FB_GROUP_STATUSES`, `ApprovalToken`, `check_approval()`, `APPROVAL_MISMATCH`, `utc_now_iso()`, `text_sha256()`, `MessageStateError`, `StaleApprovalError`, `ConcurrentChangeError`, `MESSAGE_STATUSES`, `OPEN_MESSAGE_STATUSES`
- `__init__.py` — re-exports the above

## Schema

| Table | Columns |
|---|---|
| `schema_version` | `version` (number of migrations applied; one row) |
| `listings` | `id` PK (`source:source_id`), `source`, `source_id`, `json` (the `Listing`), `first_seen`, `last_seen` |
| `decisions` | `id`, `listing_id`, `action` (`skip`/`save`/`interested`), `reason`, `at` |
| `events` | `id`, `at`, `kind`, `listing_id?`, `data` (JSON) — append-only |
| `source_health` | `id`, `source`, `at`, `status` (`ok`/`error`/`empty`), `count`, `message`, `error_kind` (migration 7: `blocked` or NULL) |
| `source_alerts` (migration 7) | `id`, `source`, `kind` (`zero_unexpected`/`consecutive_errors`/`blocked`), `reason`, `opened_at`, `updated_at`, `notified_at` (the announce claim), `cleared_at` (NULL = open) |
| `source_cooldowns` (migration 8) | `source` PK, `level` (blocks in a row since the last healthy run), `until`, `reason`, `started_at`, `cleared_at` (owner's Clear) |
| `notified` (migration 3) | `listing_id` PK, `at` (notified), `seen_at` (NULL until the owner views the review page) |
| `fb_groups` (migration 4) | `group_id` PK, `name`, `url` (safe URL or `''`), `member_count`, `privacy`, `status` (`candidate`/`approved`/`rejected`/`joined`/`pending_join`), `last_listing_at`, `listing_ratio`, `posts_sampled`, `discovered_query`, `questions` (JSON list), `updated_at` |
| `fb_group_answers` (migration 5) | `group_id` PK → `fb_groups`, `answers` (JSON list of `{question, answer, source}`), `answers_sha256` (the **approval**; NULL while unapproved), `approved_at`, `updated_at` |
| `duplicates` (migration 6) | `listing_id` PK (the duplicate), `canonical_id` (the earliest seen listing of the cluster), `reason`, `at` |
| `messages` (migration 2) | `id`, `listing_id`, `channel`, `text`, `language`, `status` (`draft`/`approved`/`sent`/`failed`/`cancelled`), `text_sha256` (the **approval**: sha256 of the approved text; NULL while draft), `created_at`, `approved_at`, `sent_at`, `error`, `reply_received_at`, `reply_note` |

All timestamps are UTC ISO-8601 with microseconds (`2026-10-10T12:00:00.000000+00:00`).

## API (`Store(path)`; `path` may be `":memory:"`)

- `upsert_listing(listing) -> bool` — True when new; existing rows get JSON + `last_seen` refreshed, `first_seen` kept.
- `get_listing(id) -> Listing | None`, `iter_listings()` (oldest first), `recent_listings(since) -> list[(Listing, first_seen)]` (last seen ≥ `since`, oldest first), `undecided_listings() -> list[Listing]` (canonical listings whose cluster — itself and its duplicates — has no decision at all; duplicates are never listed).
- `record_decision(id, action, reason=None) -> Decision`, `latest_decision(id) -> Decision | None`, `decision_count() -> int` (all decisions ever; Home's checklist), `shortlist() -> list[Listing]` (latest decision is `save`, newest first).
- `log_event(kind, listing_id=None, **data) -> Event`, `events(limit=100) -> list[Event]` (newest first).
- `record_health(source, status, count=0, message="", *, error_kind=None) -> HealthRow` (`error_kind` only `blocked`, only on `error`), `latest_health() -> dict[str, HealthRow]`, `health_history(source, limit=10)` (newest first), `health_histories(limit=10) -> dict[source, list[HealthRow]]` (one query, for `/health`).
- `schema_version`, `close()`; usable as a context manager.

### Duplicates (migration 6)

`quality/dedup.py` decides; the store holds the links.

- `link_duplicate(id, canonical_id, reason) -> bool` — False when `id` is already linked; `ValueError` for a self-link, a chain (`canonical_id` is a duplicate, or `id` is a canonical) or an unknown listing. Logs `duplicate_linked`.
- `duplicate_links() -> dict[id, (canonical_id, reason)]`, `canonical_of(id)` (the id itself when not a duplicate), `cluster_ids(id)` (canonical first), `duplicates_of(canonical_id) -> list[(Listing, reason)]`.

### Source alerts (migration 7)

`collector/health.py` decides; the store holds the incidents.

- `raise_alert(source, kind, reason) -> (SourceAlert, opened)` — opens an incident (logs `source_alert_opened`), or refreshes the open one's kind/reason (`opened` False).
- `clear_alert(source, *, by_owner=False) -> SourceAlert | None` — closes the open incident (logs `source_alert_cleared`, or `source_alert_dismissed` when the owner dismissed it).
- `open_alert(source)`, `open_alerts()` (by source).
- `claim_alert_notifications() -> list[SourceAlert]` — sets `notified_at` on open incidents not yet announced (guarded UPDATE) and returns them: each incident is announced once.

### Source cooldowns (migration 8)

The collector decides; the store holds one row per blocked source.

- `start_cooldown(source, reason, *, now=None) -> Cooldown` — level + 1
  (an active cooldown is returned unchanged), `until = now + COOLDOWN_STEPS`
  (6 h for level 1, 24 h after); logs `source_cooldown_started`.
- `active_cooldown(source, *, now=None)`, `get_cooldown(source)`,
  `cooldowns()` (all rows); `Cooldown.active(now)`.
- `clear_cooldown(source)` — the owner's Clear: sets `cleared_at`, keeps the
  level (the next block is 24 h); logs `source_cooldown_cleared`; None when
  nothing is active.
- `reset_cooldown(source) -> bool` — a healthy run deletes the row; logs
  `source_cooldown_reset`.

### Notifications (migration 3)

- `claim_notifications(ids) -> list[str]` — inserts each id into `notified` (`INSERT OR IGNORE`); returns only the ids not notified before, in order. A listing is claimed once, ever.
- `is_notified(id) -> bool`; `unseen_match_count() -> int` (rows with `seen_at` NULL — the badge); `mark_matches_seen() -> int` (sets `seen_at`, returns how many were unseen).

### Facebook groups (migration 4)

- `upsert_fb_group(group_id, *, name, url="", member_count=None, privacy=None, discovered_query=None, last_listing_at=None, listing_ratio=None, posts_sampled=None) -> bool` — new → inserted as `candidate` (logs `fb_group_discovered`); existing → name / non-empty url / given member_count, privacy refreshed, first `discovered_query` kept, stats replaced only when `posts_sampled` is given. **Never changes status.**
- `get_fb_group(id) -> FbGroup | None`, `fb_groups(status=None) -> list[FbGroup]` (by name).
- `set_fb_group_status(id, status) -> FbGroup` — logs `fb_group_status` (old/new); `KeyError` unknown group, `ValueError` unknown status. Owner approve/reject (groups page) and the joiner (secure-sessions) call it; discovery never does.

### Facebook entry answers (migration 5)

Approval binds the exact answers: `answers_sha256(group_id, pairs)` = sha256
of the canonical JSON `["house-finder/fb-entry-answers/v1", group_id,
[[question, answer], ...]]` (UTF-8, no whitespace, order kept). Events never
carry answer text (answers may be sensitive) — only counts and the hash.

- `set_fb_group_questions(id, questions) -> FbGroup` — for the browser layer: stripped, blanks/duplicates dropped; a real change **deletes the group's saved answers** (trigger) and logs `fb_group_questions`. `KeyError` unknown group.
- `group_answers(id) -> GroupAnswers | None` — `items` (`AnswerItem(question, answer, source)`; source `fact`/`remembered`/`needs_input`/`owner`), `pairs`, `complete` (no blank answer), `approved`.
- `save_group_answers(id, items) -> GroupAnswers` — group must be `approved`, items must be its CURRENT questions in order (else `AnswersStateError`); answers stripped, blanks allowed. Identical answers → no-op (approval kept); any change clears the approval. Logs `fb_answers_saved`.
- `approve_group_answers(id, sha) -> GroupAnswers` — `StaleAnswersApprovalError` unless `sha == answers_sha256(id, current pairs)`; `AnswersStateError` for no saved answers, a non-approved group, changed questions or **any blank answer**; guarded UPDATE (0 rows → `AnswersStateError`, nothing logged). Logs `fb_answers_approved`.
- `answers_approval_for(id) -> AnswersApprovalToken | None` — the ONLY source of a token: issued when `check_answers_approval` passes for the current rows.
- `check_group_answers(id, token) -> str | None` — `check_answers_approval(group, answers, token)` on the CURRENT rows: real token for this group, group `approved`, answers approved, questions unchanged, none blank, token hash = stored hash = hash of current pairs; else the refusal reason (starts with `APPROVAL_MISMATCH`). **The joiner (secure-sessions) must call it right before submitting, and submit exactly `group_answers(id).pairs`.**

### Messages

Every call logs its event (`message_drafted`, `message_edited`,
`message_approved`, `message_sent` — with channel, listing URL and text —
`message_failed`, `message_cancelled`, `reply_recorded`). `KeyError` for an
unknown message; `MessageStateError` for a transition the status forbids.

- `create_draft(listing_id, channel, text, language) -> Message` — status `draft`; unknown listing → `KeyError`, blank text → `ValueError`.
- `update_draft_text(id, text) -> Message` — only `draft` / `approved`; a real change returns the message to `draft` and clears `text_sha256` + `approved_at`; identical text is a no-op.
- `approve(id, approved_sha256) -> Message` — `StaleApprovalError` unless the hash equals `text_sha256(current text)`; only a `draft` (re-approving an `approved` message with the same hash is a no-op).
- `approval_for(id) -> ApprovalToken | None` — the ONLY source of an `ApprovalToken`: issued for an `approved` message whose approval hash matches its current text, else None.
- `mark_sent(id, approval, *, assisted=False)` — first runs `check_approval(row, approval)`: the token must be a real `ApprovalToken` for this message, the row `approved`, and token hash = stored hash = sha256(current text), else `MessageStateError`. `assisted=True` (owner's "I sent it") is logged on `message_sent`. `mark_failed(id, error)` — only from `approved`.
- `approve` / `mark_sent` / `mark_failed` check the guarded UPDATE's `rowcount`: 0 rows (the row changed between the check and the write, e.g. another process) → `ConcurrentChangeError`, no event logged.
- `cancel_message(id)` — from `draft` / `approved`. `record_reply(id, note="")` — only for `sent`.
- `get_message(id)`, `messages_for(listing_id)` (newest first), `open_message_for(listing_id)` (newest `draft`/`approved`), `contacted() -> list[(Listing, Message)]` (sent, newest first).
- `text_sha256(text)` — hex sha256 of the UTF-8 text; `Message.approval_matches_text`.

## Adding a migration

Append a new SQL script to `MIGRATIONS` in `db.py`. **Never edit or reorder
an existing entry** — an owner's database has already applied it. Opening a
`Store` applies every script past the stored `schema_version`, each in its
own transaction together with the version bump.

## Optimizations and Features

- One connection shared across threads (`check_same_thread=False`) guarded by
  an internal `RLock` — the scheduler thread and web worker threads use the
  same `Store`.
- Decisions are history, not state: the latest row per listing is current,
  ordered by autoincrement `id` (not timestamp) so same-microsecond writes
  still order correctly. `undecided_listings` excludes any listing with any
  decision.
- `record_decision` / `record_health` validate the action/status in Python
  and the tables carry matching `CHECK` constraints.
- Each migration runs as `BEGIN; …; UPDATE schema_version; COMMIT;` in one
  `executescript`, so a failed migration leaves the version unchanged.
- **The database itself enforces the approval rules** (migration 2 triggers +
  CHECK), so SQL that bypasses the API still cannot: insert a message that is
  not an unapproved `draft`; move a message to `sent` from anything but
  `approved`; be `approved`/`sent` without a hash and `approved_at`; change
  the text without the same UPDATE returning it to an unapproved `draft`.
- `approve` / `mark_sent` re-read the row under the store lock and the
  UPDATEs repeat the expected status / text / hash in their `WHERE`; a
  0-row UPDATE is a `ConcurrentChangeError` with no event, so the log never
  records a change that did not happen (the lock only covers this process).
- `ApprovalToken` cannot be built outside `approval_for` (a private key),
  is immutable, and refuses copy/pickle; but it is never trusted alone —
  `check_approval` re-compares it with the current row and text.
- No migration in messaging stage 2: the migration-2 triggers already refuse
  `sent` from anything but `approved` and in-place edits of approved text.
- **The database enforces the group rules** (migration 4 triggers): a group
  is inserted only as `candidate`, and `pending_join` / `joined` can only
  follow `approved` (or each other) — no code path, including raw SQL, joins
  a group the owner did not approve (VISION priority 1, BRIEF §9).
- **The database enforces the entry-answer rules** (migration 5 triggers +
  CHECK): answers are inserted unapproved; changing `answers` without
  clearing `answers_sha256` in the same UPDATE is refused; only an
  `approved` group's answers can be approved; a change of a group's
  `questions` deletes its answers; and a group with entry questions cannot
  move from `approved` to `pending_join` / `joined` without an approved
  answers row (a group with no questions keeps the migration-4 rule only).
- `AnswersApprovalToken` mirrors `ApprovalToken`: private construction key,
  immutable, no copy/pickle, and never trusted alone — `check_group_answers`
  recomputes the hash from the current rows.
- **The database enforces the duplicate rules** (migration 6 CHECK +
  triggers): no self-link, no chain (a canonical is never a duplicate and a
  duplicate never a canonical), both listings must exist, and a link is
  never edited.
- A decision on any member of a duplicate cluster decides the cluster
  (`undecided_listings` checks the canonical and its duplicates).
- **One open incident per source** is a partial UNIQUE index
  (`source_alerts(source) WHERE cleared_at IS NULL`); `notified_at` is set by
  a guarded UPDATE, so an incident is announced once across processes.
- Migration 7 back-fills `error_kind='blocked'` on old rows whose message
  starts `blocked: ` (the collector's prefix), so history stays consistent.
- `notified.listing_id` is the PRIMARY KEY, so "notify once" holds in the
  database across restarts and two processes, not just in this process.
- `log_event` serialises `data` with `default=str` (dates, enums) and
  `ensure_ascii=False` (Hebrew stays readable in the DB).

"""``dispatch(store, message_id)`` — the ONE place an approved message is
handed to a sender.

The web "Approve & send" route approves the exact text and then calls this;
``_run_sender`` below holds the only ``sender.send(...)`` call in the
package. The token it passes comes only from ``store.approval_for()``, and
the sender re-checks it against the current text before doing anything.

Outcomes:

- ``refused`` — no matching approval (draft, edited after approval, sent,
  cancelled, unknown) or the sender's gate refused; nothing changes.
- ``sent`` — a sender delivered it (the opt-in browser sender):
  ``store.mark_sent(id, token)``.
- ``needs_owner`` — assisted: the message stays ``approved``, the result
  carries the ``OwnerAction``; the owner sends by hand and confirms with
  "I sent it" (``store.mark_sent(..., assisted=True)``) or "It failed".
- ``failed`` — the sender tried and failed: ``store.mark_failed``.
- ``no_sender`` — no sender registered for the channel / mode; stays
  ``approved`` and the note says so (fail loudly).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

from house_finder.messaging.senders import ASSISTED, NoSenderError, OwnerAction, SenderRegistry, SendResult, channel_for
from house_finder.store import APPROVAL_MISMATCH, MessageStateError

if TYPE_CHECKING:
    from house_finder.profile import OwnerSettings
    from house_finder.store import Store

DispatchStatus = Literal["refused", "sent", "needs_owner", "failed", "no_sender"]


@dataclass(frozen=True)
class DispatchResult:
    """What happened to a dispatched message; ``action`` for ``needs_owner``."""

    status: DispatchStatus
    note: str
    action: OwnerAction | None = None


def _run_sender(
    store: Store, message_id: int, settings: OwnerSettings | None, senders: SenderRegistry | None,
    *, assisted_only: bool = False,
) -> tuple[SendResult | DispatchResult | None, str | None]:
    """Gate + the single ``sender.send`` call. Returns the sender's result
    and its channel, or a ``DispatchResult`` when no sender ran.
    ``assisted_only``: return None instead of calling a non-assisted sender
    (a page reload must never trigger a real send)."""
    approval = store.approval_for(message_id)
    if approval is None:
        return DispatchResult("refused", APPROVAL_MISMATCH), None
    message = store.get_message(message_id)
    listing = store.get_listing(message.listing_id) if message is not None else None
    if message is None or listing is None:
        return DispatchResult("refused", f"{APPROVAL_MISMATCH}: message or listing missing"), None
    try:
        sender = channel_for(listing, settings, senders)
    except NoSenderError as exc:
        return DispatchResult("no_sender", f"Not sent: {exc}. The message stays approved."), message.channel
    if assisted_only and sender.mode != ASSISTED:
        return None, sender.channel
    return sender.send(message, approval), sender.channel


def dispatch(
    store: Store,
    message_id: int,
    *,
    settings: OwnerSettings | None = None,
    senders: SenderRegistry | None = None,
) -> DispatchResult:
    """Hand an approved message to its channel's sender (see module doc).

    Refuses — nothing sent, nothing changed — unless ``store.approval_for``
    issues a token (message ``approved`` and its approval hash matches its
    current text). Logs ``send_assisted`` / ``send_no_sender``; ``mark_sent``
    / ``mark_failed`` log their own events.
    """
    result, channel = _run_sender(store, message_id, settings, senders)
    if result is None:  # only assisted_only returns None; never here
        return DispatchResult("refused", APPROVAL_MISMATCH)
    message = store.get_message(message_id)
    listing_id = message.listing_id if message is not None else None
    if isinstance(result, DispatchResult):
        if result.status == "no_sender":
            store.log_event("send_no_sender", listing_id, message_id=message_id, channel=channel,
                            note=result.note)
        return result
    if result.refused:
        return DispatchResult("refused", result.error or APPROVAL_MISMATCH)
    if result.status == "needs_owner":
        action = result.action
        store.log_event("send_assisted", listing_id, message_id=message_id, channel=channel,
                        open_url=action.open_url if action else None,
                        why_no_open=action.why_no_open if action else None)
        return DispatchResult("needs_owner", "Ready for you to send — then confirm below.", action)
    if result.status == "sent":
        approval = store.approval_for(message_id)
        if approval is None:  # changed after the sender ran: say so, never fake it
            return DispatchResult("failed", "Sent, but the message changed meanwhile; not recorded as sent.")
        try:
            store.mark_sent(message_id, approval)
        except MessageStateError as exc:
            return DispatchResult("failed", f"Sent, but not recorded: {exc}")
        return DispatchResult("sent", "Sent.")
    error = result.error or "sender failed"
    try:
        store.mark_failed(message_id, error)
    except MessageStateError as exc:
        error = f"{error} (not recorded: {exc})"
    return DispatchResult("failed", f"Not sent: {error}")


def pending_action(
    store: Store,
    message_id: int,
    *,
    settings: OwnerSettings | None = None,
    senders: SenderRegistry | None = None,
) -> DispatchResult | None:
    """For re-showing the assisted screen of an ``approved`` message (page
    reload): the same gate and sender as ``dispatch``, but read-only — no
    event, no state change, and only ASSISTED senders are asked (an
    automated sender is never run from a page view). None unless the sender
    answers ``needs_owner`` or there is no sender."""
    result, _ = _run_sender(store, message_id, settings, senders, assisted_only=True)
    if result is None:
        return None
    if isinstance(result, DispatchResult):
        return result if result.status == "no_sender" else None
    if result.status == "needs_owner":
        return DispatchResult("needs_owner", "Ready for you to send — then confirm below.", result.action)
    return None

# messaging — drafts, templates, senders, dispatch

The "I'm interested" message (BRIEF §8, F7): a draft in the listing's
language built only from the listing's facts and the owner's settings, stored
as a `draft`, approved for its exact text by the owner, then handed to the
single dispatch point, which gives it to the channel's sender. The default
senders are **assisted**: they open the right page with the text ready and
the owner sends by hand and confirms "I sent it" (VISION tradeoff "assisted
send"). Opt-in automated Messenger sending (`FacebookBrowserSender`, send
mode `browser`, Facebook only) lives in [browser.md](../browser/browser.md)
and is registered here at startup once the owner has run `fb-login`.

## Code Files

- `language.py` — `detect_language(text) -> "he" | "en"`, `has_letters()`, `HEBREW_SHARE`
- `templates.py` — `DEFAULT_TEMPLATES`, `DETAIL_PHRASES`, `PROPERTY_NOUNS` / `property_noun()`, `PLACEHOLDERS`, `render_template()`, `validate_template()`, `load_templates()` / `save_templates()` (`data/templates.json`), `TemplateError`
- `drafts.py` — `Draft`, `draft_message()`, `listing_language()`, `channel_for_listing()`, `template_values()`, `pick_detail()`, `greeting()`, `format_place/price/rooms()`
- `senders.py` — `Sender` protocol, `SendResult`, `OwnerAction`, `WhatsAppAssistedSender`, `FacebookAssistedSender`, `Yad2AssistedSender` (`ListingPageAssistedSender`), `refusal()` (the gate), `normalize_il_mobile()`, `whatsapp_url()`, `PhoneError`, `SenderRegistry` / `registry` / `default_registry()`, `NoSenderError`, `channel_for()`
- `dispatch.py` — `dispatch(store, message_id, *, settings, senders) -> DispatchResult`: the one call site that hands an approved message to a sender; `pending_action()` (read-only re-show of the assisted screen)
- `__init__.py` — re-exports the above

## Life cycle

```
create_draft ──> draft ──approve(sha256 of current text)──> approved ──dispatch──> sender
                   ^  \                                        |          sent ──> mark_sent(token)
                   |   `─────────── cancel ──> cancelled <──────┤   needs_owner ──> stays approved;
                   `──── update_draft_text (real change) ───────'                   owner: "I sent it" -> mark_sent(token)
                                                                                     owner: "It failed" -> mark_failed
                                                                        failed ──> mark_failed
```

### The approval gate

`ApprovalToken(message_id, text_sha256)` can only be built by
`store.approval_for(message_id)`, which issues one only for an `approved`
row whose approval hash equals the sha256 of its CURRENT text (direct
construction raises `TypeError`; it is immutable and cannot be copied or
pickled). `store.check_approval(message, token)` is the first thing every
sender's `send` and `Store.mark_sent` do: no token / a forged object / a token
for another message / status not `approved` / token hash, stored hash and
`sha256(text)` not all equal → `failed` "approval does not match text" (or
`MessageStateError` in the store), nothing opened, nothing changed.

The store owns the states and the checks (see [store.md](../store/store.md));
the web routes in [web.md](../web/web.md) drive them.

## API

- `detect_language(text)` — Hebrew when Hebrew letters (U+05D0–U+05EA) are
  ≥ 30% of all letters; English otherwise; no letters → `he`.
- `listing_language(listing)` — detection over title + description + street +
  neighborhood + city; only when that has no letters, `listing.language`
  (`he`/`en`); else `he`.
- `channel_for_listing(listing)` — `whatsapp` (contact has a phone),
  `facebook` (source facebook or a Messenger contact), else `listing.source`.
- `channel_for(listing, settings=None, senders=None) -> Sender` — that
  channel name + `settings.send_mode(name)` (default `assisted`) looked up in
  the registry; `NoSenderError` when nothing is registered (e.g. a new
  source).
- `draft_message(listing, settings, *, profile=None, templates=None) -> Draft(text, language, channel, listing_id)`.
  `profile` supplies the wish list for `{detail}`; `templates` defaults to
  `DEFAULT_TEMPLATES` (the web passes `load_templates()`).
- `render_template(template, values)`; `load_templates(path=None)` (missing
  file → defaults; invalid → raises); `save_templates(templates, path=None)`
  (validates, atomic write).
- `dispatch(store, message_id, *, settings=None, senders=None) -> DispatchResult(status, note, action)`:
  `refused` unless `store.approval_for` issues a token (or the sender's gate
  refuses); `needs_owner` (assisted; logs `send_assisted` with the URL; the
  message stays `approved`); `sent` (`mark_sent(id, token)`); `failed`
  (`mark_failed`); `no_sender` (logs `send_no_sender`, stays `approved`).
- `pending_action(store, message_id, ...)` — the same gate and sender for a
  page reload, read-only (no event) and assisted senders only: an automated
  sender is never run from a page view.

### Senders (`senders.py`)

`Sender.send(message, approval: ApprovalToken) -> SendResult(status:
sent|needs_owner|failed, action: OwnerAction?, error?)`. `approval` is
required (no default). `OwnerAction(open_url, open_label, copy_text,
text_in_url, why_no_open)`.

| Channel | Sender | Opens |
|---|---|---|
| `whatsapp` (contact has a phone) | `WhatsAppAssistedSender` | `https://wa.me/972XXXXXXXXX?text=<url-encoded text>`; a number that is not an Israeli mobile → the listing URL, with the reason |
| `facebook` | `FacebookAssistedSender` | the poster's profile URL, else the post URL; text copied |
| `yad2` (no phone) | `Yad2AssistedSender` | the listing URL; text copied |

Every URL goes through `text.safe_url` (http/https only); with none safe,
`open_url` is None and `why_no_open` says why (the text is still offered).

`normalize_il_mobile(raw)` → `9725XXXXXXXX` from `05X-XXXXXXX`, `+972…`,
`972…`, `00972…`, `+972 (0)5X…`, with spaces / dashes / dots / parentheses;
`PhoneError` with the reason for empty, foreign, landline (WhatsApp needs a
mobile), wrong-length or non-numeric input.

`registry` (`SenderRegistry`) maps `(channel, mode)` → factory(listing).
Defaults: `("whatsapp"|"facebook"|"yad2", "assisted")`.
`__main__.facebook_browser` adds `("facebook", "browser")` →
`FacebookBrowserSender` (`browser.register_browser_sender`, `replace=True`)
when the logged-in browser exists; registering an existing key otherwise
raises. `OwnerSettings.SendMode` is `assisted | browser`, `browser` allowed
for `facebook` only; `/settings` offers a mode only when a sender is
registered for it, so `browser` appears after `fb-login`. A saved `browser`
mode with no browser sender registered → `no_sender` (stays approved).
`FacebookBrowserSender` (`facebook` / `browser`) types the exact approved
text into Messenger, reads it back and presses Enter only when it matches
(see browser.md); `sent` → `mark_sent(token)`.

### Template syntax

| Piece | Meaning |
|---|---|
| `{greeting}` | `שלום <contact name>,` / `Hi <contact name>,`; no name → `שלום,` / `Hello,` |
| `{property}` | from `property_type`: room → `החדר` / `the room`, studio → `הסטודיו` / `the studio`, house → `הבית` / `the house`, anything else or unknown → `הדירה` / `the apartment` |
| `{place}` | street + (neighborhood or city), else neighborhood, else city |
| `{price}` | `6,000 ₪` (he) / `₪6,000` (en) |
| `{rooms}` | `3`, `2.5` |
| `{detail}` | the first wish (nice-to-haves, then must-haves, `Attribute` order) the listing states as TRUE, as a phrase from `DETAIL_PHRASES` (balcony → `המרפסת` / `the balcony`) |
| `{name}` | `settings.owner_name` |
| `[ … ]` | optional piece on one line: kept only if every placeholder in it has a value |
| empty placeholder outside `[ ]` | its whole line is dropped |

Unknown placeholders, stray `{`/`}` and unbalanced, nested or multi-line
brackets raise `TemplateError` on load, render and save.

## Optimizations and Features

- **No invented facts** (VISION non-goal): every value comes from the listing,
  the owner's settings or the owner's own wish list; a value the listing does
  not state is empty and the template rules remove the clause / sentence that
  needed it, so no `None`, `₪` without a number, or dangling preposition.
- Values are substituted with one regex pass per piece, so listing text
  containing `{name}` or `[` is never re-read as template syntax, and there is
  no `str.format` attribute access (`{x.__class__}` is rejected).
- Detection beats the source's language hint: yad2 tags every listing `he`;
  an English-written listing still gets an English draft.
- `dispatch` takes its token only from `store.approval_for`, and the sender
  re-checks that token against the message's current text as its first line;
  `mark_sent` checks it again under the store lock. A test parses the package
  (AST) and asserts the single `.send(` call is the one in `dispatch.py`.
- Assisted sends never mark anything sent: the owner's "I sent it" does,
  and only for the text hash the page showed.
- The default Hebrew template avoids gendered words that would have to agree
  with `{property}` (asks whether "the ad" is still relevant), and the
  sign-off is `תודה!` / `Thanks!` on its own line, so an empty owner name
  drops only the name line — no dangling `Thanks,`.
- `channel_for` fails loudly (`NoSenderError` → `no_sender`) for a channel
  without a sender instead of guessing one.
- The owner's templates file is never reset when broken — the message page
  shows the error and no draft is made.

# web — local web UI

FastAPI + Jinja2 server-rendered pages, plain CSS; the only JavaScript is a
small inline script on the message page for the assisted send (copy + open),
one on the updating page (polls `/update/status` across the restart), and an `onerror` on listing photos that removes an image that fails to load. Served by
`house-finder serve` / `house-finder app` on **127.0.0.1 only**. UI text is English; listing text
is rendered with `dir="auto"` so Hebrew reads right-to-left.

## Code Files

- `app.py` — `create_app()`, `FacebookLink` (the current browser + provider, `app.state.facebook`), `default_group_check()`, `APP_MARKER`, `NO_CONNECT_MESSAGE`, `DraftRefused`, the about-me form helpers `bank_to_form()` / `about_me_form_from_request()` / `parse_about_me_form()`, `NO_PROVIDER_MESSAGE`, the profile-form helpers `profile_to_form()` / `form_from_request()` / `parse_profile_form()`, the settings-form helpers `settings_to_form()` / `settings_form_from_request()` / `parse_settings_form()`, `send_channels()`, `SEND_MODES`, `SMTP_SECURITY`, `safe_url()` (re-exported from `house_finder.text`), `normalize_message_text()`, `message_url()`, `UNSAVE_REASON`, `DEFAULT_PORT`
- `guard.py` — `LocalOriginGuard` (ASGI middleware), `local_hosts(port)`
- `jobs.py` — `BackgroundJob` (one job per slot: Facebook = Discover / Join / Connect / Test a group; yad2 = Check yad2; `last(name)` keeps each kind's latest result), `JobState`
- `icons.py` — `icon(name, size)`: constant inline SVG icons (`ICONS`; Lucide-style, `currentColor`), a Jinja global
- `templates/base.html` — layout: left sidebar nav with icons (Home, Review, Saved, Contacted, Facebook groups | My search, About me, Settings, Status, Activity; a scrolling top bar under 800 px), the header (`{% block heading %}`, the "N new matches" badge, the empty `#header-actions` slot / `{% block header_actions %}` holding the **Quit** button (`#quit-form`)), the source-alert banner (open incidents), the update banner (`#update-banner`: "Update available: version X — notes" + **Update now** (`POST /update`), or a link to the new installer when the update needs one), the red source-error banner (sources and `notify:*` channels), the broken-profile banner
- `templates/_listing.html` — one listing's facts (price, place, stats, attribute chips, source link)
- `templates/_flags.html` — a listing's scam warning box (reason + escaped `dir="auto"` evidence) and stale/other notes
- `templates/_macros.html` — `thumb(listing)` (first photo via `safe_url`, or a placeholder) and `statline(listing)`
- `templates/_facebook_connect.html` — the Connect Facebook box (`#facebook-connect`: connected / not connected / logging in…, the button, the last result) on `/groups` and `/settings`
- `templates/_checks.html` — **Checks** on `/health` (`#checks`): Check yad2, Test reading this group (joined-group select), the latest results as escaped `<pre>`
- `templates/updating.html` — the stand-alone "Updating to version X…" page `POST /update` returns; a small inline script polls `/update/status` and opens `/home` once the new version answers (or shows the failure)
- `templates/stopped.html` — the stand-alone "House Finder has stopped" page `POST /quit` returns
- `templates/home.html`, `review.html`, `profile.html`, `shortlist.html`, `message.html`, `contacted.html`, `log.html`, `health.html`, `settings.html`, `groups.html`, `about_me.html` — the pages
- `static/style.css` — the design system (see **Design system** below)
- `__init__.py` — re-exports `create_app`

## API

`create_app(store, profile_path, adapters, scheduler=None, *, port=8765,
allowed_hosts=None, settings_path=None, templates_path=None,
about_me_path=None, group_provider=None, secrets=None, browser=None,
facebook_connect=None, yad2_check=None, group_check=default_group_check,
shutdown=None, updates=None, restart=None) -> FastAPI`.
`adapters` may be a factory (`serve` rebuilds the list per run; `/health`
lists the factory's sources). `browser` is the `FacebookBrowser`
(`fb-login` done): the joiner's session and the `/health` pacer status.
`app.state.jobs` is the Facebook `BackgroundJob`, `app.state.yad2_jobs` the
yad2 one (tests `wait()` on them). `app.state.facebook` (`FacebookLink`)
holds the current browser and group provider: Connect Facebook replaces them,
and `serve`'s adapter factory reads it every run. The runners are injected
(`serve` builds them; tests pass fakes): `facebook_connect(progress,
current_browser) -> (browser, logged_in)` (`__main__.facebook_connector`:
the `fb-login` flow on the app's own visible session, or a visible login
window when there is none / it is hidden, then reopened), `yad2_check(progress)
-> report text` (`__main__.yad2_checker` over the server's client and yad2
browser), `group_check(progress, browser, group_id) -> text`
(`browser.fb_check.check_group`). `shutdown` is stored as
`app.state.shutdown` (`serve` sets `server.should_exit`; tests set a fake).
`updates` is the `updater.UpdateService` (None = updates off; tests pass a
fake with `available` / `error` / `checked_at` / `check()` / `apply(progress)`);
`restart` (`app.state.restart`, set by `serve`) runs after a successful
apply. Routes: `GET /ping` → `{"app": "house-finder", "version": APP_VERSION}`;
`POST /update` (guarded; 409 without an update, for a needs-installer one, or
while one runs) starts the `update` job in `app.state.update_jobs` (apply,
then restart) and returns `updating.html`; `GET /update/status` → `{version,
running, error, progress}`; `POST /update/check` (guarded) checks now and
redirects to `/settings#version`. `/settings` shows "Version X" and **Check
for updates now** (`#version`). Requires [../updater.md](../updater.md).
`secrets` is the `SecretStore` (default: the one next to the settings file;
the bank uses the one next to `about_me_path` — both the data dir in
production). At startup `create_app` runs `secrets.migrate.migrate_plaintext`
(event `secrets_migrated`, names only). Requires
[secrets.md](../secrets/secrets.md). `group_provider` is the
Facebook `PageProvider` "Discover groups" uses (`serve` passes
`__main__.facebook_provider(browser)`: the logged-in browser's provider,
else the dev `FixtureProvider` when `<data>/fb_fixtures/` exists, else
None).
The profile, settings and templates are re-read on every request that uses
them. `allowed_hosts` defaults to `127.0.0.1:<port>` / `localhost:<port>`;
`serve` passes its `--port`. Tests pass `allowed_hosts=("testserver",)` and an
`Origin: http://testserver` header — production never allows `testserver`.

| Route | Does |
|---|---|
| `GET /home` | **Home**, the landing page (brand link, launcher): a big **Find new listings** (`POST /collect`); counts — new matches (`unseen_match_count`), to review (the review queue's length, same `review_queue()` as `/`), saved, contacted + waiting for a reply; a **Getting started** checklist from real state (search has a location · any non-`notify:` health row · `store.decision_count() > 0` · any `joined` Facebook group), each step `data-step` / `data-done`; the last check per source (configured + recorded, `notify:*` left out, active cooldown). **Read-only**: no `shown` event, the badge is not cleared. |
| `GET /` | Review (nav label "Review"): big photo (or a placeholder), price / rooms / size / floor as large stats, requirement chips ordered ✗ missed → ? unknown → ✓ met, flags box above the card, a sticky decision bar (Skip / Save / I’m interested). Ranking:  `quality.rank_clusters(store.undecided_listings(), duplicates, profile)` — one entry per duplicate cluster (the canonical, or its best passing duplicate when the canonical fails); shows the best one — photo, price, place, rooms/sqm/floor/type/move-in/poster, attribute chips, source link, posted time, score, **Also on** (each other cluster member: source, reason, `safe_url` link) — with **Requirements** (hard reasons ✓ met / ✗ missed / ? unknown) and **Score** (ranking reasons with points) listed separately. Logs a `shown` event. Scam / stale flags (`quality.flags_for`, read time) open the card: a scam warning box first, each flag with its reason and evidence; the `shown` event lists the flag kinds. Stale clusters (`quality.stale_flag`) leave the queue unless `settings.show_stale`; the counter says "N more to review · M hidden (fail a requirement) · K stale hidden" with the **Show stale** / **Hide stale listings** toggle. A broken settings file → stale stay hidden, banner. Clears the new-matches badge (`store.mark_matches_seen()`) and says how many arrived. |
| `POST /settings/show-stale` | `show` (`1`/`0`) → `settings.show_stale`, saved; `settings_saved` event; redirect `/`. A broken settings file → 409, never overwritten. |
| `POST /decide` | `listing_id`, `action` (`skip`/`save`/`interested`), `reason` (kept for skip only). Records the decision on that listing — it decides its whole duplicate cluster — logs a `decision` event. Skip/save redirect to `/?done=<action>&id=<id>`; **interested** creates a draft (unless one is open) and redirects to `/listing/<id>/message`; a draft refused by the payment-details guard → 409 message page with the reason, no draft. 400 on unknown action, 404 on unknown listing. |
| `GET /listing/<id>/message` | The listing's flags (same box as the review card, over its duplicate cluster), its facts, the open message (`draft`/`approved`) in an editable `dir="auto"` textarea with channel, language, status, and **Approve & send** / **Save draft** / **Cancel**; earlier messages below. Read-only (never creates a draft). Shows a banner when settings/templates cannot be read. For an `approved` message, the **Send it yourself** panel (below) from `messaging.pending_action()` (no event, assisted senders only). |
| `POST /listing/<id>/message` | Create a new draft when none is open ("Draft a message" after a cancel); 409 when the payment-details guard refuses it. |
| `POST /message/<mid>/approve` | `text`, `base_sha256` (hash of the text the page showed). One click: if the box was edited, the edit is saved first (only if the stored text still hashes to `base_sha256`, else 409 "changed since this page was opened", nothing approved); then `store.approve(mid, sha256(text))`; then `messaging.dispatch(store, mid, settings=…)` — the single send call site — and redirect `?done=<dispatch status>` (`needs_owner` for every assisted channel: the message stays `approved`; `no_sender`, `refused`, `sent`, `failed`). |
| `POST /message/<mid>/sent` | **I sent it**: `sha256` (hash of the text the page showed). Only when `store.approval_for(mid)` issues a token whose hash equals `sha256` → `store.mark_sent(mid, token, assisted=True)`, redirect `?done=marked_sent`; otherwise 409, nothing marked. |
| `POST /message/<mid>/failed` | **It failed**: `sha256` (hash of the text the page showed) + optional `error`. Only when `store.approval_for(mid)` issues a token whose hash equals `sha256` → `mark_failed`, redirect `?done=marked_failed` (the owner can draft again); otherwise 409, nothing marked. |
| `POST /message/<mid>/edit` | `text` → `update_draft_text` (an approved message returns to draft). 409 for a closed message, empty text, or payment details. |
| `POST /message/<mid>/cancel` | Cancel a draft/approved message. |
| `GET /contacted` | Sent messages, newest first: listing facts + link, channel, time, text, and a **Reply received** form (or the recorded reply). |
| `POST /message/<mid>/reply` | `note` → `record_reply` (only for sent; 409 otherwise). |
| `GET/POST /profile` | Edit every `SearchProfile` field. Invalid input → 400, the page shows the errors and the submitted values, **nothing is saved**. Success → `save_profile`, `profile_saved` event, redirect with "Profile saved". |
| `GET /shortlist` | Listings whose latest decision is `save`, each re-evaluated: one that fails the current profile is flagged "No longer matches" with the failed reasons. |
| `POST /unsave` | Records a `skip` with reason `"unsaved"` (see below). |
| `GET /log` | Latest events (`?limit=`, default 200). |
| `GET /health` | Latest health row per source (configured sources that never ran show "never run") with its open alert (kind, reason, since), then **History**: the last `HISTORY_LIMIT` (10) runs per source (`store.health_histories`) — time, status (+ `blocked`), listings, message — expanded for an alerting or failing source; scheduler state, Collect now. **Paused after a block** banner: every active cooldown (source, until, level, reason) with **Clear**; a cooling source's row says "Skipped until …". With a browser: the **Facebook browser** box — today's counts against the caps, min delay, "Stopped for today: <reason>" and the cooldown pause (red when stopped/paused). |
| `POST /health/cooldown/clear` | Form `source` → `store.clear_cooldown` (the source runs at the next collection; the level is kept, so another block pauses 24 h). 404 when none is active; redirect `/health`. Does not clear the pacer's stop-for-today. |
| `POST /health/alerts/dismiss` | Form `source`. The owner closes an open alert (`store.clear_alert(source, by_owner=True)`): an alert otherwise stays open while its source keeps returning nothing or no longer runs (fail loudly, VISION priority 3). 404 when none is open; redirect `/health`. A Dismiss button sits on each alert in the banner on every page. |
| `POST /collect` | `scheduler.trigger_now()` (background; serve's scheduler runs the notify hook) or, without a scheduler, `notify.collect_and_notify` in the request; redirects to `/health?collected=1`. |
| `POST /health/check-yad2` | **Check yad2**: no runner → 503; one running → 409. Else the `check_yad2` job in the yad2 slot (the `check-yad2` report, also written to `<data>/debug/yad2-report.txt`), `check_requested` event, redirect `/health#checks`. `/health` shows the latest report text escaped in a `<pre>` (refreshing every 5 s while a check runs). |
| `POST /health/check-group` | **Test reading this group** (`fb-check`): form `group_id`. No browser → 503; not a `joined` group → 400; a `facebook` cooldown or a Facebook job running → 409. Else the `fb_check` job in the Facebook slot with the app's own browser (stores and sends nothing); `SourceBlocked` → `store.start_cooldown("facebook")`. Result shown under **Checks**. |
| `GET /ping` | `{"app": "house-finder"}` — how `house-finder app` knows the port is ours. |
| `POST /quit` | **Quit**: guard-protected like every POST (same-origin, no other body). `app.state.shutdown` unset → 503; else `quit_requested` event, the hook (uvicorn finishes this response, then exits) and `stopped.html`. |
| `POST /facebook/login` | **Connect Facebook**: form `back` (`/groups` or `/settings`). No runner (no `[facebook]` extra) → 503 `NO_CONNECT_MESSAGE`; a Facebook job running → 409 on `/groups`. Else the `fb_login` job: the runner opens facebook.com in a visible window where the owner logs in by hand (the app never types, sees or stores the password); a new browser replaces `app.state.facebook`; `fb_login` event (`logged_in` only). Redirect `<back>?done=fb_login_started`. `/groups` and `/settings` show "Facebook: connected / not connected / logging in…" (refreshing while logging in) and the last result. |
| `GET /settings` | Owner name, notification channels (dashboard always on; ntfy checkbox + topic URL; email checkbox + SMTP server, port, encryption `starttls`/`ssl`, user name, password, From, To), send mode per sender channel (a select of the modes registered for that channel — `assisted`, plus `browser` for Facebook once `fb-login` was done — and the saved mode), the Hebrew/English templates. The ntfy topic URL and SMTP password are **write-only**: "set" / "not set", an empty password-type box, a "clear" checkbox when set. **Weaker key storage** notice when the key is a file (`key_source() == "file"`). A broken settings/templates file is shown in a banner, never reset (saving the form replaces it); an unreadable secret store is a banner and saving is refused. |
| `POST /settings` | Keeps `show_stale` (set on the review page). Reads the stored topic / password presence first — unreadable store (wrong key, corrupted) → 409, nothing saved. Validates everything; any error → 400 with the errors and the submitted values except the secrets, **nothing saved**: non-https / credential-carrying / topic-less ntfy URL, ntfy on without a URL, email on without server / From / To, email on with a user name but no password stored or typed, a bad port, an encryption other than `starttls`/`ssl`, an address with a line break / list / name, a secret typed AND "clear" ticked, a send mode with no sender registered for that channel (`browser` before `fb-login`, `browser` for anything but Facebook), a template `TemplateError`. An empty secret box keeps the stored value; "clear" removes it. Success → SMTP password set/deleted, `save_templates` (only languages that differ from the defaults; an empty box = default), `save_settings` (topic into the store), `settings_saved` event (channels, `ntfy`, `email`, which secrets were set/cleared — never values), `clear_stale_notify_health`, redirect `?saved=1`. |
| `GET /groups` | **Candidates** table (name + safe link, members, last listing, listing ratio + classification, sampled posts, query) with Approve / Reject; **Discover groups**; **Approved** groups with their entry questions: the saved answers, or drafts from the bank (`answers.draft_answers`, computed, never stored by a GET) — each with its reason, "Needs your input" for `needs_input`, "remember this answer" (not for sensitive questions), **Approve answers** / **Save without approving**, "ready to join" when `store.answers_approval_for` issues a token, and **Join** (enabled with a browser, no job running, no Facebook cooldown) for a ready group or one with no captured questions; other groups (rejected / joined / pending_join — the last with **I'm a member now**). The background job's panel: running (label, last progress line; the page refreshes every 5 s via `<meta refresh>`), failed (the error), Join's result, or the finished discovery report. A Facebook cooldown banner. |
| `POST /groups/discover` | No provider → 503 `NO_PROVIDER_MESSAGE`; broken profile → 500; a job running or a `facebook` cooldown → 409. Else starts `discover_groups(..., progress=)` as the background job and redirects `/groups?done=discover_started`. In the job: logs `fb_discovery` (ok / error / blocked); `SourceBlocked` → `store.start_cooldown("facebook")`. Stores candidates only. |
| `POST /groups/<gid>/join` | The owner's Join click. 409 unless `approved`; 503 without a browser (`NO_BROWSER_MESSAGE`); 409 when the group has questions and no answers token, a job runs, or Facebook cools down. Else `browser.join_group(...)` as the background job (it re-checks everything; new/changed live questions are stored and nothing submitted); `SourceBlocked` → cooldown. Redirect `?done=join_started`. |
| `POST /groups/<gid>/joined` | **I'm a member now**: `pending_join` → `joined` only (else 409), so the group is read from the next run. |
| `POST /groups/<gid>/status` | `action` `approve` / `reject` → `approved` / `rejected`, **only from `candidate`** (else 409); 400 unknown action, 404 unknown group. Only the joiner sets `pending_join` (after submitting approved answers); only the owner's "I'm a member now" (or the joiner seeing membership) sets `joined`. |
| `POST /groups/<gid>/answers/approve` | `answer_<i>`, `remember_<i>`, `base_sha256` (= `answers_sha256` of what the page showed). 409 unless the group is `approved` and the current saved/drafted answers still hash to `base_sha256` (questions or answers changed → nothing saved); 400 when any answer is blank (re-rendered with the typed values, nothing saved); then `save_group_answers` + `approve_group_answers(answers_sha256(submitted))`; ticked owner-typed answers to non-sensitive questions that do not `reveals_sensitive` are appended to the bank's `remembered`. |
| `POST /groups/<gid>/answers` | Save without approving (same 409 check); a changed answer clears an approval. |
| `GET /about-me` | The answer bank: facts (key, label, value, sensitive — the always-sensitive keys shown locked), suggested keys as blank rows, two empty rows; remembered answers with Delete. A sensitive fact (flag or always-sensitive key) is **write-only**: a stored one shows "set" with a read-only key, an empty password-type box (`fact_set_<i>` hidden marker) and "clear"; never its value. A broken file is a banner, never reset; an encrypted file that cannot be decrypted says saving is refused. |
| `POST /about-me` | Loads the current bank first — wrong key / corrupted → 409, nothing saved. Validate everything (bad / duplicate key, value without key) → 400 with errors and the submitted values (sensitive values blanked), nothing saved; else `save_bank` (encrypted) and `about_me_saved` (keys + count only — no values). A blank value drops a fact; on a "set" sensitive row it keeps the stored fact (value and flag; label editable), "clear" removes it, a typed value replaces it. |
| `/static/*` | `style.css`. |

Nav labels are plain English while routes stay: `/shortlist` = **Saved**
(a card grid), `/health` = **Status**, `/log` = **Activity**, `/profile` =
**My search**.

### Design system (`static/style.css`)

Tokens on `:root` (surfaces, text, primary / success / danger / warning with
soft + border variants, radii, shadows), redefined under
`prefers-color-scheme: dark`. Font stack Segoe UI → system → Noto Sans
Hebrew / Arial Hebrew (no web fonts: offline). Components: `.btn` (secondary)
+ `.btn-primary` / `-success` / `-danger` / `-ghost` and sizes `-xs/-sm/-lg/-xl`
(old `btn-save` / `btn-interested` / `btn-skip` / `btn-small` are aliases);
`.card`, `.chip` (`.yes` / `.no`), `.reason-chips li.r-met|r-missed|r-unknown`,
`.status-*` pills, `.banner` (icon + `.banner-body`), `.notice`, `.warn`,
`.empty` states, `.table-wrap` + `.table`, `.field` / `.fields` grids,
`.checks` pill checkboxes, `.switch` toggles, `.savebar` (sticky Save),
`.thumb` / `.photo-placeholder`, Home `.tiles` / `.steps`. Breakpoints:
1100 px (one column), 800 px (sidebar → top bar, 16 px gutter).

### Host / Origin guard (`guard.py`)

`LocalOriginGuard` wraps the whole app, so every route — including any added
later — is covered. 403 when the `Host` header is not an allowed host (DNS
rebinding), and for any method other than GET/HEAD/OPTIONS when `Origin` (or,
if absent, `Referer`) is not `http://<allowed host>`, is `null`, or both are
missing (fail closed; browsers send `Origin` on every POST). GET routes never
change state except logging (`shown`) and clearing the new-matches badge on
`/` (harmless if a foreign page triggers it).

Every page shows a **source-alert banner** while an incident is open
(`store.open_alerts()`, hardening stage 3): source, what happened
(`KIND_LABELS`), the reason and since when — all autoescaped, the reason
`dir="auto"`. It stays until that source's next healthy run (see
[collector.md](../collector/collector.md)).

Every page also shows a red banner when any source's latest health status is
`error` (BRIEF N5) — including a failed notification channel
(`notify:ntfy`, shown on `/health` as "(notification)"), and a banner when the profile file cannot be parsed (the
file is never reset).

### Assisted send panel

After **Approve & send** the page shows: (1) a button that opens the
sender's `open_url` in a new tab (`target="_blank" rel="noopener
noreferrer"`, through `safe_url` again) — WhatsApp (`wa.me` with the text
pre-filled), the Facebook profile/post, or the listing page; when there is no
safe URL the button is absent and the reason is shown; (2) a **Copy text**
button and a read-only `dir="auto"` box holding the approved text; (3) **I
sent it** / **It failed**. Nothing is ever marked sent automatically.

The inline script reads its data only from `data-` attributes (no template
values inside JavaScript). On `?done=needs_owner` it tries to copy the text
(Clipboard API — `127.0.0.1` is a secure context — falling back to
select + `execCommand("copy")`) and to open the tab. **Browsers may block
both without a fresh click** (popup blockers; Firefox/Safari require a user
gesture for the clipboard): then the owner clicks the open button (which also
copies) or **Copy text**, or selects the text in the visible box and presses
Ctrl+C — the page says so. A reload without `?done` does not re-open the tab.

### Un-save

The `decisions` table's CHECK allows only `skip|save|interested`, so un-save
is recorded as `skip` with reason `"unsaved"` (no migration). The listing
leaves the shortlist and does not return to the review queue.

### Profile form

- Numbers are text inputs parsed server-side; empty = no constraint
  (`max_listing_age_days` empty = default 14).
- Reversed ranges are rejected with a visible error: price, rooms, sqm,
  lease (min > max) and move-in (earliest > latest). `SearchProfile` does not
  check these itself.
- Locations are cards (`loc_<field>_<i>` + `loc_count`): city and
  comma-separated neighborhoods; radius km, lat, lon and yad2 code sit in a
  collapsed **Advanced** `<details>` per city. A row with a blank city is
  dropped; two blank "Add a city" cards are always offered.
- Must-have / nice-to-have are two pill checkboxes per `Attribute` row;
  property types pill checkboxes (none = any); agents / ground floor are
  switches; exclusion keywords one per line. Save sits in a sticky bar.

## Optimizations and Features

- **Update without a dead tab**: `POST /update` answers at once and the
  job applies + restarts in the background; the updating page polls
  `/update/status` (connection errors = restarting, keep polling) and opens
  `/home` when the new version answers. The update job has its own slot,
  so it never waits for a Facebook job.

- **One browser per profile**: Connect Facebook reuses the app's own
  visible session; a hidden one is closed before the visible login window
  opens and reopened after. The Facebook slot also serialises it with
  Discover / Join / Test a group, and Check yad2 uses the server's own yad2
  fetcher — never a second Chromium on a profile.
- Check results are kept per job kind (`BackgroundJob.last`), so a later
  Discover does not hide the last group test on `/health`.

- The review queue is one card per duplicate cluster; a decision on any
  member removes the whole cluster, including duplicates linked later.
- Matching runs per request, so a profile save re-ranks the queue at once
  (no stored scores to invalidate).
- `shown` is logged only when a listing is actually rendered on `/` (BRIEF F8).
- Buttons carry `accesskey`s (s / v / i — Alt+key in most browsers) instead
  of a JavaScript keyboard handler.
- Photos load with `referrerpolicy="no-referrer"` and `loading="lazy"`.
- The form keeps the submitted (invalid) values when re-rendered, so the
  owner fixes one field instead of re-typing the form.
- Listing-derived links (`listing.url`, photo URLs) go through the
  `safe_url` filter: only absolute `http`/`https` URLs become `href`/`src`;
  anything else (`javascript:`, `data:`, scheme-relative) renders as "no
  usable link". Listing and message text is autoescaped — never `|safe`.
- **Payment-details guard** (`quality.payment_details_problem`): a new
  draft (an owner template or a listing field could carry an IBAN), an edit
  and an approval are refused with the reason when the text holds an IBAN,
  a card-like number or an account number — the tool never sends payment
  details (VISION hard constraint). A refused draft logs `draft_refused`.
- Scam-flagged listings are shown, never hidden; only stale ones leave the
  queue, and the page says how many.
- Message text from the form is CRLF→LF normalised and trimmed before it is
  compared and hashed, so a browser round-trip of an unchanged draft is not
  an edit.
- `/decide` interested re-uses an open draft instead of piling up new ones.
- The **N new matches** badge (`store.unseen_match_count()`) is in the top
  bar of every page and links to `/`; viewing `/` clears it.
- "It failed" carries the same hash as "I sent it", so a stale tab never
  marks a different (re-approved) text as failed.
- "I sent it" carries the hash of the text the page showed, so a confirmation
  from a stale tab (text edited and re-approved meanwhile) is refused.
- The assisted panel is recomputed on every view through the same approval
  gate, so a reload or a later visit still offers the link and the buttons.
- Group names, questions, queries and failures (untrusted, from Facebook)
  are autoescaped with `dir="auto"`; group links go through `safe_url` and
  open with `rel="noopener noreferrer"`; group ids in form actions are
  percent-encoded (`pathq` filter).
- Entry-answer approval mirrors the message flow: the page posts the hash of
  what it showed, so a stale tab (answers edited, questions re-captured, bank
  changed) never approves answers the owner did not see.
- Answers for a sensitive question are never remembered (no checkbox, and
  the route re-checks), nor is an answer that `reveals_sensitive` (a
  sensitive fact's value, a phone/ID-shaped number, an email), so ID numbers
  etc. are not copied into `about_me.json`.
- The `/about-me` and entry-answer forms are `autocomplete="off"`, so fact
  values and answers stay out of the browser's form history. A broken
  `about_me.json` banner names the problem, never the file's values
  (`load_bank`).
- Secrets (ntfy topic URL, SMTP password, sensitive facts) are write-only:
  `settings_view` / `about_me_view` blank them even when re-rendering a
  submitted form, so a typed secret is never echoed into HTML; inputs are
  `type="password"` with `autocomplete="off"` / `new-password`.
- A store the key cannot read is never overwritten: `/settings` and
  `/about-me` answer 409 instead of saving over it (VISION priority 3).
- `/health` history is one windowed query (`ROW_NUMBER() OVER (PARTITION BY
  source)`), not one query per source.
- `docs_url` / `openapi_url` are disabled: the app is a UI, not an API.
- Discover and Join run off the request in ONE background slot: a second
  start is refused (409), never queued, so Facebook actions never pile up;
  the page refresh is a `<meta>` tag (no JavaScript).
- Every new POST route (`/groups/<gid>/join`, `/joined`,
  `/health/cooldown/clear`) sits behind `LocalOriginGuard` like the rest
  (a test posts them from a foreign origin).
- `review_queue(profile)` is the one side-effect-free queue computation:
  `/` adds the `shown` event and badge clearing, `/home` only counts it.
- Icons are inline SVG from a constant table (`icons.py`), never built from
  request or listing data, so `Markup` is safe; they inherit `currentColor`
  and so follow dark mode without extra assets.
- A listing photo that fails to load (offline, expired) removes itself
  (`onerror`) and the striped `.thumb` background shows instead of a broken
  image icon.
- The sidebar column colour is painted on `.app` (gradient) so it reaches
  the bottom of long pages while the sidebar itself stays sticky.
- Placeholders for later controls: `#header-actions` / `{% block
  header_actions %}` in `base.html`, `{% block facebook_connect %}` in
  `groups.html`, `{% block status_tools %}` in `health.html`.
- A broken profile file is reported in a banner, never replaced: `load()`
  catches the error and the pages render without a profile.

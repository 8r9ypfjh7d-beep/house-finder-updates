"""``BackgroundJob`` — one Facebook browser job at a time, off the request.

"Discover groups" and "Join" take minutes with the ``Pacer``'s human delays,
so the web starts them here and ``/groups`` shows the progress (the page
refreshes itself while a job runs). One slot: a second start while a job
runs is refused, never queued — Facebook actions never pile up. The app
keeps two slots: Facebook (discover, join, connect, test a group — they share
the one browser session) and yad2 (the "Check yad2" report). ``last(name)``
keeps each job kind's latest state, so a check's result stays on the page
after another job ran in the same slot.
"""

from __future__ import annotations

import logging
import threading
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from house_finder.store.db import utc_now_iso

log = logging.getLogger(__name__)


@dataclass
class JobState:
    """A snapshot of the current / last job for the page."""

    name: str
    label: str
    running: bool
    started_at: str
    finished_at: str | None = None
    progress: list[str] = field(default_factory=list)
    result: Any = None
    error: str | None = None


class BackgroundJob:
    """Runs ``fn(progress)`` on a daemon thread; ``state()`` for the page."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._state: JobState | None = None
        self._last: dict[str, JobState] = {}
        self._thread: threading.Thread | None = None

    def start(self, name: str, label: str, fn: Callable[[Callable[[str], None]], Any]) -> bool:
        """Start ``fn`` unless a job runs; False when refused."""
        with self._lock:
            if self._state is not None and self._state.running:
                return False
            state = JobState(name=name, label=label, running=True, started_at=utc_now_iso())
            self._state = state
            self._last[name] = state

        def progress(text: str) -> None:
            with self._lock:
                state.progress = (state.progress + [str(text)])[-20:]

        def run() -> None:
            try:
                result, error = fn(progress), None
            except Exception as exc:  # shown on the page, never lost
                log.warning("background job %s failed: %s", name, exc)
                result, error = None, f"{type(exc).__name__}: {exc}"
            with self._lock:
                state.result, state.error = result, error
                state.finished_at = utc_now_iso()
                state.running = False

        self._thread = threading.Thread(target=run, name=f"job-{name}", daemon=True)
        self._thread.start()
        return True

    def state(self) -> JobState | None:
        """The current or last job (None before the first)."""
        with self._lock:
            return None if self._state is None else _copy(self._state)

    def last(self, name: str) -> JobState | None:
        """The latest job called ``name`` (running or finished), or None."""
        with self._lock:
            s = self._last.get(name)
            return None if s is None else _copy(s)

    def running(self) -> JobState | None:
        """The running job, or None when the slot is free."""
        state = self.state()
        return state if state is not None and state.running else None

    def wait(self, timeout: float | None = None) -> None:
        """Wait for the running job (tests)."""
        thread = self._thread
        if thread is not None:
            thread.join(timeout)


def _copy(s: JobState) -> JobState:
    return JobState(name=s.name, label=s.label, running=s.running, started_at=s.started_at,
                    finished_at=s.finished_at, progress=list(s.progress), result=s.result, error=s.error)

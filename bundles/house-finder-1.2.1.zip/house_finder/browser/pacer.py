"""``Pacer`` — every Facebook page load and action goes through it.

- **Delays**: before every page load, wait until a randomised human delay
  (``min_delay`` .. ``max_delay`` seconds, never under ``MIN_DELAY_FLOOR``
  = 8 s) has passed since the previous one — also across restarts (the
  last load time is persisted).
- **Daily caps** per kind of action (``DEFAULT_CAPS``: 20 group reads,
  5 searches, 5 joins, 10 messages), counted BEFORE the action runs and
  persisted, so a restart or a crash never resets them. A reached cap
  raises ``DailyCapReached`` (a ``SourceError``) before any page is loaded.
- **Stop for the day**: ``stop_for_today(reason)`` (called on any
  checkpoint / captcha / "temporarily blocked" page) makes every later call
  raise ``SourceBlocked`` until the next local day. ``gate`` (optional) is
  asked before every action too: the app passes the store's Facebook
  cooldown, so nothing runs while it is cooling down.

The state lives in a small JSON file (``config.pacer_state_path()``),
re-read before every action so two processes (``serve`` and ``fb-check``)
share the counts. Clock, sleep, randomness and "today" are injectable:
tests never really sleep.
"""

from __future__ import annotations

import json
import logging
import os
import random
import tempfile
import threading
import time
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from typing import Any

from house_finder.sources.base import SourceBlocked, SourceError

log = logging.getLogger(__name__)

MIN_DELAY_FLOOR = 8.0
"""No configuration can make page loads closer than this (VISION priority 1)."""
DEFAULT_MIN_DELAY = MIN_DELAY_FLOOR
DEFAULT_MAX_DELAY = 20.0
GROUP_READ, SEARCH, JOIN, MESSAGE = "group_read", "search", "join", "message"
DEFAULT_CAPS: dict[str, int] = {GROUP_READ: 20, SEARCH: 5, JOIN: 5, MESSAGE: 10}
YAD2_PAGE = "yad2_page"
YAD2_CAPS: dict[str, int] = {YAD2_PAGE: 30}
"""The yad2 browser fallback's own pacer (separate state file): 30 search-page loads a day."""
YAD2_MIN_DELAY = 10.0
"""Seconds between two yad2 browser page loads at least (same as the HTTP interval)."""


class DailyCapReached(SourceError):
    """Today's cap for this kind of browser action is used up (not a block)."""


@dataclass(frozen=True)
class PacerStatus:
    """What ``/health`` shows: today's counts against the caps, and the
    stop-for-the-day reason (None while running)."""

    day: str
    counts: dict[str, int]
    caps: dict[str, int]
    stopped_reason: str | None = None
    stopped_at: str | None = None
    gate_reason: str | None = None
    min_delay: float = DEFAULT_MIN_DELAY
    max_delay: float = DEFAULT_MAX_DELAY
    extra: dict[str, Any] = field(default_factory=dict)


class Pacer:
    """Delays, daily caps and stop-for-the-day for one browser profile.

    ``base_caps`` is the set of action kinds (default: Facebook's
    ``DEFAULT_CAPS``; the yad2 fallback passes ``YAD2_CAPS``) and ``caps``
    overrides some of them; ``label`` names the site in messages.
    """

    def __init__(
        self,
        state_path: Path | str,
        *,
        min_delay: float = DEFAULT_MIN_DELAY,
        max_delay: float = DEFAULT_MAX_DELAY,
        caps: Mapping[str, int] | None = None,
        gate: Callable[[], str | None] | None = None,
        clock: Callable[[], float] = time.time,
        sleep: Callable[[float], None] = time.sleep,
        rng: Callable[[], float] = random.random,
        today: Callable[[], date] = date.today,
        base_caps: Mapping[str, int] = DEFAULT_CAPS,
        label: str = "Facebook",
    ) -> None:
        if min_delay < MIN_DELAY_FLOOR:
            raise ValueError(f"min_delay must be at least {MIN_DELAY_FLOOR:g} s")
        if max_delay < min_delay:
            raise ValueError("max_delay must be >= min_delay")
        self.state_path = Path(state_path)
        self.min_delay = float(min_delay)
        self.max_delay = float(max_delay)
        self.caps = {**dict(base_caps), **dict(caps or {})}
        self.label = label
        self.gate = gate
        self._clock = clock
        self._sleep = sleep
        self._rng = rng
        self._today = today
        self._lock = threading.RLock()

    # ------------------------------------------------------------- state file

    def _load(self) -> dict[str, Any]:
        """Today's state; a new day starts with zero counts and no stop. An
        unreadable file is NOT reset to zero counts silently: it raises."""
        day = self._today().isoformat()
        try:
            raw = json.loads(self.state_path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            raw = {}
        except (OSError, ValueError) as exc:
            raise SourceError(f"pacer state {self.state_path.name} cannot be read: {exc}") from None
        if not isinstance(raw, dict):
            raise SourceError(f"pacer state {self.state_path.name} is not a JSON object")
        state = {"day": day, "counts": {}, "stopped": None, "last_load": raw.get("last_load")}
        if raw.get("day") == day:
            state["counts"] = {str(k): int(v) for k, v in dict(raw.get("counts") or {}).items()}
            state["stopped"] = raw.get("stopped")
        return state

    def _save(self, state: dict[str, Any]) -> None:
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(prefix=f".{self.state_path.name}.", suffix=".tmp", dir=self.state_path.parent)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump(state, fh)
            os.replace(tmp, self.state_path)
        except BaseException:
            Path(tmp).unlink(missing_ok=True)
            raise

    # ---------------------------------------------------------------- checks

    def _refuse_if_stopped(self, state: dict[str, Any]) -> None:
        stopped = state.get("stopped")
        if stopped:
            raise SourceBlocked(f"{self.label} actions stopped for today: {stopped.get('reason', '')}")
        if self.gate is not None:
            reason = self.gate()
            if reason:
                raise SourceBlocked(f"{self.label} actions paused: {reason}")

    def check(self) -> None:
        """Raise ``SourceBlocked`` when stopped for today or the gate refuses."""
        with self._lock:
            self._refuse_if_stopped(self._load())

    def begin(self, kind: str) -> int:
        """Count one ``kind`` action (cap checked and persisted BEFORE it
        runs); returns today's count including this one. Raises
        ``SourceBlocked`` when stopped / gated, ``DailyCapReached`` at the cap."""
        if kind not in self.caps:
            raise ValueError(f"unknown {self.label} action kind {kind!r}")
        with self._lock:
            state = self._load()
            self._refuse_if_stopped(state)
            used = state["counts"].get(kind, 0)
            if used >= self.caps[kind]:
                raise DailyCapReached(f"daily cap reached: {used}/{self.caps[kind]} {kind.replace('_', ' ')}s today")
            state["counts"][kind] = used + 1
            self._save(state)
            return used + 1

    def page(self) -> None:
        """Wait out the human delay since the previous page load, then record
        this one. Call it before EVERY navigation / scroll that loads content."""
        with self._lock:
            state = self._load()
            self._refuse_if_stopped(state)
            wait = self.min_delay + (self.max_delay - self.min_delay) * self._rng()
            last = state.get("last_load")
            if isinstance(last, (int, float)):
                remaining = wait - (self._clock() - float(last))
                if remaining > 0:
                    self._sleep(remaining)
            state["last_load"] = self._clock()
            self._save(state)

    def stop_for_today(self, reason: str) -> None:
        """Stop every Facebook action until tomorrow (a checkpoint, captcha or
        "temporarily blocked" page was seen). Logged loudly."""
        with self._lock:
            state = self._load()
            if not state.get("stopped"):
                state["stopped"] = {"reason": reason[:500], "at": self._clock()}
                self._save(state)
            log.error("%s actions stopped for today: %s", self.label, reason)

    def status(self) -> PacerStatus:
        """Today's counts, caps and stop reason (for ``/health`` and the CLI)."""
        with self._lock:
            try:
                state = self._load()
            except SourceError as exc:
                return PacerStatus(day=self._today().isoformat(), counts={}, caps=dict(self.caps),
                                   stopped_reason=str(exc))
        stopped = state.get("stopped") or {}
        gate_reason = None
        if self.gate is not None:
            try:
                gate_reason = self.gate()
            except Exception as exc:  # status must render
                gate_reason = f"cannot check: {exc}"
        return PacerStatus(day=state["day"], counts=dict(state["counts"]), caps=dict(self.caps),
                           stopped_reason=stopped.get("reason"), stopped_at=_fmt_epoch(stopped.get("at")),
                           gate_reason=gate_reason, min_delay=self.min_delay, max_delay=self.max_delay)


def _fmt_epoch(value: Any) -> str | None:
    if not isinstance(value, (int, float)):
        return None
    from datetime import datetime, timezone

    return datetime.fromtimestamp(float(value), timezone.utc).isoformat()

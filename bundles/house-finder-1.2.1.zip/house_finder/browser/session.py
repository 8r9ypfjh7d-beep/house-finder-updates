"""``BrowserSession`` — the one persistent Chromium context Facebook is used through.

- Persistent profile in ``data/browser-profile/`` (``config.browser_profile_dir()``):
  Facebook's cookies live there, never in the SQLite file or the code. On
  Windows Chromium encrypts its cookie store with DPAPI (the N3 mechanism for
  session data); see ``browser.md`` for other systems.
- **The tool never sees the password**: ``fb_login`` opens a headed window on
  facebook.com and only waits until the owner has logged in by hand (the
  ``c_user`` cookie appears), then writes ``.house-finder-login.json`` (time
  only) into the profile. Without that marker no Facebook reader or sender is
  registered.
- Playwright's sync API must stay on the thread that started it, while the
  scheduler and the web workers are different threads: every call runs on
  ONE dedicated worker thread (``call(fn)``), which also serialises all
  Facebook actions.
- ``check_page`` runs after every navigation: a checkpoint / captcha /
  "temporarily blocked" page -> ``pacer.stop_for_today`` + ``SourceBlocked``;
  a login page or a missing session cookie -> ``NotLoggedIn``.

Playwright is the optional ``[facebook]`` extra; this module imports it only
inside the worker thread.
"""

from __future__ import annotations

import importlib.util
import json
import logging
import os
import sys
import time
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any, TypeVar

from house_finder.sources.base import SourceBlocked, SourceError

if TYPE_CHECKING:
    from house_finder.browser.pacer import Pacer

log = logging.getLogger(__name__)

BROWSERS_ENV = "PLAYWRIGHT_BROWSERS_PATH"
T = TypeVar("T")

FACEBOOK_URL = "https://www.facebook.com"
LOGIN_MARKER = ".house-finder-login.json"
SESSION_COOKIE = "c_user"  # Facebook sets it only for a logged-in account
CALL_TIMEOUT = 900.0
NAV_TIMEOUT_MS = 45_000

# Lower-cased texts of pages that mean "stop": a checkpoint, a captcha, a block.
BLOCK_MARKERS: tuple[str, ...] = (
    "you're temporarily blocked",
    "you’re temporarily blocked",
    "temporarily blocked",
    "you can't use this feature right now",
    "you can’t use this feature right now",
    "security check",
    "confirm your identity",
    "we suspended your account",
    "your account has been locked",
    "captcha",
    "נחסמת באופן זמני",
    "חסום באופן זמני",
    "בדיקת אבטחה",
    "אשר את זהותך",
    "אמת את זהותך",
)


class NotLoggedIn(SourceError):
    """The browser profile has no logged-in Facebook session: run ``house-finder fb-login``."""


class BrowserUnavailable(SourceError):
    """Playwright or Chromium is missing, or the browser could not start."""


def playwright_available() -> bool:
    """True when the optional ``playwright`` package is installed."""
    return importlib.util.find_spec("playwright") is not None


# ------------------------------------------------------------ login marker


def login_info(profile_dir: Path | str) -> dict[str, Any] | None:
    """The marker ``fb_login`` wrote (``{"logged_in_at": ...}``), or None."""
    try:
        data = json.loads((Path(profile_dir) / LOGIN_MARKER).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return data if isinstance(data, dict) else None


def write_login_marker(profile_dir: Path | str) -> Path:
    """Record that the owner logged in (the time only — nothing secret)."""
    path = Path(profile_dir) / LOGIN_MARKER
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"logged_in_at": datetime.now(timezone.utc).isoformat()}), encoding="utf-8")
    return path


# ---------------------------------------------------------------- chromium


def find_chromium(base: Path | str | None = None) -> Path | None:
    """A Chromium executable under ``base`` (default ``$PLAYWRIGHT_BROWSERS_PATH``)
    — for when the installed playwright expects a different browser build than
    the one present. None when nothing is found."""
    raw = str(base) if base is not None else os.environ.get("PLAYWRIGHT_BROWSERS_PATH", "")
    if not raw.strip():
        return None
    root = Path(raw)
    if not root.is_dir():
        return None
    names = ("chrome-linux/chrome", "chrome-linux64/chrome", "chrome-win/chrome.exe", "chrome-win64/chrome.exe",
             "chrome-mac/Chromium.app/Contents/MacOS/Chromium")
    for folder in sorted(root.glob("chromium-*"), reverse=True):
        for name in names:
            candidate = folder / name
            if candidate.is_file():
                return candidate
    return None


INSTALL_TIMEOUT_S = 840  # under the 900 s browser-call limit, so the caller sees the failure


def install_chromium(run: Callable[..., Any] | None = None) -> None:
    """Download playwright's Chromium (``playwright install chromium``) —
    the installed app does this the first time a browser is needed, so the
    owner never runs a command. Blocks (a few minutes, ~150 MB); no console
    window on Windows. Raises ``BrowserUnavailable`` when it fails."""
    import subprocess

    from playwright._impl._driver import compute_driver_executable, get_driver_env

    driver = compute_driver_executable()
    cmd = [*driver, "install", "chromium"] if isinstance(driver, tuple) else [str(driver), "install", "chromium"]
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    log.info("downloading the browser (Chromium) once; this takes a few minutes")
    try:
        result = (run or subprocess.run)(
            cmd, env=get_driver_env(), capture_output=True, text=True,
            timeout=INSTALL_TIMEOUT_S, creationflags=flags,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        raise BrowserUnavailable(f"the browser could not be downloaded: {exc}") from None
    if result.returncode != 0:
        lines = [ln.strip() for ln in (result.stderr or result.stdout or "").splitlines() if ln.strip()]
        errors = [ln for ln in lines if ln.startswith("Error")]  # not the stack-trace "at …" lines
        detail = (errors[0] if errors else lines[-1] if lines else "no output")[:300]
        raise BrowserUnavailable(f"the browser could not be downloaded: {detail}")
    log.info("browser downloaded")


def chromium_executable(pw: Any) -> Path:
    """The Chromium this playwright launches (it may not exist yet)."""
    return Path(pw.chromium.executable_path)


def ensure_chromium(pw: Any = None, install: Callable[[], None] | None = None) -> None:
    """Download Chromium unless the one playwright will launch is present;
    ``BrowserUnavailable`` when it is still missing afterwards (the download
    went somewhere the launch does not look)."""
    own = pw is None
    if own:
        from playwright.sync_api import sync_playwright

        pw = sync_playwright().start()
    try:
        exe = chromium_executable(pw)
        if exe.exists():
            return
        (install or install_chromium)()
        if not exe.exists():
            raise BrowserUnavailable(
                f"the browser was downloaded but is not where it is started from ({exe}); "
                f"{BROWSERS_ENV}={os.environ.get(BROWSERS_ENV, '(unset)')}"
            )
    finally:
        if own:
            pw.stop()


def launch_check() -> None:
    """Start and close a headless Chromium (``install-browser``'s proof)."""
    from playwright.sync_api import Error as PlaywrightError
    from playwright.sync_api import sync_playwright

    with sync_playwright() as pw:
        try:
            pw.chromium.launch(headless=True).close()
        except PlaywrightError as exc:
            raise BrowserUnavailable(f"the browser does not start: {str(exc).splitlines()[0]}") from None


def has_session_cookie(context: Any, base_url: str) -> bool:
    """True when the context holds Facebook's logged-in cookie for ``base_url``."""
    try:
        return any(c.get("name") == SESSION_COOKIE and c.get("value") for c in context.cookies(base_url))
    except Exception:  # a closed / broken context is not logged in
        return False


# --------------------------------------------------------------- page check

_PAGE_STATE_JS = """
() => {
  const body = document.body ? document.body.innerText || "" : "";
  const dialogs = Array.from(document.querySelectorAll('[role="dialog"], [role="alertdialog"]'))
    .map(d => d.innerText || "").join("\\n");
  return {
    hasFeed: !!document.querySelector('[role="feed"]'),
    captcha: !!document.querySelector('iframe[src*="captcha" i], [id*="captcha" i]'),
    dialogText: dialogs.slice(0, 5000),
    bodyText: body.slice(0, 5000),
    hasPasswordBox: !!document.querySelector('input[type="password"]'),
  };
}
"""


def block_reason(url: str, state: dict[str, Any]) -> str | None:
    """Why a page means "stop" (checkpoint URL, captcha, block text), or None.
    Text markers are searched in dialogs always, and in the page body only
    when there is no feed — a rental post that happens to say "captcha" must
    not stop the day."""
    path = url.split("?", 1)[0].lower()
    if "/checkpoint" in path:
        return f"checkpoint page ({path})"
    if state.get("captcha"):
        return "captcha on the page"
    texts = [str(state.get("dialogText") or "")]
    if not state.get("hasFeed"):
        texts.append(str(state.get("bodyText") or ""))
    lowered = "\n".join(texts).lower()
    for marker in BLOCK_MARKERS:
        if marker in lowered:
            return f"page says {marker!r}"
    return None


def check_page(page: Any, *, base_url: str, pacer: Pacer) -> dict[str, Any]:
    """After a navigation: stop for the day on a block page (``SourceBlocked``),
    ``NotLoggedIn`` on a login page / missing session. Returns the page state."""
    state = page.evaluate(_PAGE_STATE_JS)
    reason = block_reason(page.url, state)
    if reason is not None:
        pacer.stop_for_today(reason)
        raise SourceBlocked(f"Facebook: {reason}; stopped for today")
    path = page.url.split("?", 1)[0].lower()
    if "/login" in path or (state.get("hasPasswordBox") and not state.get("hasFeed")) \
            or not has_session_cookie(page.context, base_url):
        raise NotLoggedIn("Facebook is not logged in in the tool's browser: press Connect Facebook "
                          "(Groups or Settings; developers: `house-finder fb-login`)")
    return state


# ----------------------------------------------------------------- session


class BrowserSession:
    """One persistent Chromium context on one worker thread.

    ``call(fn)`` runs ``fn(page)`` on the worker thread (launching the
    browser on first use) and returns its result or raises its exception.
    ``headless`` defaults to False: a real, visible browser (VISION
    priority 1, "real browser session"); tests pass True.
    """

    def __init__(
        self,
        profile_dir: Path | str,
        *,
        headless: bool = False,
        base_url: str = FACEBOOK_URL,
        executable_path: Path | str | None = None,
        locale: str = "he-IL",
        thread_name: str = "fb-browser",
    ) -> None:
        self.profile_dir = Path(profile_dir)
        self.headless = headless
        self.base_url = base_url.rstrip("/")
        self.executable_path = str(executable_path) if executable_path else None
        self.locale = locale
        self._executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix=thread_name)
        self._pw: Any = None
        self._context: Any = None
        self._closed = False

    # Runs on the worker thread only.
    def _ensure(self) -> Any:
        if self._context is not None:
            return self._context
        if not playwright_available():
            raise BrowserUnavailable("playwright is not installed: pip install -e \".[facebook]\"")
        from playwright.sync_api import Error as PlaywrightError
        from playwright.sync_api import sync_playwright

        self.profile_dir.mkdir(parents=True, exist_ok=True)
        self._pw = sync_playwright().start()
        if not self.executable_path and find_chromium() is None:
            try:  # first use: fetch the browser instead of asking for a command
                ensure_chromium(self._pw)
            except BrowserUnavailable:
                self._pw.stop()
                self._pw = None
                raise
        options: dict[str, Any] = {"headless": self.headless, "locale": self.locale, "viewport": None}
        if self.executable_path:
            options["executable_path"] = self.executable_path
        try:
            try:
                self._context = self._pw.chromium.launch_persistent_context(str(self.profile_dir), **options)
            except PlaywrightError as exc:
                if "Executable doesn't exist" not in str(exc) or self.executable_path:
                    raise
                fallback = find_chromium()
                if fallback is None:
                    raise
                log.info("using Chromium at %s", fallback)
                options["executable_path"] = str(fallback)
                self._context = self._pw.chromium.launch_persistent_context(str(self.profile_dir), **options)
        except Exception as exc:
            self._pw.stop()
            self._pw = None
            hint = " (is another house-finder or fb-login using the same browser profile?)" \
                if "ProcessSingleton" in str(exc) or "profile" in str(exc).lower() else ""
            raise BrowserUnavailable(f"the browser could not start{hint}: {str(exc).splitlines()[0]}") from None
        self._context.set_default_navigation_timeout(NAV_TIMEOUT_MS)
        return self._context

    def _page(self) -> Any:
        context = self._ensure()
        pages = [p for p in context.pages if not p.is_closed()]
        return pages[0] if pages else context.new_page()

    def _invoke(self, fn: Callable[[Any], T]) -> T:
        return fn(self._page())

    def call(self, fn: Callable[[Any], T], *, timeout: float = CALL_TIMEOUT) -> T:
        """Run ``fn(page)`` on the browser thread; its result or exception."""
        if self._closed:
            raise BrowserUnavailable("the browser session is closed")
        return self._executor.submit(self._invoke, fn).result(timeout)

    def logged_in(self) -> bool:
        """True when the context holds Facebook's session cookie (no page load)."""
        return self.call(lambda page: has_session_cookie(page.context, self.base_url))

    def close(self) -> None:
        """Close the browser and stop the worker thread."""
        if self._closed:
            return

        def shutdown(_: Any = None) -> None:
            try:
                if self._context is not None:
                    self._context.close()
            finally:
                self._context = None
                if self._pw is not None:
                    self._pw.stop()
                    self._pw = None

        try:
            self._executor.submit(shutdown).result(60)
        except Exception:
            log.exception("closing the browser failed")
        self._closed = True
        self._executor.shutdown(wait=False)


def _print(text: str) -> None:
    sys.stdout.write(text + "\n")
    sys.stdout.flush()


def fb_login(
    session: BrowserSession,
    pacer: Pacer,
    *,
    timeout: float = 600.0,
    poll: float = 2.0,
    out: Callable[[str], None] | None = None,
    clock: Callable[[], float] = time.monotonic,
    sleep: Callable[[float], None] = time.sleep,
    raise_window: Callable[[], int] | None = None,
) -> bool:
    """Open facebook.com in the (headed) session and wait until the owner has
    logged in by hand — the code never types anything. Writes the login
    marker and returns True when the session cookie appears; False on timeout.
    The window is brought to the front (``raise_window``, default
    ``winfocus.show_tool_windows``): Windows otherwise opens it behind the
    owner's browser, where it looks as if nothing happened."""
    out = out or _print
    if raise_window is None:
        from house_finder.browser.winfocus import show_tool_windows as raise_window

    def open_home(page: Any) -> bool:
        if has_session_cookie(page.context, session.base_url):
            return True
        pacer.page()
        page.goto(session.base_url + "/", wait_until="domcontentloaded")
        return has_session_cookie(page.context, session.base_url)

    if session.call(open_home):
        write_login_marker(session.profile_dir)
        out("Already logged in to Facebook in the tool's browser.")
        return True
    session.call(lambda page: page.bring_to_front())
    raise_window()
    out("A Facebook window opened: log in there — the tool never sees your password. If you do not see "
        "it, press Show the Facebook window, or click its icon in the taskbar.")
    deadline = clock() + timeout
    while clock() < deadline:
        sleep(poll)
        if session.logged_in():
            write_login_marker(session.profile_dir)
            out("Logged in. You can close this window; the session is kept in the browser profile.")
            return True
    out("Timed out waiting for the login; start it again (Connect Facebook, or `house-finder fb-login`).")
    return False

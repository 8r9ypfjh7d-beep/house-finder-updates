"""``Yad2BrowserFetcher`` — yad2's search page in a real browser, for when
plain HTTP is blocked.

For one city it opens ``https://www.yad2.co.il/realestate/rent?city=…`` with
the profile's filters in its own persistent Chromium profile
(``data/browser-yad2/``, never the Facebook one), records the JSON the page
itself loads from ``gw.yad2.co.il`` (``page.on("response")``) plus
``__NEXT_DATA__`` when present, and hands every body to the existing
``yad2.find_payloads`` / ``parse_response``.

- **Read-only**: one paced navigation per city (``Pacer`` kind
  ``yad2_page``: ≥ 10 s apart, 30 a day); it never clicks, types or scrolls.
- **Captcha** (Radware / perfdrive URL, or a captcha title / text): in a
  VISIBLE window it waits up to ``captcha_wait`` s (default 120) for the
  owner to solve it by hand, re-checking every ``poll`` s; headless or
  unsolved → ``SourceBlocked``. A flat 403 → ``SourceBlocked`` at once.
- **Fail loudly**: no JSON of a known shape → ``SourceError`` naming the
  captured URLs (redacted); never an empty list for a page it did not
  understand. A known shape with zero items is a real empty result.
- No browser / today's cap used up → ``yad2.BrowserFallbackUnavailable``
  (the adapter, whose HTTP is already blocked, reports a block).
"""

from __future__ import annotations

import json
import logging
import time
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any
from urllib.parse import urlencode, urlsplit

from house_finder.browser.pacer import YAD2_CAPS, YAD2_MIN_DELAY, YAD2_PAGE, DailyCapReached, Pacer
from house_finder.browser.session import BrowserSession, BrowserUnavailable, playwright_available
from house_finder.net.http import BOT_VALIDATOR_HOSTS, is_captcha_page
from house_finder.sources.base import SourceBlocked, SourceError
from house_finder.sources.yad2 import SEARCH_URL, BrowserFallbackUnavailable, find_payloads, parse_response
from house_finder.sources.yad2_report import json_shape, redact_url

if TYPE_CHECKING:
    from house_finder.models import Listing
    from house_finder.store import Store

log = logging.getLogger(__name__)

YAD2_BASE_URL = "https://www.yad2.co.il"
YAD2_API_HOSTS: tuple[str, ...] = ("gw.yad2.co.il",)
YAD2_SOURCE = "yad2"
CAPTCHA_MESSAGE = ("yad2: captcha in the browser — solve it in the House Finder browser window, "
                   "or try later")
DEFAULT_CAPTCHA_WAIT = 120.0
DEFAULT_POLL = 2.0
DEFAULT_JSON_WAIT = 20.0
DEFAULT_SETTLE = 1.5
YAD2_MAX_DELAY = 20.0
MAX_BODY_BYTES = 5_000_000
MAX_RESPONSES = 30
# Words that mean a real challenge on a 403 page (else a flat 403 is a block, no wait).
_CHALLENGE_WORDS = ("captcha", "radware", "perfdrive", "shieldsquare", "px-captcha", "challenge")

_PAGE_TEXT_JS = "() => document.body ? (document.body.innerText || '').slice(0, 5000) : ''"
_NEXT_DATA_JS = "() => { const s = document.getElementById('__NEXT_DATA__'); return s ? s.textContent : null; }"


def page_block(url: str, title: str, text: str, status: int | None, *, have_json: bool) -> str | None:
    """``"captcha"`` for a bot-manager challenge, ``"forbidden"`` for a flat
    403, else None. Page text is only searched while no listings JSON has
    arrived (a listing that says "captcha" must not look like a block)."""
    host = (urlsplit(url).hostname or "").lower()
    if any(host == h or host.endswith("." + h) for h in BOT_VALIDATOR_HOSTS):
        return "captcha"
    if is_captcha_page(title):
        return "captcha"
    if status == 403:
        lowered = f"{title}\n{text}".lower()
        return "captcha" if any(w in lowered for w in _CHALLENGE_WORDS) else "forbidden"
    if not have_json and is_captcha_page(text):
        return "captcha"
    return None


@dataclass
class CapturedJson:
    """One response from an API host: redacted URL, status, keys/types only."""

    url: str
    status: int
    shape: Any


@dataclass
class Yad2Capture:
    """What the last ``fetch`` saw (for ``check-yad2``); no values, only structure."""

    final_url: str = ""
    title: str = ""
    status: int | None = None
    captcha: bool = False
    captcha_solved: bool = False
    next_data_shape: Any = None
    responses: list[CapturedJson] = field(default_factory=list)


@dataclass
class Yad2BrowserResult:
    """Listings of one city plus per-item parse errors and the matched sources."""

    listings: list[Listing]
    item_count: int
    errors: list[str]
    sources: list[str]


class Yad2BrowserFetcher:
    """Loads yad2's search page through ``session`` (one ``BrowserSession``)
    paced by ``pacer`` (kind ``yad2_page``). ``fetch(params)`` →
    ``Yad2BrowserResult``. ``interactive`` (default: the session is not
    headless) decides whether a captcha is waited on. Waits are injectable
    for tests."""

    def __init__(
        self,
        session: BrowserSession,
        pacer: Pacer,
        *,
        search_url: str = SEARCH_URL,
        api_hosts: tuple[str, ...] = YAD2_API_HOSTS,
        captcha_wait: float = DEFAULT_CAPTCHA_WAIT,
        poll: float = DEFAULT_POLL,
        json_wait: float = DEFAULT_JSON_WAIT,
        settle: float = DEFAULT_SETTLE,
        now: Callable[[], datetime] | None = None,
        clock: Callable[[], float] = time.monotonic,
        interactive: bool | None = None,
    ) -> None:
        self.session = session
        # Can the owner see the window (and solve a captcha)? Default: not headless.
        self.interactive = (not session.headless) if interactive is None else bool(interactive)
        self.pacer = pacer
        self.search_url = search_url
        self.api_hosts = tuple(h.lower() for h in api_hosts)
        self.captcha_wait = float(captcha_wait)
        self.poll = float(poll)
        self.json_wait = float(json_wait)
        self.settle = float(settle)
        self._now = now or (lambda: datetime.now(timezone.utc))
        self._clock = clock
        self.last_capture: Yad2Capture | None = None

    def close(self) -> None:
        self.session.close()

    # ------------------------------------------------------------------ fetch

    def fetch(self, params: Mapping[str, Any]) -> Yad2BrowserResult:
        """Listings of the search page for ``params`` (``yad2.search_params``)."""
        url = f"{self.search_url}?{urlencode(dict(params))}"
        self.last_capture = Yad2Capture()
        try:
            self.pacer.begin(YAD2_PAGE)
        except DailyCapReached as exc:
            raise BrowserFallbackUnavailable(f"yad2 browser: {exc}") from None
        try:
            bodies = self.session.call(lambda page: self._load(page, url))
        except BrowserUnavailable as exc:
            raise BrowserFallbackUnavailable(f"yad2 browser: {exc}") from None
        except SourceError:
            raise
        except Exception as exc:  # a Playwright timeout / crash: loud, not empty
            first = (str(exc).splitlines() or [""])[0]
            raise SourceError(f"yad2 browser: {type(exc).__name__}: {first}") from None
        return self._parse(bodies)

    # Runs on the browser thread.
    def _load(self, page: Any, url: str) -> list[tuple[str, Any]]:
        capture = self.last_capture or Yad2Capture()
        pending: list[Any] = []

        def on_response(response: Any) -> None:
            host = (urlsplit(response.url).hostname or "").lower()
            if host in self.api_hosts and len(pending) < MAX_RESPONSES:
                pending.append(response)

        page.on("response", on_response)
        try:
            self.pacer.page()
            capture.status = self._goto(page, url)
            # First look: URL, title and status only (the page text may still be loading).
            kind = self._block_kind(page, capture.status, have_json=True)
            bodies: list[tuple[str, Any]] = []
            if kind is None:
                bodies = self._collect(page, pending, capture)
                if not self._has_payload(bodies):  # nothing understood: is it a challenge page?
                    kind = self._block_kind(page, capture.status, have_json=False)
            if kind == "forbidden":
                self._note_page(page, capture)
                raise SourceBlocked("yad2: HTTP 403 in the browser (blocked by the site)")
            if kind == "captcha":
                capture.captcha = True
                if not self.interactive or self.captcha_wait <= 0 or not self._wait_for_owner(page):
                    self._note_page(page, capture)
                    raise SourceBlocked(CAPTCHA_MESSAGE)
                capture.captcha_solved = True
                if urlsplit(page.url).path.rstrip("/") != urlsplit(url).path.rstrip("/"):
                    self.pacer.page()
                    capture.status = self._goto(page, url)
                bodies = self._collect(page, pending, capture)
            self._note_page(page, capture)
            return bodies
        finally:
            page.remove_listener("response", on_response)

    @staticmethod
    def _has_payload(bodies: list[tuple[str, Any]]) -> bool:
        return any(True for _, body in bodies for _ in find_payloads(body))

    def _goto(self, page: Any, url: str) -> int | None:
        response = page.goto(url, wait_until="domcontentloaded")
        return response.status if response is not None else None

    def _note_page(self, page: Any, capture: Yad2Capture) -> None:
        capture.final_url = page.url
        try:
            capture.title = page.title()
        except Exception:  # navigating: the title is informational only
            capture.title = ""

    def _block_kind(self, page: Any, status: int | None, *, have_json: bool) -> str | None:
        try:
            title = page.title()
            text = page.evaluate(_PAGE_TEXT_JS)
        except Exception:  # mid-navigation; judge by the URL alone
            title, text = "", ""
        return page_block(page.url, title, str(text or ""), status, have_json=have_json)

    def _wait_for_owner(self, page: Any) -> bool:
        """Visible window on a captcha: wait for the owner to solve it."""
        log.warning("yad2 shows a captcha in the browser window; waiting up to %.0f s", self.captcha_wait)
        try:
            page.bring_to_front()
        except Exception:
            pass
        deadline = self._clock() + self.captcha_wait
        while self._clock() < deadline:
            page.wait_for_timeout(self.poll * 1000)
            if self._block_kind(page, None, have_json=False) is None:
                try:
                    page.wait_for_load_state("domcontentloaded")
                except Exception:
                    pass
                return True
        return False

    def _collect(self, page: Any, pending: list[Any], capture: Yad2Capture) -> list[tuple[str, Any]]:
        """Wait for listings JSON (``json_wait`` s at most, ``settle`` s after
        the first known shape) and return ``(redacted url, body)`` pairs."""
        bodies: list[tuple[str, Any]] = []
        done = 0
        next_data_read = False
        matched_at: float | None = None
        deadline = self._clock() + self.json_wait
        while True:
            while done < len(pending):
                self._read(pending[done], bodies, capture)
                done += 1
            if not next_data_read:
                next_data_read = self._read_next_data(page, bodies, capture)
            if matched_at is None and self._has_payload(bodies):
                matched_at = self._clock()
            now = self._clock()
            if (matched_at is not None and now - matched_at >= self.settle) or now >= deadline:
                break
            page.wait_for_timeout(250)
        return bodies

    def _read(self, response: Any, bodies: list[tuple[str, Any]], capture: Yad2Capture) -> None:
        url = redact_url(response.url)
        try:
            raw = response.body()
        except Exception as exc:  # a redirect or a body Chromium already dropped
            capture.responses.append(CapturedJson(url, response.status, f"no body ({type(exc).__name__})"))
            return
        if len(raw) > MAX_BODY_BYTES:
            capture.responses.append(CapturedJson(url, response.status, f"too large ({len(raw)} bytes)"))
            return
        try:
            body = json.loads(raw)
        except (ValueError, UnicodeDecodeError):
            ctype = response.headers.get("content-type", "")
            capture.responses.append(CapturedJson(url, response.status, f"not JSON ({ctype}, {len(raw)} bytes)"))
            return
        capture.responses.append(CapturedJson(url, response.status, json_shape(body)))
        bodies.append((url, body))

    def _read_next_data(self, page: Any, bodies: list[tuple[str, Any]], capture: Yad2Capture) -> bool:
        try:
            raw = page.evaluate(_NEXT_DATA_JS)
        except Exception:  # still navigating: try again next round
            return False
        if raw:
            try:
                data = json.loads(raw)
            except ValueError:
                capture.next_data_shape = "not JSON"
                return True
            capture.next_data_shape = json_shape(data, max_depth=8)
            bodies.append(("__NEXT_DATA__", data))
        return True

    # ----------------------------------------------------------------- parse

    def _parse(self, bodies: list[tuple[str, Any]]) -> Yad2BrowserResult:
        found: dict[str, Listing] = {}
        errors: list[str] = []
        failures: list[str] = []
        sources: list[str] = []
        count = 0
        for url, body in bodies:
            for payload in find_payloads(body):
                try:
                    listings, _, n, item_errors = parse_response(payload, self._now())
                except SourceError as exc:
                    failures.append(f"{url}: {exc}")
                    continue
                if url not in sources:
                    sources.append(url)
                count += n
                errors.extend(item_errors)
                for listing in listings:
                    found.setdefault(listing.id, listing)
        if not sources:
            if failures:
                raise SourceError(f"yad2 browser: listings JSON not understood: {failures[0]}")
            urls = [u for u, _ in bodies] or ["no JSON from " + ", ".join(self.api_hosts)]
            others = [c.url for c in (self.last_capture.responses if self.last_capture else [])
                      if c.url not in urls]
            raise SourceError(
                "yad2 browser: no listings in a known shape on the search page; captured: "
                + "; ".join((urls + others)[:8])
            )
        return Yad2BrowserResult(listings=list(found.values()), item_count=count, errors=errors,
                                 sources=sources)


def make_yad2_pacer(store: Store | None = None, state_path: Path | str | None = None) -> Pacer:
    """The yad2 browser's own ``Pacer`` (``config.yad2_pacer_state_path()``):
    10–20 s between loads, 30 a day, gated by the store's ``yad2`` cooldown."""
    from house_finder import config
    from house_finder.browser.runtime import cooldown_gate

    return Pacer(state_path if state_path is not None else config.yad2_pacer_state_path(),
                 min_delay=YAD2_MIN_DELAY, max_delay=YAD2_MAX_DELAY, base_caps=YAD2_CAPS,
                 gate=cooldown_gate(store, YAD2_SOURCE) if store is not None else None, label="yad2")


def open_yad2_browser(
    store: Store | None,
    *,
    headless: bool = False,
    profile_dir: Path | str | None = None,
    pacer: Pacer | None = None,
    captcha_wait: float = DEFAULT_CAPTCHA_WAIT,
) -> Yad2BrowserFetcher | None:
    """The process's yad2 browser fallback, or None without the ``[facebook]``
    extra (playwright). No login needed; Chromium starts on first use."""
    if not playwright_available():
        return None
    from house_finder import config

    folder = Path(profile_dir) if profile_dir is not None else config.yad2_browser_profile_dir()
    session = BrowserSession(folder, headless=headless, base_url=YAD2_BASE_URL, thread_name="yad2-browser")
    return Yad2BrowserFetcher(session, pacer if pacer is not None else make_yad2_pacer(store),
                              captcha_wait=captcha_wait)

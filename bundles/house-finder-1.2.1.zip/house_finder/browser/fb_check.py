"""``check_group`` — the read-only "Test a Facebook group" (``fb-check``).

Reads ONE group through the given ``FacebookBrowser`` (its pacer counts one
``group_read``) and returns the lines the owner reads: group stats, each
post's link / parsed fields / first 200 characters. Stores nothing, sends
nothing. ``SourceBlocked`` / ``SourceError`` propagate: the caller starts the
cooldown (CLI) or shows the failure (the ``/health`` job).
"""

from __future__ import annotations

from collections.abc import Callable
from datetime import date
from typing import Any

DEFAULT_POSTS = 5


def check_group(browser: Any, group_id: str, *, posts: int = DEFAULT_POSTS,
                out: Callable[[str], None] | None = None) -> list[str]:
    """The report lines for one group (each also passed to ``out``)."""
    from house_finder.textparse import parse_listing_text

    lines: list[str] = []

    def emit(text: str) -> None:
        lines.append(text)
        if out is not None:
            out(text)

    snapshot = browser.provider.read_group(group_id, max(1, posts))
    emit(f"Group: {snapshot.name} ({snapshot.group_id}) members={snapshot.member_count} "
         f"privacy={snapshot.privacy}")
    emit(f"Posts extracted: {len(snapshot.posts)}; rejected: {snapshot.rejected_posts}")
    for reason in snapshot.rejected_reasons[:10]:
        emit(f"  rejected {reason}")
    for post in snapshot.posts:
        parsed = parse_listing_text(post.text, today=date.today())
        emit(f"- post {post.post_id} by {post.author_name or '?'} at {post.posted_at or '?'}"
             f" images={len(post.image_urls)}")
        emit(f"  link: {post.permalink}")
        emit(f"  read as: price={parsed.price} rooms={parsed.rooms} city={parsed.city}")
        emit("  text: " + " ".join(post.text.split())[:200])
    status = browser.pacer.status()
    emit(f"Today: {status.counts} of caps {status.caps}. Nothing was stored or sent.")
    return lines

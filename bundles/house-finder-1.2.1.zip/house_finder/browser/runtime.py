"""``FacebookBrowser`` — the session, pacer and read-only provider of one process.

``open_facebook_browser(store)`` returns one only when the ``[facebook]``
extra (playwright) is installed AND the owner has run ``house-finder
fb-login`` (the login marker exists); otherwise None, and no Facebook reader,
joiner or browser sender is registered. The browser itself starts lazily, on
the first Facebook action. The pacer's gate is the store's ``facebook``
cooldown, so no Facebook action runs while it cools down after a block.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from house_finder import config
from house_finder.browser.fb_provider import BrowserPageProvider
from house_finder.browser.pacer import Pacer
from house_finder.browser.session import BrowserSession, login_info, playwright_available

if TYPE_CHECKING:
    from house_finder.store import Store

FACEBOOK_SOURCE = "facebook"


@dataclass
class FacebookBrowser:
    """What ``serve`` / ``collect`` / ``fb-check`` share for Facebook."""

    session: BrowserSession
    pacer: Pacer
    provider: BrowserPageProvider

    def close(self) -> None:
        self.session.close()


def cooldown_gate(store: Store, source: str = FACEBOOK_SOURCE):
    """A ``Pacer`` gate: the reason while ``source`` cools down, else None."""

    def gate() -> str | None:
        cooldown = store.active_cooldown(source)
        return None if cooldown is None else f"cooling down after a block until {cooldown.until}"

    return gate


def make_pacer(store: Store | None = None, state_path: Path | str | None = None) -> Pacer:
    """The default ``Pacer`` (``config.pacer_state_path()``), gated by the
    store's Facebook cooldown when a store is given."""
    return Pacer(state_path if state_path is not None else config.pacer_state_path(),
                 gate=cooldown_gate(store) if store is not None else None)


def open_facebook_browser(
    store: Store | None,
    *,
    profile_dir: Path | str | None = None,
    pacer: Pacer | None = None,
    headless: bool = False,
    base_url: str | None = None,
) -> FacebookBrowser | None:
    """The process's Facebook browser, or None without playwright or before
    ``fb-login`` (no login marker)."""
    folder = Path(profile_dir) if profile_dir is not None else config.browser_profile_dir()
    if not playwright_available() or login_info(folder) is None:
        return None
    kwargs = {"base_url": base_url} if base_url else {}
    session = BrowserSession(folder, headless=headless, **kwargs)
    pace = pacer if pacer is not None else make_pacer(store)
    return FacebookBrowser(session=session, pacer=pace, provider=BrowserPageProvider(session, pace))

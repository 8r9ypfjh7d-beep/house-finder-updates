"""``BrowserPageProvider`` — the ``PageProvider`` over the logged-in browser.

Reads only: ``search_groups(query)`` and ``read_group(group_id, max_posts)``.
Extraction runs IN the page and returns plain dicts, which go through the
same pydantic snapshots as fixtures (``GroupSnapshot.from_raw``,
``GroupSearchResult``) — untrusted input, validated post by post.

Selectors are roles, aria and link patterns only — never Facebook's hashed
class names: the feed is ``[role="feed"]``, a post is a top-level
``[role="article"]`` in it, and its id comes from a permalink matching
``/groups/<id>/posts/<id>`` or ``/groups/<id>/permalink/<id>``. **Real
Facebook DOM compatibility is NOT verified** (no network to Facebook where
this was built): ``house-finder fb-check`` is the owner's first-run check.

Every navigation and scroll goes through the ``Pacer`` (delay + daily cap),
and every loaded page through ``session.check_page`` (checkpoint / captcha /
block -> stop for the day + ``SourceBlocked``; logged out -> ``NotLoggedIn``).
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any
from urllib.parse import quote

from pydantic import ValidationError

from house_finder.browser.pacer import GROUP_READ, SEARCH
from house_finder.browser.session import check_page
from house_finder.sources.base import SourceError
from house_finder.sources.facebook.snapshots import GROUP_ID_PATTERN, GroupSearchResult, GroupSnapshot

if TYPE_CHECKING:
    from house_finder.browser.pacer import Pacer
    from house_finder.browser.session import BrowserSession

_GROUP_ID = re.compile(GROUP_ID_PATTERN)
MAX_SCROLLS = 3
MAX_SEARCH_RESULTS = 30

# In-page extraction of a group page. Returns plain data only.
_READ_GROUP_JS = r"""
(args) => {
  const [groupId, maxPosts] = args;
  const PERMALINK = /\/groups\/([^\/?#]+)\/(?:posts|permalink)\/([A-Za-z0-9:._-]+)/;
  const abs = (href) => { try { const u = new URL(href, location.href); u.hash = ""; return u; } catch (e) { return null; } };
  const clean = (u) => u ? (u.origin + u.pathname) : null;
  const feed = document.querySelector('[role="feed"]');
  const h1 = document.querySelector('[role="main"] h1') || document.querySelector('h1');
  let memberCount = null;
  const mainText = (document.querySelector('[role="main"]') || document.body).innerText || "";
  const m = mainText.match(/([\d][\d,.]*)\s*(K|M|אלף)?\s*(members|חברים|חברות)/i);
  if (m) {
    let n = parseFloat(m[1].replace(/,/g, ""));
    if (m[2] && /k|אלף/i.test(m[2])) n *= 1000;
    if (m[2] && /m/i.test(m[2])) n *= 1000000;
    memberCount = Math.round(n);
  }
  let privacy = null;
  if (/\b(private group|קבוצה פרטית)\b/i.test(mainText)) privacy = "private";
  else if (/\b(public group|קבוצה ציבורית)\b/i.test(mainText)) privacy = "public";
  const posts = [];
  const seen = new Set();
  let valid = 0;
  if (feed) {
    for (const art of feed.querySelectorAll('[role="article"]')) {
      if (art.parentElement && art.parentElement.closest('[role="article"]')) continue;  // comments
      let postId = null, permalink = null;
      for (const a of art.querySelectorAll('a[href]')) {
        const u = abs(a.getAttribute("href"));
        const mm = u && u.pathname.match(PERMALINK);
        if (mm) { postId = mm[2]; permalink = clean(u); break; }
      }
      if (!postId) { posts.push({group_id: groupId, post_id: "", permalink: ""}); continue; }
      if (seen.has(postId)) continue;
      seen.add(postId);
      let authorName = null, authorUrl = null;
      const authorLink = art.querySelector('h2 a[href], h3 a[href], h4 a[href], strong a[href]');
      if (authorLink) {
        authorName = (authorLink.innerText || "").trim() || null;
        const u = abs(authorLink.getAttribute("href"));
        authorUrl = u ? clean(u) : null;
      }
      const msg = art.querySelector('[data-ad-preview="message"], [data-ad-comet-preview="message"]');
      let text = "";
      if (msg) text = msg.innerText || "";
      else text = Array.from(art.querySelectorAll('div[dir="auto"]'))
        .filter(d => !d.parentElement.closest('div[dir="auto"]')).map(d => d.innerText || "").join("\n");
      let postedAt = null;
      const t = art.querySelector('time[datetime], abbr[data-utime]');
      if (t) {
        if (t.getAttribute("datetime")) postedAt = t.getAttribute("datetime");
        else postedAt = new Date(parseInt(t.getAttribute("data-utime"), 10) * 1000).toISOString();
      }
      const images = [];
      for (const img of art.querySelectorAll('a[href*="/photo"] img[src], img[src][alt]')) {
        const src = img.getAttribute("src");
        if (src && /^https?:/i.test(new URL(src, location.href).href) && !images.includes(src)) images.push(new URL(src, location.href).href);
        if (images.length >= 20) break;
      }
      posts.push({group_id: groupId, post_id: postId, permalink: permalink, author_name: authorName,
                  author_url: authorUrl, text: text.trim().slice(0, 20000), posted_at: postedAt,
                  image_urls: images});
      valid++;
      if (valid >= maxPosts) break;
    }
  }
  return {feed: !!feed, group: {group_id: groupId, name: h1 ? (h1.innerText || "").trim() : "",
          url: location.origin + "/groups/" + groupId + "/", member_count: memberCount, privacy: privacy},
          posts: posts, articleCount: feed ? feed.querySelectorAll('[role="article"]').length : 0};
}
"""

# Expand truncated posts: click only a button whose whole text is "See more"
# and that is not a link (a link would navigate: an unpaced page load).
_SEE_MORE_JS = r"""
() => {
  let n = 0;
  for (const b of document.querySelectorAll('[role="feed"] [role="article"] [role="button"]')) {
    if (b.closest('a[href]') || b.querySelector('a[href]')) continue;
    const t = (b.innerText || "").trim().toLowerCase();
    if (t === "see more" || t === "ראה עוד" || t === "הצג עוד") { b.click(); n++; }
    if (n >= 30) break;
  }
  return n;
}
"""

_SEARCH_JS = r"""
() => {
  const GROUP = /^\/groups\/([^\/?#]+)\/?$/;
  const main = document.querySelector('[role="main"]');
  const feed = document.querySelector('[role="feed"]');
  const text = (main || document.body).innerText || "";
  const noResults = /no results|we didn't find any results|we didn’t find any results|לא נמצאו תוצאות|אין תוצאות/i.test(text);
  const out = [];
  const seen = new Set();
  const scope = feed || main;
  if (scope) {
    for (const a of scope.querySelectorAll('a[href]')) {
      let u; try { u = new URL(a.getAttribute("href"), location.href); } catch (e) { continue; }
      const m = u.pathname.match(GROUP);
      if (!m || m[1] === "search" || m[1] === "feed" || m[1] === "discover" || seen.has(m[1])) continue;
      const name = (a.innerText || a.getAttribute("aria-label") || "").trim();
      if (!name) continue;
      seen.add(m[1]);
      const card = a.closest('[role="article"]') || a.parentElement;
      const cardText = card ? (card.innerText || "") : "";
      let members = null;
      const mm = cardText.match(/([\d][\d,.]*)\s*(K|M|אלף)?\s*(members|חברים|חברות)/i);
      if (mm) {
        let n = parseFloat(mm[1].replace(/,/g, ""));
        if (mm[2] && /k|אלף/i.test(mm[2])) n *= 1000;
        if (mm[2] && /m/i.test(mm[2])) n *= 1000000;
        members = Math.round(n);
      }
      out.push({group_id: m[1], name: name.split("\n")[0].slice(0, 500), url: u.origin + u.pathname,
                member_count: members, description: cardText.slice(0, 2000) || null});
    }
  }
  return {recognised: !!(feed || noResults), noResults: noResults, results: out};
}
"""


def _valid_count(data: dict[str, Any]) -> int:
    return sum(1 for p in data["posts"] if p.get("post_id"))


class BrowserPageProvider:
    """``PageProvider`` over a ``BrowserSession`` (read-only: no join, post
    or message method — those are in ``fb_actions``)."""

    def __init__(self, session: BrowserSession, pacer: Pacer, *, max_scrolls: int = MAX_SCROLLS) -> None:
        self.session = session
        self.pacer = pacer
        self.base_url = session.base_url
        self.max_scrolls = max(0, int(max_scrolls))

    def search_groups(self, query: str) -> list[GroupSearchResult]:
        """Groups Facebook lists for ``query``. A page that is neither a
        result list nor a "no results" page raises ``SourceError``."""
        self.pacer.begin(SEARCH)

        def run(page: Any) -> dict[str, Any]:
            self.pacer.page()
            page.goto(f"{self.base_url}/search/groups/?q={quote(query)}", wait_until="domcontentloaded")
            check_page(page, base_url=self.base_url, pacer=self.pacer)
            return page.evaluate(_SEARCH_JS)

        data = self.session.call(run)
        if not data.get("recognised"):
            raise SourceError(f"group search page for {query!r} not recognised (layout changed?)")
        results: list[GroupSearchResult] = []
        for raw in data.get("results", [])[:MAX_SEARCH_RESULTS]:
            try:
                results.append(GroupSearchResult.model_validate(raw))
            except ValidationError:
                continue  # one odd link never fails the search
        return results

    def read_group(self, group_id: str, max_posts: int) -> GroupSnapshot:
        """The group's head and up to ``max_posts`` recent posts (newest
        first). No feed on the page -> ``SourceError`` (not a member,
        layout changed) — never an empty group."""
        if not _GROUP_ID.fullmatch(group_id or ""):
            raise SourceError(f"invalid group id {group_id!r}")
        self.pacer.begin(GROUP_READ)
        limit = max(0, int(max_posts))

        def run(page: Any) -> dict[str, Any]:
            self.pacer.page()
            page.goto(f"{self.base_url}/groups/{group_id}/?sorting_setting=CHRONOLOGICAL",
                      wait_until="domcontentloaded")
            check_page(page, base_url=self.base_url, pacer=self.pacer)
            page.evaluate(_SEE_MORE_JS)
            data = page.evaluate(_READ_GROUP_JS, [group_id, limit])
            scrolls = 0
            while data["feed"] and _valid_count(data) < limit and scrolls < self.max_scrolls:
                before = data["articleCount"]
                self.pacer.page()
                page.mouse.wheel(0, 2500)
                page.wait_for_timeout(1500)
                check_page(page, base_url=self.base_url, pacer=self.pacer)
                page.evaluate(_SEE_MORE_JS)
                data = page.evaluate(_READ_GROUP_JS, [group_id, limit])
                scrolls += 1
                if data["articleCount"] == before:
                    break
            return data

        data = self.session.call(run)
        if not data.get("feed"):
            raise SourceError(f"group {group_id}: no feed on the page (not a member, or the layout changed)")
        posts = data["posts"]
        valid = [p for p in posts if p.get("post_id")][:limit]
        raw = {**data["group"], "posts": valid + [p for p in posts if not p.get("post_id")]}
        if not raw.get("name"):
            raw["name"] = f"group {group_id}"
        try:
            return GroupSnapshot.from_raw(raw)
        except (ValidationError, TypeError) as exc:
            raise SourceError(f"group {group_id}: page not understood: {exc}") from None

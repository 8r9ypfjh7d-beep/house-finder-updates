# collector — collection runs and schedule

Runs every source adapter in isolation, stores what they return, and records
one health row per adapter per run, so a broken source shows up in the UI
and never stops the others (VISION priority 3). It does **not** run
matching — matching runs at read time, so a profile change re-ranks at once.

## Code Files

- `collector.py` — `run_collection()`, `run_adapter()`, `resolve_adapters()`, `AdapterSource`, `CollectionReport`, `SourceRun`
- `scheduler.py` — `Scheduler` (background thread), `DEFAULT_INTERVAL_MINUTES`
- `health.py` — source health alerts: `evaluate()` (pure) + `Verdict`, `update_alerts()`, `alert_sources()`, `alert_text()`, `is_internal()`; constants `CONSECUTIVE_ERRORS`, `ZERO_LOOKBACK`, `HISTORY_LIMIT`, `KIND_LABELS`, `HEALTH_ALERTS`
- `__init__.py` — re-exports the above

## API

`run_collection(store, profile, adapters) -> CollectionReport` — `adapters`
is a list or a factory (`resolve_adapters` calls it once per run; `serve`
passes one so a group joined meanwhile is read without a restart); for each
adapter, `run_adapter(store, profile, adapter)`:

0. **Cooldown** (secure-sessions stage 2): `store.active_cooldown(name)` →
   skipped: `SourceRun(status="cooldown", message="skipped: cooling down
   after a block until …")`, a `source_skipped` event, NO fetch and NO health
   row (the last row stays the `blocked` one, so its alert stays open).
1. `adapter.fetch(profile)` inside try/except (any `Exception`).
2. Upsert every listing; ids that were new go into `new_ids`.
3. Health row: `ok` (count), `empty` (0 listings), or `error` (message;
   `SourceBlocked` → `error_kind="blocked"` and a message starting `blocked: `). Listings in
   `SourceError.partial` are stored and counted even on `error`. The
   adapter's `warnings` are appended to the message (`; `-joined).
4. A `SourceBlocked` run → `store.start_cooldown(name, message)` (6 h, then
   24 h for the next block in a row — every source, yad2 included); an `ok`
   / `empty` run → `store.reset_cooldown(name)` (escalation starts over).
5. One `collected` event: `source`, `status`, `count`, `new_ids`, `message`.

`CollectionReport`: `started_at`, `finished_at`, `runs: list[SourceRun]`,
properties `new_ids` (all sources) and `errors`.
`SourceRun`: `source`, `status` (`ok`/`empty`/`error`/`cooldown`), `count`,
`new_ids`, `message`. A `cooldown` run is not in `errors`.

A store (SQLite) failure is not an adapter failure and does propagate.

`Scheduler(job, interval_minutes=30, *, run_immediately=True)`:

- `start()` — daemon thread; first run right away when `run_immediately`.
- `trigger_now()` — wake the thread for a run now; without a started thread
  it runs the job synchronously in the caller.
- `run_once()` — run in the calling thread (waits if a run is in progress).
- `stop(timeout=10)` — stop and join.
- `last_result`, `last_error`, `runs`, `is_alive`, `is_running_job`.
- `Scheduler.for_collection(store, adapters, profile_path=None, interval_minutes=30, *, after=None, **kw)`
  — `adapters` may be a factory, called on every run.
  — job = `run_collection(store, load_profile(profile_path), adapters)`, then
  `after(report, profile)` when given. `serve` passes
  `notify.make_after_collection(...)` (deduplication, then new-match
  notifications; never raises); see [notify.md](../notify/notify.md).

## Source health alerts (`health.py`, hardening stage 3)

Here (not in `quality/`, which judges listings) because it reads only the
`source_health` rows this package writes, and imports no matching.
`notify.run_health_alerts` calls it after EVERY collection.

`evaluate(source, history_newest_first) -> Verdict` (`raise` kind+reason /
`clear` / `keep`), first that holds:

| Kind | When |
|---|---|
| `blocked` | latest row is `error` with `error_kind == "blocked"` (never message text) |
| `consecutive_errors` | the latest `CONSECUTIVE_ERRORS` (2) rows are `error` |
| `zero_unexpected` | latest row is `empty` AND one of the `ZERO_LOOKBACK` (5) rows before it has `count > 0` |
| clear | latest row is `ok` |

Internal rows (`notify`, `notify:*`, `quality:*`, `health:*` — `is_internal`)
are not sources: `consecutive_errors` only, and any non-error latest row
clears (an `empty` "turned off" channel is the owner's fix).

`update_alerts(store, sources)` applies the verdicts (`store.raise_alert` /
`clear_alert`) and returns the incidents it OPENED. `alert_sources(store,
ran)` = the sources in the report + every internal row: a source that did
not run (Facebook with no joined group is not registered) is never
evaluated, so its absence is never "zero unexpected".


- New-match notification is a hook (`after`), not part of `run_collection`:
  the collector stays free of matching imports (a test checks it).
- One run at a time: a lock around the job, shared by the thread,
  `trigger_now()` and `run_once()`.
- Triggers that arrive during a run coalesce into a single follow-up run (one
  `Event`), so a double click on "collect now" does not double the requests.
- `for_collection` reloads the profile from disk on every run — profile
  edits apply to the next run without a restart.
- A job exception is logged and kept in `last_error`; the thread survives.
- A non-list return or a non-`Listing` item from an adapter is an `error`
  run, not a crash.
- If storing `partial` listings fails, the original error message is kept
  and the storage failure appended.
- One incident per source (open until an `ok` run): a still-failing source
  refreshes the open incident's kind/reason instead of opening a new one, so
  the owner is notified once per incident, not every 30 minutes.
- `blocked` is a structured column (`error_kind`), so a message that merely
  contains "blocked" never raises the blocked alert.
- A blocked source is not retried every 30 minutes: the cooldown is stored
  (survives restarts), shown on `/health` with the owner's **Clear**, and
  a second block before a healthy run doubles down to 24 h.

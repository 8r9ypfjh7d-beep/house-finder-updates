"""``FacebookGroupsAdapter``: posts of the owner's joined groups -> Listings.

Reads every group the store has as ``joined`` through a ``PageProvider``
and turns each post into a ``Listing`` with ``textparse``. Per-group
failures are isolated and named in ``warnings`` (the collector appends them
to the health message); if every joined group fails, or there are none,
``fetch`` raises ``SourceError`` — never an empty list for a run that read
nothing (VISION priority 3).
"""

from __future__ import annotations

from collections.abc import Callable, Sequence
from datetime import date, datetime, timezone
from typing import TYPE_CHECKING, Any

from pydantic import ValidationError

from house_finder.models import Contact, ContactChannel, Listing
from house_finder.sources.base import SourceBlocked, SourceError
from house_finder.sources.facebook.groups import is_listing
from house_finder.sources.facebook.snapshots import GroupSnapshot, PostSnapshot
from house_finder.text import canonical_city, normalize_place, safe_url
from house_finder.textparse import ParsedFields, parse_listing_text

if TYPE_CHECKING:
    from house_finder.profile import LocationArea, SearchProfile
    from house_finder.sources.facebook.provider import PageProvider
    from house_finder.store import FbGroup, Store

SOURCE = "facebook"
DEFAULT_MAX_POSTS = 30


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def group_city(group: FbGroup, areas: Sequence[LocationArea]) -> str | None:
    """The one city the group's ``discovered_query`` names (read with
    ``textparse``, so two cities or a neighborhood-only query give None)."""
    if not group.discovered_query:
        return None
    return parse_listing_text(group.discovered_query, locations=areas).city


def city_from_group(parsed: ParsedFields, group: FbGroup, areas: Sequence[LocationArea]) -> str | None:
    """The group's city for a post that names a neighborhood but no city —
    only when unambiguous: the group's query names exactly one city, the
    neighborhood is listed under that city in the profile, and under no
    other profile city. Else None."""
    if parsed.city is not None or parsed.neighborhood is None:
        return None
    city = group_city(group, areas)
    if city is None:
        return None
    hood = normalize_place(parsed.neighborhood)
    owners = {canonical_city(a.city) for a in areas
              if hood in {normalize_place(n) for n in a.neighborhoods}}
    return city if owners == {canonical_city(city)} else None


class FacebookGroupsAdapter:
    """``SourceAdapter`` over the joined Facebook groups.

    ``warnings`` (reset per ``fetch``) names failed groups, rejected
    (malformed) posts and dropped unsafe URLs. ``counts`` holds the last
    run's ``groups``, ``failed_groups``, ``posts``, ``listings``,
    ``discussion``, ``rejected`` and ``unsafe_permalink`` totals.
    """

    name = SOURCE

    def __init__(
        self,
        provider: PageProvider,
        store: Store,
        *,
        max_posts: int = DEFAULT_MAX_POSTS,
        today: date | None = None,
        now: Callable[[], datetime] = _utc_now,
    ) -> None:
        self.provider = provider
        self.store = store
        self.max_posts = max_posts
        self.today = today
        self.now = now
        self.warnings: list[str] = []
        self.counts: dict[str, int] = {}

    def fetch(self, profile: SearchProfile) -> list[Listing]:
        self.warnings = []
        self.counts = dict.fromkeys(
            ("groups", "failed_groups", "posts", "listings", "discussion", "rejected",
             "unsafe_permalink"), 0)
        groups = self.store.fb_groups(status="joined")
        if not groups:
            raise SourceError("no joined Facebook groups")
        self.counts["groups"] = len(groups)
        areas = list(profile.locations)
        listings: dict[str, Listing] = {}
        failed: list[str] = []
        for group in groups:
            label = f"{group.name} ({group.group_id})"
            try:
                snapshot = self._read(group.group_id)
                for listing in self._listings(snapshot, group, areas, label):
                    listings.setdefault(listing.id, listing)
            except SourceBlocked as exc:
                # Facebook refuses us: stop reading for this run (account safety).
                raise SourceBlocked(f"{label}: {exc}", partial=list(listings.values())) from exc
            except Exception as exc:  # one failing group never stops the others
                failed.append(f"{label}: {exc}")
        self.counts["failed_groups"] = len(failed)
        self.counts["listings"] = len(listings)
        if failed and len(failed) == len(groups):
            raise SourceError("every joined Facebook group failed: " + "; ".join(failed))
        if failed:
            self.warnings.insert(0, "failed groups: " + "; ".join(failed))
        if self.counts["posts"] == 0 and self.counts["rejected"] == 0:
            # Joined groups always have posts: reading none at all means the
            # page reader is broken, not that the groups are quiet (VISION 3).
            raise SourceError("no posts read from any joined Facebook group"
                              + (" (" + "; ".join(failed) + ")" if failed else ""))
        return list(listings.values())

    def _read(self, group_id: str) -> GroupSnapshot:
        raw: Any = self.provider.read_group(group_id, self.max_posts)
        if not isinstance(raw, GroupSnapshot):
            try:
                raw = GroupSnapshot.from_raw(raw)
            except (ValidationError, TypeError) as exc:
                raise SourceError(f"malformed group snapshot: {exc}") from None
        if raw.group_id != group_id:
            raise SourceError(f"provider returned group {raw.group_id}")
        return raw

    def _listings(
        self, snapshot: GroupSnapshot, group: FbGroup, areas: list[LocationArea], label: str
    ) -> list[Listing]:
        out: list[Listing] = []
        if snapshot.rejected_posts:
            self.counts["rejected"] += snapshot.rejected_posts
            self.warnings.append(f"{label}: {snapshot.rejected_posts} malformed posts skipped"
                                 f" ({'; '.join(snapshot.rejected_reasons[:3])})")
        if not snapshot.posts and not snapshot.rejected_posts:
            self.warnings.append(f"{label}: no posts read")
        for post in snapshot.posts[: self.max_posts]:
            self.counts["posts"] += 1
            parsed = parse_listing_text(post.text, today=self.today, locations=areas)
            if not is_listing(parsed):
                self.counts["discussion"] += 1
                continue
            url = safe_url(post.permalink)
            if not url:
                self.counts["unsafe_permalink"] += 1
                self.warnings.append(f"{label}: post {post.post_id} dropped: unsafe permalink")
                continue
            out.append(self._to_listing(post, parsed, group, areas, url, label))
        return out

    def _to_listing(
        self,
        post: PostSnapshot,
        parsed: ParsedFields,
        group: FbGroup,
        areas: list[LocationArea],
        url: str,
        label: str,
    ) -> Listing:
        evidence = dict(parsed.evidence)
        city = parsed.city
        if (filled := city_from_group(parsed, group, areas)) is not None:
            city = filled
            evidence["city"] = f"group search query: {group.discovered_query}"
        profile_url = safe_url(post.author_url) or None
        if post.author_url and profile_url is None:
            self.warnings.append(f"{label}: post {post.post_id}: unsafe author URL dropped")
        photos = [u for u in (safe_url(i) for i in post.image_urls) if u]
        phones = list(dict.fromkeys(parsed.phones))
        return Listing(
            source=SOURCE,
            source_id=post.post_id,
            url=url,
            description=post.text,
            price=parsed.price,
            city=city,
            neighborhood=parsed.neighborhood,
            rooms=parsed.rooms,
            sqm=parsed.sqm,
            floor=parsed.floor,
            property_type=parsed.property_type,
            move_in_date=parsed.move_in_date,
            move_in_immediate=parsed.move_in_immediate,
            lease_months=parsed.lease_months,
            attributes=dict(parsed.attributes),
            is_agent=parsed.is_agent,
            photos=photos,
            posted_at=post.posted_at,
            fetched_at=self.now(),
            contact=Contact(
                channel=ContactChannel.facebook_messenger,
                name=post.author_name or None,
                phone=phones[0] if len(phones) == 1 else None,
                profile_url=profile_url,
            ),
            language=parsed.language,
            raw={
                "group_id": group.group_id,
                "group_name": group.name,
                "post": post.model_dump(mode="json"),
                "evidence": evidence,
            },
        )

"""Facebook groups source — see ``facebook.md``."""

from house_finder.sources.facebook.adapter import FacebookGroupsAdapter, city_from_group, group_city
from house_finder.sources.facebook.groups import (
    DiscoveryReport,
    GroupStats,
    classify,
    discover_groups,
    discovery_queries,
    group_stats,
    is_listing,
)
from house_finder.sources.facebook.provider import FixtureProvider, PageProvider, ProviderError
from house_finder.sources.facebook.snapshots import GroupSearchResult, GroupSnapshot, PostSnapshot

__all__ = [
    "DiscoveryReport",
    "FacebookGroupsAdapter",
    "FixtureProvider",
    "GroupSearchResult",
    "GroupSnapshot",
    "GroupStats",
    "PageProvider",
    "PostSnapshot",
    "ProviderError",
    "city_from_group",
    "classify",
    "discover_groups",
    "discovery_queries",
    "group_city",
    "group_stats",
    "is_listing",
]

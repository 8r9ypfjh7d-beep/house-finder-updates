# sources/facebook — Facebook groups source

Turns posts of the owner's **joined** Facebook groups into `Listing`s, and
discovers candidate groups with stats for the owner to approve (BRIEF §9,
F3, F10). Pages arrive as structured snapshots from a `PageProvider` — the
logged-in browser session in production (`BrowserPageProvider`,
[browser.md](../../browser/browser.md)), JSON fixtures in tests and
development. **This package never parses
Facebook HTML, and never joins, posts or messages**: a provider only reads.

## Code Files

- `snapshots.py` — `PostSnapshot`, `GroupSnapshot` (+ `from_raw()`), `GroupSearchResult`; `GROUP_ID_PATTERN`, `POST_ID_PATTERN`
- `provider.py` — `PageProvider` protocol, `FixtureProvider`, `ProviderError`
- `adapter.py` — `FacebookGroupsAdapter`, `group_city()`, `city_from_group()`
- `groups.py` — `is_listing()`, `classify()`, `GroupStats`, `group_stats()`, `discovery_queries()`, `DiscoveryReport`, `discover_groups()`
- `__init__.py` — re-exports the above (not re-exported from `sources/__init__.py`, which `net` imports)

## Snapshots (`snapshots.py`) — untrusted input

| Model | Fields |
|---|---|
| `PostSnapshot` | `group_id`, `post_id`, `permalink`, `author_name?`, `author_url?`, `text` (≤20,000), `posted_at?`, `image_urls` (≤50) |
| `GroupSnapshot` | `group_id`, `name`, `url`, `member_count?` (≥0), `privacy?`, `posts`, `rejected_posts`, `rejected_reasons` |
| `GroupSearchResult` | `group_id`, `name`, `url`, `member_count?`, `description?` |

Pydantic-validated, frozen, unknown keys ignored. Ids must match
`GROUP_ID_PATTERN` / `POST_ID_PATTERN` (letters, digits, `. _ -`, and `:`
in post ids) — never a path. `GroupSnapshot.from_raw(dict)` validates each
post on its own: a malformed post, or one whose `group_id` is another
group's, is skipped and counted with a reason; a bad group head raises.
URLs are NOT checked here — the adapter passes each through `text.safe_url`.

## Provider (`provider.py`)

`PageProvider`: `search_groups(query) -> list[GroupSearchResult]`,
`read_group(group_id, max_posts) -> GroupSnapshot` (raise `SourceError`;
`SourceBlocked` when Facebook refuses us).

`FixtureProvider(root)`: `root/groups/<group_id>.json` (one group snapshot,
through `from_raw`, truncated to `max_posts`) and `root/search.json`
(`{query: [results]}`; an absent query or file = no results). Missing,
unreadable or malformed files, an invalid id, or a file describing another
group → `ProviderError` (a `SourceError`). Test fixtures:
`tests/fixtures/facebook/` (hand-written, see its README).

## Adapter (`adapter.py`)

`FacebookGroupsAdapter(provider, store, *, max_posts=30, today=None, now=utc)`,
`name = "facebook"`.

- Reads every `store.fb_groups("joined")` group. **No joined groups →
  `SourceError("no joined Facebook groups")`**; the CLI therefore registers
  the adapter only when there is at least one (see below).
- Each post → `textparse.parse_listing_text(text, today, locations=profile.locations)`.
  **No price and no rooms → discussion**: counted (`counts["discussion"]`),
  never a listing.
- Listing: `source="facebook"`, `source_id=post_id`, `url=safe_url(permalink)`
  (unsafe → post dropped, named in `warnings`), `description` = post text,
  every parsed field, `posted_at`, `photos` = safe image URLs only,
  `contact = Contact(facebook_messenger, name=author_name,
  profile_url=safe_url(author_url) or None (unsafe → dropped + warning),
  phone = the post's phone when it states exactly one)`, `language`,
  `raw = {group_id, group_name, post, evidence}`.
- **City from the group** (`city_from_group`): only when the post names a
  neighborhood and no city, the group's `discovered_query` names exactly one
  city (read with `textparse`), the neighborhood is listed under that city in
  the profile and under no other profile city. Evidence:
  `raw["evidence"]["city"] = "group search query: <query>"`. Nothing else is
  ever filled in.
- A provider may return a dict instead of a `GroupSnapshot`; it goes through
  `from_raw`. A snapshot for another group id is a group failure.
- Isolation: a failing group is caught and the run continues;
  `warnings[0] = "failed groups: <name> (<id>): <reason>; …"` (the collector
  appends `warnings` to the health message). **Every** joined group failed →
  `SourceError("every joined Facebook group failed: …")`. `SourceBlocked`
  stops the run at once (no more page reads) and is re-raised with the
  listings so far in `partial`. A group whose page yields no posts at all is
  warned (`<name> (<id>): no posts read`); when NO joined group yields any
  post, `fetch` raises `SourceError("no posts read from any joined Facebook
  group")` — a broken page reader must not look like quiet groups.
- Also in `warnings`: malformed posts skipped per group, dropped permalinks
  and author URLs. `counts`: `groups`, `failed_groups`, `posts`, `listings`,
  `discussion`, `rejected`, `unsafe_permalink`.

## Groups (`groups.py`)

- `is_listing(parsed)` — price or rooms stated.
- `group_stats(snapshot, *, locations, today) -> GroupStats(posts_sampled,
  listing_posts, listing_ratio, last_listing_at, classification)` —
  ratio = listing posts / valid posts (None for no posts); last listing =
  newest dated listing post (naive times read as UTC).
- `classify(ratio)`: ≥0.6 `mostly listings`, <0.3 `mostly discussion`, else
  `mixed`; None → `unknown`.
- `discovery_queries(profile)`: per area `דירות להשכרה <city>`,
  `דירות להשכרה <neighborhood>` per neighborhood, `<city> apartments for rent`;
  deduplicated.
- `discover_groups(provider, profile, store, *, max_posts=20, today)` →
  `DiscoveryReport(queries, found, new, failures)`: search every query,
  dedup by group id (first query = `discovered_query`), sample each group
  (except `rejected` ones) with `read_group`, store with
  `store.upsert_fb_group` (new → `candidate`; existing status untouched).
  **Never joins, never calls `set_fb_group_status`.** A failing query or
  sample is listed in `failures` (sample failed → stored without stats); an
  unsafe group URL is stored as `""` and listed. No locations, or every
  query failed → `SourceError`; `SourceBlocked` is re-raised at once.
  Optional `progress(text)` is told each step (`searching n/N: …`,
  `sampling group n/N: …`) — the web runs discovery in the background and
  shows it on `/groups`.

## Registration (`__main__.build_adapters`)

`build_adapters(store=..., fb_provider=...)` adds the adapter only when a
provider exists AND the store has a `joined` group. The provider is the
logged-in browser's `BrowserPageProvider` (after `house-finder fb-login`,
with the `[facebook]` extra), else `FixtureProvider(<data>/fb_fixtures/)`
when that folder exists (development). Zero joined groups is a
configuration state (nothing to read), not a failing source, so no adapter
and no red health row. `serve` rebuilds the list on every collection run,
so a group joined (or marked joined) while it runs is read at the next run.

## Optimizations and Features

- Posts are validated one by one (`from_raw`), so one broken post in a
  scraped page costs that post, not the group; the count and first reasons
  reach `/health`.
- Snapshot ids are pattern-restricted, so a fixture or provider id can never
  become a path (`FixtureProvider` rechecks before opening a file).
- `SourceBlocked` stops all further reads in the run and in discovery
  (account safety, VISION priority 1) instead of being isolated per group.
- Listings are deduplicated by id within a run (first wins).
- `group_city` reuses `textparse` on the stored query, so "one city only"
  follows the parser's own place rules (prefixes, aliases, negation).
- Discovery samples a group found by several queries once, and skips
  re-sampling groups the owner rejected (fewer page reads).

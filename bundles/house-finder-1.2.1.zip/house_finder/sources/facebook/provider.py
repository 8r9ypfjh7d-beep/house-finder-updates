"""``PageProvider``: where Facebook pages come from.

In production the logged-in browser session (secure-sessions plan) is the
provider; in tests and development ``FixtureProvider`` reads JSON snapshots
from a folder. Either way this package receives structured snapshots, never
HTML. A provider only READS: it has no join / post / message method.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Protocol, runtime_checkable

from pydantic import ValidationError

from house_finder.sources.base import SourceError
from house_finder.sources.facebook.snapshots import (
    GROUP_ID_PATTERN,
    GroupSearchResult,
    GroupSnapshot,
)

_GROUP_ID = re.compile(GROUP_ID_PATTERN)


class ProviderError(SourceError):
    """The provider could not deliver a page (missing, unreadable, malformed)."""


@runtime_checkable
class PageProvider(Protocol):
    """Read-only access to Facebook group pages as snapshots."""

    def search_groups(self, query: str) -> list[GroupSearchResult]:
        """Groups Facebook lists for ``query`` (may be empty)."""
        ...

    def read_group(self, group_id: str, max_posts: int) -> GroupSnapshot:
        """The group's metadata and up to ``max_posts`` recent posts, or raise
        ``SourceError`` (``SourceBlocked`` when Facebook refuses us)."""
        ...


class FixtureProvider:
    """Snapshots from a folder of JSON files (tests and development):

    - ``groups/<group_id>.json`` — one ``GroupSnapshot`` object;
    - ``search.json`` — ``{"<query>": [GroupSearchResult, ...], ...}``.

    A query absent from ``search.json`` (or no ``search.json``) has no
    results. A missing or malformed group file raises ``ProviderError``.
    """

    def __init__(self, root: Path | str) -> None:
        self.root = Path(root)

    def _load(self, path: Path) -> Any:
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            raise ProviderError(f"no fixture {path.name}") from None
        except (OSError, ValueError) as exc:
            raise ProviderError(f"unreadable fixture {path.name}: {exc}") from None

    def search_groups(self, query: str) -> list[GroupSearchResult]:
        path = self.root / "search.json"
        if not path.exists():
            return []
        data = self._load(path)
        if not isinstance(data, dict):
            raise ProviderError("search.json must map a query to a list of groups")
        raw = data.get(query, [])
        if not isinstance(raw, list):
            raise ProviderError(f"search.json: results for {query!r} are not a list")
        try:
            return [GroupSearchResult.model_validate(r) for r in raw]
        except ValidationError as exc:
            raise ProviderError(f"search.json: invalid result for {query!r}: {exc.errors()[0]['msg']}") from None

    def read_group(self, group_id: str, max_posts: int) -> GroupSnapshot:
        if not _GROUP_ID.fullmatch(group_id or ""):
            raise ProviderError(f"invalid group id {group_id!r}")
        data = self._load(self.root / "groups" / f"{group_id}.json")
        try:
            snapshot = GroupSnapshot.from_raw(data)
        except (ValidationError, TypeError) as exc:
            raise ProviderError(f"malformed snapshot for group {group_id}: {exc}") from None
        if snapshot.group_id != group_id:
            raise ProviderError(f"fixture for {group_id} describes group {snapshot.group_id}")
        return snapshot.model_copy(update={"posts": snapshot.posts[:max(0, max_posts)]})

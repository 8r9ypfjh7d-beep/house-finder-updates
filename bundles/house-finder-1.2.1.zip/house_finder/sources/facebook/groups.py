"""Facebook group discovery and per-group stats (BRIEF §9, F10).

``discover_groups`` searches Facebook (through the provider) with queries
built from the profile's locations, samples each found group's recent posts
for stats, and stores every group as a ``candidate``. **It never joins and
never sets ``approved`` / ``joined`` / ``pending_join``** — the owner
approves a group, and only the joiner (secure-sessions) joins it, after an
approval record (VISION priority 1). The store's ``fb_groups`` triggers
enforce the same rule.
"""

from __future__ import annotations

from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from typing import TYPE_CHECKING

from house_finder.sources.base import SourceBlocked, SourceError
from house_finder.sources.facebook.snapshots import GroupSearchResult, GroupSnapshot
from house_finder.text import safe_url
from house_finder.textparse import ParsedFields, parse_listing_text

if TYPE_CHECKING:
    from house_finder.profile import LocationArea, SearchProfile
    from house_finder.sources.facebook.provider import PageProvider
    from house_finder.store import Store

MOSTLY_LISTINGS = 0.6  # ratio >= this -> "mostly listings"
MOSTLY_DISCUSSION = 0.3  # ratio < this -> "mostly discussion"
DEFAULT_SAMPLE_POSTS = 20


def is_listing(parsed: ParsedFields) -> bool:
    """A post is a listing when it states a price or a room count; anything
    else is discussion (counted for the ratio, never stored as a listing)."""
    return parsed.price is not None or parsed.rooms is not None


def classify(ratio: float | None) -> str:
    """``mostly listings`` (>= 0.6), ``mixed``, ``mostly discussion`` (< 0.3),
    or ``unknown`` when no post was sampled."""
    if ratio is None:
        return "unknown"
    if ratio >= MOSTLY_LISTINGS:
        return "mostly listings"
    if ratio < MOSTLY_DISCUSSION:
        return "mostly discussion"
    return "mixed"


def _utc(value: datetime) -> datetime:
    return value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value.astimezone(timezone.utc)


@dataclass(frozen=True)
class GroupStats:
    """How listing-heavy a group is, from a sample of its recent posts."""

    posts_sampled: int
    listing_posts: int
    listing_ratio: float | None
    last_listing_at: datetime | None
    classification: str


def group_stats(
    snapshot: GroupSnapshot,
    *,
    locations: Iterable[LocationArea] = (),
    today: date | None = None,
) -> GroupStats:
    """Stats over the snapshot's (valid) posts: listing ratio = listing posts
    / posts, the newest dated listing post, and the classification."""
    areas = list(locations)
    total = len(snapshot.posts)
    listing_times: list[datetime] = []
    listings = 0
    for post in snapshot.posts:
        if is_listing(parse_listing_text(post.text, today=today, locations=areas)):
            listings += 1
            if post.posted_at is not None:
                listing_times.append(_utc(post.posted_at))
    ratio = listings / total if total else None
    return GroupStats(
        posts_sampled=total,
        listing_posts=listings,
        listing_ratio=ratio,
        last_listing_at=max(listing_times) if listing_times else None,
        classification=classify(ratio),
    )


def discovery_queries(profile: SearchProfile) -> list[str]:
    """Search queries from the profile's locations, in order, without
    duplicates: ``דירות להשכרה <city>``, ``דירות להשכרה <neighborhood>`` for
    each neighborhood, ``<city> apartments for rent``."""
    queries: list[str] = []
    for area in profile.locations:
        city = " ".join(area.city.split())
        if not city:
            continue
        queries.append(f"דירות להשכרה {city}")
        for hood in area.neighborhoods:
            hood = " ".join(hood.split())
            if hood:
                queries.append(f"דירות להשכרה {hood}")
        queries.append(f"{city} apartments for rent")
    return list(dict.fromkeys(queries))


@dataclass
class DiscoveryReport:
    """What one ``discover_groups`` call did."""

    queries: list[str] = field(default_factory=list)
    found: list[str] = field(default_factory=list)  # group ids, first-seen order
    new: list[str] = field(default_factory=list)  # group ids stored for the first time
    failures: list[str] = field(default_factory=list)  # failed queries / samples, with reasons


def discover_groups(
    provider: PageProvider,
    profile: SearchProfile,
    store: Store,
    *,
    max_posts: int = DEFAULT_SAMPLE_POSTS,
    today: date | None = None,
    progress: Callable[[str], None] | None = None,
) -> DiscoveryReport:
    """Search, dedup by group id (the first query that found a group is its
    ``discovered_query``), sample each group's recent posts for stats, and
    store it with ``upsert_fb_group`` — new groups as ``candidate``; an
    existing group's status is never touched. A rejected group is not
    re-sampled.

    One failing query or sample never stops the others (it is listed in
    ``failures``; a group whose sample failed is stored without stats).
    Raises ``SourceError`` when the profile has no locations or every query
    failed, and re-raises ``SourceBlocked`` at once (stop reading a site
    that refuses us; groups stored so far stay stored).
    ``progress(text)`` (optional) is told each step (the web's background
    "Discover groups" shows it on ``/groups``).
    """
    say = progress or (lambda text: None)
    report = DiscoveryReport(queries=discovery_queries(profile))
    if not report.queries:
        raise SourceError("the profile has no locations to search Facebook groups for")
    areas = list(profile.locations)
    found: dict[str, tuple[str, GroupSearchResult]] = {}
    failed_queries = 0
    for n, query in enumerate(report.queries, start=1):
        say(f"searching {n}/{len(report.queries)}: {query}")
        try:
            results = provider.search_groups(query)
        except SourceBlocked:
            raise
        except Exception as exc:  # one failing query never stops the others
            failed_queries += 1
            report.failures.append(f"search {query!r}: {exc}")
            continue
        for result in results:
            found.setdefault(result.group_id, (query, result))
    if failed_queries == len(report.queries):
        raise SourceError("every Facebook group search failed: " + "; ".join(report.failures))

    for n, (group_id, (query, result)) in enumerate(found.items(), start=1):
        say(f"sampling group {n}/{len(found)}: {result.name}")
        report.found.append(group_id)
        existing = store.get_fb_group(group_id)
        stats: GroupStats | None = None
        privacy = None
        member_count = result.member_count
        if existing is None or existing.status != "rejected":
            try:
                snapshot = provider.read_group(group_id, max_posts)
            except SourceBlocked:
                raise
            except Exception as exc:
                report.failures.append(f"sample {group_id}: {exc}")
            else:
                stats = group_stats(snapshot, locations=areas, today=today)
                privacy = snapshot.privacy
                if snapshot.member_count is not None:
                    member_count = snapshot.member_count
        url = safe_url(result.url)
        if result.url and not url:
            report.failures.append(f"group {group_id}: unsafe URL dropped")
        is_new = store.upsert_fb_group(
            group_id,
            name=result.name,
            url=url,
            member_count=member_count,
            privacy=privacy,
            discovered_query=query,
            last_listing_at=(stats.last_listing_at.isoformat()
                             if stats and stats.last_listing_at else None),
            listing_ratio=stats.listing_ratio if stats else None,
            posts_sampled=stats.posts_sampled if stats else None,
        )
        if is_new:
            report.new.append(group_id)
    return report

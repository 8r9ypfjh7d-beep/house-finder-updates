"""The source-adapter interface and its errors.

An adapter turns one site into ``Listing`` objects. It either returns the
listings it found or raises — **never an empty list for a response it did
not understand** (VISION priority 3). The collector runs each adapter in
isolation and turns a raise into an ``error`` health row.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Protocol, runtime_checkable

if TYPE_CHECKING:
    from house_finder.models import Listing
    from house_finder.profile.profile import SearchProfile


class SourceError(Exception):
    """A source failed: bad status, unrecognised response, network failure.

    ``partial`` carries listings the adapter had already parsed before the
    failure (e.g. earlier cities), so the collector can still store them while
    reporting the run as an error.
    """

    def __init__(self, message: str, *, partial: list[Listing] | None = None) -> None:
        super().__init__(message)
        self.partial: list[Listing] = list(partial or [])


class SourceBlocked(SourceError):
    """The site refused us: captcha / bot page, HTTP 403, or persistent 429.

    Adapters stop querying the site for the rest of the run when they see it.
    """


@runtime_checkable
class SourceAdapter(Protocol):
    """One site. ``name`` is the ``Listing.source`` value and health key.

    ``fetch`` returns listings or raises ``SourceError`` / ``SourceBlocked``.
    Optionally an adapter exposes ``warnings: list[str]`` — non-fatal notes
    from its last ``fetch`` (e.g. a profile area it could not query) that
    the collector appends to the health message.
    """

    name: str

    def fetch(self, profile: SearchProfile) -> list[Listing]:
        """Return the listings this source currently has for ``profile``."""
        ...

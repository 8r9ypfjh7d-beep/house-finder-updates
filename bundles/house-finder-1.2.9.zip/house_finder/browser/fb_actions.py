"""Facebook actions under the owner's name — each behind an approval record.

``join_group`` (facebook stage 3 contract):

1. The group must be ``approved`` (the owner's click). With stored entry
   questions it needs ``store.answers_approval_for(group_id)``; with none,
   ``approved`` alone (the owner's click) is the approval.
2. Open the group, press Join. If the live Join dialog's questions differ
   from the stored ones — including the first time they are seen — store
   them (``set_fb_group_questions``, which deletes the old answers), close
   the dialog without submitting, and stop: the owner answers and approves.
3. Fill exactly ``store.group_answers(id).pairs`` (their hash must be the
   token's), read every box back, call ``store.check_group_answers``
   immediately before Submit, submit, and only then set ``pending_join``
   (``joined`` when the page shows membership).

``FacebookBrowserSender`` (send mode ``browser`` for Facebook, opt-in):
the same ``ApprovalToken`` gate as the assisted senders as its first line;
types the exact approved text into the Messenger box; reads the box back
and NEVER presses send when it differs (the box is cleared); re-checks the
approval against the store right before pressing Enter. ``dispatch`` is its
only caller.

Real Facebook DOM compatibility is NOT verified (see ``browser.md``).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Literal
from urllib.parse import parse_qs, urlsplit

from house_finder.browser.pacer import JOIN, MESSAGE
from house_finder.browser.session import check_page
from house_finder.messaging.senders import SendResult, refusal
from house_finder.models import Listing
from house_finder.sources.base import SourceBlocked, SourceError
from house_finder.store import APPROVAL_MISMATCH, ApprovalToken, Message, answers_sha256, check_approval

if TYPE_CHECKING:
    from house_finder.browser.pacer import Pacer
    from house_finder.browser.session import BrowserSession
    from house_finder.messaging.senders import SenderRegistry
    from house_finder.store import Store

BROWSER = "browser"
JoinStatus = Literal["refused", "questions_changed", "unsupported", "pending_join", "joined", "failed"]

_JOIN_NAME = re.compile(r"^\s*(join group|join|הצטרפות לקבוצה|הצטרף לקבוצה|הצטרפות|הצטרף)\s*$", re.I)
_SUBMIT_NAME = re.compile(r"^\s*(submit|send|שליחה|שלח|שלחי)\s*$", re.I)
_CLOSE_NAME = re.compile(r"^\s*(close|cancel|סגירה|סגור|ביטול)\s*$", re.I)
_PENDING = re.compile(r"(cancel request|pending|request sent|ביטול הבקשה|ממתין|הבקשה נשלחה)", re.I)
_JOINED = re.compile(r"^\s*(joined|member|חבר בקבוצה|הצטרפת)\s*$", re.I)
_BOXES = 'textarea, input[type="text"], [role="textbox"]'
_TARGET = re.compile(r"^[A-Za-z0-9.]{1,100}$")
_RESERVED = {"groups", "messages", "people", "pages", "events", "watch", "marketplace", "profile.php",
             "permalink.php", "story.php", "photo.php", "search", "login", "checkpoint", "share"}

# The Join dialog: every free-text box with its question. Choice questions
# (radio / checkbox, e.g. "I agree to the rules") are not supported.
_DIALOG_JS = r"""
() => {
  const BOXES = 'textarea, input[type="text"], [role="textbox"]';
  const CHOICES = 'input[type="radio"], input[type="checkbox"], [role="radio"], [role="checkbox"]';
  const dialogs = Array.from(document.querySelectorAll('[role="dialog"]'));
  const dlg = dialogs.find(d => d.querySelector(BOXES)) || dialogs.find(d => d.querySelector(CHOICES));
  if (!dlg) return {dialog: dialogs.length > 0, questions: [], unsupported: false};
  const textOf = (el) => (el ? (el.innerText || el.textContent || "") : "").trim();
  const label = (box) => {
    if (box.getAttribute("aria-label")) return box.getAttribute("aria-label").trim();
    const by = box.getAttribute("aria-labelledby");
    if (by) return by.split(/\s+/).map(id => textOf(document.getElementById(id))).join(" ").trim();
    if (box.id) { const l = dlg.querySelector('label[for="' + CSS.escape(box.id) + '"]'); if (l) return textOf(l); }
    let el = box;
    for (let i = 0; i < 4 && el && el !== dlg; i++) {
      let prev = el.previousElementSibling;
      while (prev) { const t = textOf(prev); if (t) return t; prev = prev.previousElementSibling; }
      el = el.parentElement;
    }
    return "";
  };
  const boxes = Array.from(dlg.querySelectorAll(BOXES));
  return {dialog: true, questions: boxes.map(label),
          unsupported: !!dlg.querySelector(CHOICES)};
}
"""

# A box's current text: value for inputs; for a contenteditable, one line per
# block child (an editor's <p>/<div>), else its innerText.
_READ_BOX_JS = r"""
(el) => {
  if (el.tagName === "TEXTAREA" || el.tagName === "INPUT") return el.value;
  const blocks = Array.from(el.children).filter(c => /^(P|DIV)$/.test(c.tagName));
  if (blocks.length) return blocks.map(b => b.textContent || "").join("\n");
  return el.innerText || "";
}
"""


@dataclass(frozen=True)
class JoinResult:
    """What ``join_group`` did. ``questions`` = the live questions seen."""

    status: JoinStatus
    note: str
    questions: list[str] = field(default_factory=list)


def normalize_box_text(text: str) -> str:
    """Whitespace-only normalisation for comparing a box with approved text:
    CRLF -> LF, no-break space -> space, trailing spaces per line and outer
    blank lines dropped. Every other character must match exactly."""
    lines = text.replace("\r\n", "\n").replace("\r", "\n").replace(" ", " ").split("\n")
    return "\n".join(line.rstrip() for line in lines).strip("\n").strip()


def _read_box(locator: Any) -> str:
    return str(locator.evaluate(_READ_BOX_JS))


def _clear_box(page: Any, locator: Any) -> None:
    try:
        if locator.evaluate("el => el.tagName === 'TEXTAREA' || el.tagName === 'INPUT'"):
            locator.fill("")
        else:
            locator.click()
            page.keyboard.press("ControlOrMeta+A")
            page.keyboard.press("Delete")
    except Exception:  # best effort: the caller already refuses to submit
        pass


def _type_into(page: Any, locator: Any, text: str) -> None:
    """Type ``text`` without ever pressing a bare Enter (which sends in
    Messenger): lines are inserted, line breaks are Shift+Enter."""
    if locator.evaluate("el => el.tagName === 'TEXTAREA' || el.tagName === 'INPUT'"):
        locator.fill(text)
        return
    locator.click()
    for i, line in enumerate(text.split("\n")):
        if i:
            page.keyboard.press("Shift+Enter")
        if line:
            page.keyboard.insert_text(line)


def _close_dialog(page: Any) -> None:
    try:
        close = page.locator('[role="dialog"]').get_by_role("button", name=_CLOSE_NAME)
        if close.count():
            close.first.click()
        else:
            page.keyboard.press("Escape")
    except Exception:
        page.keyboard.press("Escape")


# A button belongs to the group's own header only when it is in the main
# column and not inside a post, the feed, a side column or a dialog: a post
# sharing ANOTHER group, or "Suggested groups", has its own Join button.
_OWN_BUTTON_JS = (
    "el => !!el.closest('[role=\"main\"]') && !el.closest("
    "'[role=\"feed\"], [role=\"article\"], [role=\"complementary\"], [role=\"dialog\"]')"
)


def _own_buttons(page: Any, name: Any = None) -> list[Any]:
    """The group header's buttons (``_OWN_BUTTON_JS``), optionally by name."""
    found = page.get_by_role("button", name=name) if name is not None else page.get_by_role("button")
    own = []
    for button in found.all()[:200]:
        try:
            if button.evaluate(_OWN_BUTTON_JS):
                own.append(button)
        except Exception:
            continue
    return own


def _membership(page: Any) -> str | None:
    """``pending_join`` / ``joined`` from the group header's buttons, else None."""
    for button in _own_buttons(page):
        try:
            name = (button.get_attribute("aria-label") or button.inner_text() or "").strip()
        except Exception:
            continue
        if _PENDING.search(name):
            return "pending_join"
        if _JOINED.match(name):
            return "joined"
    return None


def join_group(store: Store, session: BrowserSession, pacer: Pacer, group_id: str) -> JoinResult:
    """Join an approved group with exactly its approved answers (module doc).

    Never submits without the approval: refuses unless the group is
    ``approved`` and (when it has stored questions) a valid answers token
    exists; re-checks the token right before Submit. Raises ``SourceBlocked``
    (stopped for the day) / ``SourceError`` (page not understood, logged out)."""
    group = store.get_fb_group(group_id)
    if group is None:
        return JoinResult("refused", f"no Facebook group {group_id!r}")
    if group.status != "approved":
        return JoinResult("refused", f"{group.name} is {group.status}; only an approved group is joined")
    stored = list(group.questions)
    token = store.answers_approval_for(group_id) if stored else None
    pairs: list[tuple[str, str]] = []
    if stored:
        saved = store.group_answers(group_id)
        if token is None or saved is None:
            return JoinResult("refused", f"{APPROVAL_MISMATCH}: the entry answers are not approved")
        pairs = list(saved.pairs)
        if answers_sha256(group_id, pairs) != token.answers_sha256 or [q for q, _ in pairs] != stored:
            return JoinResult("refused", f"{APPROVAL_MISMATCH}: the answers changed since approval")
    pacer.begin(JOIN)
    base = session.base_url

    def run(page: Any) -> JoinResult:
        pacer.page()
        page.goto(f"{base}/groups/{group_id}/", wait_until="domcontentloaded")
        check_page(page, base_url=base, pacer=pacer)
        join = _own_buttons(page, _JOIN_NAME)  # never a Join inside a post or a side column
        if not join:
            state = _membership(page)
            if state is not None:
                return JoinResult(state, f"Facebook already shows {state.replace('_', ' ')} for this group")
            return JoinResult("failed", "no Join button found on the group page (layout changed?)")
        if len(join) > 1:
            return JoinResult("failed", "more than one Join button on the group page; nothing clicked")
        join[0].click()
        live: dict[str, Any] = {"dialog": False, "questions": [], "unsupported": False}
        for _ in range(20):  # up to ~5 s for the dialog or the new button state
            page.wait_for_timeout(250)
            live = page.evaluate(_DIALOG_JS)
            if live["questions"] or live["unsupported"] or _membership(page) is not None:
                break
        check_page(page, base_url=base, pacer=pacer)
        questions = [q.strip() for q in live["questions"]]
        if live["unsupported"]:
            _close_dialog(page)
            return JoinResult("unsupported", "the Join dialog has choice questions or a rules checkbox; "
                                             "join this group by hand", questions)
        if any(not q for q in questions):
            _close_dialog(page)
            return JoinResult("failed", "an entry question has no readable text (layout changed?)", questions)
        if questions != stored:
            if questions:
                _close_dialog(page)
                return JoinResult("questions_changed", "the group's entry questions are new or changed; "
                                                       "answer and approve them, then join again", questions)
        if not questions:
            # No questions dialog: pressing Join already sent the request (the
            # owner approved joining this group). Only a visible pending /
            # joined state counts; anything else is reported, not assumed.
            state = _membership(page)
            if state is None:
                _close_dialog(page)
                return JoinResult("failed", "after Join, Facebook showed neither entry questions nor a "
                                            "pending / joined state; check the group by hand", questions)
            note = ("Facebook asked no entry questions this time; the join request was sent"
                    if stored else "join request sent")
            return JoinResult(state, note, questions)
        dialog = page.locator('[role="dialog"]').filter(has=page.locator(_BOXES)).first
        boxes = dialog.locator(_BOXES)
        if boxes.count() != len(pairs):
            _close_dialog(page)
            return JoinResult("failed", "the dialog's answer boxes do not match its questions", questions)
        for i, (_, answer) in enumerate(pairs):
            _type_into(page, boxes.nth(i), answer)
        for i, (_, answer) in enumerate(pairs):
            if normalize_box_text(_read_box(boxes.nth(i))) != normalize_box_text(answer):
                _close_dialog(page)
                return JoinResult("failed", f"answer {i + 1} reads back differently; not submitted", questions)
        reason = store.check_group_answers(group_id, token)  # immediately before Submit
        if reason is not None:
            _close_dialog(page)
            return JoinResult("refused", reason, questions)
        submit = dialog.get_by_role("button", name=_SUBMIT_NAME)
        if not submit.count():
            _close_dialog(page)
            return JoinResult("failed", "no Submit button in the Join dialog", questions)
        submit.first.click()
        page.wait_for_timeout(1500)
        return JoinResult(_membership(page) or "pending_join", "answers submitted", questions)

    result = session.call(run, retry=False)  # never press Join twice
    if result.status == "questions_changed":
        store.set_fb_group_questions(group_id, result.questions)
    elif result.status in ("pending_join", "joined"):
        if not result.questions and stored:
            store.set_fb_group_questions(group_id, [])  # Facebook asked none this time
        store.set_fb_group_status(group_id, "pending_join")
        if result.status == "joined":
            store.set_fb_group_status(group_id, "joined")
    store.log_event("fb_group_join", group_id=group_id, status=result.status, note=result.note,
                    questions=len(result.questions))  # never the answer text
    return result


# ------------------------------------------------------------------ sender


def messenger_target(profile_url: str | None, base_url: str) -> str | None:
    """The Messenger conversation URL for a poster's Facebook profile link
    (``/groups/<g>/user/<id>/``, ``profile.php?id=<id>``, ``/people/<n>/<id>``,
    ``/<username>``), or None when it is not one."""
    if not profile_url:
        return None
    try:
        parts = urlsplit(profile_url)
    except ValueError:
        return None
    base_host = (urlsplit(base_url).hostname or "").lower()
    host = (parts.hostname or "").lower()
    if parts.scheme not in ("http", "https") or not (host == base_host or host == "facebook.com"
                                                     or host.endswith(".facebook.com")):
        return None
    segs = [s for s in parts.path.split("/") if s]
    target = None
    if len(segs) >= 4 and segs[0] == "groups" and segs[2] == "user":
        target = segs[3]
    elif segs == ["profile.php"]:
        target = (parse_qs(parts.query).get("id") or [None])[0]
    elif len(segs) >= 3 and segs[0] == "people":
        target = segs[2]
    elif len(segs) == 1 and segs[0].lower() not in _RESERVED:
        target = segs[0]
    if not target or not _TARGET.fullmatch(target):
        return None
    return f"{base_url.rstrip('/')}/messages/t/{target}/"


class FacebookBrowserSender:
    """Opt-in automated Messenger send (send mode ``browser``) — see module doc."""

    channel = "facebook"
    mode = BROWSER

    def __init__(self, listing: Listing, *, session: BrowserSession, pacer: Pacer, store: Store | None = None) -> None:
        self.listing = listing
        self.session = session
        self.pacer = pacer
        self.store = store

    def send(self, message: Message, approval: ApprovalToken) -> SendResult:
        refused = refusal(message, approval)  # the approval gate — always first
        if refused is not None:
            return refused
        profile = self.listing.contact.profile_url if self.listing.contact else None
        url = messenger_target(profile, self.session.base_url)
        if url is None:
            return SendResult("failed", error="no Messenger link for the poster; use assisted sending")
        try:
            self.pacer.begin(MESSAGE)
            return self.session.call(lambda page: self._type_and_send(page, url, message, approval),
                                     retry=False)  # never send twice
        except SourceBlocked as exc:
            if self.store is not None:
                self.store.start_cooldown("facebook", str(exc))
            return SendResult("failed", error=f"not sent: {exc}")
        except SourceError as exc:
            return SendResult("failed", error=f"not sent: {exc}")
        except Exception as exc:  # e.g. the page navigated after Enter: the outcome is unknown
            return SendResult("failed", error=f"browser error, the message MAY have been sent — check "
                                              f"Messenger before drafting again: {type(exc).__name__}: {exc}")

    def _type_and_send(self, page: Any, url: str, message: Message, approval: ApprovalToken) -> SendResult:
        base = self.session.base_url
        self.pacer.page()
        page.goto(url, wait_until="domcontentloaded")
        check_page(page, base_url=base, pacer=self.pacer)
        box = page.locator('[role="main"] [role="textbox"][contenteditable="true"]')
        if not box.count():
            box = page.locator('[role="textbox"][contenteditable="true"]')
        if not box.count():
            return SendResult("failed", error="no message box on the conversation page (layout changed?)")
        box = box.first
        if normalize_box_text(_read_box(box)):
            return SendResult("failed", error="the message box already holds text; nothing typed, not sent")
        _type_into(page, box, message.text)
        typed = _read_box(box)
        if normalize_box_text(typed) != normalize_box_text(message.text):
            _clear_box(page, box)
            return SendResult("failed", error="the text in the message box differs from the approved text; "
                                              "cleared, not sent")
        if self.store is not None:  # the approval must still hold right before Enter
            reason = check_approval(self.store.get_message(message.id), approval)
            if reason is not None:
                _clear_box(page, box)
                return SendResult("failed", error=reason)
        box.press("Enter")
        page.wait_for_timeout(2000)
        if normalize_box_text(_read_box(box)):
            return SendResult("failed", error="send not confirmed (the text is still in the box); "
                                              "check Messenger before trying again")
        return SendResult("sent")


def register_browser_sender(registry: SenderRegistry, *, session: BrowserSession, pacer: Pacer,
                            store: Store | None = None) -> None:
    """Register ``FacebookBrowserSender`` for ``("facebook", "browser")``. It
    is used only for listings whose channel is Facebook while the owner's
    send mode for Facebook is ``browser``."""
    registry.register("facebook", BROWSER,
                      lambda listing: FacebookBrowserSender(listing, session=session, pacer=pacer, store=store),
                      replace=True)

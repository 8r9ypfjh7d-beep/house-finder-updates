"""``BrowserPageProvider`` — the ``PageProvider`` over the logged-in browser.

Reads only: ``search_groups(query)`` and ``read_group(group_id, max_posts)``.
Extraction runs IN the page and returns plain dicts, which go through the
same pydantic snapshots as fixtures (``GroupSnapshot.from_raw``,
``GroupSearchResult``) — untrusted input, validated post by post.

Selectors are roles, aria and link patterns only — never Facebook's hashed
class names: the feed is ``[role="feed"]``; a post is an ``[aria-posinset]``
block, else a top-level ``[role="article"]``, else a feed child with text.
Before reading, "See more" is expanded and empty post links get hover/focus
events (Facebook fills a permalink's href lazily), then ONE short wait. The
post id comes from a ``/groups/<g>/posts|permalink/<id>`` link (numeric or
``pfbid…``), a ``story_fbid`` / ``multi_permalinks`` query, a photo link's
``set=gm.<id>``, any ``/posts/pfbid…`` link — else a stable content id
(``content_id``), so a post with text is never thrown away. **Real
Facebook DOM compatibility is NOT verified** (no network to Facebook where
this was built): ``house-finder fb-check`` is the owner's first-run check.

Every navigation and scroll goes through the ``Pacer`` (delay + daily cap),
and every loaded page through ``session.check_page`` (checkpoint / captcha /
block -> stop for the day + ``SourceBlocked``; logged out -> ``NotLoggedIn``).
"""

from __future__ import annotations

import hashlib
import re
from typing import TYPE_CHECKING, Any
from urllib.parse import quote

from pydantic import ValidationError

from house_finder.browser.pacer import GROUP_READ, MY_GROUPS, SEARCH
from house_finder.browser.session import check_page
from house_finder.sources.base import SourceError
from house_finder.sources.facebook.snapshots import GROUP_ID_PATTERN, GroupSearchResult, GroupSnapshot
from house_finder.text import clean_group_name

if TYPE_CHECKING:
    from house_finder.browser.pacer import Pacer
    from house_finder.browser.session import BrowserSession

_GROUP_ID = re.compile(GROUP_ID_PATTERN)
MAX_SCROLLS = 3
MAX_SEARCH_RESULTS = 30

# In-page extraction of a group page. Returns plain data only.
#
# Posts: top-level [role=feed] [role=article] (a nested article is a comment);
# when the feed has none, top-level [aria-posinset] blocks (anywhere in main),
# else the feed's direct children that hold text. The container kind used is
# reported (``container``) so the logs say which guess matched.
# Post id, in order: a /groups/<g>/posts|permalink/<id> link (numeric or
# pfbid…), a story_fbid / multi_permalinks query, a photo link's
# set=gm.<id> / set=pcb.<id>, any /posts/pfbid… link. None found: the post
# is returned with its text and an empty id (Python gives it a content id).
_READ_GROUP_JS = r"""
(args) => {
  const [groupId, maxPosts] = args;
  const PERMALINK = /\/groups\/([^\/?#]+)\/(?:posts|permalink)\/([A-Za-z0-9_-]+)/;
  const PFBID = /\/posts\/(pfbid[A-Za-z0-9]+)/;
  const ID = /^[A-Za-z0-9_-]{1,190}$/;
  const abs = (href) => { try { const u = new URL(href, location.href); u.hash = ""; return u; } catch (e) { return null; } };
  const clean = (u) => u ? (u.origin + u.pathname) : null;
  const postUrl = (id) => location.origin + "/groups/" + groupId + "/posts/" + id + "/";
  const feed = document.querySelector('[role="feed"]');
  const main = document.querySelector('[role="main"]') || document.body;
  const h1 = document.querySelector('[role="main"] h1') || document.querySelector('h1');
  let memberCount = null;
  const mainText = main.innerText || "";
  const m = mainText.match(/([\d][\d,.]*)\s*(K|M|אלף)?\s*(members|חברים|חברות)/i);
  if (m) {
    let n = parseFloat(m[1].replace(/,/g, ""));
    if (m[2] && /k|אלף/i.test(m[2])) n *= 1000;
    if (m[2] && /m/i.test(m[2])) n *= 1000000;
    memberCount = Math.round(n);
  }
  let privacy = null;
  // JS \b is ASCII-only (never matches beside Hebrew letters): explicit edges instead
  if (/(^|[^\p{L}])(private group|קבוצה פרטית)(?![\p{L}])/iu.test(mainText)) privacy = "private";
  else if (/(^|[^\p{L}])(public group|קבוצה ציבורית)(?![\p{L}])/iu.test(mainText)) privacy = "public";

  let containers = [], container = "none";
  const scope = feed || main;
  const topArticles = (root) => Array.from(root.querySelectorAll('[role="article"]'))
    .filter(a => { const up = a.parentElement && a.parentElement.closest('[role="article"]'); return !up || !root.contains(up); });
  // [aria-posinset] blocks: the block is the post when its text lives outside
  // any article (an article inside it is then a comment); a block wrapping one
  // article with all the text is that article.
  const blocks = Array.from(scope.querySelectorAll('[aria-posinset]'))
    .filter(b => !(b.parentElement && b.parentElement.closest('[aria-posinset]')));
  if (blocks.length) {
    let plain = 0;
    containers = blocks.map(b => {
      if (b.getAttribute("role") === "article") return b;
      const arts = topArticles(b);
      const textOutside = Array.from(b.querySelectorAll('[dir="auto"], [data-ad-preview="message"], [data-ad-comet-preview="message"]'))
        .some(d => !d.closest('[role="article"]') && (d.innerText || "").trim());
      if (arts.length === 1 && !textOutside) return arts[0];
      plain++;
      return b;
    });
    container = plain ? "posinset" : "article";
  }
  if (!containers.length && feed) {
    containers = topArticles(feed);
    if (containers.length) container = "article";
  }
  if (!containers.length && feed) {
    containers = Array.from(feed.children).filter(c => (c.innerText || "").trim().length > 0);
    if (containers.length) container = "feed_child";
  }
  const posts = [];
  const seen = new Set();
  let valid = 0;
  for (const art of containers) {
    // An element belongs to this post unless it sits in a nested article (a comment).
    const own = (el) => { const inner = el.closest('[role="article"]'); return !inner || inner === art || !art.contains(inner); };
    const links = Array.from(art.querySelectorAll('a[href]')).filter(own);
    let postId = null, permalink = null, idSource = null;
    for (const a of links) {
      const u = abs(a.getAttribute("href"));
      const mm = u && u.pathname.match(PERMALINK);
      if (mm && ID.test(mm[2])) { postId = mm[2]; permalink = clean(u); idSource = mm[2].startsWith("pfbid") ? "pfbid" : "permalink"; break; }
    }
    if (!postId) for (const a of links) {
      const u = abs(a.getAttribute("href"));
      if (!u) continue;
      let v = u.searchParams.get("story_fbid") || (u.searchParams.get("multi_permalinks") || "").split(",")[0];
      if (v && ID.test(v)) { postId = v; idSource = "query"; break; }
    }
    if (!postId) for (const a of links) {
      const u = abs(a.getAttribute("href"));
      const set = u ? (u.searchParams.get("set") || "") : "";
      const sm = set.match(/^(?:gm|pcb)\.([A-Za-z0-9_-]+)/);
      if (sm && ID.test(sm[1])) { postId = sm[1]; idSource = "photo_set"; break; }
    }
    if (!postId) for (const a of links) {
      const u = abs(a.getAttribute("href"));
      const pm = u && u.pathname.match(PFBID);
      if (pm && ID.test(pm[1])) { postId = pm[1]; idSource = "pfbid"; break; }
    }
    if (postId && !permalink) permalink = postUrl(postId);
    if (postId && seen.has(postId)) continue;
    let authorName = null, authorUrl = null;
    const authorLink = Array.from(art.querySelectorAll('h2 a[href], h3 a[href], h4 a[href], strong a[href]')).find(own);
    if (authorLink) {
      authorName = (authorLink.innerText || "").trim() || null;
      const u = abs(authorLink.getAttribute("href"));
      const href = authorLink.getAttribute("href") || "";
      authorUrl = (u && href && href !== "#") ? clean(u) : null;
    }
    // Facebook pads posts with invisible decoy text (e.g. "Facebook" over and
    // over); read only what is actually painted on screen.
    const visible = (el) => {
      const r = el.getBoundingClientRect();
      if (r.width < 2 || r.height < 2) return false;
      const st = getComputedStyle(el);
      return st.visibility !== "hidden" && st.display !== "none" && parseFloat(st.opacity || "1") > 0.05
        && parseFloat(st.fontSize || "12") >= 6 && !el.closest('[aria-hidden="true"]');
    };
    const msg = Array.from(art.querySelectorAll(
      '[data-ad-rendering-role="story_message"], [data-ad-preview="message"], [data-ad-comet-preview="message"]'))
      .find(m => own(m) && visible(m));
    let text = "";
    if (msg) text = msg.innerText || "";
    else {
      const blocks = Array.from(art.querySelectorAll('div[dir="auto"], span[dir="auto"]'))
        .filter(d => own(d) && visible(d) && !d.parentElement.closest('[dir="auto"]')
                     && !d.closest('h2, h3, h4, strong, a[href], [role="button"]'));
      text = blocks.map(d => d.innerText || "").filter(t => t.trim()).join("\n");
    }
    text = text.trim();
    if (!postId && !text) { posts.push({group_id: groupId, post_id: "", permalink: "", reason: "no_text"}); continue; }
    if (postId) seen.add(postId);
    let postedAt = null;
    const t = Array.from(art.querySelectorAll('time[datetime], abbr[data-utime]')).find(own);
    if (t) {
      if (t.getAttribute("datetime")) postedAt = t.getAttribute("datetime");
      else postedAt = new Date(parseInt(t.getAttribute("data-utime"), 10) * 1000).toISOString();
    }
    // ALL the post's photos (not comments' — a nested article — nor emoji /
    // avatars: tiny or inside the author heading). Facebook shows at most a
    // few tiles with "+N"; the hidden ones are only on the post itself.
    const httpUrl = (src) => { try { const u = new URL(src, location.href); return /^https?:$/i.test(u.protocol) ? u.href : null; } catch (e) { return null; } };
    const tiny = (img) => { const w = parseInt(img.getAttribute("width") || "0", 10), h = parseInt(img.getAttribute("height") || "0", 10);
                            return (w && w <= 48) || (h && h <= 48) || /emoji|\/rsrc\.php\//i.test(img.getAttribute("src") || ""); };
    const VIDEO_LINK = /\/(videos|watch|reel)(\/|\?|$)/i;
    const images = [], posters = [];
    let videos = 0;
    for (const img of art.querySelectorAll('a[href*="/photo"] img[src], img[src][alt]')) {
      if (!own(img) || tiny(img) || img.closest('h2, h3, h4, strong')) continue;
      const link = img.closest('a[href]');
      if (link && VIDEO_LINK.test(link.getAttribute("href") || "")) continue;  // a video's thumbnail
      const url = httpUrl(img.getAttribute("src"));
      if (url && !images.includes(url)) images.push(url);
      if (images.length >= 50) break;
    }
    // Videos: Facebook streams them (blob:/MSE), so only a poster image is
    // taken; the review page links to the post to watch it there.
    for (const v of art.querySelectorAll('video')) {
      if (!own(v)) continue;
      videos++;
      const url = httpUrl(v.getAttribute("poster") || "");
      if (url && !posters.includes(url)) posters.push(url);
    }
    if (!videos) {
      const seenVideo = new Set();
      for (const a of links) {
        if (!VIDEO_LINK.test(a.getAttribute("href") || "")) continue;
        const key = (httpUrl(a.getAttribute("href")) || "").split(/[?#]/)[0];
        if (seenVideo.has(key)) continue;
        seenVideo.add(key);
        videos++;
        const img = a.querySelector('img[src]');
        const url = img ? httpUrl(img.getAttribute("src")) : null;
        if (url && !posters.includes(url)) posters.push(url);
      }
    }
    posts.push({group_id: groupId, post_id: postId || "", permalink: permalink || "", id_source: idSource,
                author_name: authorName, author_url: authorUrl, text: text.slice(0, 20000), posted_at: postedAt,
                image_urls: images, video_count: Math.min(videos, 50), video_posters: posters.slice(0, 50)});
    valid++;
    if (valid >= maxPosts) break;
  }
  return {feed: !!feed || container !== "none", container: container, containers: containers.length,
          group: {group_id: groupId, name: h1 ? (h1.innerText || "").trim() : "",
                  url: location.origin + "/groups/" + groupId + "/", member_count: memberCount, privacy: privacy},
          posts: posts, articleCount: containers.length};
}
"""

# Before reading: expand truncated posts and wake lazy links, in ONE call.
# - "See more": click only a button whose whole text is "See more" / "ראה עוד"
#   / "הצג עוד" / "עוד" and that is not (inside) a link — a link would
#   navigate: an unpaced page load. At most 30.
# - Facebook fills a post's timestamp/permalink href only on hover/focus
#   (href="#" or none until then): send mouseover / mouseenter / pointerover
#   / focus (no scrolling) to each post's empty links, at most 200. No
#   navigation, no click. The caller then waits ONCE (``LAZY_LINK_WAIT_MS``).
_PREPARE_JS = r"""
() => {
  const feed = document.querySelector('[role="feed"]');
  const main = document.querySelector('[role="main"]') || document.body;
  let posts = [];
  if (feed) posts = Array.from(feed.querySelectorAll('[role="article"]'));
  posts = posts.concat(Array.from(main.querySelectorAll('[aria-posinset]')));
  if (!posts.length && feed) posts = Array.from(feed.children);
  const SEE_MORE = new Set(["see more", "ראה עוד", "הצג עוד", "עוד", "ראו עוד"]);
  let expanded = 0, woken = 0;
  const done = new Set();
  for (const post of posts) {
    for (const b of post.querySelectorAll('[role="button"]')) {
      if (expanded >= 30 || done.has(b)) continue;
      done.add(b);
      if (b.closest('a[href]') || b.querySelector('a[href]')) continue;
      const t = (b.innerText || "").trim().toLowerCase().replace(/[.…]+$/, "").trim();
      if (SEE_MORE.has(t)) { b.click(); expanded++; }
    }
    for (const a of post.querySelectorAll('a, [role="link"]')) {
      if (woken >= 200 || done.has(a)) continue;
      const href = a.getAttribute("href");
      if (href && href !== "#" && !/^javascript:/i.test(href)) continue;
      done.add(a);
      for (const type of ["pointerover", "mouseover", "mouseenter"]) {
        try { a.dispatchEvent(new MouseEvent(type, {bubbles: type !== "mouseenter", cancelable: true, view: window})); } catch (e) {}
      }
      try { a.focus({preventScroll: true}); } catch (e) {}
      try { a.dispatchEvent(new FocusEvent("focus")); a.dispatchEvent(new FocusEvent("focusin", {bubbles: true})); } catch (e) {}
      woken++;
    }
  }
  if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
  return {expanded: expanded, woken: woken};
}
"""
LAZY_LINK_WAIT_MS = 500
"""One wait per page after waking lazy links / expanding posts (never per post)."""

_SEARCH_JS = r"""
() => {
  const GROUP = /^\/groups\/([^\/?#]+)\/?$/;
  const main = document.querySelector('[role="main"]');
  const feed = document.querySelector('[role="feed"]');
  const text = (main || document.body).innerText || "";
  const noResults = /no results|we didn't find any results|we didn’t find any results|לא נמצאו תוצאות|אין תוצאות/i.test(text);
  const out = [];
  const seen = new Set();
  const scope = feed || main;
  if (scope) {
    for (const a of scope.querySelectorAll('a[href]')) {
      let u; try { u = new URL(a.getAttribute("href"), location.href); } catch (e) { continue; }
      const m = u.pathname.match(GROUP);
      if (!m || m[1] === "search" || m[1] === "feed" || m[1] === "discover") continue;
      const shown = (a.innerText || "").trim();
      const name = (shown || a.getAttribute("aria-label") || "").trim();
      if (!name) continue;
      if (seen.has(m[1])) {
        // The first link may be the group's photo (name only in its aria-label):
        // a later link with visible text gives the real name.
        const prev = out.find(r => r.group_id === m[1]);
        if (prev && prev.fromLabel && shown) { prev.name = shown.split("\n")[0].slice(0, 500); prev.fromLabel = false; }
        continue;
      }
      seen.add(m[1]);
      const card = a.closest('[role="article"]') || a.parentElement;
      const cardText = card ? (card.innerText || "") : "";
      let members = null;
      const mm = cardText.match(/([\d][\d,.]*)\s*(K|M|אלף)?\s*(members|חברים|חברות)/i);
      if (mm) {
        let n = parseFloat(mm[1].replace(/,/g, ""));
        if (mm[2] && /k|אלף/i.test(mm[2])) n *= 1000;
        if (mm[2] && /m/i.test(mm[2])) n *= 1000000;
        members = Math.round(n);
      }
      out.push({group_id: m[1], name: name.split("\n")[0].slice(0, 500), url: u.origin + u.pathname,
                member_count: members, description: cardText.slice(0, 2000) || null, fromLabel: !shown});
    }
  }
  return {recognised: !!(feed || noResults), noResults: noResults, results: out};
}
"""

# The owner's own memberships page (/groups/joins/): group links in the main
# column only (the left nav holds "Your feed" / "Discover" / "Your groups").
_MY_GROUPS_JS = r"""
() => {
  const GROUP = /^\/groups\/([^\/?#]+)\/?$/;
  const SKIP = new Set(["feed", "discover", "joins", "search", "create", "notifications", "yours",
                        "your_groups", "browse", "category", "invites", "requests"]);
  const main = document.querySelector('[role="main"]');
  const text = main ? (main.innerText || "") : "";
  const none = /you haven't joined any groups|you haven’t joined any groups|לא הצטרפת לאף קבוצה|אין לך קבוצות/i.test(text);
  const out = [];
  if (main) {
    for (const a of main.querySelectorAll('a[href]')) {
      let u; try { u = new URL(a.getAttribute("href"), location.href); } catch (e) { continue; }
      const m = u.pathname.match(GROUP);
      if (!m || SKIP.has(m[1].toLowerCase())) continue;
      const shown = (a.innerText || "").trim();
      const name = (shown || a.getAttribute("aria-label") || "").trim().split("\n")[0].slice(0, 500);
      const prev = out.find(r => r.group_id === m[1]);
      if (prev) { if (prev.fromLabel && shown) { prev.name = name; prev.fromLabel = false; } continue; }
      if (!name) continue;
      out.push({group_id: m[1], name: name, url: u.origin + u.pathname, fromLabel: !shown});
    }
  }
  return {recognised: !!main && (out.length > 0 || none), none: none, results: out};
}
"""
MY_GROUPS_SCROLLS = 3
MAX_MY_GROUPS = 200


def _valid_count(data: dict[str, Any]) -> int:
    return sum(1 for p in data["posts"] if p.get("post_id"))


class BrowserPageProvider:
    """``PageProvider`` over a ``BrowserSession`` (read-only: no join, post
    or message method — those are in ``fb_actions``)."""

    def __init__(self, session: BrowserSession, pacer: Pacer, *, max_scrolls: int = MAX_SCROLLS) -> None:
        self.session = session
        self.pacer = pacer
        self.base_url = session.base_url
        self.max_scrolls = max(0, int(max_scrolls))

    def search_groups(self, query: str) -> list[GroupSearchResult]:
        """Groups Facebook lists for ``query``. A page that is neither a
        result list nor a "no results" page raises ``SourceError``."""
        self.pacer.begin(SEARCH)

        def run(page: Any) -> dict[str, Any]:
            self.pacer.page()
            page.goto(f"{self.base_url}/search/groups/?q={quote(query)}", wait_until="domcontentloaded")
            check_page(page, base_url=self.base_url, pacer=self.pacer)
            return page.evaluate(_SEARCH_JS)

        data = self.session.call(run)
        if not data.get("recognised"):
            raise SourceError(f"group search page for {query!r} not recognised (layout changed?)")
        results: list[GroupSearchResult] = []
        for raw in data.get("results", [])[:MAX_SEARCH_RESULTS]:
            if isinstance(raw, dict):  # a photo link's aria-label: "Profile photo of <group>"
                raw = {**raw, "name": clean_group_name(raw.get("name"))}
            try:
                results.append(GroupSearchResult.model_validate(raw))
            except ValidationError:
                continue  # one odd link never fails the search
        return results

    def my_groups(self, *, max_scrolls: int = MY_GROUPS_SCROLLS) -> list[GroupSearchResult]:
        """The groups the logged-in owner is already a member of, from
        Facebook's "Your groups" page (``/groups/joins/``): id, name (image
        labels cleaned), url — nothing else. One ``my_groups_read`` against
        the daily cap; the load and each of at most ``max_scrolls`` scrolls
        go through ``pacer.page()``. A page that is neither a group list nor
        a "no groups" page -> ``SourceError`` (never an empty list)."""
        self.pacer.begin(MY_GROUPS)
        limit = max(0, int(max_scrolls))

        def run(page: Any) -> dict[str, Any]:
            self.pacer.page()
            page.goto(f"{self.base_url}/groups/joins/", wait_until="domcontentloaded")
            check_page(page, base_url=self.base_url, pacer=self.pacer)
            data = page.evaluate(_MY_GROUPS_JS)
            data["on_joins_page"] = "/groups/joins" in (page.url or "")
            for _ in range(limit):
                before = len(data["results"])
                self.pacer.page()
                page.mouse.wheel(0, 2500)
                page.wait_for_timeout(1500)
                check_page(page, base_url=self.base_url, pacer=self.pacer)
                data = {**page.evaluate(_MY_GROUPS_JS), "on_joins_page": data["on_joins_page"]}
                if len(data["results"]) == before or len(data["results"]) >= MAX_MY_GROUPS:
                    break
            return data

        data = self.session.call(run)
        if data.get("on_joins_page") is False:  # redirected (e.g. to Discover): those are not your groups
            raise SourceError("Facebook did not open your groups page (it redirected); nothing was listed")
        if not data.get("recognised"):
            raise SourceError("your Facebook groups page was not recognised (layout changed?)")
        results: list[GroupSearchResult] = []
        for raw in data.get("results", [])[:MAX_MY_GROUPS]:
            if not isinstance(raw, dict):
                continue
            raw = {"group_id": raw.get("group_id"), "name": clean_group_name(raw.get("name")), "url": raw.get("url")}
            try:
                results.append(GroupSearchResult.model_validate(raw))
            except ValidationError:
                continue  # one odd link never fails the page
        return results

    def read_group(self, group_id: str, max_posts: int) -> GroupSnapshot:
        """The group's head and up to ``max_posts`` recent posts (newest
        first). No feed on the page -> ``SourceError`` (not a member,
        layout changed) — never an empty group."""
        if not _GROUP_ID.fullmatch(group_id or ""):
            raise SourceError(f"invalid group id {group_id!r}")
        self.pacer.begin(GROUP_READ)
        limit = max(0, int(max_posts))

        def run(page: Any) -> dict[str, Any]:
            self.pacer.page()
            page.goto(f"{self.base_url}/groups/{group_id}/?sorting_setting=CHRONOLOGICAL",
                      wait_until="domcontentloaded")
            check_page(page, base_url=self.base_url, pacer=self.pacer)
            tally = {"expanded": 0, "lazy_links": 0}
            data = self._extract(page, group_id, limit, tally)
            scrolls = 0
            while data["feed"] and _valid_count(data) < limit and scrolls < self.max_scrolls:
                before = data["articleCount"]
                self.pacer.page()
                page.mouse.wheel(0, 2500)
                page.wait_for_timeout(1500)
                check_page(page, base_url=self.base_url, pacer=self.pacer)
                data = self._extract(page, group_id, limit, tally)
                scrolls += 1
                if data["articleCount"] == before:
                    break
            data.update(tally)
            return data

        data = self.session.call(run)
        if not data.get("feed"):
            raise SourceError(f"group {group_id}: no feed on the page (not a member, or the layout changed)")
        posts = [_with_content_id(p, data["group"]["url"]) for p in data["posts"] if isinstance(p, dict)]
        valid = [p for p in posts if p.get("post_id")][:limit]
        raw = {**data["group"], "posts": valid + [p for p in posts if not p.get("post_id")]}
        raw["name"] = clean_group_name(raw.get("name"))
        if not raw.get("name"):
            raw["name"] = f"group {group_id}"
        ids: dict[str, int] = {}
        for p in valid:
            ids[str(p.get("id_source") or "permalink")] = ids.get(str(p.get("id_source") or "permalink"), 0) + 1
        raw["extraction"] = {"container": str(data.get("container") or "none"),
                             "containers": int(data.get("containers") or 0), "ids": ids,
                             "lazy_links": int(data.get("lazy_links") or 0),
                             "expanded": int(data.get("expanded") or 0)}
        try:
            return GroupSnapshot.from_raw(raw)
        except (ValidationError, TypeError) as exc:
            raise SourceError(f"group {group_id}: page not understood: {exc}") from None

    @staticmethod
    def _extract(page: Any, group_id: str, limit: int, tally: dict[str, int]) -> dict[str, Any]:
        """Expand posts + wake lazy links (one call), wait ONCE when anything
        changed, then extract."""
        prepared = page.evaluate(_PREPARE_JS) or {}
        tally["expanded"] += int(prepared.get("expanded") or 0)
        tally["lazy_links"] += int(prepared.get("woken") or 0)
        if prepared.get("expanded") or prepared.get("woken"):
            page.wait_for_timeout(LAZY_LINK_WAIT_MS)
        return page.evaluate(_READ_GROUP_JS, [group_id, limit])


def content_id(group_id: str, author: str | None, text: str) -> str:
    """A stable id for a post whose own link was not found: ``h:`` + 16 hex
    of sha256(group id, author, first 300 characters of the text). The same
    post read again gets the same id (no duplicate listing)."""
    key = "\x1f".join((group_id, " ".join((author or "").split()), " ".join(text.split())[:300]))
    return "h:" + hashlib.sha256(key.encode("utf-8")).hexdigest()[:16]


def _with_content_id(post: dict[str, Any], group_url: str) -> dict[str, Any]:
    """A post with text but no id: never discarded — it gets ``content_id``
    and the group page as its link (``id_source = "content"``)."""
    text = str(post.get("text") or "").strip()
    if post.get("post_id") or not text:
        return post
    return {**post, "post_id": content_id(str(post.get("group_id") or ""), post.get("author_name"), text),
            "permalink": group_url, "id_source": "content"}

"""The browser layer (Facebook session, yad2 fallback) — see ``browser.md``.

Importing this package never imports playwright (the optional ``[facebook]``
extra); the browser thread does, on first use.
"""

from house_finder.browser.fb_actions import (
    BROWSER,
    FacebookBrowserSender,
    JoinResult,
    join_group,
    messenger_target,
    normalize_box_text,
    register_browser_sender,
)
from house_finder.browser.fb_provider import BrowserPageProvider
from house_finder.browser.pacer import (
    DEFAULT_CAPS,
    MIN_DELAY_FLOOR,
    YAD2_CAPS,
    YAD2_MESSAGE,
    YAD2_PAGE,
    DailyCapReached,
    Pacer,
    PacerStatus,
)
from house_finder.browser.runtime import FacebookBrowser, cooldown_gate, make_pacer, open_facebook_browser
from house_finder.browser.yad2_actions import (
    Yad2BrowserSender,
    clear_yad2_login_marker,
    register_yad2_sender,
    write_yad2_login_marker,
    yad2_auth_cookie,
    yad2_item_url,
    yad2_login,
    yad2_login_info,
)
from house_finder.browser.yad2_page import (
    Yad2BrowserFetcher,
    Yad2BrowserResult,
    Yad2Capture,
    make_yad2_pacer,
    open_yad2_browser,
    page_block,
)
from house_finder.browser.session import (
    BLOCK_MARKERS,
    FACEBOOK_URL,
    BrowserSession,
    BrowserUnavailable,
    NotLoggedIn,
    block_reason,
    check_page,
    fb_login,
    find_chromium,
    login_info,
    playwright_available,
    write_login_marker,
)

__all__ = [
    "BLOCK_MARKERS",
    "BROWSER",
    "DEFAULT_CAPS",
    "FACEBOOK_URL",
    "MIN_DELAY_FLOOR",
    "BrowserPageProvider",
    "BrowserSession",
    "BrowserUnavailable",
    "DailyCapReached",
    "FacebookBrowser",
    "FacebookBrowserSender",
    "JoinResult",
    "NotLoggedIn",
    "Pacer",
    "PacerStatus",
    "block_reason",
    "check_page",
    "cooldown_gate",
    "fb_login",
    "find_chromium",
    "join_group",
    "login_info",
    "make_pacer",
    "messenger_target",
    "normalize_box_text",
    "open_facebook_browser",
    "playwright_available",
    "register_browser_sender",
    "write_login_marker",
    "YAD2_CAPS",
    "YAD2_MESSAGE",
    "YAD2_PAGE",
    "Yad2BrowserSender",
    "clear_yad2_login_marker",
    "register_yad2_sender",
    "write_yad2_login_marker",
    "yad2_auth_cookie",
    "yad2_item_url",
    "yad2_login",
    "yad2_login_info",
    "Yad2BrowserFetcher",
    "Yad2BrowserResult",
    "Yad2Capture",
    "make_yad2_pacer",
    "open_yad2_browser",
    "page_block",
]

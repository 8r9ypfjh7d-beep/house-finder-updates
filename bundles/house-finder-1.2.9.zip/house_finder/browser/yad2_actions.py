"""yad2 under the owner's name: **Connect yad2** and the opt-in automatic sender.

``yad2_login`` (the **Connect yad2** button): opens yad2 in the yad2
browser profile (``data/browser-yad2/``, the SAME ``BrowserSession`` the
search fallback uses), brings the window to the front, and only WAITS while
the owner logs in by hand — no code path types or stores a password. It
finishes when a logged-in cookie appears (``yad2_auth_cookie``: a guess at
yad2's cookie names, UNVERIFIED) or when the owner presses **I'm logged in**
(then the next send verifies it). Either way a marker
(``.house-finder-yad2-login.json``: time + how, nothing secret) is written;
without it the sender does not run.

``Yad2BrowserSender`` (send mode ``browser`` for the ``yad2`` channel):

1. ``refusal(message, approval)`` — the shared ``ApprovalToken`` gate — first.
2. The listing URL must be ``<yad2 base>/realestate/item/<token>``
   (``yad2_item_url``, through ``text.safe_url``); else nothing is opened.
3. ``pacer.begin("yad2_message")`` (10 a day), then on the browser thread,
   with ``retry=False``: ``pacer.page()``, open the listing, stop on a
   captcha / 403 / login page; press the contact / chat entry (paced like a
   page load); find the ONE message box; ``fill`` exactly the approved text;
   read it back — any difference beyond whitespace -> box cleared, nothing
   sent; re-check the approval against the store; press the ONE send
   button; confirm the text appeared in the conversation.
4. Anything that stops it BEFORE the send button is pressed returns
   ``needs_owner`` with the assisted "open the listing, paste the text"
   action and the reason: the message stays ``approved`` and the owner can
   send it by hand. After the press, an unconfirmed send or a browser error
   is ``failed`` ("may have been sent — check yad2"): never sent twice.

Each step that fails is logged by NAME (``step``), never with the message
text or listing data, so a later selector fix knows where yad2's page
differs. Real yad2 DOM is NOT verified (yad2 refuses datacenter IPs).
"""

from __future__ import annotations

import json
import logging
import re
import time
from collections.abc import Callable, Iterable
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any
from urllib.parse import urlsplit

from house_finder.browser.fb_actions import BROWSER, _READ_BOX_JS, normalize_box_text
from house_finder.browser.pacer import YAD2_MESSAGE
from house_finder.browser.session import NotLoggedIn
from house_finder.browser.yad2_page import page_block
from house_finder.messaging.senders import SendResult, listing_page_action, refusal
from house_finder.models import Listing
from house_finder.sources.base import SourceBlocked, SourceError
from house_finder.store import ApprovalToken, Message, check_approval
from house_finder.text import safe_url

if TYPE_CHECKING:
    from house_finder.browser.pacer import Pacer
    from house_finder.browser.session import BrowserSession
    from house_finder.messaging.senders import SenderRegistry
    from house_finder.store import Store

log = logging.getLogger(__name__)

YAD2_SOURCE = "yad2"
YAD2_LOGIN_MARKER = ".house-finder-yad2-login.json"
YAD2_LOGIN_PATH = "/"
"""Where Connect yad2 opens: yad2's home page (its log-in button is at the
top). The address of yad2's own login form is unverified, so it is not guessed."""
RELOGIN_MESSAGE = "yad2 asked to log in again / verify — press Connect yad2 (Settings)"
NOT_CONNECTED_MESSAGE = "yad2 is not connected — press Connect yad2 (Settings)"
CONNECTED_MESSAGE = ("Logged in to yad2. You can minimize this window — House Finder uses it to send the "
                     "messages you approve. Please keep it open.")
BOX_WAIT_S = 10.0
CONFIRM_WAIT_S = 10.0

# Cookie names a logged-in yad2 session plausibly sets. UNVERIFIED: yad2
# refuses every datacenter IP, so a real logged-in session was never seen.
# The owner's "I'm logged in" button is the fallback when none matches.
YAD2_AUTH_COOKIES: frozenset[str] = frozenset({
    "y2018-2-access-token", "y2018-2-refresh-token", "y2_token", "yad2_token", "y2-token",
    "accesstoken", "access_token", "refreshtoken", "refresh_token", "auth_token", "authtoken",
})
_AUTH_COOKIE_RE = re.compile(r"(access|refresh|auth)[-_]?token", re.I)

_ITEM_PATH = re.compile(r"/realestate/item/([A-Za-z0-9_-]{1,64})/?")
# The contact / chat entry on a listing page (accessible names, Hebrew first).
CONTACT_NAME = re.compile(
    r"(שליחת הודעה|שלח(?:ו|י)? הודעה|צ['׳]?אט|הודעה למפרסם|send (?:a )?message|"
    r"message (?:the )?(?:advertiser|seller|owner|landlord)|^\s*chat\s*$|contact (?:the )?(?:advertiser|seller))",
    re.I,
)
# The send button INSIDE the chat (whole name only).
SEND_NAME = re.compile(r"^\s*(שליחה|שלח|שלחי|שלחו|send)\s*$", re.I)
_TESTID_ENTRY = ('button[data-testid*="chat" i], a[data-testid*="chat" i], [role="button"][data-testid*="chat" i], '
                 'button[data-testid*="message" i], a[data-testid*="message" i]')
_LOGIN_WORDS = ("התחברות", "התחבר/י", "להתחבר", "כניסה לחשבון", "הזדהות", "log in", "login", "sign in")

# The chat state after the entry was pressed: the message box(es), and the
# signs of a login wall. Marks the one box and its container for the locators.
_CHAT_STATE_JS = r"""
() => {
  const visible = (el) => { const r = el.getBoundingClientRect(); const s = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none"; };
  const BOX = 'textarea, [contenteditable="true"], [role="textbox"]';
  document.querySelectorAll('[data-hf-box],[data-hf-chat]').forEach(e => {
    e.removeAttribute('data-hf-box'); e.removeAttribute('data-hf-chat'); });
  const dialogs = Array.from(document.querySelectorAll('[role="dialog"], dialog, [aria-modal="true"]')).filter(visible);
  let boxes = [];
  for (const d of dialogs) boxes = boxes.concat(Array.from(d.querySelectorAll(BOX)).filter(visible));
  if (!boxes.length) boxes = Array.from(document.querySelectorAll(BOX)).filter(visible);
  // a contenteditable inside another box is the same box
  boxes = boxes.filter(b => !boxes.some(o => o !== b && o.contains(b)));
  const password = Array.from(document.querySelectorAll('input[type="password"]')).some(visible);
  const dialogText = dialogs.map(d => d.innerText || "").join("\n").slice(0, 3000);
  if (boxes.length === 1) {
    const box = boxes[0];
    box.setAttribute('data-hf-box', '1');
    const chat = box.closest('[role="dialog"], dialog, [aria-modal="true"], form');
    if (chat) chat.setAttribute('data-hf-chat', '1');
  }
  return {boxes: boxes.length, password: password, dialogText: dialogText};
}
"""

# How many elements (outside the box) show exactly ``text`` — a sent bubble.
_BUBBLES_JS = r"""
(text) => {
  const norm = (s) => (s || "").replace(/ /g, " ").replace(/\s+/g, " ").trim();
  const target = norm(text);
  if (!target) return 0;
  const box = document.querySelector('[data-hf-box]');
  let n = 0;
  for (const el of document.body.querySelectorAll('*')) {
    if (el.matches('textarea, input, script, style, [contenteditable="true"]')) continue;
    if (box && (el.contains(box) || box.contains(el))) continue;
    if (norm(el.innerText) !== target) continue;
    if (Array.from(el.children).some(c => norm(c.innerText) === target)) continue;  // the innermost only
    n++;
  }
  return n;
}
"""


# ------------------------------------------------------------- pure helpers


def yad2_auth_cookie(names: Iterable[str]) -> bool:
    """Whether a set of cookie NAMES looks like a logged-in yad2 session —
    an exact name from ``YAD2_AUTH_COOKIES`` or an ``access/refresh/auth
    token`` pattern. UNVERIFIED against real yad2 (see module doc); bot
    managers' cookies (``rbzid``, ``__uzma``, ``_px…``) never match."""
    for raw in names:
        name = str(raw or "").strip()
        if name and (name.lower() in YAD2_AUTH_COOKIES or _AUTH_COOKIE_RE.search(name)):
            return True
    return False


def yad2_item_url(listing_url: str | None, base_url: str) -> str | None:
    """``<base>/realestate/item/<token>`` for a yad2 listing link (through
    ``safe_url``; same scheme, host and port as ``base_url`` — ``yad2.co.il``
    without ``www`` too), query and fragment dropped. None for anything else."""
    url = safe_url(listing_url)
    if not url:
        return None
    try:
        parts, base = urlsplit(url), urlsplit(base_url)
        port, base_port = parts.port, base.port
    except ValueError:
        return None
    host, base_host = (parts.hostname or "").lower(), (base.hostname or "").lower()
    same_host = host == base_host or (base_host.startswith("www.") and host == base_host[4:])
    if parts.scheme != base.scheme or not same_host or port != base_port or parts.username or parts.password:
        return None
    match = _ITEM_PATH.fullmatch(parts.path)
    if match is None:
        return None
    return f"{base_url.rstrip('/')}/realestate/item/{match.group(1)}"


def yad2_login_info(profile_dir: Path | str) -> dict[str, Any] | None:
    """The Connect yad2 marker (``{"logged_in_at", "how"}``), or None."""
    try:
        data = json.loads((Path(profile_dir) / YAD2_LOGIN_MARKER).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return data if isinstance(data, dict) else None


def write_yad2_login_marker(profile_dir: Path | str, how: str) -> Path:
    """Record that the owner logged in to yad2 (time + ``cookie`` / ``owner``)."""
    path = Path(profile_dir) / YAD2_LOGIN_MARKER
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"logged_in_at": datetime.now(timezone.utc).isoformat(), "how": how}),
                    encoding="utf-8")
    return path


def clear_yad2_login_marker(profile_dir: Path | str) -> None:
    """Forget the login (yad2 showed a login wall): status "not connected"."""
    (Path(profile_dir) / YAD2_LOGIN_MARKER).unlink(missing_ok=True)


def _cookie_names(page: Any, base_url: str) -> list[str]:
    try:
        return [str(c.get("name")) for c in page.context.cookies(base_url) if c.get("value")]
    except Exception:  # a closed context is not logged in
        return []


# ------------------------------------------------------------------ login


def yad2_login(
    session: BrowserSession,
    pacer: Pacer,
    *,
    confirmed: Callable[[], bool] = lambda: False,
    timeout: float = 600.0,
    poll: float = 2.0,
    out: Callable[[str], None] | None = None,
    clock: Callable[[], float] = time.monotonic,
    sleep: Callable[[float], None] = time.sleep,
    raise_window: Callable[[], int] | None = None,
) -> str | None:
    """Open yad2 in the (visible) session and wait while the owner logs in
    by hand — the code never types anything. Returns ``"cookie"`` when a
    logged-in cookie appears, ``"owner"`` when ``confirmed()`` turns True
    (the owner's **I'm logged in**), None on timeout; writes the marker."""
    out = out or (lambda text: log.info("%s", text))
    if raise_window is None:
        from house_finder.browser.winfocus import show_tool_windows as raise_window
    base = session.base_url

    def open_site(page: Any) -> bool:
        if yad2_auth_cookie(_cookie_names(page, base)):
            return True
        pacer.page()
        page.goto(base + YAD2_LOGIN_PATH, wait_until="domcontentloaded")
        return yad2_auth_cookie(_cookie_names(page, base))

    if session.call(open_site):
        write_yad2_login_marker(session.profile_dir, "cookie")
        out("Already logged in to yad2 in the tool's browser.")
        return "cookie"
    session.call(lambda page: page.bring_to_front())
    raise_window()
    out("A yad2 window opened: press התחברות (log in) at the top and log in there — House Finder never "
        "sees your password. When you are logged in, press I'm logged in if this does not change by itself.")
    deadline = clock() + timeout
    while clock() < deadline:
        sleep(poll)
        if session.call(lambda page: yad2_auth_cookie(_cookie_names(page, base))):
            write_yad2_login_marker(session.profile_dir, "cookie")
            out(CONNECTED_MESSAGE)
            return "cookie"
        if confirmed():
            write_yad2_login_marker(session.profile_dir, "owner")
            out("Marked as logged in to yad2 (your confirmation); the first automatic send checks it.")
            return "owner"
    out("Timed out waiting for the yad2 login; press Connect yad2 to try again.")
    return None


# ----------------------------------------------------------------- sender


class _Stop(Exception):
    """A step stopped the send before the send button was pressed."""

    def __init__(self, step: str, reason: str) -> None:
        super().__init__(reason)
        self.step = step
        self.reason = reason


class _Relogin(Exception):
    """yad2 showed a login wall or a captcha: the owner must reconnect / verify."""

    def __init__(self, step: str, why: str) -> None:
        super().__init__(why)
        self.step = step
        self.why = why


class _Forbidden(SourceBlocked):
    """A flat 403 on the listing page: the ``yad2`` cooldown starts."""


class Yad2BrowserSender:
    """Opt-in automatic yad2 message (send mode ``browser``) — see module doc.

    ``browser`` is the app's ``Yad2BrowserFetcher`` (its ``session`` and
    ``pacer`` are read at send time: Connect yad2 may have replaced the
    session)."""

    channel = YAD2_SOURCE
    mode = BROWSER

    def __init__(self, listing: Listing, *, browser: Any, store: Store | None = None) -> None:
        self.listing = listing
        self.browser = browser
        self.store = store

    def _fallback(self, message: Message, step: str, reason: str) -> SendResult:
        log.warning("yad2 automatic send stopped at step %s: %s", step, reason)
        return SendResult("needs_owner", listing_page_action(self.listing, message.text),
                          error=f"{reason} [step: {step}]")

    def send(self, message: Message, approval: ApprovalToken) -> SendResult:
        refused = refusal(message, approval)  # the approval gate — always first
        if refused is not None:
            return refused
        session: BrowserSession = self.browser.session
        pacer: Pacer = self.browser.pacer
        url = yad2_item_url(self.listing.url, session.base_url)
        if url is None:
            return self._fallback(message, "listing_url", "the listing link is not a yad2 listing page; "
                                                          "nothing was opened")
        if yad2_login_info(session.profile_dir) is None:
            return self._fallback(message, "connected", NOT_CONNECTED_MESSAGE)
        try:
            pacer.begin(YAD2_MESSAGE)
        except SourceError as exc:  # daily cap, cooldown gate (SourceBlocked is a SourceError)
            return self._fallback(message, "pacer", f"not sent: {exc}")
        pressed = {"send": False}
        try:
            return session.call(lambda page: self._run(page, url, message, approval, pressed),
                                retry=False)  # never send twice
        except _Stop as stop:
            return self._fallback(message, stop.step, stop.reason)
        except _Relogin as wall:
            if wall.why == "login":
                clear_yad2_login_marker(session.profile_dir)
            return self._fallback(message, wall.step, RELOGIN_MESSAGE)
        except Exception as exc:
            first = (str(exc).splitlines() or [""])[0][:200]
            if pressed["send"]:  # the click happened: the outcome is unknown, never left for a resend
                log.warning("yad2 automatic send: browser error after pressing send: %s", type(exc).__name__)
                return SendResult("failed", error=f"browser error after pressing send — the message MAY have "
                                                  f"been sent; check your yad2 messages before drafting again "
                                                  f"({type(exc).__name__}: {first})")
            if isinstance(exc, _Forbidden) and self.store is not None:
                self.store.start_cooldown(YAD2_SOURCE, str(exc))
            return self._fallback(message, "browser", f"nothing was sent ({type(exc).__name__}: {first})")

    # Runs on the browser thread.
    def _run(self, page: Any, url: str, message: Message, approval: ApprovalToken,
             pressed: dict[str, bool]) -> SendResult:
        pacer: Pacer = self.browser.pacer
        pacer.page()
        response = page.goto(url, wait_until="domcontentloaded")
        self._check_page(page, "open_listing", response.status if response is not None else None)
        entry = self._contact_entry(page)
        if entry is None:
            raise _Stop("contact_button", "no contact / chat button on the listing page (layout changed?)")
        pacer.page()  # the chat may load like a page
        entry.click()
        box = self._message_box(page)
        if normalize_box_text(str(box.evaluate(_READ_BOX_JS))):
            raise _Stop("message_box", "the message box already holds text; nothing typed, not sent")
        box.fill(message.text)  # exactly the approved text, as one value
        typed = str(box.evaluate(_READ_BOX_JS))
        if normalize_box_text(typed) != normalize_box_text(message.text):
            _clear(box)
            raise _Stop("read_back", "the text in yad2's message box differs from the approved text; "
                                     "cleared, not sent")
        button = self._send_button(page)
        if self.store is not None:  # the approval must still hold right before the click
            reason = check_approval(self.store.get_message(message.id), approval)
            if reason is not None:
                _clear(box)
                raise _Stop("approval", reason)
        before = int(page.evaluate(_BUBBLES_JS, message.text))
        pressed["send"] = True
        button.click()
        waited = 0.0
        while waited < CONFIRM_WAIT_S:
            page.wait_for_timeout(500)
            waited += 0.5
            if int(page.evaluate(_BUBBLES_JS, message.text)) > before:
                return SendResult("sent")
        log.warning("yad2 automatic send: step confirm failed (no sent bubble)")
        return SendResult("failed", error="send not confirmed (the text did not appear in the conversation) — "
                                          "it MAY have been sent; check your yad2 messages before drafting again "
                                          "[step: confirm]")

    def _check_page(self, page: Any, step: str, status: int | None) -> None:
        path = urlsplit(page.url).path.lower()
        if "/login" in path or "/auth" in path:
            raise _Relogin(step, "login")
        try:
            title = page.title()
        except Exception:
            title = ""
        kind = page_block(page.url, title, "", status, have_json=True)  # URL, title, status only
        if kind == "captcha":
            raise _Relogin(step, "captcha")
        if kind == "forbidden":
            raise _Forbidden("yad2: HTTP 403 on the listing page (blocked by the site)")

    def _contact_entry(self, page: Any) -> Any:
        for loc in (page.locator(_TESTID_ENTRY), page.get_by_role("button", name=CONTACT_NAME),
                    page.get_by_role("link", name=CONTACT_NAME)):
            for i in range(min(loc.count(), 10)):
                if loc.nth(i).is_visible():
                    return loc.nth(i)
        return None

    def _message_box(self, page: Any) -> Any:
        waited = 0.0
        while True:
            self._check_page(page, "message_box", None)
            state = page.evaluate(_CHAT_STATE_JS)
            if state["boxes"] == 1:
                return page.locator("[data-hf-box]").first
            if state["boxes"] > 1:
                raise _Stop("message_box", "more than one message box on the page; nothing typed")
            if state["password"] or any(w in str(state["dialogText"]).lower() for w in _LOGIN_WORDS):
                raise _Relogin("message_box", "login")
            if waited >= BOX_WAIT_S:
                raise _Stop("message_box", "no message box after pressing the contact button (layout changed?)")
            page.wait_for_timeout(250)
            waited += 0.25

    def _send_button(self, page: Any) -> Any:
        chat = page.locator("[data-hf-chat]")
        scope = chat.first if chat.count() else page
        for loc in (scope.get_by_role("button", name=SEND_NAME), scope.locator('button[type="submit"]'),
                    scope.locator('button[data-testid*="send" i], [role="button"][data-testid*="send" i]')):
            shown = [loc.nth(i) for i in range(min(loc.count(), 10)) if loc.nth(i).is_visible()]
            if len(shown) == 1:
                return shown[0]
            if len(shown) > 1:
                raise _Stop("send_button", "more than one send button in the chat; nothing sent")
        raise _Stop("send_button", "no send button in the chat (layout changed?)")


def _clear(box: Any) -> None:
    try:
        box.fill("")
    except Exception:  # best effort: the caller already refuses to send
        log.warning("yad2 automatic send: could not clear the message box")


def register_yad2_sender(registry: SenderRegistry, *, browser: Any, store: Store | None = None) -> None:
    """Register ``Yad2BrowserSender`` for ``("yad2", "browser")`` — done at
    startup when the yad2 login marker exists, and by Connect yad2. Used only
    while the owner's send mode for yad2 is ``browser``."""
    registry.register(YAD2_SOURCE, BROWSER,
                      lambda listing: Yad2BrowserSender(listing, browser=browser, store=store), replace=True)

"""Bring the tool's own Chromium window to the front (Windows only).

The installed app runs without a console, so Windows treats it as a
background process and refuses to put its windows in front: the Facebook
login window opened *behind* the owner's browser and looked like nothing
happened. ``show_tool_windows()`` finds the visible top-level windows whose
process runs a Chromium under playwright's browser folder (never the
owner's own Chrome or Edge), restores them and makes one the foreground
window. A no-op (returns 0) off Windows or when nothing matches.
"""

from __future__ import annotations

import logging
import os
import sys
from pathlib import Path

log = logging.getLogger(__name__)

SW_RESTORE = 9
VK_MENU = 0x12  # Alt: a key event lets a background process take the foreground
KEYEVENTF_KEYUP = 0x0002
PROCESS_QUERY_LIMITED_INFORMATION = 0x1000


def browsers_root() -> Path | None:
    """playwright's browser folder (``PLAYWRIGHT_BROWSERS_PATH``, pinned by
    ``config.pin_browsers_path()`` in the installed app), else its default."""
    raw = os.environ.get("PLAYWRIGHT_BROWSERS_PATH", "").strip()
    if raw and raw != "0":
        return Path(raw)
    base = os.environ.get("LOCALAPPDATA", "").strip()
    return Path(base) / "ms-playwright" if base else None


def is_tool_browser(image_path: str, root: Path | None) -> bool:
    """Whether a process image belongs to the tool's Chromium: under the
    browser folder (or a playwright ``.local-browsers`` folder)."""
    path = image_path.replace("/", "\\").lower()
    if root is not None and path.startswith(str(root).replace("/", "\\").lower().rstrip("\\") + "\\"):
        return True
    return "\\ms-playwright\\" in path or "\\.local-browsers\\" in path


def show_tool_windows() -> int:
    """Restore and raise the tool's Chromium windows; the number found."""
    if sys.platform != "win32":
        return 0
    try:
        return _show_windows()
    except Exception as exc:  # never break the login over a window nicety
        log.warning("could not bring the browser window to the front: %s", exc)
        return 0


def _show_windows() -> int:  # pragma: no cover - Windows only
    import ctypes
    from ctypes import wintypes

    user32 = ctypes.WinDLL("user32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    root = browsers_root()
    found: list[int] = []

    def image_of(hwnd: int) -> str:
        pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(wintypes.HWND(hwnd), ctypes.byref(pid))
        handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid.value)
        if not handle:
            return ""
        try:
            size = wintypes.DWORD(1024)
            buf = ctypes.create_unicode_buffer(size.value)
            ok = kernel32.QueryFullProcessImageNameW(handle, 0, buf, ctypes.byref(size))
            return buf.value if ok else ""
        finally:
            kernel32.CloseHandle(handle)

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def visit(hwnd, _lparam):
        if user32.IsWindowVisible(hwnd) and user32.GetWindowTextLengthW(hwnd) > 0:
            if is_tool_browser(image_of(hwnd), root):
                found.append(hwnd)
        return True

    user32.EnumWindows(visit, 0)
    for hwnd in found:
        user32.ShowWindow(hwnd, SW_RESTORE)
    if found:
        user32.keybd_event(VK_MENU, 0, 0, 0)
        user32.keybd_event(VK_MENU, 0, KEYEVENTF_KEYUP, 0)
        user32.BringWindowToTop(found[0])
        user32.SetForegroundWindow(found[0])
    log.info("brought %d browser window(s) to the front", len(found))
    return len(found)

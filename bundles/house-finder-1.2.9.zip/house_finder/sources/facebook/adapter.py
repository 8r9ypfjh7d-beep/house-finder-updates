"""``FacebookGroupsAdapter``: posts of the owner's readable groups -> Listings.

Reads the groups ``store.readable_fb_groups()`` returns — ``joined``
groups, and ``approved`` groups discovery saw as PUBLIC (public posts are
readable without joining) — through a ``PageProvider`` and turns each
offer post into a ``Listing`` with ``textparse``.

**Rotation** (owner report, v1.2.5: the 30-minute schedule read every group
each run, so the daily cap was gone after one run and every later run
reported every group "failed"): one ``fetch`` reads at most
``MAX_GROUPS_PER_RUN`` groups, least recently read first, never a group
sooner than ``MIN_READ_INTERVAL`` (rental-looking names) or
``OTHER_READ_INTERVAL`` (others) after its last read. A reached daily cap is
a normal state: the run returns what it read with a calm note. Each read is
recorded on the group (``store.record_fb_group_read``: counts and one plain
line for the groups page). Real failures raise ``SourceError`` with ONE
short sentence — never an empty list for a run that read nothing (VISION
priority 3), never a wall of per-group messages.
"""

from __future__ import annotations

import logging
import re
from collections import Counter
from collections.abc import Callable, Sequence
from datetime import date, datetime, timedelta, timezone
from typing import TYPE_CHECKING, Any

from pydantic import ValidationError

from house_finder.models import Contact, ContactChannel, Listing
from house_finder.sources.base import SourceBlocked, SourceError
from house_finder.sources.facebook.groups import issue_kind
from house_finder.sources.facebook.posts import (
    LISTING,
    NO_TEXT,
    NOT_LISTING,
    SEEKING,
    looks_rental,
    post_kind,
    read_problem,
)
from house_finder.sources.facebook.snapshots import GroupSnapshot, PostSnapshot
from house_finder.text import canonical_city, clean_post_text, normalize_place, safe_url
from house_finder.textparse import ParsedFields, parse_listing_text

if TYPE_CHECKING:
    from house_finder.profile import LocationArea, SearchProfile
    from house_finder.sources.facebook.provider import PageProvider
    from house_finder.store import FbGroup, Store

log = logging.getLogger(__name__)

SOURCE = "facebook"
DEFAULT_MAX_POSTS = 30
MAX_GROUPS_PER_RUN = 3
"""Groups read per collection (every 30 min): a person checking a few groups."""
MIN_READ_INTERVAL = timedelta(hours=3)
"""A rental-looking group is not read again sooner than this."""
OTHER_READ_INTERVAL = timedelta(hours=24)
"""A group whose name does not look like a rental group: at most once a day."""
SEE_GROUPS = "see Facebook groups"


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def group_city(group: FbGroup, areas: Sequence[LocationArea]) -> str | None:
    """The one city the group's ``discovered_query`` names (read with
    ``textparse``, so two cities or a neighborhood-only query give None)."""
    if not group.discovered_query:
        return None
    return parse_listing_text(group.discovered_query, locations=areas).city


def city_from_group(parsed: ParsedFields, group: FbGroup, areas: Sequence[LocationArea]) -> str | None:
    """The group's city for a post that names a neighborhood but no city —
    only when unambiguous: the group's query names exactly one city, the
    neighborhood is listed under that city in the profile, and under no
    other profile city. Else None."""
    if parsed.city is not None or parsed.neighborhood is None:
        return None
    city = group_city(group, areas)
    if city is None:
        return None
    hood = normalize_place(parsed.neighborhood)
    owners = {canonical_city(a.city) for a in areas
              if hood in {normalize_place(n) for n in a.neighborhoods}}
    return city if owners == {canonical_city(city)} else None


def _parse_time(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        t = datetime.fromisoformat(value)
    except ValueError:
        return None
    return t.replace(tzinfo=timezone.utc) if t.tzinfo is None else t


def _plural(n: int, one: str, many: str | None = None) -> str:
    return f"{n} {one if n == 1 else (many or one + 's')}"


def profile_places(areas: Sequence[LocationArea]) -> list[str]:
    """The profile's city and neighborhood names (``looks_rental`` hints)."""
    return [p for a in areas for p in (a.city, *a.neighborhoods) if p]


def read_interval(group: FbGroup, places: Sequence[str] = ()) -> timedelta:
    """How long after a read the group is due again."""
    return MIN_READ_INTERVAL if looks_rental(group.name, places) else OTHER_READ_INTERVAL


def reading_order(groups: Sequence[FbGroup], now: datetime,
                  places: Sequence[str] = ()) -> tuple[list[FbGroup], datetime | None]:
    """``(due groups in reading order, when the next not-due group is due)``.
    Never-read groups first, then the least recently read; rental-looking
    names before others at the same point. A group read less than its
    interval ago (``read_interval``) is not due."""
    due: list[tuple[tuple[bool, bool, str], FbGroup]] = []
    next_due: datetime | None = None
    for group in groups:
        rental = looks_rental(group.name, places)
        last = _parse_time(group.last_read_at)
        if last is not None:
            ready = last + (MIN_READ_INTERVAL if rental else OTHER_READ_INTERVAL)
            if ready > now:
                next_due = ready if next_due is None or ready < next_due else next_due
                continue
        due.append(((last is not None, not rental, group.last_read_at or ""), group))
    due.sort(key=lambda item: item[0])  # stable: ties keep the store's name order
    return [g for _, g in due], next_due


def read_note(stats: dict[str, Any]) -> str:
    """One plain line for a group's last read: "12 posts: 3 listings, 2
    looking for a place, 6 not apartments, 1 without text"."""
    posts = int(stats.get("posts", 0))
    if not posts:
        rejected = int(stats.get("rejected", 0))
        return ("no posts found on the page" + (f" ({_plural(rejected, 'post')} could not be read)"
                                                if rejected else ""))
    parts = [_plural(int(stats.get("listings", 0)), "listing")]
    for key, label in ((SEEKING, "looking for a place"), (NOT_LISTING, "not an apartment"),
                       (NO_TEXT, "without text"), ("unsafe", "with an unusable link")):
        n = int(stats.get(key, 0))
        if n:
            parts.append(f"{n} {label}" if key != NOT_LISTING else _plural(n, "not an apartment",
                                                                              "not apartments"))
    return f"{_plural(posts, 'post')}: " + ", ".join(parts)


class FacebookGroupsAdapter:
    """``SourceAdapter`` over the readable (joined, or approved + public) Facebook groups.

    ``warnings`` (reset per ``fetch``) holds ONE short summary sentence (the
    collector appends it to the health message). ``expected_empty`` is True
    when zero listings is a normal outcome of this run (groups read without
    an offer, nothing due, the daily cap) — the collector then records ``ok``,
    not ``empty``. ``counts`` holds the last run's totals.
    """

    name = SOURCE

    def __init__(
        self,
        provider: PageProvider,
        store: Store,
        *,
        max_posts: int = DEFAULT_MAX_POSTS,
        max_groups: int = MAX_GROUPS_PER_RUN,
        today: date | None = None,
        now: Callable[[], datetime] = _utc_now,
    ) -> None:
        self.provider = provider
        self.store = store
        self.max_posts = max_posts
        self.max_groups = max(1, int(max_groups))
        self.today = today
        self.now = now
        self.warnings: list[str] = []
        self.expected_empty = False
        self.counts: dict[str, int] = {}

    def fetch(self, profile: SearchProfile) -> list[Listing]:
        self.warnings = []
        self.expected_empty = False
        self.counts = dict.fromkeys(
            ("groups", "due", "read", "failed_groups", "posts", "listings", "discussion", "seeking",
             "no_text", "rejected", "unsafe_permalink"), 0)
        groups = self.store.readable_fb_groups()
        if not groups:
            raise SourceError("no joined or approved public Facebook groups")
        self.counts["groups"] = len(groups)
        areas = list(profile.locations)
        places = profile_places(areas)
        now = self.now()
        due, next_due = reading_order(groups, now, places)
        self.counts["due"] = len(due)
        if not due:
            wait = max(1, round(((next_due or now) - now).total_seconds() / 60))
            when = f"{wait} min" if wait < 90 else f"{round(wait / 60)} h"
            self.expected_empty = True
            self.warnings = [f"all {_plural(len(groups), 'group')} were read recently; next read in about {when}"]
            return []
        listings: dict[str, Listing] = {}
        failed: list[tuple[FbGroup, str]] = []
        attempted = 0
        cap_note: str | None = None
        for group in due[: self.max_groups]:
            try:
                snapshot = self._read(group.group_id)
            except SourceBlocked as exc:
                # Facebook refuses us: stop reading for this run (account safety).
                self._record(group, "blocked", read_problem(exc), {"detail": str(exc)[:300]})
                raise SourceBlocked(f"Facebook stopped the reading: {exc}",
                                    partial=list(listings.values())) from exc
            except Exception as exc:  # one failing group never stops the others
                kind = issue_kind(exc)
                if kind == "cap":  # a normal state, not a failure: nothing was loaded
                    cap_note = self._cap_note(exc)
                    break
                if kind == "logged_out":  # every group would fail the same way
                    raise SourceError("Facebook is not logged in in House Finder's window — press "
                                      "Connect Facebook", partial=list(listings.values())) from exc
                attempted += 1
                problem = read_problem(exc)
                failed.append((group, problem))
                self._record(group, "error", problem, {"detail": str(exc)[:300]})
                log.warning("facebook group %s: read failed (%s): %s", group.group_id, problem,
                            type(exc).__name__)
                continue
            attempted += 1
            for listing in self._listings(snapshot, group, areas):
                listings.setdefault(listing.id, listing)
        self.counts["read"] = attempted
        self.counts["failed_groups"] = len(failed)
        self.counts["listings"] = len(listings)
        read_ok = attempted - len(failed)
        failure = self._failure_sentence(failed)
        if attempted and not read_ok:
            raise SourceError(f"Facebook: {failure}", partial=list(listings.values()))
        if read_ok and self.counts["posts"] == 0 and self.counts["rejected"] == 0:
            # Readable groups have posts: reading none at all means the page
            # reader is broken, not that the groups are quiet (VISION 3).
            raise SourceError(f"Facebook: no posts could be read from {_plural(read_ok, 'group')} "
                              f"(page not recognised?) — {SEE_GROUPS}")
        summary = []
        if read_ok:
            summary.append(f"read {read_ok} of {_plural(len(groups), 'group')} "
                           f"({_plural(self.counts['posts'], 'post')}, "
                           f"{_plural(len(listings), 'listing')})")
        if failure:
            summary.append(failure)
        if cap_note:
            summary.append(cap_note)
        self.warnings = ["; ".join(summary)] if summary else []
        self.expected_empty = True  # this run's slice simply had no offer
        return list(listings.values())

    @staticmethod
    def _cap_note(exc: BaseException) -> str:
        m = re.search(r"(\d+)/(\d+)", str(exc))
        limit = f" ({m.group(2)} group reads)" if m else ""
        return f"daily Facebook reading limit reached{limit} — continues tomorrow"

    @staticmethod
    def _failure_sentence(failed: list[tuple[FbGroup, str]]) -> str:
        if not failed:
            return ""
        reasons = ", ".join(dict.fromkeys(problem for _, problem in failed))
        verb = "could not be read"
        return f"{_plural(len(failed), 'group')} {verb} ({reasons}) — {SEE_GROUPS}"

    def _record(self, group: FbGroup, status: str, note: str, stats: dict[str, Any]) -> None:
        try:
            self.store.record_fb_group_read(group.group_id, status, note=note, stats=stats,
                                            at=self.now().isoformat())
        except KeyError:  # removed meanwhile: nothing to record
            pass

    def _read(self, group_id: str) -> GroupSnapshot:
        raw: Any = self.provider.read_group(group_id, self.max_posts)
        if not isinstance(raw, GroupSnapshot):
            try:
                raw = GroupSnapshot.from_raw(raw)
            except (ValidationError, TypeError) as exc:
                raise SourceError(f"malformed group snapshot: {exc}") from None
        if raw.group_id != group_id:
            raise SourceError(f"provider returned group {raw.group_id}")
        return raw

    def _listings(self, snapshot: GroupSnapshot, group: FbGroup, areas: list[LocationArea]) -> list[Listing]:
        out: list[Listing] = []
        kinds: Counter[str] = Counter()
        unsafe = 0
        id_sources: Counter[str] = Counter()
        self.counts["rejected"] += snapshot.rejected_posts
        posts = snapshot.posts[: self.max_posts]
        for post in posts:
            self.counts["posts"] += 1
            id_sources[post.id_source or "given"] += 1
            text = clean_post_text(post.text)  # no decoy "Facebook" / action-bar lines
            parsed = parse_listing_text(text, today=self.today, locations=areas)
            kind = post_kind(text, parsed)
            kinds[kind] += 1
            if kind != LISTING:
                key = {SEEKING: "seeking", NO_TEXT: "no_text"}.get(kind, "discussion")
                self.counts[key] += 1
                continue
            url = safe_url(post.permalink)
            if not url:
                unsafe += 1
                self.counts["unsafe_permalink"] += 1
                continue
            out.append(self._to_listing(post, parsed, group, areas, url))
        stats: dict[str, Any] = {
            "posts": len(posts), "listings": len(out), SEEKING: kinds[SEEKING],
            NOT_LISTING: kinds[NOT_LISTING], NO_TEXT: kinds[NO_TEXT], "unsafe": unsafe,
            "rejected": snapshot.rejected_posts, "ids": dict(id_sources),
        }
        extraction = snapshot.extraction or {}
        for key in ("container", "lazy_links", "expanded", "containers"):
            if key in extraction:
                stats[key] = extraction[key]
        if snapshot.rejected_reasons:
            stats["rejected_reasons"] = [r[:120] for r in snapshot.rejected_reasons[:3]]
        self._record(group, "ok" if posts else "no_posts", read_note(stats), stats)
        # Counts and fallback names only: never post text or names in the log.
        log.info("facebook group %s: %d posts, %d listings, %d seeking, %d not listings, %d no text,"
                 " %d rejected; container=%s ids=%s", group.group_id, len(posts), len(out),
                 kinds[SEEKING], kinds[NOT_LISTING], kinds[NO_TEXT], snapshot.rejected_posts,
                 extraction.get("container", "-"), dict(id_sources))
        return out

    def _to_listing(
        self,
        post: PostSnapshot,
        parsed: ParsedFields,
        group: FbGroup,
        areas: list[LocationArea],
        url: str,
    ) -> Listing:
        evidence = dict(parsed.evidence)
        city = parsed.city
        if (filled := city_from_group(parsed, group, areas)) is not None:
            city = filled
            evidence["city"] = f"group search query: {group.discovered_query}"
        profile_url = safe_url(post.author_url) or None
        photos = list(dict.fromkeys(u for u in (safe_url(i) for i in post.image_urls) if u))
        posters = [u for u in dict.fromkeys(safe_url(i) for i in post.video_posters) if u and u not in photos]
        phones = list(dict.fromkeys(parsed.phones))
        return Listing(
            source=SOURCE,
            source_id=post.post_id,
            url=url,
            description=clean_post_text(post.text),
            price=parsed.price,
            city=city,
            neighborhood=parsed.neighborhood,
            rooms=parsed.rooms,
            sqm=parsed.sqm,
            floor=parsed.floor,
            property_type=parsed.property_type,
            move_in_date=parsed.move_in_date,
            move_in_immediate=parsed.move_in_immediate,
            lease_months=parsed.lease_months,
            attributes=dict(parsed.attributes),
            is_agent=parsed.is_agent,
            photos=photos,
            video_count=post.video_count,
            video_posters=posters,
            posted_at=post.posted_at,
            fetched_at=self.now(),
            contact=Contact(
                channel=ContactChannel.facebook_messenger,
                name=post.author_name or None,
                phone=phones[0] if len(phones) == 1 else None,
                profile_url=profile_url,
            ),
            language=parsed.language,
            raw={
                "group_id": group.group_id,
                "group_name": group.name,
                "post": post.model_dump(mode="json"),
                "post_link": post.has_post_link,  # False: the url is the group page
                "evidence": evidence,
            },
        )

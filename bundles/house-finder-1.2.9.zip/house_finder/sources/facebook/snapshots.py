"""Structured page snapshots handed over by a ``PageProvider``.

The browser layer (secure-sessions) extracts posts in-page and returns these
objects; this package never parses Facebook HTML. Snapshots are **untrusted
input**: every field is validated by pydantic, and ``GroupSnapshot.from_raw``
validates each post on its own so one malformed post is skipped and counted
(``rejected_posts``) instead of failing the whole group.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, ValidationError

# Facebook group ids are numeric or a slug; nothing that could be a path.
GROUP_ID_PATTERN = r"^[A-Za-z0-9][A-Za-z0-9._-]{0,99}$"
POST_ID_PATTERN = r"^[A-Za-z0-9][A-Za-z0-9:._-]{0,199}$"
MAX_TEXT = 20_000
MAX_URL = 2_000


class _Snapshot(BaseModel):
    model_config = ConfigDict(extra="ignore", str_strip_whitespace=True, frozen=True)


class PostSnapshot(_Snapshot):
    """One group post as the browser layer saw it. URLs are not yet checked
    with ``text.safe_url`` — the adapter does that."""

    group_id: str = Field(pattern=GROUP_ID_PATTERN)
    post_id: str = Field(pattern=POST_ID_PATTERN)
    permalink: str = Field(min_length=1, max_length=MAX_URL)
    author_name: str | None = Field(default=None, max_length=300)
    author_url: str | None = Field(default=None, max_length=MAX_URL)
    text: str = Field(default="", max_length=MAX_TEXT)
    posted_at: datetime | None = None
    image_urls: list[str] = Field(default_factory=list, max_length=50)
    video_count: int = Field(default=0, ge=0, le=50)
    video_posters: list[str] = Field(default_factory=list, max_length=50)
    id_source: str | None = Field(default=None, max_length=20)
    """Where ``post_id`` came from (browser provider): ``permalink`` /
    ``query`` / ``photo_set`` / ``pfbid`` / ``content`` (no link found: a
    stable hash of the post, ``permalink`` = the group page)."""

    @property
    def has_post_link(self) -> bool:
        """False when the post's own link was never found (``content`` id):
        the page then says "open the group" instead of linking a post."""
        return self.id_source != "content"


class GroupSearchResult(_Snapshot):
    """One group from a Facebook group search."""

    group_id: str = Field(pattern=GROUP_ID_PATTERN)
    name: str = Field(min_length=1, max_length=500)
    url: str = Field(default="", max_length=MAX_URL)
    member_count: int | None = Field(default=None, ge=0)
    description: str | None = Field(default=None, max_length=MAX_TEXT)


class GroupSnapshot(_Snapshot):
    """A group page: metadata plus its most recent posts.

    ``rejected_posts`` counts posts dropped by ``from_raw`` because they
    failed validation; ``rejected_reasons`` holds a short reason for each.
    """

    group_id: str = Field(pattern=GROUP_ID_PATTERN)
    name: str = Field(min_length=1, max_length=500)
    url: str = Field(default="", max_length=MAX_URL)
    member_count: int | None = Field(default=None, ge=0)
    privacy: str | None = Field(default=None, max_length=50)
    posts: list[PostSnapshot] = Field(default_factory=list)
    rejected_posts: int = Field(default=0, ge=0)
    rejected_reasons: list[str] = Field(default_factory=list)
    extraction: dict[str, Any] = Field(default_factory=dict)
    """How the browser read the page (counts and fallback names only, never
    text): ``container``, ``ids`` (id source -> posts), ``lazy_links``,
    ``expanded``. Logged and shown in the groups page's technical details."""

    @classmethod
    def from_raw(cls, data: Any) -> "GroupSnapshot":
        """Validate an untrusted dict. Group-level problems raise
        ``ValidationError``; each post is validated separately and a bad one
        (including a post claiming another group) is skipped and counted."""
        if not isinstance(data, dict):
            raise TypeError(f"group snapshot must be an object, not {type(data).__name__}")
        raw_posts = data.get("posts", [])
        if not isinstance(raw_posts, list):
            raise TypeError("group snapshot 'posts' must be a list")
        head = cls.model_validate({k: v for k, v in data.items()
                                   if k not in ("posts", "rejected_posts", "rejected_reasons")})
        posts: list[PostSnapshot] = []
        reasons: list[str] = []
        for i, raw in enumerate(raw_posts):
            try:
                post = PostSnapshot.model_validate(raw)
            except ValidationError as exc:
                first = exc.errors()[0]
                where = ".".join(str(p) for p in first.get("loc", ())) or "post"
                reasons.append(f"post #{i + 1}: {where}: {first.get('msg', 'invalid')}")
                continue
            if post.group_id != head.group_id:
                reasons.append(f"post #{i + 1}: belongs to group {post.group_id}")
                continue
            posts.append(post)
        return head.model_copy(update={"posts": posts, "rejected_posts": len(reasons),
                                       "rejected_reasons": reasons})

"""What a group post IS, and whether a group looks like a rental group.

Pure functions over text (no I/O), used by the adapter, discovery stats and
the groups page:

- ``post_kind(text, parsed)`` — ``listing`` (an apartment / room offered),
  ``seeking`` (someone LOOKING for a place: "מחפש דירה"), ``not_listing``
  (a question, a ticket sale, chatter) or ``no_text``. A missing price or
  room count never stops an offer from being a listing (matching shows
  ``unknown``); an offer needs a rental signal, so a ticket sale with a
  price is not an apartment.
- ``looks_rental(name, places)`` — a group name with a rental word or a city
  (the owner's own groups include ticket sales and chatter groups).
- ``read_problem(exc)`` — one plain phrase for a failed group read.
"""

from __future__ import annotations

import re
from collections.abc import Iterable

from house_finder.text import CITY_ALIASES, normalize_place
from house_finder.textparse import ParsedFields

LISTING, SEEKING, NOT_LISTING, NO_TEXT = "listing", "seeking", "not_listing", "no_text"
POST_KINDS: tuple[str, ...] = (LISTING, SEEKING, NOT_LISTING, NO_TEXT)

# Hebrew prefix letters (ו ה ב ל מ ש כ) before a word; edges are explicit
# because \b does not see Hebrew letters as word characters in every engine.
_P = "[והבלמשכ]{0,3}"
_EDGE_L = r"(?:^|(?<=[^\w֐-׿]))"
_EDGE_R = r"(?=$|[^\w֐-׿])"


def _words(*words: str) -> str:
    return "(?:" + "|".join(words) + ")"


_SEEK_VERB = _words("מחפש", "מחפשת", "מחפשים", "מחפשות", "מחפש/ת", "מחפש\\(ת\\)", "דרוש", "דרושה",
                    "דרושים", "אשמח למצוא", "צריך", "צריכה", "צריכים")
_SEEK_NOUN = _words("דירה", "דירת", "דירות", "חדר", "יחידת", "יחידה", "יח\"ד", "סטודיו", "מקום", "בית",
                    "סאבלט", "סבלט", "שכירות", "פנטהאוז", "דופלקס")
# "מחפשים שותף / דיירים / שוכרים" is a LANDLORD or flatmate offering a place.
_TENANT_NOUN = _words("שותף", "שותפה", "שותפים", "שותפות", "שותף/ה", "שותף\\(ה\\)", "דייר", "דיירת",
                      "דיירים", "דיירות", "שוכר", "שוכרת", "שוכרים", "מחליף", "מחליפה", "מחליפים",
                      "מחליף/ה")
_GAP = r"(?:\s+\S+){0,3}?\s+"
_HE_SEEKING = re.compile(_EDGE_L + _SEEK_VERB + _GAP + _P + _SEEK_NOUN + _EDGE_R)
_HE_TENANT_WANTED = re.compile(_EDGE_L + _SEEK_VERB + r"(?:\s+\S+){0,1}?\s+" + _P + _TENANT_NOUN + _EDGE_R)
_EN_SEEKING = re.compile(
    r"\b(?:looking for|searching for|in search of|iso|seeking|need|wanted)\b(?:\s+\S+){0,3}?\s+"
    r"(?:apartment|apt|flat|room|place|studio|sublet|housing|home|house)s?\b", re.IGNORECASE)
_EN_TENANT_WANTED = re.compile(
    r"\b(?:looking for|searching for|seeking|need|wanted)\b(?:\s+\S+){0,2}?\s+"
    r"(?:roommates?|flatmates?|housemates?|tenants?|subletters?|replacement)\b", re.IGNORECASE)

# An OFFER: the poster has a place (rent words, a move-in, a sublet).
_HE_OFFER = re.compile(_EDGE_L + _P + _words(
    "להשכרה", "השכרה", "להשכיר", "משכיר", "משכירה", "משכירים", "סאבלט", "סבלט", "מתפנה", "מתפנית",
    "מתפנים", "פנויה", "פנוי", "מפנה", "מפנים", "עוזבת", "עוזב", "עוזבים", "מוסר", "מוסרת", "מוסרים",
) + _EDGE_R)
_EN_OFFER = re.compile(r"\b(?:for rent|to rent out|for sublet|sublet(?:ting)?|available (?:from|now|for)"
                       r"|renting out|move[- ]in|lease)\b", re.IGNORECASE)
# A HOME is mentioned (for a price-only post: "6,000 ₪" alone could be a ticket).
_HE_HOME = re.compile(_EDGE_L + _P + _words(
    "דירה", "דירת", "דירות", "חדר", "חדרים", "יחידת", "יחידה", "יח\"ד", "סטודיו", "פנטהאוז", "דופלקס",
    "קוטג'", "בית", "נכס", "מרפסת", "מטבח", "סלון", "קומה") + _EDGE_R)
_EN_HOME = re.compile(r"\b(?:apartment|apt|flat|studio|room|rooms|bedroom|penthouse|duplex|house|unit"
                      r"|balcony|kitchen|floor)s?\b", re.IGNORECASE)

_MONTHLY = re.compile(r"לחודש|בחודש|חודשי|per month|a month|/month|monthly|p/m", re.IGNORECASE)


def _clean(text: str) -> str:
    # Facebook's "See more" and typographic quotes must not hide a word.
    return (text or "").replace("״", '"').replace("׳", "'").replace("‏", "").replace("‎", "")


def is_seeking(text: str) -> bool:
    """The poster is LOOKING for a place ("מחפשת דירה 3 חדרים", "looking for
    an apartment") — not a landlord or flatmate looking for a tenant
    ("מחפשים שותף לדירה", "looking for a roommate")."""
    s = _clean(text)
    seeking = bool(_HE_SEEKING.search(s) or _EN_SEEKING.search(s))
    if not seeking:
        return False
    first_seek = min((m.start() for m in (_HE_SEEKING.search(s), _EN_SEEKING.search(s)) if m))
    tenant = [m.start() for m in (_HE_TENANT_WANTED.search(s), _EN_TENANT_WANTED.search(s)) if m]
    offer = [m.start() for m in (_HE_OFFER.search(s), _EN_OFFER.search(s)) if m]
    # "Looking for a roommate" / "להשכרה ... מחפשים דיירים" before the seeking phrase: an offer.
    return not any(t <= first_seek for t in tenant + offer)


def post_kind(text: str | None, parsed: ParsedFields) -> str:
    """``listing`` / ``seeking`` / ``not_listing`` / ``no_text`` (see the
    module doc). An offer is a listing even with no price or rooms stated."""
    s = _clean(text or "").strip()
    if not s:
        return NO_TEXT
    if is_seeking(s):
        return SEEKING
    offer = bool(_HE_OFFER.search(s) or _EN_OFFER.search(s))
    home = bool(_HE_HOME.search(s) or _EN_HOME.search(s))
    has_facts = parsed.rooms is not None or parsed.property_type is not None
    moving = parsed.move_in_immediate or parsed.move_in_date is not None
    question = s.endswith("?") and len(s) < 200 and parsed.price is None and parsed.rooms is None
    if question:
        return NOT_LISTING  # "יש דירה להשכרה בפלורנטין?" asks, it does not offer
    monthly = parsed.price is not None and bool(_MONTHLY.search(s))  # "4500 ₪ לחודש": rent, not a ticket
    if has_facts or offer or monthly or (home and (parsed.price is not None or moving or parsed.sqm is not None)):
        return LISTING
    return NOT_LISTING


# --------------------------------------------------------------- group names

_RENTAL_NAME_WORDS = re.compile(
    _EDGE_L + _P + _words("דירות", "דירה", "דירת", "השכרה", "להשכרה", "שכירות", "שכירה", "שותפים",
                          "שותפות", "שותפ", "סאבלט", "סבלט", "סאבלטים", "יחידות דיור", "יחידת דיור", "נדל\"ן",
                          "מגורים", "דיור") + _EDGE_R
    + r"|\b(?:rent|rents|rental|rentals|renting|apartment|apartments|apt|apts|roommate|roommates"
      r"|flatmate|flatmates|sublet|sublets|flat|flats|housing|real estate)\b",
    re.IGNORECASE)


def looks_rental(name: str | None, places: Iterable[str] = ()) -> bool:
    """A group name that looks like a rental group: a rental word (Hebrew or
    English) or a city name (built-in aliases + the profile's cities and
    neighborhoods, ``places``). Only a hint for the owner and the reading
    order — never a reason to read or skip a group on its own."""
    s = _clean(name or "")
    if not s.strip():
        return False
    if _RENTAL_NAME_WORDS.search(s):
        return True
    norm = " " + normalize_place(s) + " "
    names = {a for aliases in CITY_ALIASES.values() for a in aliases} | {p for p in places if p}
    for place in names:
        key = normalize_place(place)
        if key and re.search(r"(?:^|\s)" + _P + re.escape(key) + r"(?=\s)", norm):
            return True
    return False


# ------------------------------------------------------------ read problems

def read_problem(exc: BaseException) -> str:
    """One plain phrase for why a group could not be read (the groups page and
    the one-sentence health message); the raw message stays in the details."""
    name = type(exc).__name__
    text = str(exc).lower()
    if name == "NotLoggedIn" or "not logged in" in text:
        return "Facebook is not logged in"
    if name == "TargetClosedError" or "has been closed" in text or "target closed" in text:
        return "the Facebook window was closed"
    if "no feed" in text or "not recognised" in text or "not understood" in text or "layout" in text:
        return "page not recognised"
    if "malformed" in text or "provider returned group" in text:
        return "page not understood"
    if "timeout" in text or "timed out" in text:
        return "Facebook did not answer in time"
    if "no fixture" in text:
        return "page not found"
    return "unexpected error"

"""``check-yad2``: one live check of yad2 (plain HTTP, then the browser
fallback) written to ``data/debug/yad2-report.txt`` for the owner to send.

The report holds **structure, never personal values**: status codes, final
URLs (query values kept only for the search filters; a bot validator's
``ss*`` tokens and every other value replaced), JSON shapes (keys and types
only — ``json_shape``), how many listings parsed, and for the first three
only price, rooms and city. No phone, name, street or description.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any
from urllib.parse import parse_qsl, quote, urlsplit

from house_finder.sources.base import SourceBlocked, SourceError
from house_finder.sources.yad2 import (
    MAP_URL,
    REQUEST_HEADERS,
    Yad2Adapter,
    find_payloads,
    parse_response,
    search_params,
)

if TYPE_CHECKING:
    from house_finder.models import Listing
    from house_finder.profile.profile import SearchProfile

REPORT_FILENAME = "yad2-report.txt"
# Query keys whose values are search filters (kept); every other value is replaced.
SAFE_QUERY_KEYS = frozenset({
    "city", "area", "topArea", "neighborhood", "minPrice", "maxPrice", "minRooms", "maxRooms",
    "price", "rooms", "page", "forceLdLoad", "property", "zoom", "region",
})
_LONG_DIGITS = re.compile(r"\d{7,}")
MAX_KEYS = 40


def redact_url(url: str) -> str:
    """``url`` without secrets: scheme, host and path, plus the query with
    only search-filter values (others become ``…``)."""
    try:
        parts = urlsplit(str(url))
    except ValueError:
        return "<unparseable url>"
    query = parse_qsl(parts.query, keep_blank_values=True)
    kept = [f"{quote(k)}={quote(v) if k in SAFE_QUERY_KEYS else '…'}" for k, v in query]
    path = _LONG_DIGITS.sub("<digits>", parts.path)
    base = f"{parts.scheme}://{parts.hostname or ''}{f':{parts.port}' if parts.port else ''}{path}"
    return base + ("?" + "&".join(kept) if kept else "")


def _key(key: Any) -> str:
    return _LONG_DIGITS.sub("<digits>", str(key))[:60]


def json_shape(value: Any, *, max_depth: int = 6, _depth: int = 0) -> Any:
    """Keys and types of a JSON value — never a value. Lists show their
    length and the shape of the first item."""
    if _depth > max_depth:
        return "…"
    if isinstance(value, dict):
        out = {_key(k): json_shape(v, max_depth=max_depth, _depth=_depth + 1)
               for k, v in list(value.items())[:MAX_KEYS]}
        if len(value) > MAX_KEYS:
            out["…"] = f"{len(value) - MAX_KEYS} more keys"
        return out
    if isinstance(value, list):
        if not value:
            return "list[0]"
        return [f"list[{len(value)}]", json_shape(value[0], max_depth=max_depth, _depth=_depth + 1)]
    if value is None:
        return "null"
    return type(value).__name__  # bool / int / float / str


def listing_summary(listing: Listing) -> str:
    """Price, rooms and city only — nothing that identifies a person or a door."""
    return f"price={listing.price} rooms={listing.rooms} city={listing.city}"


@dataclass
class Yad2Report:
    """The lines of one check; ``text()`` is the file's content."""

    lines: list[str] = field(default_factory=list)

    def add(self, line: str = "") -> None:
        self.lines.append(line)

    def text(self) -> str:
        return "\n".join(self.lines) + "\n"


def _stamp(now: datetime) -> str:
    return f"{now.astimezone(timezone.utc).isoformat(timespec='seconds')} (local {now.astimezone().isoformat(timespec='seconds')})"


def check_http(report: Yad2Report, client: Any, profile: SearchProfile, code: int,
               now: Callable[[], datetime]) -> bool:
    """One plain-HTTP request for one city; True when listings parsed."""
    params = search_params(profile, code)
    try:
        region = Yad2Adapter(client).region_for(code)
    except SourceError as exc:
        region = None
        report.add(f"[http] region lookup failed: {exc}")
    if region is not None:
        params["region"] = region
    report.add(f"[http] {_stamp(now())} GET {redact_url(MAP_URL)} params={params}")
    outcome, ok, body = "", False, None
    try:
        body = client.get_json(MAP_URL, params=params, headers=REQUEST_HEADERS)
        outcome = "ok (JSON)"
    except SourceBlocked as exc:
        outcome = f"BLOCKED: {exc}"
    except SourceError as exc:
        outcome = f"ERROR: {exc}"
    response = getattr(client, "last_response", None)
    if response is not None:
        hops = [*getattr(response, "history", []), response]
        report.add("[http] status chain: " + " -> ".join(
            f"{h.status_code} {redact_url(str(h.url))}" for h in hops))
        report.add(f"[http] content-type: {response.headers.get('content-type', '')}"
                   f" bytes={len(response.content)}")
    report.add(f"[http] outcome: {outcome}")
    if body is not None:
        report.add(f"[http] JSON shape: {json_shape(body)}")
        ok = _report_parse(report, "http", [body], now)
    return ok


def _report_parse(report: Yad2Report, label: str, bodies: list[Any],
                  now: Callable[[], datetime]) -> bool:
    listings: list[Listing] = []
    matched = 0
    for body in bodies:
        for payload in find_payloads(body):
            matched += 1
            try:
                found, _, count, errors = parse_response(payload, now())
            except SourceError as exc:
                report.add(f"[{label}] known shape but not parsed: {exc}")
                continue
            listings.extend(found)
            if errors:
                report.add(f"[{label}] skipped {len(errors)} of {count} items; first: {errors[0]}")
    if not matched:
        report.add(f"[{label}] no known listings shape in the JSON")
        return False
    report.add(f"[{label}] parsed listings: {len(listings)}")
    for listing in listings[:3]:
        report.add(f"[{label}]   {listing_summary(listing)}")
    return bool(listings)


def check_browser(report: Yad2Report, fetcher: Any, profile: SearchProfile, code: int,
                  now: Callable[[], datetime]) -> bool:
    """The browser fallback for one city; True when listings parsed."""
    report.add(f"[browser] {_stamp(now())} loading the search page")
    ok, outcome = False, ""
    try:
        result = fetcher.fetch(search_params(profile, code))
        outcome = f"ok: {len(result.listings)} listings from {', '.join(result.sources) or '?'}"
        ok = bool(result.listings)
    except SourceBlocked as exc:
        outcome = f"BLOCKED: {exc}"
        result = None
    except SourceError as exc:
        outcome = f"ERROR: {exc}"
        result = None
    capture = getattr(fetcher, "last_capture", None)
    if capture is not None:
        report.add(f"[browser] page status: {capture.status}  final url: {redact_url(capture.final_url) if capture.final_url else '(none)'}")
        report.add(f"[browser] title: {capture.title[:120]!r}")
        report.add(f"[browser] captcha seen: {capture.captcha}  solved: {capture.captcha_solved}")
        report.add(f"[browser] __NEXT_DATA__: {'present' if capture.next_data_shape is not None else 'absent'}")
        if capture.next_data_shape is not None:
            report.add(f"[browser] __NEXT_DATA__ shape: {capture.next_data_shape}")
        report.add(f"[browser] JSON responses captured: {len(capture.responses)}")
        for item in capture.responses:
            report.add(f"[browser]   {item.status} {item.url}")
            report.add(f"[browser]     shape: {item.shape}")
    report.add(f"[browser] outcome: {outcome}")
    if result is not None:
        for listing in result.listings[:3]:
            report.add(f"[browser]   {listing_summary(listing)}")
    return ok


def run_check(profile: SearchProfile, *, client: Any, fetcher: Any, out_path: Path | str,
              profile_note: str = "", now: Callable[[], datetime] | None = None) -> Yad2Report:
    """HTTP then the browser fallback for the profile's first city with a
    yad2 code; writes the report to ``out_path`` and returns it. Never
    raises for a site failure: the report says what happened."""
    clock = now or (lambda: datetime.now(timezone.utc))
    from house_finder.sources.yad2 import Yad2Adapter

    report = Yad2Report()
    report.add("House Finder — yad2 check")
    report.add(f"started: {_stamp(clock())}")
    if profile_note:
        report.add(f"profile: {profile_note}")
    queries = Yad2Adapter(client).queries(profile)
    if not queries:
        report.add("no profile city has a yad2 code: nothing checked")
    else:
        city, code = queries[0]
        report.add(f"city code: {code}")
        report.add("")
        http_ok = check_http(report, client, profile, code, clock)
        report.add("")
        if fetcher is None:
            browser_ok = False
            report.add("[browser] not available (playwright not installed)")
        else:
            browser_ok = check_browser(report, fetcher, profile, code, clock)
        report.add("")
        report.add(f"RESULT: http={'worked' if http_ok else 'failed'} "
                   f"browser={'worked' if browser_ok else 'failed' if fetcher else 'n/a'}")
    report.add(f"finished: {_stamp(clock())}")
    path = Path(out_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(report.text(), encoding="utf-8")
    return report

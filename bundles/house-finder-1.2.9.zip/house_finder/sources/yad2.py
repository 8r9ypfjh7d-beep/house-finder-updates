"""yad2 rental adapter.

One query per profile city (code from ``LocationArea.yad2_city_code`` or
``yad2_cities``), with the profile's price and rooms ranges, up to
``max_pages`` pages. Both known response shapes are parsed whichever
endpoint was called:

- current (``realestate-feed/rent/map``): ``data.markers[]``
- legacy (``feed-search-legacy/realestate/rent``): ``data.feed.feed_items[]``

Anything else raises ``SourceError`` — never an empty list.

When plain HTTP is blocked (``SourceBlocked``) and a ``browser_fetcher`` is
configured (``browser.Yad2BrowserFetcher``), that city is retried by loading
yad2's search page in a real browser and parsing the JSON the page itself
loads (``find_payloads`` + ``parse_response``). ``warnings`` names the path
that served each city. The shapes and
query parameters come from public descriptions of the API, not from a live
capture (the build machine cannot reach yad2); run
``house-finder collect --source yad2 --dump`` on the first live run and
compare ``data/debug/`` with ``tests/fixtures/yad2/``.
"""

from __future__ import annotations

import json
import re
from collections.abc import Callable
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal

from pydantic import ValidationError

from house_finder.models import Attribute, Contact, ContactChannel, Listing, PropertyType
from house_finder.sources.base import SourceBlocked, SourceError
from house_finder.sources.yad2_cities import yad2_city_code, yad2_region_code
from house_finder.text import normalize_place

if TYPE_CHECKING:
    from collections.abc import Iterator, Mapping

    from house_finder.net.http import ThrottledClient
    from house_finder.profile.profile import SearchProfile

SOURCE = "yad2"
SEARCH_URL = "https://www.yad2.co.il/realestate/rent"
MAP_URL = "https://gw.yad2.co.il/realestate-feed/rent/map"
LEGACY_URL = "https://gw.yad2.co.il/feed-search-legacy/realestate/rent"
ITEM_URL = "https://www.yad2.co.il/realestate/item/{token}"
REQUEST_HEADERS = {"Referer": "https://www.yad2.co.il/", "Origin": "https://www.yad2.co.il"}
YAD2_HOSTS = ("gw.yad2.co.il", "www.yad2.co.il")
DEFAULT_MAX_PAGES = 3

Endpoint = Literal["map", "legacy"]

# normalize_place(label) -> PropertyType. Unlisted labels map to None
# (unknown), never to a guess.
_PROPERTY_TYPES: dict[str, PropertyType] = {
    normalize_place(k): v
    for k, v in {
        "דירה": PropertyType.apartment,
        "apartment": PropertyType.apartment,
        "דירת גן": PropertyType.garden_apartment,
        "גג/פנטהאוז": PropertyType.penthouse,
        "פנטהאוז": PropertyType.penthouse,
        "דופלקס": PropertyType.duplex,
        "טריפלקס": PropertyType.duplex,
        "סטודיו/לופט": PropertyType.studio,
        "סטודיו": PropertyType.studio,
        "יחידת דיור": PropertyType.unit,
        "בית פרטי/קוטג'": PropertyType.house,
        "דו משפחתי": PropertyType.house,
        "משק חקלאי/נחלה": PropertyType.house,
        "חדר": PropertyType.room,
        "חדר בדירת שותפים": PropertyType.room,
        "מחסן": PropertyType.other,
        "חניה": PropertyType.other,  # parking spots are listed as rentals too
    }.items()
}

# Substrings of a normalised tag -> attribute (tag present => True).
_TAG_ATTRIBUTES: tuple[tuple[str, Attribute], ...] = (
    ("חניה", Attribute.parking),
    ("חנייה", Attribute.parking),
    ("מעלית", Attribute.elevator),
    ("מרפסת", Attribute.balcony),
    ("בעלי חיים", Attribute.pets_allowed),
    ("חיות מחמד", Attribute.pets_allowed),
    ("מרוהט", Attribute.furnished),
    ("ריהוט", Attribute.furnished),
    ("מיזוג", Attribute.air_conditioning),
    ("מזגן", Attribute.air_conditioning),
    ("ממד", Attribute.safe_room),
    ("מחסן", Attribute.storage),
    ("גישה לנכים", Attribute.accessible),
    ("נגיש", Attribute.accessible),
    ("משופץ", Attribute.renovated),  # masculine (final tsadi)
    ("משופצ", Attribute.renovated),  # משופצת / משופצים
    ("renovated", Attribute.renovated),
)
_NEGATIONS = ("ללא", "אין", "בלי")
_LEGACY_TYPES = frozenset({"ad", "advanced_ad"})  # item types seen in a legacy feed

_DIGITS = re.compile(r"\d+")
_SIGNED_INT = re.compile(r"-?\d+")
_NUMBER = re.compile(r"\d+(?:\.\d+)?")

try:  # Israel local time for yad2's naive timestamps
    from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

    try:
        _ISRAEL_TZ: Any = ZoneInfo("Asia/Jerusalem")
    except ZoneInfoNotFoundError:  # Windows without the tzdata package
        _ISRAEL_TZ = timezone(timedelta(hours=2), "IST")
except ImportError:  # pragma: no cover
    _ISRAEL_TZ = timezone(timedelta(hours=2), "IST")


# ------------------------------------------------------------------ helpers


def _text(value: Any) -> str | None:
    """A yad2 label: ``{"text": ...}`` or a plain string; blank -> None."""
    if isinstance(value, dict):
        value = value.get("text")
    if value is None:
        return None
    s = str(value).strip()
    return s or None


def _dig(obj: Any, *path: str) -> Any:
    for key in path:
        if not isinstance(obj, dict):
            return None
        obj = obj.get(key)
    return obj


def parse_price(value: Any) -> int | None:
    """``5500`` / ``"5,500 ₪"`` -> 5500; no digits (e.g. "לא צוין מחיר") -> None."""
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, (int, float)):
        return int(value) if value > 0 else None
    digits = "".join(_DIGITS.findall(str(value)))
    return int(digits) if digits and int(digits) > 0 else None


def parse_float(value: Any) -> float | None:
    """``3.5`` / ``"3.5"`` / ``"3.5 חדרים"`` -> 3.5."""
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    m = _NUMBER.search(str(value))
    return float(m.group()) if m else None


def parse_int(value: Any) -> int | None:
    """``80`` / ``"80"`` / ``"80 מ\"ר"`` -> 80."""
    f = parse_float(value)
    return int(f) if f is not None else None


def parse_floor(value: Any) -> int | None:
    """``2`` / ``"קומה 2"`` -> 2; ground floor (קרקע) -> 0; basement (מרתף) -> -1."""
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, int):
        return value
    s = normalize_place(str(value))
    if "קרקע" in s or "ground" in s:
        return 0
    if "מרתף" in s or "basement" in s:
        return -1
    m = _SIGNED_INT.search(s)
    return int(m.group()) if m else None


def parse_entry_date(value: Any) -> tuple[date | None, bool]:
    """``date_of_entry`` -> (date, immediate). "מיידי"/"immediate" -> (None, True);
    ``YYYY-MM-DD[...]`` or ``DD/MM/YYYY`` -> (date, False); else (None, False)."""
    if not value:
        return None, False
    s = str(value).strip()
    if "מיידי" in s or "immediate" in s.casefold():
        return None, True
    for fmt, part in (("%Y-%m-%d", s[:10]), ("%d/%m/%Y", s[:10])):
        try:
            return datetime.strptime(part, fmt).date(), False
        except ValueError:
            continue
    return None, False


def parse_posted(value: Any) -> datetime | None:
    """``"2026-10-08 14:23:11"`` (Israel local time) -> aware datetime."""
    if not value:
        return None
    s = str(value).strip().replace("T", " ")
    for fmt, width in (("%Y-%m-%d %H:%M:%S", 19), ("%Y-%m-%d %H:%M", 16), ("%Y-%m-%d", 10)):
        try:
            parsed = datetime.strptime(s[:width], fmt)
        except ValueError:
            continue
        return parsed.replace(tzinfo=_ISRAEL_TZ)
    return None


def parse_property_type(label: str | None) -> PropertyType | None:
    """yad2 property label -> ``PropertyType``; unknown label -> None."""
    return _PROPERTY_TYPES.get(normalize_place(label)) if label else None


def tags_to_attributes(tags: Any) -> dict[Attribute, bool]:
    """yad2 ``tags[]`` (strings or ``{"name"|"text": ...}``) -> attributes.

    A tag such as "חניה" sets True; "ללא חניה" sets False. Attributes no tag
    mentions stay absent (unknown).
    """
    out: dict[Attribute, bool] = {}
    if not isinstance(tags, list):
        return out
    for tag in tags:
        label = tag.get("name") or tag.get("text") if isinstance(tag, dict) else tag
        s = normalize_place(str(label)) if label else ""
        if not s:
            continue
        negated = any(s.startswith(n + " ") for n in _NEGATIONS)
        for needle, attr in _TAG_ATTRIBUTES:
            if needle in s:
                out[attr] = not negated
    return out


def _photos(*sources: Any) -> list[str]:
    """Collect image URLs from strings, lists, ``{"src"|"url": ...}`` and dicts of those."""
    out: list[str] = []

    def add(item: Any) -> None:
        if isinstance(item, str):
            if item.startswith("http") and item not in out:
                out.append(item)
        elif isinstance(item, dict):
            if "src" in item or "url" in item:
                add(item.get("src") or item.get("url"))
            else:
                for v in item.values():
                    add(v)
        elif isinstance(item, list):
            for v in item:
                add(v)

    for src in sources:
        add(src)
    return out


def _join(*parts: Any) -> str | None:
    text = " ".join(str(p).strip() for p in parts if p not in (None, "") and str(p).strip())
    return text or None


# ------------------------------------------------------------- shape parsing


def detect_shape(payload: Any) -> Literal["map", "legacy"]:
    """Which known shape ``payload`` is; ``SourceError`` for anything else."""
    data = payload.get("data") if isinstance(payload, dict) else None
    if isinstance(data, dict):
        if isinstance(data.get("markers"), list):
            return "map"
        feed = data.get("feed")
        if isinstance(feed, dict) and isinstance(feed.get("feed_items"), list):
            return "legacy"
    if isinstance(payload, dict):
        keys = sorted(payload)
        detail = f"{keys}"
        if isinstance(data, dict):
            detail += f"; data keys {sorted(data)}"
    else:
        detail = type(payload).__name__
    raise SourceError(f"unrecognized yad2 response shape: {detail}")


def find_payloads(value: Any, *, max_depth: int = 8, _depth: int = 0) -> Iterator[Any]:
    """Every object inside ``value`` (a JSON body or ``__NEXT_DATA__``) that
    ``parse_response`` accepts: one of the known shapes itself, or its
    ``data`` part (``{"markers": [...]}`` / ``{"feed": {"feed_items": [...]}}``,
    as a page's state may hold it), wrapped as ``{"data": ...}``. A match is
    not searched further inside."""
    if _depth > max_depth:
        return
    if isinstance(value, dict):
        data = value.get("data")
        if isinstance(data, dict) and (
            isinstance(data.get("markers"), list)
            or (isinstance(data.get("feed"), dict) and isinstance(data["feed"].get("feed_items"), list))
        ):
            yield value
            return
        if isinstance(value.get("markers"), list) or (
            isinstance(value.get("feed"), dict) and isinstance(value["feed"].get("feed_items"), list)
        ):
            yield {"data": value}
            return
        children: list[Any] = list(value.values())
    elif isinstance(value, list):
        children = value[:200]
    else:
        return
    for child in children:
        yield from find_payloads(child, max_depth=max_depth, _depth=_depth + 1)


class BrowserFallbackUnavailable(SourceError):
    """The browser fallback cannot run now (no browser, or today's page cap is
    used up). With plain HTTP already blocked the adapter reports a block."""


def parse_marker(marker: dict[str, Any], fetched_at: datetime) -> Listing:
    """One current-shape ``data.markers[]`` item -> ``Listing``."""
    token = marker.get("token")
    if not token:
        raise ValueError("marker has no token")
    address = marker.get("address") or {}
    details = marker.get("additionalDetails") or {}
    meta = marker.get("metaData") or {}
    house = address.get("house") or {}
    coords = address.get("coords") or {}
    property_label = _text(details.get("property"))
    street = _text(address.get("street"))
    ad_type = str(marker.get("adType") or "").casefold()
    return Listing(
        source=SOURCE,
        source_id=str(token),
        url=ITEM_URL.format(token=token),
        title=_join(property_label and f"{property_label},", street, house.get("number")),
        price=parse_price(marker.get("price")),
        city=_text(address.get("city")),
        neighborhood=_text(address.get("neighborhood")),
        street=street,
        lat=parse_float(coords.get("lat")),
        lon=parse_float(coords.get("lon")),
        rooms=parse_float(details.get("roomsCount")),
        sqm=parse_int(details.get("squareMeter")),
        floor=parse_floor(house.get("floor")),
        property_type=parse_property_type(property_label),
        attributes=tags_to_attributes(marker.get("tags")),
        is_agent={"private": False, "agency": True, "commercial": True}.get(ad_type),
        photos=_photos(meta.get("coverImage"), meta.get("images")),
        fetched_at=fetched_at,
        contact=Contact(channel=ContactChannel.yad2),
        language="he",
        raw=marker,
    )


def parse_feed_item(item: dict[str, Any], fetched_at: datetime) -> Listing:
    """One legacy-shape ``data.feed.feed_items[]`` ad -> ``Listing``."""
    token = item.get("link_token") or item.get("id")
    if not token:
        raise ValueError("feed item has no link_token / id")
    move_in, immediate = parse_entry_date(item.get("date_of_entry"))
    coords = item.get("coordinates") or {}
    merchant = item.get("merchant")
    property_label = _text(item.get("HomeTypeID_text"))
    rooms = item.get("Rooms_text")
    if rooms in (None, ""):
        rooms = item.get("rooms")
    return Listing(
        source=SOURCE,
        source_id=str(token),
        url=ITEM_URL.format(token=token),
        title=_text(item.get("title_1")) or _join(item.get("street"), item.get("address_home_number")),
        description=_text(item.get("info_text")) or "",
        price=parse_price(item.get("price")),
        city=_text(item.get("city")),
        neighborhood=_text(item.get("neighborhood")),
        street=_text(item.get("street")),
        lat=parse_float(coords.get("latitude")),
        lon=parse_float(coords.get("longitude")),
        rooms=parse_float(rooms),
        sqm=parse_int(item.get("square_meters")),
        floor=parse_floor(item.get("Floor_text")),
        property_type=parse_property_type(property_label),
        move_in_date=move_in,
        move_in_immediate=immediate,
        attributes=tags_to_attributes(item.get("tags")),
        is_agent=bool(merchant) if isinstance(merchant, (bool, int)) else None,
        photos=_photos(item.get("images"), item.get("images_urls")),
        posted_at=parse_posted(item.get("date_added")),
        fetched_at=fetched_at,
        contact=Contact(channel=ContactChannel.yad2, name=_text(item.get("contact_name"))),
        language="he",
        raw=item,
    )


def _last_page(data: dict[str, Any]) -> int | None:
    pagination = data.get("pagination")
    if not isinstance(pagination, dict):
        return None
    for key in ("last_page", "lastPage", "total_pages", "totalPages"):
        value = parse_int(pagination.get(key))
        if value is not None:
            return value
    return None


def parse_response(
    payload: Any, fetched_at: datetime
) -> tuple[list[Listing], int | None, int, list[str]]:
    """Parse one yad2 response of either known shape.

    Returns ``(listings, last_page, item_count, errors)``: ``item_count`` is
    the number of listing items in the response and ``errors`` one message
    per item that could not be parsed. Raises ``SourceError`` for an unknown
    shape, or when the response has items and none of them parse.
    """
    shape = detect_shape(payload)
    data = payload["data"]
    if shape == "map":
        # Rentals are ``markers`` (private) plus ``agencyPromotions`` (agency
        # ads, adType "commercial"). ``yad1Markers`` (new-build projects),
        # ``grayMarkers`` (public buildings) and ``clusters`` are not flats.
        raw_items = list(data["markers"]) + [
            m for m in (data.get("agencyPromotions") or []) if isinstance(m, dict)
        ]
        items = [m for m in raw_items if isinstance(m, dict)]
        parse = parse_marker
    else:
        raw_items = data["feed"]["feed_items"]
        items = [i for i in raw_items if isinstance(i, dict) and i.get("type") == "ad"]
        # Known non-listing entries (promotions) may be all a page holds; any
        # other item type means we do not understand the feed.
        recognised = [
            i for i in raw_items if isinstance(i, dict) and i.get("type") in _LEGACY_TYPES
        ]
        if raw_items and not recognised:
            raise SourceError(
                f"unrecognized yad2 legacy feed items (none of {len(raw_items)} has type 'ad'): "
                f"{sorted({str(i.get('type')) if isinstance(i, dict) else type(i).__name__ for i in raw_items})}"
            )
        parse = parse_feed_item
        data = {**data, **data["feed"]}  # legacy keeps pagination under data.feed too
    if shape == "map" and raw_items and not items:
        raise SourceError(f"unrecognized yad2 markers: none of {len(raw_items)} is an object")
    listings: list[Listing] = []
    errors: list[str] = []
    for item in items:
        try:
            listings.append(parse(item, fetched_at))
        except (ValueError, ValidationError, TypeError) as exc:
            errors.append(f"{type(exc).__name__}: {str(exc).splitlines()[0]}")
    if items and not listings:
        raise SourceError(
            f"could not parse any of {len(items)} yad2 {shape} items; first error: {errors[0]}"
        )
    return listings, _last_page(data), len(items), errors


# ------------------------------------------------------------------- adapter


DISCOVER_REGIONS = tuple(range(1, 9))
REGION_MISS_DAYS = 1


def _has_city(payload: Any, code: int) -> bool:
    """Whether a map response holds any listing in city ``code``; an
    unrecognized response raises (``detect_shape``), never reads as empty."""
    detect_shape(payload)
    data = payload["data"]
    items = list(data.get("markers") or []) + list(data.get("agencyPromotions") or [])
    return any(parse_int(_dig(m, "address", "city", "id")) == code for m in items)


def _range(lo: float | None, hi: float | None) -> str:
    def fmt(v: float | None) -> str:
        if v is None:
            return "-1"
        return str(int(v)) if float(v).is_integer() else str(v)

    return f"{fmt(lo)}-{fmt(hi)}"


def search_params(profile: SearchProfile, code: int) -> dict[str, Any]:
    """The current API's (and the search page's) query for one city, page 1:
    ``city``, ``minPrice``, ``maxPrice``, ``minRooms``, ``maxRooms``."""
    params: dict[str, Any] = {"city": code}
    for key, value in (
        ("minPrice", profile.price_min),
        ("maxPrice", profile.price_max),
        ("minRooms", profile.rooms_min),
        ("maxRooms", profile.rooms_max),
    ):
        if value is not None:
            params[key] = int(value) if float(value).is_integer() else value
    return params


class Yad2Adapter:
    """yad2 rentals through a ``ThrottledClient``.

    ``endpoint`` picks which URL is requested (``"map"`` = current,
    ``"legacy"``); the parser accepts either shape from either. ``now``
    supplies ``fetched_at`` (tests pass a fixed clock). After ``fetch``,
    ``warnings`` lists skipped areas, unparseable items and — when a
    ``browser_fetcher`` is set — which path (``http`` / ``browser``) served
    each city.

    ``browser_fetcher`` (optional, ``browser.Yad2BrowserFetcher``): used only
    after plain HTTP raised ``SourceBlocked``; for that city and every later
    one in the same run (HTTP is not retried after a block). A plain
    ``SourceError`` from HTTP never falls back: it is a bug to see.

    The map endpoint needs a ``region`` next to ``city``. It comes from the
    verified table (``yad2_region_code``), else ``region_cache`` (JSON
    ``{"city code": region}``), else discovery: regions 1..8 are asked once
    and the first whose listings are in that city is cached.
    """

    name = SOURCE

    def __init__(
        self,
        client: ThrottledClient,
        *,
        max_pages: int = DEFAULT_MAX_PAGES,
        endpoint: Endpoint = "map",
        now: Callable[[], datetime] | None = None,
        browser_fetcher: Any = None,
        region_cache: Path | None = None,
    ) -> None:
        if endpoint not in ("map", "legacy"):
            raise ValueError(f"unknown yad2 endpoint: {endpoint!r}")
        self.client = client
        self.max_pages = max(1, int(max_pages))
        self.endpoint = endpoint
        self._now = now or (lambda: datetime.now(timezone.utc))
        self.browser_fetcher = browser_fetcher
        self.region_cache = region_cache
        self.warnings: list[str] = []

    def queries(self, profile: SearchProfile) -> list[tuple[str, int]]:
        """``(city, code)`` per profile area with a known code (deduplicated
        by code); areas without one are added to ``warnings``."""
        out: list[tuple[str, int]] = []
        seen: set[int] = set()
        for area in profile.locations:
            code = area.yad2_city_code or yad2_city_code(area.city)
            if code is None:
                self.warnings.append(
                    f"skipped area {area.city!r}: no yad2 city code "
                    "(set yad2_city_code for it in the profile)"
                )
                continue
            if code not in seen:
                seen.add(code)
                out.append((area.city, code))
        return out

    def params(
        self, profile: SearchProfile, code: int, page: int, region: int | None = None
    ) -> dict[str, Any]:
        """Query parameters for one city and page (``region``: map endpoint)."""
        if self.endpoint == "legacy":
            params: dict[str, Any] = {"city": code, "page": page, "forceLdLoad": "true"}
            if profile.price_min is not None or profile.price_max is not None:
                params["price"] = _range(profile.price_min, profile.price_max)
            if profile.rooms_min is not None or profile.rooms_max is not None:
                params["rooms"] = _range(profile.rooms_min, profile.rooms_max)
            return params
        params = search_params(profile, code)
        if region is not None:
            params["region"] = region
        if page > 1:
            params["page"] = page
        return params

    def _read_cache(self) -> dict[str, Any]:
        if self.region_cache is None or not self.region_cache.exists():
            return {}
        try:
            data = json.loads(self.region_cache.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}  # a bad cache only costs a re-discovery
        return data if isinstance(data, dict) else {}

    def _write_cache(self, update: Callable[[dict[str, Any]], None]) -> None:
        if self.region_cache is None:
            return
        data = self._read_cache()  # re-read: another run may have added a city
        update(data)
        try:
            self.region_cache.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.region_cache.with_name(self.region_cache.name + ".tmp")
            tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
            tmp.replace(self.region_cache)
        except OSError as exc:
            self.warnings.append(f"could not save the yad2 region cache: {exc}")

    def region_for(self, code: int) -> int | None:
        """yad2 region id for a city code: the verified table, the cache, else
        discovered (regions 1..8, first one with a listing in that city).
        None = no region had a listing in it (nothing to fetch now); that is
        remembered for ``REGION_MISS_DAYS`` so it costs 8 requests once a day."""
        region = yad2_region_code(code)
        if region is not None:
            return region
        cached = self._read_cache()
        if isinstance(cached.get(str(code)), int):
            return cached[str(code)]
        missed = (cached.get("misses") or {}).get(str(code))
        today = self._now().date()
        if isinstance(missed, str):
            try:
                if today - date.fromisoformat(missed) < timedelta(days=REGION_MISS_DAYS):
                    return None
            except ValueError:
                pass
        for candidate in DISCOVER_REGIONS:
            payload = self.client.get_json(
                MAP_URL, params={"city": code, "region": candidate}, headers=REQUEST_HEADERS
            )
            if _has_city(payload, code):
                def found(data: dict[str, Any], c: int = candidate) -> None:
                    data[str(code)] = c
                    (data.get("misses") or {}).pop(str(code), None)
                self._write_cache(found)
                return candidate

        def miss(data: dict[str, Any]) -> None:
            misses = data.get("misses") if isinstance(data.get("misses"), dict) else {}
            misses[str(code)] = today.isoformat()
            data["misses"] = misses
        self._write_cache(miss)
        return None

    def fetch(self, profile: SearchProfile) -> list[Listing]:
        """Listings for every profile city. Raises ``SourceError`` (with
        ``partial`` = listings from cities already fetched) or
        ``SourceBlocked``; returns ``[]`` only for well-formed empty results."""
        self.warnings = []
        if not profile.locations:
            raise SourceError("profile has no locations; yad2 needs at least one city")
        queries = self.queries(profile)
        if not queries:
            raise SourceError(
                "no profile location has a yad2 city code: "
                + ", ".join(repr(a.city) for a in profile.locations)
                + " (set yad2_city_code in the profile)"
            )
        found: dict[str, Listing] = {}
        http_blocked: SourceBlocked | None = None
        for city, code in queries:
            try:
                if http_blocked is None:
                    try:
                        self._fetch_city(profile, city, code, found)
                    except SourceBlocked as exc:
                        if self.browser_fetcher is None:
                            raise
                        http_blocked = exc
                    else:
                        if self.browser_fetcher is not None:
                            self.warnings.append(f"{city}: served by http")
                        continue
                self._fetch_city_browser(profile, city, code, found, http_blocked)
            except SourceError as exc:
                raise type(exc)(
                    f"{city} (city {code}): {exc}", partial=list(found.values())
                ) from exc
        return list(found.values())

    def _fetch_city_browser(
        self, profile: SearchProfile, city: str, code: int, found: dict[str, Listing],
        http_blocked: SourceBlocked,
    ) -> None:
        try:
            result = self.browser_fetcher.fetch(search_params(profile, code))
        except BrowserFallbackUnavailable as exc:
            raise SourceBlocked(f"{http_blocked}; browser fallback unavailable: {exc}") from exc
        except SourceBlocked as exc:
            raise SourceBlocked(f"{http_blocked}; browser: {exc}") from exc
        except SourceError as exc:
            raise SourceError(f"http blocked ({http_blocked}); browser: {exc}") from exc
        if result.errors:
            self.warnings.append(
                f"{city} (browser): skipped {len(result.errors)} of {result.item_count} items "
                f"({result.errors[0]})"
            )
        for listing in result.listings:
            found.setdefault(listing.id, listing)
        self.warnings.append(f"{city}: served by the browser (http blocked)")

    def _fetch_city(
        self, profile: SearchProfile, city: str, code: int, found: dict[str, Listing]
    ) -> None:
        url = LEGACY_URL if self.endpoint == "legacy" else MAP_URL
        region = None
        if self.endpoint == "map":
            region = self.region_for(code)
            if region is None:
                self.warnings.append(
                    f"{city}: no yad2 region has listings in city {code} right now "
                    f"(checked again after {REGION_MISS_DAYS} day)"
                )
                return
        for page in range(1, self.max_pages + 1):
            payload = self.client.get_json(
                url, params=self.params(profile, code, page, region), headers=REQUEST_HEADERS
            )
            listings, last_page, count, errors = parse_response(payload, self._now())
            if errors:
                self.warnings.append(
                    f"{city} page {page}: skipped {len(errors)} of {count} items ({errors[0]})"
                )
            for listing in listings:
                found.setdefault(listing.id, listing)
            if count == 0 or last_page is None or page >= last_page:
                return

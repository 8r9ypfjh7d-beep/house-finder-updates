"""yad2 ad details: the ad's own page data (``realestate-item/<token>``).

The map API the adapter reads has no ad text. The item endpoint (verified
live 2026-10-20 with the app's own ``ThrottledClient``: 200 JSON, no
captcha) has the advertiser's free text (``metaData.description``) plus a
few facts the map lacks. ``parse_item`` turns it into ``Listing`` field
values — pure, no I/O; ``fetch_item`` is the one HTTP call (through the
shared client). The advertiser's phone (``/customer``) is never fetched.

Structured values win over what ``textparse`` reads from the text; the
caller merges the result with ``models.fill_unknown`` (a fact the listing
already states always wins).
"""

from __future__ import annotations

from datetime import date
from typing import TYPE_CHECKING, Any

from house_finder.models import Attribute
from house_finder.sources.base import SourceError
from house_finder.sources.yad2 import (
    REQUEST_HEADERS,
    _dig,
    _text,
    parse_entry_date,
    parse_float,
    parse_floor,
    parse_int,
    parse_posted,
    parse_price,
    parse_property_type,
)
from house_finder.textparse import parse_listing_text

if TYPE_CHECKING:  # net imports sources.base: no runtime import (cycle)
    from collections.abc import Iterable

    from house_finder.net import ThrottledClient
    from house_finder.profile.profile import LocationArea

DETAILS_URL = "https://gw.yad2.co.il/realestate-item/{token}"
GONE_STATUSES = (404, 410)

# Exact ``inProperty`` keys -> attribute. Only a TRUE value is taken: an
# unticked box on yad2's form means "not stated", not "no" (a False would
# fail a must-have on a guess). Unlisted keys are ignored, never guessed.
# ``includeSecurityRoom`` was seen live; the others are yad2's form names.
IN_PROPERTY_ATTRIBUTES: dict[str, Attribute] = {
    "includeSecurityRoom": Attribute.safe_room,
    "includeElevator": Attribute.elevator,
    "includeParking": Attribute.parking,
    "includeBalcony": Attribute.balcony,
    "includeAirconditioner": Attribute.air_conditioning,
    "includeAirConditioner": Attribute.air_conditioning,
    "includeFurniture": Attribute.furnished,
    "includeWarhouse": Attribute.storage,  # yad2's spelling
    "includeWarehouse": Attribute.storage,
    "includeAccessibility": Attribute.accessible,
    "isPetsAllowed": Attribute.pets_allowed,
    "includePets": Attribute.pets_allowed,
    "isRenovated": Attribute.renovated,
}
_KNOWN_KEYS = frozenset({"token", "adNumber", "orderId", "metaData", "additionalDetails",
                         "inProperty", "dates", "address", "price"})
# textparse fields that may fill what the structured data leaves unknown.
_TEXT_FIELDS = ("price", "rooms", "sqm", "floor", "property_type", "move_in_date",
                "move_in_immediate", "lease_months", "is_agent")


def item_data(payload: Any, token: str | None = None) -> dict[str, Any]:
    """The ``data`` object of an item response; ``SourceError`` for any
    other shape (fail loudly) or a different ad's token."""
    data = payload.get("data") if isinstance(payload, dict) else None
    if not isinstance(data, dict) or not (_KNOWN_KEYS & data.keys()):
        keys = sorted(payload)[:10] if isinstance(payload, dict) else type(payload).__name__
        inner = sorted(data)[:10] if isinstance(data, dict) else type(data).__name__
        raise SourceError(f"unrecognized yad2 item shape: {keys} / data: {inner}")
    got = data.get("token")
    if token is not None and got is not None and str(got) != str(token):
        raise SourceError(f"yad2 item answered for another ad ({got!r}, asked {token!r})")
    description = _dig(data, "metaData", "description")
    if description is not None and not isinstance(description, str):
        raise SourceError(f"yad2 item: metaData.description is {type(description).__name__}, not text")
    return data


def structured_fields(data: dict[str, Any]) -> dict[str, Any]:
    """Facts from the item's structured parts (JSON-able ``Listing`` values;
    absent = unknown)."""
    out: dict[str, Any] = {}
    details = data.get("additionalDetails") if isinstance(data.get("additionalDetails"), dict) else {}
    in_property = data.get("inProperty") if isinstance(data.get("inProperty"), dict) else {}
    if (price := parse_price(data.get("price"))) is not None:
        out["price"] = price
    if (rooms := parse_float(details.get("roomsCount"))) is not None:
        out["rooms"] = rooms
    if (sqm := parse_int(details.get("squareMeter"))) is not None:
        out["sqm"] = sqm
    if (floor := parse_floor(_dig(data, "address", "house", "floor"))) is not None:
        out["floor"] = floor
    prop = details.get("property")
    for label in (_text(prop), _dig(prop, "textEng") if isinstance(prop, dict) else None):
        if (ptype := parse_property_type(label)) is not None:
            out["property_type"] = ptype.value
            break
    if in_property.get("isImmediateEntrance") is True:
        out["move_in_immediate"] = True
    else:
        moved, immediate = parse_entry_date(details.get("entranceDate"))
        if immediate:
            out["move_in_immediate"] = True
        elif moved is not None:
            out["move_in_date"] = moved.isoformat()
    attrs = {IN_PROPERTY_ATTRIBUTES[k].value: True
             for k, v in in_property.items() if v is True and k in IN_PROPERTY_ATTRIBUTES}
    if attrs:
        out["attributes"] = attrs
    if (posted := parse_posted(_dig(data, "dates", "createdAt"))) is not None:
        out["posted_at"] = posted.isoformat()
    return out


def parse_item(payload: Any, token: str | None = None, *, today: date | None = None,
               locations: Iterable[LocationArea] = ()) -> dict[str, Any]:
    """An item response -> ``Listing`` field values to merge: ``description``
    (the ad's full text, newlines kept), the structured facts, and — only
    where those say nothing — what ``textparse`` reads from the text, with
    ``evidence`` (field -> snippet) for each text-derived value."""
    data = item_data(payload, token)
    text = (_dig(data, "metaData", "description") or "").strip()
    out = structured_fields(data)
    evidence: dict[str, str] = {}
    if text:
        parsed = parse_listing_text(text, today=today, locations=locations)
        for key in _TEXT_FIELDS:
            value = getattr(parsed, key)
            if value is None or value is False or key in out:
                continue
            if key in ("move_in_date", "move_in_immediate") and (
                    "move_in_date" in out or "move_in_immediate" in out):
                continue
            out[key] = value.isoformat() if isinstance(value, date) else getattr(value, "value", value)
            if key in parsed.evidence:
                evidence[key] = parsed.evidence[key]
        attrs = dict(out.get("attributes") or {})
        for attr, flag in parsed.attributes.items():
            if attr.value not in attrs:
                attrs[attr.value] = flag
                if (k := f"attributes.{attr.value}") in parsed.evidence:
                    evidence[k] = parsed.evidence[k]
        if attrs:
            out["attributes"] = attrs
        if parsed.is_agent is False and "is_agent" not in out:
            out["is_agent"] = False
            if "is_agent" in parsed.evidence:
                evidence["is_agent"] = parsed.evidence["is_agent"]
    out["description"] = text
    if evidence:
        out["evidence"] = evidence
    return out


def fetch_item(client: ThrottledClient, token: str) -> Any | None:
    """``GET realestate-item/<token>`` through the shared client (its yad2
    spacing applies). None when the ad is gone (404/410); ``SourceBlocked``
    / ``SourceError`` otherwise propagate."""
    try:
        return client.get_json(DETAILS_URL.format(token=token), headers=REQUEST_HEADERS)
    except SourceError as exc:
        if getattr(exc, "status", None) in GONE_STATUSES and type(exc) is SourceError:
            return None
        raise

"""City name -> yad2 city code.

yad2 identifies cities by the Israeli CBS locality code. Lookup keys are
``normalize_place()`` forms (Hebrew and English spellings), and a name is
also tried through ``canonical_city()`` so every alias in ``text.py`` works.
A ``LocationArea.yad2_city_code`` in the profile always wins over this map.
"""

from __future__ import annotations

from house_finder.text import canonical_city, normalize_place

# code -> spellings. Written naturally; normalised when the lookup is built.
_CITIES: dict[int, tuple[str, ...]] = {
    5000: ("tel aviv", "tel aviv-yafo", "תל אביב", "תל אביב-יפו"),
    3000: ("jerusalem", "ירושלים"),
    4000: ("haifa", "חיפה"),
    8600: ("ramat gan", "רמת גן"),
    6300: ("givatayim", "גבעתיים"),
    6400: ("herzliya", "herzliyya", "הרצליה"),  # verify
    8700: ("raanana", "ra'anana", "רעננה"),  # verify
    7900: ("petah tikva", "petah tiqva", "פתח תקווה", "פתח תקוה"),  # verify
    6600: ("holon", "חולון"),  # verify
    6200: ("bat yam", "בת ים"),  # verify
    8300: ("rishon lezion", "rishon le zion", "ראשון לציון"),  # verify
    6900: ("kfar saba", "כפר סבא"),  # verify
    7400: ("netanya", "נתניה"),  # verify
    9000: ("beer sheva", "be'er sheva", "באר שבע"),  # verify
    8400: ("rehovot", "רחובות"),  # verify
    6100: ("bnei brak", "בני ברק"),  # verify
    9700: ("hod hasharon", "הוד השרון"),  # verify
    2650: ("ramat hasharon", "רמת השרון"),  # verify
    1200: ("modiin", "modi'in", "מודיעין", "מודיעין מכבים רעות"),  # verify
    70: ("ashdod", "אשדוד"),  # verify
}

YAD2_CITY_CODES: dict[str, int] = {
    normalize_place(name): code for code, names in _CITIES.items() for name in names
}
"""``normalize_place(name)`` -> yad2 city code."""


def yad2_city_code(city: str | None) -> int | None:
    """The yad2 code for ``city``, or None when the name is not in the map."""
    key = normalize_place(city)
    if not key:
        return None
    if key in YAD2_CITY_CODES:
        return YAD2_CITY_CODES[key]
    return YAD2_CITY_CODES.get(canonical_city(city))


# yad2's map API requires ``region`` with ``city`` ("region is required",
# live 2026-10-20). Verified pairs only; any other city's region is
# discovered once by the adapter and cached (``Yad2Adapter.region_cache``).
_REGIONS: dict[int, int] = {
    5000: 3,  # Tel Aviv-Yafo -> "תל אביב והסביבה" (live 2026-10-20)
}


def yad2_region_code(city_code: int) -> int | None:
    """The yad2 region id of a city code, when verified; else None."""
    return _REGIONS.get(city_code)

"""Hard filters: decide whether a listing matches the profile, with reasons.

``evaluate(listing, profile)`` returns a :class:`MatchResult` holding one
:class:`Reason` per profile criterion that is set (BRIEF N4), plus the
ranking contributions from :mod:`house_finder.matching.ranking`.

**Missing data never fails a hard filter** — it yields an ``unknown`` reason
(VISION Tradeoff Defaults). Present-and-failing data always fails.
Pure: no I/O.
"""

from __future__ import annotations

import math
from datetime import date, datetime, timezone
from enum import Enum

from pydantic import BaseModel, Field

from house_finder.models import Listing
from house_finder.profile import LocationArea, SearchProfile
from house_finder.text import canonical_city, normalize_place


class ReasonStatus(str, Enum):
    """Outcome of one criterion for one listing."""

    met = "met"
    missed = "missed"
    unknown = "unknown"


class Reason(BaseModel):
    """Why a criterion was met, missed, or could not be checked.

    ``hard`` is True for hard-filter reasons (a ``missed`` one drops the
    listing). Ranking reasons have ``hard=False`` and carry the ``points``
    they added to the score.
    """

    criterion: str
    status: ReasonStatus
    detail: str
    hard: bool = True
    points: float | None = None


class MatchResult(BaseModel):
    """Verdict for one listing: pass/fail, score in [0, 100], and reasons.

    ``failed`` holds the hard-filter reasons with status ``missed``;
    ``passed`` is True exactly when ``failed`` is empty.
    """

    passed: bool
    score: float
    reasons: list[Reason] = Field(default_factory=list)
    failed: list[Reason] = Field(default_factory=list)

    @property
    def unknowns(self) -> list[Reason]:
        """Hard-filter reasons that could not be checked (missing data)."""
        return [r for r in self.reasons if r.hard and r.status is ReasonStatus.unknown]


def _r(criterion: str, status: ReasonStatus, detail: str) -> Reason:
    return Reason(criterion=criterion, status=status, detail=detail)


def _fmt(x: float | int) -> str:
    return f"{x:g}" if isinstance(x, float) else str(x)


def _range_reason(
    criterion: str,
    label: str,
    value: float | int | None,
    lo: float | int | None,
    hi: float | int | None,
    unit: str = "",
) -> Reason | None:
    """Reason for a numeric ``lo <= value <= hi`` filter; None when unset."""
    if lo is None and hi is None:
        return None
    bounds = f"{_fmt(lo) if lo is not None else '…'}–{_fmt(hi) if hi is not None else '…'}{unit}"
    if value is None:
        return _r(criterion, ReasonStatus.unknown, f"{label} not stated (want {bounds})")
    if lo is not None and value < lo:
        return _r(criterion, ReasonStatus.missed, f"{label} {_fmt(value)}{unit} below {_fmt(lo)}{unit}")
    if hi is not None and value > hi:
        return _r(criterion, ReasonStatus.missed, f"{label} {_fmt(value)}{unit} above {_fmt(hi)}{unit}")
    return _r(criterion, ReasonStatus.met, f"{label} {_fmt(value)}{unit} within {bounds}")


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Great-circle distance in km between two WGS84 points."""
    r = 6371.0088
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = p2 - p1
    dl = math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(min(1.0, math.sqrt(a)))


def _area_match(listing: Listing, area: LocationArea) -> tuple[ReasonStatus, str]:
    """Match one area: city (+ neighborhood narrowing) OR within the radius."""
    if (
        area.radius_km is not None
        and area.lat is not None
        and area.lon is not None
        and listing.lat is not None
        and listing.lon is not None
    ):
        d = haversine_km(area.lat, area.lon, listing.lat, listing.lon)
        if d <= area.radius_km:
            return ReasonStatus.met, f"{d:.1f} km from {area.city} (≤ {_fmt(area.radius_km)} km)"
        radius_note = f"{d:.1f} km from {area.city} (> {_fmt(area.radius_km)} km)"
    else:
        radius_note = ""

    if not listing.city:
        return ReasonStatus.unknown, f"city not stated (want {area.city})"
    if canonical_city(listing.city) != canonical_city(area.city):
        note = f"{listing.city} is not {area.city}"
        return ReasonStatus.missed, f"{note}; {radius_note}" if radius_note else note
    if not area.neighborhoods:
        return ReasonStatus.met, f"in {area.city}"
    wanted = ", ".join(area.neighborhoods)
    if not listing.neighborhood:
        return ReasonStatus.unknown, f"in {area.city}, neighborhood not stated (want {wanted})"
    hood = normalize_place(listing.neighborhood)
    if any(hood == normalize_place(n) for n in area.neighborhoods):
        return ReasonStatus.met, f"{listing.neighborhood}, {area.city}"
    return ReasonStatus.missed, f"neighborhood {listing.neighborhood} not in {wanted}"


def _location_reason(listing: Listing, profile: SearchProfile) -> Reason | None:
    if not profile.locations:
        return None
    results = [_area_match(listing, a) for a in profile.locations]
    for status in (ReasonStatus.met, ReasonStatus.unknown):
        hits = [d for s, d in results if s is status]
        if hits:
            # met: name the area that matched; unknown: list what could not be checked
            return _r("location", status, hits[0] if status is ReasonStatus.met else "; ".join(hits))
    return _r("location", ReasonStatus.missed, "; ".join(d for _, d in results))


def _property_type_reason(listing: Listing, profile: SearchProfile) -> Reason | None:
    if not profile.property_types:
        return None
    wanted = ", ".join(sorted(t.value for t in profile.property_types))
    if listing.property_type is None:
        return _r("property_type", ReasonStatus.unknown, f"type not stated (want {wanted})")
    if listing.property_type in profile.property_types:
        return _r("property_type", ReasonStatus.met, f"{listing.property_type.value}")
    return _r("property_type", ReasonStatus.missed, f"{listing.property_type.value} not in {wanted}")


def _move_in_reason(listing: Listing, profile: SearchProfile, today: date) -> Reason | None:
    lo, hi = profile.move_in_earliest, profile.move_in_latest
    if lo is None and hi is None:
        return None
    window = f"{lo.isoformat() if lo else '…'}–{hi.isoformat() if hi else '…'}"
    if listing.move_in_immediate:
        when, label = today, f"immediate ({today.isoformat()})"
    elif listing.move_in_date is not None:
        when, label = listing.move_in_date, listing.move_in_date.isoformat()
    else:
        return _r("move_in", ReasonStatus.unknown, f"move-in date not stated (want {window})")
    if lo is not None and when < lo:
        return _r("move_in", ReasonStatus.missed, f"move-in {label} before {lo.isoformat()}")
    if hi is not None and when > hi:
        return _r("move_in", ReasonStatus.missed, f"move-in {label} after {hi.isoformat()}")
    return _r("move_in", ReasonStatus.met, f"move-in {label} within {window}")


def _must_have_reasons(listing: Listing, profile: SearchProfile) -> list[Reason]:
    out = []
    for attr in sorted(profile.must_haves, key=lambda a: a.value):
        name = attr.value.replace("_", " ")
        value = listing.attributes.get(attr)
        if value is None:
            out.append(_r(f"must_have:{attr.value}", ReasonStatus.unknown, f"{name}: not stated"))
        elif value:
            out.append(_r(f"must_have:{attr.value}", ReasonStatus.met, f"has {name}"))
        else:
            out.append(_r(f"must_have:{attr.value}", ReasonStatus.missed, f"no {name}"))
    return out


def _exclusion_reason(listing: Listing, profile: SearchProfile) -> Reason | None:
    keywords = [k.strip() for k in profile.exclusion_keywords if k and k.strip()]
    if not keywords:
        return None
    text = f"{listing.title or ''}\n{listing.description or ''}".casefold()
    if not text.strip():
        return _r("exclusion_keywords", ReasonStatus.unknown, "no title or description to check")
    found = [k for k in keywords if k.casefold() in text]
    if found:
        return _r("exclusion_keywords", ReasonStatus.missed, "contains " + ", ".join(f'"{k}"' for k in found))
    return _r("exclusion_keywords", ReasonStatus.met, "no excluded keywords")


def _agent_reason(listing: Listing, profile: SearchProfile) -> Reason | None:
    if not profile.exclude_agents:
        return None
    if listing.is_agent is None:
        return _r("exclude_agents", ReasonStatus.unknown, "agent or private not stated")
    if listing.is_agent:
        return _r("exclude_agents", ReasonStatus.missed, "posted by an agent")
    return _r("exclude_agents", ReasonStatus.met, "private poster")


def _ground_floor_reason(listing: Listing, profile: SearchProfile) -> Reason | None:
    if not profile.exclude_ground_floor:
        return None
    if listing.floor is None:
        return _r("exclude_ground_floor", ReasonStatus.unknown, "floor not stated")
    if listing.floor <= 0:
        return _r("exclude_ground_floor", ReasonStatus.missed, f"floor {listing.floor} (ground or below)")
    return _r("exclude_ground_floor", ReasonStatus.met, f"floor {listing.floor}")


def hard_filter_reasons(listing: Listing, profile: SearchProfile, today: date) -> list[Reason]:
    """One hard-filter Reason per set profile criterion (one per must-have)."""
    p = profile
    candidates: list[Reason | None] = [
        _range_reason("price", "price", listing.price, p.price_min, p.price_max, " ₪"),
        _location_reason(listing, p),
        _range_reason("rooms", "rooms", listing.rooms, p.rooms_min, p.rooms_max),
        _range_reason("sqm", "size", listing.sqm, p.sqm_min, p.sqm_max, " m²"),
        _property_type_reason(listing, p),
        _move_in_reason(listing, p, today),
        _range_reason("lease", "lease", listing.lease_months, p.lease_min_months, p.lease_max_months, " months"),
        *_must_have_reasons(listing, p),
        _exclusion_reason(listing, p),
        _agent_reason(listing, p),
        _ground_floor_reason(listing, p),
    ]
    return [r for r in candidates if r is not None]


def evaluate(listing: Listing, profile: SearchProfile, now: datetime | None = None) -> MatchResult:
    """Run every hard filter and the ranking score for one listing.

    ``now`` (default: current local time) sets "today" for an immediate
    move-in and the reference point for recency. A naive ``now`` or
    ``posted_at`` is treated as UTC.
    """
    # Imported here: ranking imports Reason/MatchResult from this module.
    from house_finder.matching.ranking import score_reasons

    now = _aware(now) if now is not None else datetime.now().astimezone()
    hard = hard_filter_reasons(listing, profile, now.date())
    failed = [r for r in hard if r.status is ReasonStatus.missed]
    score, soft = score_reasons(listing, profile, hard, now)
    return MatchResult(passed=not failed, score=score, reasons=hard + soft, failed=failed)


def _aware(dt: datetime) -> datetime:
    """Treat a naive datetime as UTC."""
    return dt if dt.tzinfo is not None else dt.replace(tzinfo=timezone.utc)

"""Ranking: a score in [0, 100] for a listing, every point explained.

Contributions (weights sum to 100):

- nice-to-haves met — ``W_NICE`` (main weight), split evenly per attribute;
- price position in the profile's range — ``W_PRICE`` (cheaper is better);
- fewer unknown hard filters — ``W_COMPLETE``;
- recency of ``posted_at`` against ``max_listing_age_days`` — ``W_RECENT``.

A contribution that cannot apply (no nice-to-haves set, no ``price_max``)
gives half its weight to every listing alike, so it never reorders them.
Each contribution adds a non-hard :class:`Reason` carrying its ``points``.
Pure: no I/O.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Iterable

from house_finder.matching.filters import MatchResult, Reason, ReasonStatus, evaluate
from house_finder.models import Listing
from house_finder.profile import SearchProfile

W_NICE = 50.0
W_PRICE = 20.0
W_COMPLETE = 15.0
W_RECENT = 15.0


def _soft(criterion: str, status: ReasonStatus, detail: str, points: float) -> Reason:
    return Reason(criterion=criterion, status=status, detail=detail, hard=False, points=round(points, 2))


def _nice_reasons(listing: Listing, profile: SearchProfile) -> list[Reason]:
    attrs = sorted(profile.nice_to_haves, key=lambda a: a.value)
    if not attrs:
        return []
    share = W_NICE / len(attrs)
    out = []
    for attr in attrs:
        name = attr.value.replace("_", " ")
        value = listing.attributes.get(attr)
        if value is None:
            out.append(_soft(f"nice_to_have:{attr.value}", ReasonStatus.unknown, f"{name}: not stated", 0))
        elif value:
            out.append(_soft(f"nice_to_have:{attr.value}", ReasonStatus.met, f"has {name}", share))
        else:
            out.append(_soft(f"nice_to_have:{attr.value}", ReasonStatus.missed, f"no {name}", 0))
    return out


def _price_points(listing: Listing, profile: SearchProfile) -> tuple[float, Reason | None]:
    hi = profile.price_max
    if hi is None:
        # No ceiling to measure against: neutral for everyone, no reason (the
        # hard "price" reason already covers a set price_min).
        return W_PRICE / 2, None
    if listing.price is None:
        return 0.0, _soft("price_position", ReasonStatus.unknown, "price not stated", 0)
    lo = profile.price_min or 0
    span = hi - lo
    frac = 1.0 if span <= 0 else (hi - listing.price) / span
    frac = min(1.0, max(0.0, frac))
    pts = W_PRICE * frac
    status = ReasonStatus.met if frac >= 0.5 else ReasonStatus.missed
    return pts, _soft("price_position", status, f"{listing.price} ₪ is {frac:.0%} below the top of {lo}–{hi} ₪", pts)


def _completeness(hard: list[Reason]) -> tuple[float, Reason | None]:
    if not hard:
        return W_COMPLETE, None
    unknown = [r.criterion for r in hard if r.status is ReasonStatus.unknown]
    pts = W_COMPLETE * (1 - len(unknown) / len(hard))
    if unknown:
        return pts, _soft("completeness", ReasonStatus.missed, f"{len(unknown)} of {len(hard)} filters unknown: {', '.join(unknown)}", pts)
    return pts, _soft("completeness", ReasonStatus.met, f"all {len(hard)} filters checked", pts)


def _recency(listing: Listing, profile: SearchProfile, now: datetime) -> tuple[float, Reason]:
    max_days = profile.max_listing_age_days
    if listing.posted_at is None:
        return 0.0, _soft("recency", ReasonStatus.unknown, "posting time not stated", 0)
    posted = listing.posted_at if listing.posted_at.tzinfo else listing.posted_at.replace(tzinfo=timezone.utc)
    age_days = max(0.0, (now - posted).total_seconds() / 86400)
    if max_days == 0:  # "today only"
        frac = 1.0 if age_days < 1 else 0.0
    else:
        frac = max(0.0, 1 - age_days / max_days)
    pts = W_RECENT * frac
    if age_days <= max_days:
        return pts, _soft("recency", ReasonStatus.met, f"posted {age_days:.0f} days ago (limit {max_days})", pts)
    return pts, _soft("recency", ReasonStatus.missed, f"posted {age_days:.0f} days ago, older than {max_days}", pts)


def score_reasons(
    listing: Listing, profile: SearchProfile, hard: list[Reason], now: datetime
) -> tuple[float, list[Reason]]:
    """Score one listing given its hard-filter reasons; returns (score, reasons)."""
    reasons: list[Reason] = []
    nice = _nice_reasons(listing, profile)
    reasons += nice
    total = sum(r.points or 0 for r in nice) if nice else W_NICE / 2
    for pts, reason in (_price_points(listing, profile), _completeness(hard), _recency(listing, profile, now)):
        total += pts
        if reason is not None:
            reasons.append(reason)
    return round(min(100.0, max(0.0, total)), 2), reasons


def rank(
    listings: Iterable[Listing], profile: SearchProfile, now: datetime | None = None
) -> list[tuple[Listing, MatchResult]]:
    """Evaluate every listing and return only the passing ones, best first.

    Ties break by newer ``posted_at`` (unknown last), then by ``listing.id``
    so the order is deterministic.
    """
    results = [(lst, evaluate(lst, profile, now)) for lst in listings]
    passing = [(lst, res) for lst, res in results if res.passed]

    def key(item: tuple[Listing, MatchResult]):
        lst, res = item
        posted = lst.posted_at
        ts = (posted if posted.tzinfo else posted.replace(tzinfo=timezone.utc)).timestamp() if posted else float("-inf")
        return (-res.score, -ts, lst.id)

    return sorted(passing, key=key)

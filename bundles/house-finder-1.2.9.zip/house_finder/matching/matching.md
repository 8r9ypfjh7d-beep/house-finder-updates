# matching — hard filters + ranking with reasons

Pure functions (no I/O) that decide whether a `Listing` matches the
`SearchProfile` and how well, and say why for every criterion (BRIEF N4).
Runs at read time (review queue), so a profile change re-ranks instantly.

## Code Files

- `filters.py` — `ReasonStatus`, `Reason`, `MatchResult`, `evaluate()`, `hard_filter_reasons()`, `haversine_km()`
- `ranking.py` — `score_reasons()`, `rank()`, weights `W_NICE` / `W_PRICE` / `W_COMPLETE` / `W_RECENT`
- `__init__.py` — re-exports the above

## API

- `evaluate(listing, profile, now=None) -> MatchResult` — `passed`, `score`
  (0–100), `reasons` (hard-filter reasons first, then ranking reasons),
  `failed` (the hard reasons with status `missed`), property `unknowns`.
  `now` defaults to the current local time; it sets "today" for an immediate
  move-in and the reference for recency. Naive datetimes are treated as UTC.
- `rank(listings, profile, now=None) -> list[(Listing, MatchResult)]` — only
  passing listings, best score first; ties: newer `posted_at`, then `id`.
- `Reason(criterion, status, detail, hard=True, points=None)` — `status` is
  `met` / `missed` / `unknown`; `detail` is a short English sentence the UI
  shows verbatim; ranking reasons have `hard=False` and the `points` added.

## Hard filters

Every set profile criterion yields exactly one reason (one per attribute for
must-haves). **Missing data → `unknown`, never a drop** (VISION Tradeoff
Defaults); present-and-failing → `missed` → listing fails.

| Criterion | Set when | Check |
|---|---|---|
| `price` | `price_min`/`price_max` | inclusive range |
| `location` | `locations` non-empty | any area matches (see below) |
| `rooms`, `sqm`, `lease` | min/max set | inclusive range |
| `property_type` | `property_types` non-empty | membership |
| `move_in` | earliest/latest set | `move_in_immediate` counts as today, else `move_in_date` |
| `must_have:<attr>` | per must-have | `attributes[attr]` True/False/absent |
| `exclusion_keywords` | non-blank keywords | casefolded substring of title + description; both empty → unknown |
| `exclude_agents` | True | `is_agent` |
| `exclude_ground_floor` | True | `floor <= 0` fails |

Location, per `LocationArea`: met when the listing is within `radius_km` of
the area point (both sides have coordinates) **or** its city matches
(`text.canonical_city`, so Hebrew/English/Tel Aviv-Yafo aliases agree) and,
if the area lists neighborhoods, its neighborhood equals one of them under
`text.normalize_place`. Over all areas: any met → met; else any unknown →
unknown; else missed.

## Ranking (score 0–100)

| Reason | Weight | Rule |
|---|---|---|
| `nice_to_have:<attr>` | 50 split evenly | full share when met; 0 when missed/unknown |
| `price_position` | 20 | `(price_max − price) / (price_max − (price_min or 0))`, clipped; unknown price → 0 |
| `completeness` | 15 | × share of hard filters that are not `unknown` |
| `recency` | 15 | linear from posted-now to `max_listing_age_days` old; unknown → 0 |

No nice-to-haves set, or no `price_max`: half that weight to every listing
(no reason emitted for an unset criterion), so it never reorders them.

## Optimizations and Features

- `max_listing_age_days` is a ranking signal here (the `recency` reason is
  `missed` past the limit), not a hard filter: hiding stale listings is
  `quality.stale_flag` (same "older than" rule) in the review queue.
- City comparison goes through `text.canonical_city` / `normalize_place` —
  never a private copy — so the yad2 city map and matching agree.
- A radius widens an area (OR with the city match); a listing without
  coordinates still matches by city name.
- `evaluate` imports `ranking` inside the function to avoid a circular import
  (`ranking` imports `Reason`/`MatchResult` from `filters`).
- Blank exclusion keywords are ignored (an empty string would match every
  listing).

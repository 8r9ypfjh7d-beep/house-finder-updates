"""Senders: how an approved message leaves through the listing's channel.

``Sender.send(message, approval) -> SendResult``. ``approval`` is an
``ApprovalToken``, which only ``Store.approval_for()`` can issue (from an
``approved`` row whose approval hash matches its current text). The FIRST
line of every sender is ``check_approval(message, approval)``: no token, a
token for another message, a status other than ``approved``, or a hash that
is not the sha256 of the CURRENT text -> ``failed`` with
"approval does not match text", and nothing is opened or sent (VISION hard
constraint 1). ``messaging.dispatch`` is the only caller.

Every sender built here is ASSISTED (VISION tradeoff "assisted send"): it
never sends anything itself. It returns ``needs_owner`` with an
``OwnerAction`` — a URL to open (always http(s), via ``text.safe_url``) and
the text to paste — and the owner sends by hand and clicks "I sent it".
Nothing marks an assisted message sent automatically.

``registry`` maps ``(channel, send mode)`` to a sender factory. The
automated ``browser.FacebookBrowserSender`` is registered for
``("facebook", "browser")`` at startup once the owner has logged in
(``fb-login``), and ``browser.Yad2BrowserSender`` for ``("yad2",
"browser")`` once the owner connected yad2; no browser sending exists in
this module.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import dataclass
from typing import Literal, Protocol, runtime_checkable
from urllib.parse import quote

from house_finder.messaging.drafts import channel_for_listing
from house_finder.models import Listing
from house_finder.profile import OwnerSettings
from house_finder.store import APPROVAL_MISMATCH, ApprovalToken, Message, check_approval
from house_finder.text import safe_url

SendStatus = Literal["sent", "needs_owner", "failed"]
ASSISTED = "assisted"


@dataclass(frozen=True)
class OwnerAction:
    """What the owner does by hand for an assisted send.

    ``open_url`` is an http(s) URL to open in a new tab, or None when there
    is no safe one — then ``why_no_open`` says why. ``copy_text`` is the
    approved text to paste; ``text_in_url`` is True when the URL already
    carries it (wa.me pre-fills the chat).
    """

    open_url: str | None
    open_label: str
    copy_text: str
    text_in_url: bool = False
    why_no_open: str | None = None


@dataclass(frozen=True)
class SendResult:
    """The outcome of one ``send``: ``sent`` (a sender delivered it),
    ``needs_owner`` (assisted: ``action`` says what to do) or ``failed``
    (``error`` says why; an approval refusal starts with
    ``APPROVAL_MISMATCH``)."""

    status: SendStatus
    action: OwnerAction | None = None
    error: str | None = None

    @property
    def refused(self) -> bool:
        """True when the approval gate refused (nothing was attempted)."""
        return self.status == "failed" and (self.error or "").startswith(APPROVAL_MISMATCH)


@runtime_checkable
class Sender(Protocol):
    """A channel sender bound to one listing. ``approval`` is REQUIRED."""

    channel: str
    mode: str

    def send(self, message: Message, approval: ApprovalToken) -> SendResult: ...


def refusal(message: Message, approval: object) -> SendResult | None:
    """The gate every sender runs first: a ``failed`` result when the
    approval does not hold for this message's current text, else None."""
    reason = check_approval(message, approval)
    return None if reason is None else SendResult("failed", error=reason)


# ------------------------------------------------------------------ phones


class PhoneError(ValueError):
    """A phone number that cannot be used for WhatsApp; the message says why."""


_PHONE_CHARS = re.compile(r"[^0-9+\-\s().]")  # ASCII digits only (\d would accept ٠-٩, ５)
_PHONE_SEPARATORS = re.compile(r"[\s\-().]")


def normalize_il_mobile(raw: str | None) -> str:
    """An Israeli mobile number as wa.me wants it: ``9725XXXXXXXX``.

    Accepts ``05X-XXXXXXX``, ``05XXXXXXXX``, ``+972 5X…``, ``972…``,
    ``00972…``, ``+972 (0)5X…`` with spaces, dashes, dots or parentheses.
    Raises ``PhoneError`` (with the reason) for an empty, non-Israeli,
    landline or otherwise invalid number.
    """
    s = (raw or "").strip()
    if not s:
        raise PhoneError("no phone number")
    if _PHONE_CHARS.search(s):
        raise PhoneError(f"{s!r} contains characters that are not part of a phone number")
    digits = _PHONE_SEPARATORS.sub("", s)
    if "+" in digits[1:]:
        raise PhoneError(f"{s!r} is not a valid phone number")
    if digits.startswith("+"):
        if not digits.startswith("+972"):
            raise PhoneError(f"{s!r} is not an Israeli number (+972)")
        national = digits[4:]
    elif digits.startswith("00"):
        if not digits.startswith("00972"):
            raise PhoneError(f"{s!r} is not an Israeli number (+972)")
        national = digits[5:]
    elif digits.startswith("972"):
        national = digits[3:]
    elif digits.startswith("0"):
        national = digits[1:]
    else:
        raise PhoneError(f"{s!r} has no Israeli prefix (0 or +972)")
    if national.startswith("0"):  # "+972 (0)50…"
        national = national[1:]
    if re.fullmatch(r"5\d{8}", national):
        return "972" + national
    if re.fullmatch(r"[23489]\d{7}|7\d{8}", national):
        raise PhoneError(f"{s!r} is a landline / non-mobile number; WhatsApp needs a mobile (05X)")
    raise PhoneError(f"{s!r} is not a valid Israeli mobile number (05X-XXXXXXX)")


def whatsapp_url(phone: str, text: str) -> str:
    """``https://wa.me/<9725XXXXXXXX>?text=<url-encoded text>``; ``phone`` is
    normalised here, so a bad number raises ``PhoneError``."""
    return f"https://wa.me/{normalize_il_mobile(phone)}?text={quote(text, safe='')}"


# ----------------------------------------------------------------- senders


def _unsafe(url: str | None, what: str) -> str:
    return f"the {what} ({url!r}) is not an http(s) link, so it is not opened" if url else f"no {what}"


class WhatsAppAssistedSender:
    """Phone listings: open ``wa.me`` with the text pre-filled; the owner
    presses Send in WhatsApp. A number that is not an Israeli mobile falls
    back to opening the listing, and says why."""

    channel = "whatsapp"
    mode = ASSISTED

    def __init__(self, listing: Listing) -> None:
        self.listing = listing

    def send(self, message: Message, approval: ApprovalToken) -> SendResult:
        refused = refusal(message, approval)  # the approval gate — always first
        if refused is not None:
            return refused
        phone = self.listing.contact.phone if self.listing.contact else None
        try:
            url = whatsapp_url(phone or "", message.text)
        except PhoneError as exc:
            listing_url = safe_url(self.listing.url)
            why = f"WhatsApp not opened: {exc}."
            if not listing_url:
                why += f" Also {_unsafe(self.listing.url, 'listing URL')}; contact the poster another way."
            return SendResult("needs_owner", OwnerAction(
                open_url=listing_url or None, open_label="Open the listing", copy_text=message.text,
                why_no_open=why))
        return SendResult("needs_owner", OwnerAction(
            open_url=safe_url(url) or None, open_label="Open WhatsApp", copy_text=message.text,
            text_in_url=True))


class FacebookAssistedSender:
    """Facebook listings: open the poster's profile (to message them), else
    the post; the text is copied for pasting. Never automated here."""

    channel = "facebook"
    mode = ASSISTED

    def __init__(self, listing: Listing) -> None:
        self.listing = listing

    def send(self, message: Message, approval: ApprovalToken) -> SendResult:
        refused = refusal(message, approval)  # the approval gate — always first
        if refused is not None:
            return refused
        profile = self.listing.contact.profile_url if self.listing.contact else None
        if safe_url(profile):
            return SendResult("needs_owner", OwnerAction(
                open_url=safe_url(profile), open_label="Open the poster's Facebook profile",
                copy_text=message.text))
        if safe_url(self.listing.url):
            return SendResult("needs_owner", OwnerAction(
                open_url=safe_url(self.listing.url), open_label="Open the Facebook post",
                copy_text=message.text))
        why = f"Nothing opened: {_unsafe(profile, 'profile URL')} and {_unsafe(self.listing.url, 'post URL')}."
        return SendResult("needs_owner", OwnerAction(
            open_url=None, open_label="", copy_text=message.text, why_no_open=why))


def listing_page_action(listing: Listing, text: str) -> OwnerAction:
    """The "open the listing, paste the text" ``OwnerAction`` (assisted yad2,
    and the fallback of the automatic yad2 sender when it did not send)."""
    url = safe_url(listing.url)
    if url:
        return OwnerAction(open_url=url, open_label="Open the listing", copy_text=text)
    return OwnerAction(open_url=None, open_label="", copy_text=text,
                       why_no_open=f"Nothing opened: {_unsafe(listing.url, 'listing URL')}; "
                                   "contact the poster another way.")


class ListingPageAssistedSender:
    """Sources contacted on their own site (yad2 without a phone): open the
    listing page; the text is copied for the site's contact form."""

    mode = ASSISTED

    def __init__(self, listing: Listing, channel: str) -> None:
        self.listing = listing
        self.channel = channel

    def send(self, message: Message, approval: ApprovalToken) -> SendResult:
        refused = refusal(message, approval)  # the approval gate — always first
        if refused is not None:
            return refused
        return SendResult("needs_owner", listing_page_action(self.listing, message.text))


class Yad2AssistedSender(ListingPageAssistedSender):
    """yad2 without a phone: open the yad2 listing, text copied."""

    def __init__(self, listing: Listing) -> None:
        super().__init__(listing, "yad2")


# ---------------------------------------------------------------- registry

SenderFactory = Callable[[Listing], Sender]


class NoSenderError(LookupError):
    """No sender is registered for a channel + send mode."""


class SenderRegistry:
    """``(channel, mode) -> factory(listing) -> Sender``. ``secure-sessions``
    registers its browser sender with ``register("facebook", "browser", …)``.
    Registering an existing key raises unless ``replace=True``."""

    def __init__(self) -> None:
        self._factories: dict[tuple[str, str], SenderFactory] = {}

    def register(self, channel: str, mode: str, factory: SenderFactory, *, replace: bool = False) -> None:
        key = (channel, mode)
        if key in self._factories and not replace:
            raise ValueError(f"a sender is already registered for {channel!r} / {mode!r}")
        self._factories[key] = factory

    def unregister(self, channel: str, mode: str) -> None:
        """Remove a sender (no-op when none is registered)."""
        self._factories.pop((channel, mode), None)

    def keys(self) -> list[tuple[str, str]]:
        return sorted(self._factories)

    def create(self, channel: str, mode: str, listing: Listing) -> Sender:
        factory = self._factories.get((channel, mode))
        if factory is None:
            raise NoSenderError(f"no sender for channel {channel!r} in {mode!r} mode")
        return factory(listing)


def default_registry() -> SenderRegistry:
    """A registry with the assisted senders: whatsapp, facebook, yad2."""
    reg = SenderRegistry()
    reg.register("whatsapp", ASSISTED, WhatsAppAssistedSender)
    reg.register("facebook", ASSISTED, FacebookAssistedSender)
    reg.register("yad2", ASSISTED, Yad2AssistedSender)
    return reg


registry = default_registry()


def channel_for(
    listing: Listing, settings: OwnerSettings | None = None, senders: SenderRegistry | None = None
) -> Sender:
    """The sender for the listing's channel (``channel_for_listing``: a
    phone -> whatsapp, facebook, else the source) in the owner's send mode
    for it (``assisted`` unless set). ``NoSenderError`` when none exists."""
    name = channel_for_listing(listing)
    mode = settings.send_mode(name) if settings is not None else ASSISTED
    return (senders or registry).create(name, mode, listing)

"""``detect_language(text) -> "he" | "en"`` — which language to write back in.

Hebrew when Hebrew letters are at least 30% of all letters; English
otherwise. Text with no letters at all (empty, digits only) is ``he``: the
listings are Israeli, so Hebrew is the safe default (BRIEF N7).
"""

from __future__ import annotations

from typing import Literal

Language = Literal["he", "en"]
LANGUAGES: tuple[str, ...] = ("he", "en")
HEBREW_SHARE = 0.30


def _is_hebrew_letter(ch: str) -> bool:
    # U+05D0..U+05EA: alef..tav including the final forms.
    return "א" <= ch <= "ת"


def detect_language(text: str) -> Language:
    """``"he"`` if Hebrew letters are >= 30% of the letters in ``text``,
    else ``"en"``; no letters at all -> ``"he"``."""
    letters = [ch for ch in text if ch.isalpha()]
    if not letters:
        return "he"
    hebrew = sum(1 for ch in letters if _is_hebrew_letter(ch))
    return "he" if hebrew / len(letters) >= HEBREW_SHARE else "en"


def has_letters(text: str) -> bool:
    """True when ``text`` contains at least one letter (detection has
    something to go on)."""
    return any(ch.isalpha() for ch in text)

"""``draft_message(listing, settings) -> Draft`` — the "I'm interested" text.

Every value put into the template comes from the listing or the owner's
settings (and, for ``{detail}``, the owner's own wish list in the profile);
nothing is made up. A value the listing does not state is left empty, and the
template rules drop the sentence or clause that needed it.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass

from house_finder.messaging.language import LANGUAGES, Language, detect_language, has_letters
from house_finder.messaging.templates import DEFAULT_TEMPLATES, DETAIL_PHRASES, property_noun, render_template
from house_finder.models import Attribute, ContactChannel, Listing
from house_finder.profile import OwnerSettings, SearchProfile


@dataclass(frozen=True)
class Draft:
    """A rendered draft, not yet stored or approved."""

    text: str
    language: Language
    channel: str
    listing_id: str


def listing_language(listing: Listing) -> Language:
    """The language to write in: detected from the listing's own text
    (title, description, place); when that has no letters, the source's
    ``listing.language`` if it is ``he``/``en``; else ``he``."""
    text = " ".join(
        s for s in (listing.title, listing.description, listing.street, listing.neighborhood, listing.city) if s
    )
    if has_letters(text):
        return detect_language(text)
    if listing.language in LANGUAGES:
        return listing.language  # type: ignore[return-value]
    return "he"


def channel_for_listing(listing: Listing) -> str:
    """The channel the listing will be answered on (BRIEF §8 "same channel"):
    ``whatsapp`` when it has a phone number, ``facebook`` for a Facebook
    post / Messenger contact, else the listing's source (e.g. ``yad2``).
    Stage 2 maps this name to a sender."""
    contact = listing.contact
    if contact is not None and contact.phone and contact.phone.strip():
        return "whatsapp"
    if listing.source == "facebook" or (contact is not None and contact.channel == ContactChannel.facebook_messenger):
        return "facebook"
    return listing.source


def format_price(price: int | None, language: str) -> str:
    """``5,000 ₪`` (he) / ``₪5,000`` (en); empty when not stated."""
    if price is None:
        return ""
    return f"{price:,} ₪" if language == "he" else f"₪{price:,}"


def format_rooms(rooms: float | None) -> str:
    """``3`` / ``2.5``; empty when not stated."""
    if rooms is None:
        return ""
    return f"{rooms:g}"


def format_place(listing: Listing) -> str:
    """Street + neighborhood (or city), else neighborhood, else city."""
    street = (listing.street or "").strip()
    area = (listing.neighborhood or "").strip() or (listing.city or "").strip()
    if street and area:
        return f"{street}, {area}"
    return street or area


def pick_detail(listing: Listing, profile: SearchProfile | None, language: str) -> str:
    """The phrase for the first attribute the listing states as TRUE among
    the owner's nice-to-haves, then must-haves (each in ``Attribute`` order);
    empty when there is none or no profile."""
    if profile is None:
        return ""
    phrases = DETAIL_PHRASES.get(language, {})
    for wanted in (profile.nice_to_haves, profile.must_haves):
        for attr in Attribute:
            if attr in wanted and listing.attributes.get(attr) is True and attr in phrases:
                return phrases[attr]
    return ""


def greeting(listing: Listing, language: str) -> str:
    """``שלום <contact name>,`` / ``Hi <contact name>,``; without a stated
    name ``שלום,`` / ``Hello,``."""
    name = (listing.contact.name or "").strip() if listing.contact else ""
    if language == "he":
        return f"שלום {name}," if name else "שלום,"
    return f"Hi {name}," if name else "Hello,"


def template_values(
    listing: Listing, settings: OwnerSettings, language: str, profile: SearchProfile | None = None
) -> dict[str, str]:
    """Every placeholder's value; empty string = not stated."""
    return {
        "greeting": greeting(listing, language),
        "property": property_noun(listing.property_type, language),
        "place": format_place(listing),
        "price": format_price(listing.price, language),
        "rooms": format_rooms(listing.rooms),
        "detail": pick_detail(listing, profile, language),
        "name": settings.owner_name.strip(),
    }


def draft_message(
    listing: Listing,
    settings: OwnerSettings,
    *,
    profile: SearchProfile | None = None,
    templates: Mapping[str, str] | None = None,
) -> Draft:
    """Render the interested-message draft for ``listing`` in its language.

    ``profile`` supplies the owner's nice-to-haves / must-haves for
    ``{detail}`` (no profile -> no detail sentence). ``templates`` defaults to
    ``DEFAULT_TEMPLATES``; pass ``load_templates()`` for the owner's own.
    """
    language = listing_language(listing)
    source = templates if templates is not None else DEFAULT_TEMPLATES
    template = source.get(language) or DEFAULT_TEMPLATES[language]
    text = render_template(template, template_values(listing, settings, language, profile))
    return Draft(text=text, language=language, channel=channel_for_listing(listing), listing_id=listing.id)

"""Message templates: the defaults, the owner's ``data/templates.json``, and
the renderer.

Template syntax (one template per language, plain text, one line per
sentence):

- ``{greeting}``, ``{property}``, ``{place}``, ``{price}``, ``{detail}``,
  ``{name}``, ``{rooms}`` are replaced by values taken from the listing and the owner's
  settings — never anything else (VISION non-goal "Inventing facts").
- ``[ ... ]`` on one line is an optional piece: kept (without the brackets)
  only when every placeholder inside it has a value, otherwise removed whole.
- A placeholder OUTSIDE brackets that has no value removes its whole line.
- Blank lines collapse; runs of spaces collapse. Inserted values are never
  re-read as template syntax.

An unknown placeholder, a stray ``{`` / ``}`` or an unbalanced / nested
bracket is a ``TemplateError`` when the templates are loaded, so a typo never
reaches a landlord.
"""

from __future__ import annotations

import json
import os
import re
import tempfile
from collections.abc import Mapping
from pathlib import Path

from house_finder import config
from house_finder.models import Attribute, PropertyType

PLACEHOLDERS: frozenset[str] = frozenset({"greeting", "property", "place", "price", "detail", "name", "rooms"})

DEFAULT_TEMPLATES: dict[str, str] = {
    "he": (
        "{greeting}\n"
        "ראיתי את המודעה על {property}[ ב{place}][, {rooms} חדרים][, ב-{price} לחודש], ואני מאוד מעוניין/ת.\n"
        "[אהבתי במיוחד את {detail}.]\n"
        "אשמח לדעת אם המודעה עדיין רלוונטית ומתי אפשר לתאם צפייה.\n"
        "תודה!\n"
        "{name}"
    ),
    "en": (
        "{greeting}\n"
        "I saw your listing for {property}[ in {place}][ ({rooms} rooms)][ at {price} a month],"
        " and I am very interested.\n"
        "[I especially liked {detail}.]\n"
        "Is it still available, and when could I come to see it?\n"
        "Thanks!\n"
        "{name}"
    ),
}

# ``{property}``: the definite noun for the listing's ``PropertyType`` — room,
# studio and house have their own; everything else (or unknown) is an
# apartment. The Hebrew template avoids gendered words that would have to
# agree with it (הדירה is feminine, the others masculine). The sign-off is
# "Thanks!" on its own line, so an empty ``{name}`` (its line dropped) leaves
# no dangling "Thanks,".
PROPERTY_NOUNS: dict[str, dict[PropertyType | None, str]] = {
    "he": {PropertyType.room: "החדר", PropertyType.studio: "הסטודיו", PropertyType.house: "הבית"},
    "en": {PropertyType.room: "the room", PropertyType.studio: "the studio", PropertyType.house: "the house"},
}
DEFAULT_PROPERTY_NOUN: dict[str, str] = {"he": "הדירה", "en": "the apartment"}


def property_noun(property_type: PropertyType | None, language: str) -> str:
    """``החדר`` / ``the room`` etc. for the listing's type; apartment otherwise."""
    return PROPERTY_NOUNS.get(language, {}).get(property_type) or DEFAULT_PROPERTY_NOUN.get(
        language, DEFAULT_PROPERTY_NOUN["en"]
    )


# ``{detail}`` per attribute: a definite noun phrase that fits "אהבתי במיוחד
# את ___" / "I especially liked ___".
DETAIL_PHRASES: dict[str, dict[Attribute, str]] = {
    "he": {
        Attribute.balcony: "המרפסת",
        Attribute.parking: "החניה",
        Attribute.elevator: "המעלית",
        Attribute.pets_allowed: "האפשרות להכניס חיות מחמד",
        Attribute.furnished: "הריהוט",
        Attribute.air_conditioning: "המיזוג",
        Attribute.safe_room: 'הממ"ד',
        Attribute.storage: "המחסן",
        Attribute.accessible: "הנגישות",
        Attribute.renovated: "השיפוץ",
    },
    "en": {
        Attribute.balcony: "the balcony",
        Attribute.parking: "the parking",
        Attribute.elevator: "the elevator",
        Attribute.pets_allowed: "that pets are allowed",
        Attribute.furnished: "that it comes furnished",
        Attribute.air_conditioning: "the air conditioning",
        Attribute.safe_room: "the safe room",
        Attribute.storage: "the storage room",
        Attribute.accessible: "the accessibility",
        Attribute.renovated: "the renovation",
    },
}

_PLACEHOLDER = re.compile(r"\{(\w+)\}")
_OPTIONAL = re.compile(r"\[([^\[\]\n]*)\]")
_SPACES = re.compile(r"[ \t]{2,}")


class TemplateError(ValueError):
    """A template that would not render safely."""


def validate_template(template: str, language: str = "?") -> None:
    """Raise ``TemplateError`` for unknown placeholders, stray braces, or
    unbalanced / nested / multi-line brackets."""
    for name in _PLACEHOLDER.findall(template):
        if name not in PLACEHOLDERS:
            raise TemplateError(
                f"template {language!r}: unknown placeholder {{{name}}}; allowed: "
                + ", ".join(f"{{{p}}}" for p in sorted(PLACEHOLDERS))
            )
    if "{" in _PLACEHOLDER.sub("", template) or "}" in _PLACEHOLDER.sub("", template):
        raise TemplateError(f"template {language!r}: a '{{' or '}}' that is not a placeholder")
    if "[" in _OPTIONAL.sub("", template) or "]" in _OPTIONAL.sub("", template):
        raise TemplateError(f"template {language!r}: unbalanced, nested or multi-line [ ] brackets")


def _fill(piece: str, values: Mapping[str, str]) -> tuple[str, bool]:
    """``piece`` with placeholders replaced; the flag is False when any
    placeholder in it has no value."""
    complete = True

    def sub(m: re.Match[str]) -> str:
        nonlocal complete
        value = (values.get(m.group(1)) or "").strip()
        if not value:
            complete = False
        return value

    return _PLACEHOLDER.sub(sub, piece), complete


def render_template(template: str, values: Mapping[str, str]) -> str:
    """Render ``template`` with ``values`` under the rules in the module doc."""
    validate_template(template)
    out: list[str] = []
    for line in template.replace("\r\n", "\n").split("\n"):
        # re.split with one group alternates: outside, inside, outside, ...
        parts = _OPTIONAL.split(line)
        rendered: list[str] = []
        keep_line = True
        for i, part in enumerate(parts):
            text, complete = _fill(part, values)
            if i % 2 == 1:  # inside [ ]
                rendered.append(text if complete else "")
            elif not complete:
                keep_line = False
                break
            else:
                rendered.append(text)
        if not keep_line:
            continue
        text = _SPACES.sub(" ", "".join(rendered)).strip()
        if not text and line.strip():
            continue  # a line made only of dropped optional pieces
        if not text and (not out or out[-1] == ""):
            continue  # collapse blank lines
        out.append(text)
    while out and out[-1] == "":
        out.pop()
    return "\n".join(out)


def load_templates(path: Path | str | None = None) -> dict[str, str]:
    """The owner's templates from ``path`` (default ``config.templates_path()``)
    over the defaults: ``{"he": ..., "en": ...}``. A missing file means the
    defaults; an unreadable or invalid file raises (never silently replaced).
    """
    p = Path(path) if path is not None else config.templates_path()
    templates = dict(DEFAULT_TEMPLATES)
    if p.exists():
        data = json.loads(p.read_text(encoding="utf-8"))
        if not isinstance(data, dict) or not all(
            isinstance(k, str) and isinstance(v, str) for k, v in data.items()
        ):
            raise TemplateError(f"{p}: expected a JSON object of language -> template text")
        unknown = set(data) - set(DEFAULT_TEMPLATES)
        if unknown:
            raise TemplateError(f"{p}: unknown template language(s): {', '.join(sorted(unknown))}")
        templates.update(data)
    for language, text in templates.items():
        validate_template(text, language)
    return templates


def save_templates(templates: Mapping[str, str], path: Path | str | None = None) -> Path:
    """Validate and write the templates atomically."""
    for language, text in templates.items():
        if language not in DEFAULT_TEMPLATES:
            raise TemplateError(f"unknown template language {language!r}")
        validate_template(text, language)
    p = Path(path) if path is not None else config.templates_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(dict(templates), ensure_ascii=False, indent=2)
    fd, tmp_name = tempfile.mkstemp(prefix=f".{p.name}.", suffix=".tmp", dir=p.parent)
    tmp = Path(tmp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(payload)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, p)
    except BaseException:
        tmp.unlink(missing_ok=True)
        raise
    return p

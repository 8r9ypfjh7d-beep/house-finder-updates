"""Runtime paths and settings.

All runtime data (profile, SQLite, secrets, the browser profile)
lives in one data directory: the ``HOUSE_FINDER_DATA`` environment variable,
else — in the installed (frozen) app — ``%LOCALAPPDATA%\\HouseFinder\\data``,
else ``./data`` relative to the current working directory. Paths are resolved
on every call so tests can point the env var at a temp dir.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

DATA_DIR_ENV = "HOUSE_FINDER_DATA"
DEFAULT_DATA_DIR = "data"
FROZEN_APP_DIRNAME = "HouseFinder"  # %LOCALAPPDATA%\\HouseFinder\\data for the installed exe
LOGS_DIRNAME = "logs"
LOG_FILENAME = "house-finder.log"
DB_FILENAME = "house_finder.sqlite3"
PROFILE_FILENAME = "profile.json"
SETTINGS_FILENAME = "settings.json"
TEMPLATES_FILENAME = "templates.json"
ABOUT_ME_FILENAME = "about_me.json"
BROWSER_PROFILE_DIRNAME = "browser-profile"
PACER_STATE_FILENAME = "browser-pacer.json"
YAD2_BROWSER_PROFILE_DIRNAME = "browser-yad2"
YAD2_PACER_STATE_FILENAME = "browser-yad2-pacer.json"


def data_dir() -> Path:
    """Return the data directory (not created; see :func:`ensure_data_dir`)."""
    raw = os.environ.get(DATA_DIR_ENV, "").strip()
    if raw:
        return Path(raw)
    if getattr(sys, "frozen", False):  # the installed exe: never its install dir or the CWD
        return frozen_data_dir()
    return Path(DEFAULT_DATA_DIR)


def frozen_data_dir() -> Path:
    """The installed app's data dir: ``%LOCALAPPDATA%\\HouseFinder\\data``
    (``~/AppData/Local`` when the variable is missing)."""
    return _local_app_root() / DEFAULT_DATA_DIR


def _local_app_root() -> Path:
    base = os.environ.get("LOCALAPPDATA", "").strip()
    root = Path(base) if base else Path.home() / "AppData" / "Local"
    return root / FROZEN_APP_DIRNAME


UPDATES_DIR_ENV = "HOUSE_FINDER_UPDATES_DIR"
UPDATES_DIRNAME = "app"


def updates_dir() -> Path | None:
    """Where downloaded code updates live (``updater``), or None when
    updates are off. ``HOUSE_FINDER_UPDATES_DIR`` wins (a developer
    force-enables updates with it); else the installed (frozen) app uses
    ``%LOCALAPPDATA%\\HouseFinder\\app`` (beside the data dir, never the
    install dir); else None — a source checkout updates through git.
    ``packaging/update_loader.updates_root()`` repeats this rule."""
    raw = os.environ.get(UPDATES_DIR_ENV, "").strip()
    if raw:
        return Path(raw)
    if getattr(sys, "frozen", False):
        return _local_app_root() / UPDATES_DIRNAME
    return None


BROWSERS_ENV = "PLAYWRIGHT_BROWSERS_PATH"


def frozen_browsers_dir() -> Path:
    """Where the installed app keeps its Chromium: playwright's usual
    per-user folder, ``%LOCALAPPDATA%\\ms-playwright`` (survives updates and
    reinstalls; never the install dir)."""
    base = os.environ.get("LOCALAPPDATA", "").strip()
    root = Path(base) if base else Path.home() / "AppData" / "Local"
    return root / "ms-playwright"


def pin_browsers_path() -> None:
    """In the installed (frozen) app, fix ``PLAYWRIGHT_BROWSERS_PATH`` before
    any browser work. Unset, playwright's frozen mode makes the *launch* look
    in ``<install dir>\\…\\.local-browsers`` while ``playwright install``
    downloads to ``ms-playwright`` — the browser is then never found. An
    explicit value (the owner's or a test's) is kept."""
    if getattr(sys, "frozen", False) and not os.environ.get(BROWSERS_ENV, "").strip():
        os.environ[BROWSERS_ENV] = str(frozen_browsers_dir())


def ensure_data_dir() -> Path:
    """Return the data directory, creating it (and parents) if needed."""
    path = data_dir()
    path.mkdir(parents=True, exist_ok=True)
    return path


def db_path() -> Path:
    """Path of the SQLite database file inside the data dir."""
    return data_dir() / DB_FILENAME


def profile_path() -> Path:
    """Path of the owner's search profile JSON inside the data dir."""
    return data_dir() / PROFILE_FILENAME


def settings_path() -> Path:
    """Path of the owner's settings JSON (name, notifications, send modes)."""
    return data_dir() / SETTINGS_FILENAME


def templates_path() -> Path:
    """Path of the owner's message templates JSON (defaults used when absent)."""
    return data_dir() / TEMPLATES_FILENAME


def about_me_path() -> Path:
    """Path of the owner's answer bank JSON (facts + remembered entry answers)."""
    return data_dir() / ABOUT_ME_FILENAME


def debug_dir() -> Path:
    """Directory for raw source responses written by ``collect --dump``."""
    return data_dir() / "debug"


def log_path() -> Path:
    """The rotating log of the windowless app (``house-finder app``)."""
    return data_dir() / LOGS_DIRNAME / LOG_FILENAME


def browser_profile_dir() -> Path:
    """The Facebook browser's persistent Chromium profile (cookies, session).
    Created by ``house-finder fb-login``; never committed (``data/``)."""
    return data_dir() / BROWSER_PROFILE_DIRNAME


def pacer_state_path() -> Path:
    """The browser ``Pacer``'s daily counters and stop-for-the-day state."""
    return data_dir() / PACER_STATE_FILENAME


def yad2_browser_profile_dir() -> Path:
    """The yad2 fallback browser's own Chromium profile (a solved captcha's
    cookie lives here, never mixed with the Facebook login)."""
    return data_dir() / YAD2_BROWSER_PROFILE_DIRNAME


def yad2_pacer_state_path() -> Path:
    """The yad2 browser ``Pacer``'s daily page-load count and last load time."""
    return data_dir() / YAD2_PACER_STATE_FILENAME

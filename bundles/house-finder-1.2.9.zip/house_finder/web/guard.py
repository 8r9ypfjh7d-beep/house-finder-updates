"""``LocalOriginGuard`` — ASGI middleware that keeps the local UI local.

The app binds 127.0.0.1, but a web page the owner visits can still make the
browser send requests to it (cross-site POST), and DNS rebinding can make a
foreign hostname resolve to 127.0.0.1. Two checks, both answered with 403:

1. **Host**: every request's ``Host`` header must be one of ``allowed_hosts``
   (default ``127.0.0.1:<port>`` and ``localhost:<port>``). This defeats DNS
   rebinding, where the browser sends the attacker's hostname.
2. **Origin**: every state-changing request (any method other than GET, HEAD,
   OPTIONS) must carry an ``Origin`` — or, when ``Origin`` is absent, a
   ``Referer`` — whose scheme+host is ``http://<an allowed host>``. A request
   carrying neither is refused (fail closed: browsers send ``Origin`` on every
   POST, so only a non-browser client lacks both).

It wraps the whole app, so every route — including ones added later — is
covered without opting in.
"""

from __future__ import annotations

from collections.abc import Iterable
from urllib.parse import urlsplit

from starlette.types import ASGIApp, Receive, Scope, Send

SAFE_METHODS = frozenset({"GET", "HEAD", "OPTIONS"})


def local_hosts(port: int) -> tuple[str, ...]:
    """The production ``Host`` values: ``127.0.0.1:<port>`` and ``localhost:<port>``."""
    return (f"127.0.0.1:{port}", f"localhost:{port}")


def _origin_of(url: str) -> str | None:
    """``scheme://host[:port]`` of a URL (lower-cased), or None when unparsable."""
    try:
        parts = urlsplit(url.strip())
    except ValueError:
        return None
    if not parts.scheme or not parts.netloc:
        return None
    return f"{parts.scheme.lower()}://{parts.netloc.lower()}"


class LocalOriginGuard:
    """ASGI middleware enforcing the Host and same-origin checks above."""

    def __init__(self, app: ASGIApp, allowed_hosts: Iterable[str]) -> None:
        self.app = app
        self.allowed_hosts = frozenset(h.strip().lower() for h in allowed_hosts if h.strip())
        if not self.allowed_hosts:
            raise ValueError("LocalOriginGuard needs at least one allowed host")
        self.allowed_origins = frozenset(f"http://{h}" for h in self.allowed_hosts)

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] not in ("http", "websocket"):
            await self.app(scope, receive, send)
            return
        headers = {k.decode("latin-1").lower(): v.decode("latin-1") for k, v in scope.get("headers", [])}
        reason = self.refusal(scope.get("method", "GET"), headers)
        if reason is not None:
            await _forbidden(scope, receive, send, reason)
            return
        await self.app(scope, receive, send)

    def refusal(self, method: str, headers: dict[str, str]) -> str | None:
        """Why this request is refused, or None when it may pass."""
        host = headers.get("host", "").strip().lower()
        if host not in self.allowed_hosts:
            return "Forbidden: unexpected Host header."
        if method.upper() in SAFE_METHODS:
            return None
        origin_header = headers.get("origin")
        if origin_header is not None and origin_header.strip() not in ("", "null"):
            source = _origin_of(origin_header)
        elif origin_header is not None and origin_header.strip() == "null":
            return "Forbidden: opaque Origin."
        else:
            referer = headers.get("referer")
            source = _origin_of(referer) if referer else None
            if source is None:
                return "Forbidden: state-changing request without Origin or Referer."
        if source not in self.allowed_origins:
            return "Forbidden: cross-origin request."
        return None


async def _forbidden(scope: Scope, receive: Receive, send: Send, reason: str) -> None:
    if scope["type"] == "websocket":
        await send({"type": "websocket.close", "code": 1008})
        return
    body = reason.encode("utf-8")
    await send({
        "type": "http.response.start",
        "status": 403,
        "headers": [
            (b"content-type", b"text/plain; charset=utf-8"),
            (b"content-length", str(len(body)).encode("ascii")),
        ],
    })
    await send({"type": "http.response.body", "body": body})

"""Local web UI — see ``web.md``."""

from house_finder.web.app import create_app

__all__ = ["create_app"]

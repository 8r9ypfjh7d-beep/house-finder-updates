/* House Finder — the Review page's photo gallery. Plain JS, no build step,
   served locally. It only reads what the server rendered (every URL there
   already went through safe_url): the strip's links ARE the photo list.
   Without JavaScript the strip is a list of links that open each photo. */
(function () {
  "use strict";
  var gallery = document.querySelector("[data-gallery]");
  if (!gallery) return;
  var current = gallery.querySelector("[data-gallery-open]");
  var strip = document.querySelector(".gallery-strip");
  if (!current) return;
  var img = current.querySelector("img");
  var pos = gallery.querySelector("[data-gallery-pos]");
  var prev = gallery.querySelector("[data-gallery-prev]");
  var next = gallery.querySelector("[data-gallery-next]");

  var only = current.getAttribute("href");
  function thumbs() { return strip ? Array.prototype.slice.call(strip.querySelectorAll("a[data-gallery-index]")) : []; }
  function urls() {
    var list = thumbs().map(function (a) { return a.getAttribute("href"); });
    return list.length ? list : [only];
  }
  var index = 0;
  var box = null;

  function show(i) {
    var list = urls();
    if (!list.length) return;
    index = (i + list.length) % list.length;
    var src = list[index];
    current.setAttribute("href", src);
    if (!img || !img.isConnected) {
      img = document.createElement("img");
      img.referrerPolicy = "no-referrer";
      current.appendChild(img);
    }
    img.src = src;
    img.alt = "Photo " + (index + 1) + " of " + list.length;
    if (pos) pos.textContent = (index + 1) + " / " + list.length;
    thumbs().forEach(function (a, n) { a.classList.toggle("is-current", n === index); });
    if (box) boxShow();
  }

  function boxShow() {
    var list = urls();
    box.querySelector("img").src = list[index];
    box.querySelector("img").alt = "Photo " + (index + 1) + " of " + list.length;
    box.querySelector(".lightbox-pos").textContent = (index + 1) + " / " + list.length;
  }

  function openBox() {
    if (box) return;
    box = document.createElement("div");
    box.className = "lightbox";
    box.setAttribute("role", "dialog");
    box.setAttribute("aria-modal", "true");
    box.setAttribute("aria-label", "Photo viewer");
    var many = urls().length > 1;
    box.innerHTML =
      '<img alt="" referrerpolicy="no-referrer">' +
      '<button type="button" class="lightbox-close" aria-label="Close (Esc)">×</button>' +
      (many ? '<button type="button" class="lightbox-nav lightbox-prev" aria-label="Previous photo">‹</button>' +
              '<button type="button" class="lightbox-nav lightbox-next" aria-label="Next photo">›</button>' : "") +
      '<span class="lightbox-pos"></span>';
    box.addEventListener("click", function (e) {
      var t = e.target;
      if (t.classList.contains("lightbox-prev")) show(index - 1);
      else if (t.classList.contains("lightbox-next")) show(index + 1);
      else if (t.tagName !== "IMG") closeBox();
    });
    document.body.appendChild(box);
    document.body.classList.add("lightbox-open");
    boxShow();
    box.querySelector(".lightbox-close").focus();
  }

  function closeBox() {
    if (!box) return;
    box.remove();
    box = null;
    document.body.classList.remove("lightbox-open");
    current.focus();
  }

  current.addEventListener("click", function (e) { e.preventDefault(); openBox(); });
  if (prev) { prev.hidden = false; prev.addEventListener("click", function () { show(index - 1); }); }
  if (next) { next.hidden = false; next.addEventListener("click", function () { show(index + 1); }); }
  if (strip) strip.addEventListener("click", function (e) {
    var a = e.target.closest ? e.target.closest("a[data-gallery-index]") : null;
    if (!a) return;  // a video tile opens the post
    e.preventDefault();
    show(thumbs().indexOf(a));
  });
  document.addEventListener("keydown", function (e) {
    var t = e.target;
    if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.isContentEditable)) return;
    if (e.altKey || e.ctrlKey || e.metaKey) return;  // keep the decision accesskeys
    if (e.key === "ArrowLeft") { show(index - 1); e.preventDefault(); }
    else if (e.key === "ArrowRight") { show(index + 1); e.preventDefault(); }
    else if (e.key === "Escape" && box) { closeBox(); e.preventDefault(); }
  });
})();

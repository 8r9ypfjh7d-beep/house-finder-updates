"""Encrypted local credential store — see ``secrets.md``."""

from house_finder.secrets.store import (
    ENCRYPTED_HEADER,
    KEY_FILENAME,
    KEYRING_SERVICE,
    KEYRING_USERNAME,
    SECRETS_FILENAME,
    KeySource,
    SecretStore,
    SecretStoreError,
    atomic_write_bytes,
    is_encrypted,
    load_keyring,
)

# Names of the secrets the app stores.
NTFY_TOPIC = "ntfy_topic"
SMTP_PASSWORD = "smtp_password"

__all__ = [
    "ENCRYPTED_HEADER",
    "KEY_FILENAME",
    "KEYRING_SERVICE",
    "KEYRING_USERNAME",
    "NTFY_TOPIC",
    "SECRETS_FILENAME",
    "SMTP_PASSWORD",
    "KeySource",
    "SecretStore",
    "SecretStoreError",
    "atomic_write_bytes",
    "is_encrypted",
    "load_keyring",
]

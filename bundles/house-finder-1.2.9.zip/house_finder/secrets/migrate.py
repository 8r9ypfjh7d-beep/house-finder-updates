"""One-time move of plaintext secrets into the encrypted store, logged.

``load_settings`` / ``load_bank`` also migrate on every load (idempotent),
so nothing depends on this having run; it exists so the move is recorded in
the event log (names only, never values) at startup: ``create_app`` and
``house-finder collect`` call it.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from house_finder.secrets.store import SecretStore
    from house_finder.store import Store

log = logging.getLogger(__name__)


def migrate_plaintext(store: Store | None, *, settings_path: Path | str | None = None,
                      about_me_path: Path | str | None = None,
                      settings_secrets: SecretStore | None = None,
                      bank_secrets: SecretStore | None = None) -> list[str]:
    """Encrypt a plaintext ntfy topic (``settings.json``) and a plaintext
    answer bank; returns what moved (``ntfy_topic``, ``about_me``) and logs
    one ``secrets_migrated`` event naming them. Never raises: a file that
    cannot be migrated is left as it is and reported by its page's load."""
    from house_finder.answers.bank import migrate_plaintext_bank
    from house_finder.profile.settings import migrate_plaintext_ntfy_topic

    moved: list[str] = []
    for name, step in (("ntfy_topic", lambda: migrate_plaintext_ntfy_topic(settings_path, secrets=settings_secrets)),
                       ("about_me", lambda: migrate_plaintext_bank(about_me_path, secrets=bank_secrets))):
        try:
            if step():
                moved.append(name)
        except Exception as exc:  # the page that loads the file shows the error
            log.warning("could not encrypt %s: %s", name, type(exc).__name__)
    if moved and store is not None:
        store.log_event("secrets_migrated", items=moved)
    return moved

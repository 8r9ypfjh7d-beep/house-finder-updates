"""``SecretStore``: the owner's credentials, encrypted at rest (VISION hard
constraint "Credentials ... live only on my machine, encrypted at rest").

One Fernet key per data directory. Secrets (SMTP password, ntfy topic URL)
are a JSON object encrypted into ``<dir>/secrets.enc``; other files (the
answer bank) are encrypted with the same key via ``encrypt_bytes`` /
``decrypt_bytes``. Every encrypted file starts with ``ENCRYPTED_HEADER``.

Key source, in order:

1. a key file ``<dir>/secret.key`` that already exists (the weaker mode,
   chosen earlier — keep using it so its data stays readable);
2. the OS keyring (``keyring``: Windows Credential Manager) when the package
   imports and a backend works;
3. a NEW key: in the keyring when it works, else in ``secret.key`` created
   owner-only (``0o600``; on Windows the mode is not enforced — the file is
   protected only by the user account, so ``/settings`` says "weaker").

Fails closed: a wrong key or a corrupted file raises ``SecretStoreError``
and nothing is written; a new key is never generated while encrypted data
exists in the directory (that would orphan it). Values are never logged and
never appear in an error message.
"""

from __future__ import annotations

import json
import logging
import os
import tempfile
from pathlib import Path
from typing import Any, Literal, Protocol

from cryptography.fernet import Fernet, InvalidToken

log = logging.getLogger(__name__)

SECRETS_FILENAME = "secrets.enc"
KEY_FILENAME = "secret.key"
ENCRYPTED_HEADER = b"HFENC1\n"
KEYRING_SERVICE = "house-finder"
KEYRING_USERNAME = "data-key"
NAME_CHARS = frozenset("abcdefghijklmnopqrstuvwxyz0123456789_")

KeySource = Literal["keyring", "file"]


class SecretStoreError(RuntimeError):
    """The encrypted data cannot be read or written safely (wrong or missing
    key, corrupted file). Nothing was changed."""


class KeyringLike(Protocol):
    def get_password(self, service: str, username: str) -> str | None: ...
    def set_password(self, service: str, username: str, password: str) -> None: ...


def load_keyring() -> KeyringLike | None:
    """The ``keyring`` module, or None when it is not installed. Imported
    lazily: ``keyring`` is optional. Tests replace this function."""
    try:
        import keyring  # type: ignore[import-not-found]
    except Exception:  # not installed / broken install: fall back to the key file
        return None
    return keyring  # type: ignore[return-value]


def is_encrypted(data: bytes) -> bool:
    return data.startswith(ENCRYPTED_HEADER)


def atomic_write_bytes(path: Path, data: bytes) -> None:
    """Temp file in the same dir + fsync + ``os.replace`` (works on Windows)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    tmp = Path(tmp_name)
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, path)
    except BaseException:
        tmp.unlink(missing_ok=True)
        raise


def _check_name(name: str) -> str:
    if not name or len(name) > 64 or not set(name) <= NAME_CHARS:
        raise ValueError("secret names are 1-64 of a-z, 0-9, _")
    return name


class SecretStore:
    """Encrypted secrets for one data directory. Cheap to construct: nothing
    is read until a value is needed, and no key is created until the first
    write."""

    def __init__(self, directory: Path | str, *, keyring: KeyringLike | None | Literal["default"] = "default") -> None:
        self.dir = Path(directory)
        self.path = self.dir / SECRETS_FILENAME
        self.key_path = self.dir / KEY_FILENAME
        self._keyring_arg = keyring
        self._fernet: Fernet | None = None
        self._source: KeySource | None = None

    # ------------------------------------------------------------- the key

    def _keyring(self) -> KeyringLike | None:
        return load_keyring() if self._keyring_arg == "default" else self._keyring_arg  # type: ignore[return-value]

    def _keyring_get(self) -> tuple[bool, str | None]:
        """``(backend works, stored key or None)``."""
        kr = self._keyring()
        if kr is None:
            return False, None
        try:
            return True, kr.get_password(KEYRING_SERVICE, KEYRING_USERNAME)
        except Exception:  # no usable backend (keyring.errors.NoKeyringError etc.)
            return False, None

    def _encrypted_data_present(self) -> bool:
        if not self.dir.is_dir():
            return False
        for p in self.dir.iterdir():
            try:
                if p.is_file():
                    with p.open("rb") as fh:
                        if is_encrypted(fh.read(len(ENCRYPTED_HEADER))):
                            return True
            except OSError:
                continue
        return False

    def _resolve(self, *, create: bool) -> Fernet | None:
        if self._fernet is not None:
            return self._fernet
        key: bytes | None = None
        if self.key_path.exists():
            key, self._source = self.key_path.read_bytes().strip(), "file"
        else:
            works, stored = self._keyring_get()
            if stored:
                key, self._source = stored.encode("ascii", "replace"), "keyring"
            elif create:
                if self._encrypted_data_present():
                    raise SecretStoreError(
                        f"encrypted data exists in {self.dir} but its key is missing "
                        "(not in the OS keyring, no secret.key file); nothing was changed")
                key = self._create_key(works)
            else:
                return None
        try:
            self._fernet = Fernet(key)
        except (ValueError, TypeError):
            raise SecretStoreError(f"the encryption key ({self._source}) is malformed; nothing was changed") from None
        return self._fernet

    def _create_key(self, keyring_works: bool) -> bytes:
        key = Fernet.generate_key()
        if keyring_works:
            kr = self._keyring()
            try:
                kr.set_password(KEYRING_SERVICE, KEYRING_USERNAME, key.decode("ascii"))  # type: ignore[union-attr]
                if kr.get_password(KEYRING_SERVICE, KEYRING_USERNAME) == key.decode("ascii"):  # type: ignore[union-attr]
                    self._source = "keyring"
                    log.info("created the data key in the OS keyring")
                    return key
            except Exception:
                log.warning("the OS keyring refused the data key; using a key file instead")
        self.dir.mkdir(parents=True, exist_ok=True)
        # O_EXCL: never replace a key file another process just created.
        fd = os.open(self.key_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_BINARY", 0), 0o600)
        with os.fdopen(fd, "wb") as fh:
            fh.write(key)
            fh.flush()
            os.fsync(fh.fileno())
        self._source = "file"
        log.warning("created the data key as a file (weaker: protected only by the user account): %s",
                    self.key_path)
        return key

    def key_source(self) -> KeySource | None:
        """Where the key lives: ``keyring``, ``file`` (weaker) or None (no
        key yet). Never creates one."""
        if self._source is None:
            if self.key_path.exists():
                return "file"
            _, stored = self._keyring_get()
            return "keyring" if stored else None
        return self._source

    # --------------------------------------------------- encrypted bytes

    def encrypt_bytes(self, data: bytes) -> bytes:
        fernet = self._resolve(create=True)
        assert fernet is not None
        return ENCRYPTED_HEADER + fernet.encrypt(data)

    def decrypt_bytes(self, blob: bytes, what: str = "data") -> bytes:
        if not is_encrypted(blob):
            raise SecretStoreError(f"{what} is not in the encrypted format; nothing was changed")
        fernet = self._resolve(create=False)
        if fernet is None:
            raise SecretStoreError(
                f"{what} is encrypted but its key is missing (not in the OS keyring, no secret.key file); "
                "nothing was changed")
        try:
            return fernet.decrypt(blob[len(ENCRYPTED_HEADER):].strip())
        except InvalidToken:
            raise SecretStoreError(
                f"{what} cannot be decrypted: wrong key or corrupted file; nothing was changed") from None

    def write_encrypted(self, path: Path, data: bytes, what: str = "data") -> None:
        """Encrypt ``data`` into ``path`` atomically. An existing encrypted
        file must decrypt with this store's key first — a file this key cannot
        read is never overwritten."""
        if path.exists():
            current = path.read_bytes()
            if is_encrypted(current):
                self.decrypt_bytes(current, what)
        atomic_write_bytes(path, self.encrypt_bytes(data))

    # ------------------------------------------------------------ secrets

    def _read_all(self) -> dict[str, str]:
        if not self.path.exists():
            return {}
        raw = self.decrypt_bytes(self.path.read_bytes(), SECRETS_FILENAME)
        try:
            data: Any = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, ValueError):
            raise SecretStoreError(f"{SECRETS_FILENAME} is corrupted; nothing was changed") from None
        if not isinstance(data, dict) or not all(isinstance(v, str) for v in data.values()):
            raise SecretStoreError(f"{SECRETS_FILENAME} is corrupted; nothing was changed")
        return data

    def _write_all(self, data: dict[str, str]) -> None:
        self.write_encrypted(self.path, json.dumps(data, sort_keys=True).encode("utf-8"), SECRETS_FILENAME)

    def names(self) -> list[str]:
        """The names of the stored secrets (never the values)."""
        return sorted(self._read_all())

    def has(self, name: str) -> bool:
        return _check_name(name) in self._read_all()

    def get(self, name: str) -> str | None:
        return self._read_all().get(_check_name(name))

    def set(self, name: str, value: str) -> None:
        if not isinstance(value, str) or not value:
            raise ValueError("a secret value must be a non-empty string (use delete to remove it)")
        data = self._read_all()
        data[_check_name(name)] = value
        self._write_all(data)
        log.info("secret %s stored", name)

    def delete(self, name: str) -> bool:
        """Remove ``name``; False when it was not stored."""
        data = self._read_all()
        if _check_name(name) not in data:
            return False
        del data[name]
        self._write_all(data)
        log.info("secret %s removed", name)
        return True

    def __repr__(self) -> str:  # never the values
        return f"SecretStore({str(self.dir)!r})"

# secrets — encrypted local credential store

The owner's credentials and personal data, encrypted at rest on the owner's
machine (VISION hard constraint "Credentials … encrypted at rest"; BRIEF N3).
Holds the SMTP password and the ntfy topic URL, and lends its key to the
encrypted answer bank ([answers.md](../answers/answers.md)).

## Code Files

- `store.py` — `SecretStore`, `SecretStoreError`, `load_keyring()`, `is_encrypted()`, `atomic_write_bytes()`, `SECRETS_FILENAME`, `KEY_FILENAME`, `ENCRYPTED_HEADER`, `KEYRING_SERVICE`, `KEYRING_USERNAME`, `KeySource`
- `migrate.py` — `migrate_plaintext()`: move plaintext secrets into the store at startup, log `secrets_migrated`
- `__init__.py` — re-exports the above + the secret names `NTFY_TOPIC`, `SMTP_PASSWORD`

## Files on disk (per directory — the data dir in production)

| File | Holds |
|---|---|
| `secrets.enc` | `ENCRYPTED_HEADER` (`HFENC1\n`) + a Fernet token of a JSON object `{name: value}` |
| `secret.key` | the Fernet key — only in the weaker mode (no OS keyring) |
| `about_me.json` | the answer bank, same header + Fernet token (`answers/bank.py`) |

The store belongs to a directory: `SecretStore(dir)`. `load_settings(path)` /
`load_bank(path)` use the store of their file's directory unless one is
passed, so tests with temp paths are isolated.

## Key source

`cryptography`'s Fernet (AES-128-CBC + HMAC-SHA256). Order:

1. `secret.key` already in the directory → use it (the weaker mode chosen
   earlier; switching would orphan its data).
2. The OS keyring (`keyring`, Windows Credential Manager), service
   `house-finder`, user `data-key`, when the package imports and a backend
   answers.
3. No key yet → created on the **first write** only: in the keyring when it
   accepts and reads back the key, else `secret.key` created with
   `O_CREAT|O_EXCL` and mode `0o600`. On Windows the mode is not enforced:
   the file is protected only by the user account. `/settings` then shows
   **Weaker key storage** (`key_source() == "file"`).

`keyring` is imported lazily (`load_keyring()`); missing or broken → step 3
uses the key file. Tests replace `load_keyring` with a fake (conftest), never
the real keyring.

## API

- `get(name)`, `set(name, value)`, `delete(name) -> bool`, `has(name)`,
  `names()` (never values). Names: 1–64 of `a-z 0-9 _`; values non-empty
  strings.
- `key_source() -> "keyring" | "file" | None` — never creates a key.
- `encrypt_bytes(data)`, `decrypt_bytes(blob, what)`,
  `write_encrypted(path, data, what)` — for other encrypted files (the bank).
- `migrate_plaintext(store, *, settings_path, about_me_path, …) -> list[str]`
  — moves a plaintext `ntfy_topic` out of `settings.json` and encrypts a
  plaintext `about_me.json`; logs one `secrets_migrated` event with the
  names (`["ntfy_topic", "about_me"]`), never values; never raises.
  `create_app` and `house-finder collect` call it. `load_settings` /
  `load_bank` migrate too (idempotent), with a Python log line.

## Optimizations and Features

- **Fails closed**: a wrong key, a corrupted or non-encrypted `secrets.enc`
  raises `SecretStoreError` ("nothing was changed"); `set` / `delete` /
  `write_encrypted` read (decrypt) the existing file first, so a file this key
  cannot read is never overwritten. Pages show the error and refuse to save
  (409).
- **No new key over existing data**: when encrypted data exists in the
  directory (any file starting with `ENCRYPTED_HEADER`) and no key is found,
  it raises instead of generating one — a new key would orphan that data.
- **No key until needed**: reads of a store with no `secrets.enc` return
  None without touching the keyring; settings with no secrets never create a
  key.
- Values never appear in logs, error messages or `repr` (tests check logs).
  Log lines name the secret only.
- The key is read once per `SecretStore` object (cached `Fernet`); the web
  app keeps one per process, so a key change needs a restart.
- Atomic writes: temp file in the same directory + `fsync` + `os.replace`
  (works on Windows); a crash leaves the old file or the new one.
- One keyring entry (`house-finder` / `data-key`) is shared by every data
  dir on the machine; a dir that already has `secret.key` keeps using it.

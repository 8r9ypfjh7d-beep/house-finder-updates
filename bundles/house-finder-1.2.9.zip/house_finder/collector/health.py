"""Source health alerts (hardening plan, stage 3; BRIEF §12, N5; VISION priority 3).

After each collection the recent ``source_health`` rows of every source that
ran are evaluated; a problem opens an INCIDENT (``store.raise_alert``) that
stays open — the banner on every page — until that source's next healthy
run clears it. Announcing an incident (once) is the notify hook's job.

Alert kinds, checked newest row first, in this order:

- ``blocked`` — the latest run raised ``SourceBlocked`` (``error_kind``).
- ``consecutive_errors`` — the latest ``CONSECUTIVE_ERRORS`` runs are errors.
- ``zero_unexpected`` — the latest run is ``empty`` and at least one of the
  ``ZERO_LOOKBACK`` runs before it returned listings. A source that never
  returned anything is not "unexpected"; a source that did not run (e.g.
  Facebook with no joined group is not registered) has no row to evaluate.

Internal rows (``notify``, ``notify:<channel>``, ``quality:*``,
``health:*``) are not sources: they alert only on ``consecutive_errors``,
and any non-error latest row clears them (``empty`` "turned off" is the
owner's fix for a channel).

Pure evaluation (``evaluate``) is separate from the store writes
(``update_alerts``). No matching import (``collector`` stays free of it).
"""

from __future__ import annotations

from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from house_finder.store import HealthRow, SourceAlert, Store

CONSECUTIVE_ERRORS = 2
ZERO_LOOKBACK = 5
HISTORY_LIMIT = 10  # runs shown per source on /health
INTERNAL_PREFIXES = ("notify", "quality:", "health:")
HEALTH_ALERTS = "health:alerts"  # the evaluation itself failed

KIND_LABELS = {
    "zero_unexpected": "returned no listings unexpectedly",
    "consecutive_errors": "failed several runs in a row",
    "blocked": "blocked by the site",
}


@dataclass(frozen=True)
class Verdict:
    """What the latest rows say: ``action`` is ``raise`` (with ``kind`` +
    ``reason``), ``clear`` (a healthy run) or ``keep`` (no change)."""

    action: str
    kind: str | None = None
    reason: str = ""


KEEP = Verdict("keep")
CLEAR = Verdict("clear")


def is_internal(source: str) -> bool:
    """True for the hook's own rows (notification channels, dedup, alerts)."""
    return source.startswith(INTERNAL_PREFIXES)


def _errors_in_a_row(history: Sequence[HealthRow]) -> int:
    n = 0
    for row in history:
        if row.status != "error":
            break
        n += 1
    return n


def evaluate(source: str, history: Sequence[HealthRow]) -> Verdict:
    """The verdict for ``source`` from its health rows, NEWEST FIRST."""
    if not history:
        return KEEP
    latest = history[0]
    internal = is_internal(source)
    if latest.status != "error" and (internal or latest.status == "ok"):
        return CLEAR
    if not internal and latest.status == "error" and latest.error_kind == "blocked":
        return Verdict("raise", "blocked", f"{source} was blocked by the site: {latest.message}")
    errors = _errors_in_a_row(history)
    if errors >= CONSECUTIVE_ERRORS:
        return Verdict("raise", "consecutive_errors",
                       f"{source} failed {errors} runs in a row; last error: {latest.message or 'failed'}")
    if not internal and latest.status == "empty":
        earlier = [r for r in history[1:1 + ZERO_LOOKBACK] if r.count > 0]
        if earlier:
            best = max(r.count for r in earlier)
            return Verdict("raise", "zero_unexpected",
                           f"{source} returned 0 listings; it returned up to {best} in its "
                           f"last {ZERO_LOOKBACK} runs — the site may have changed")
    return KEEP


def update_alerts(store: Store, sources: Iterable[str]) -> list[SourceAlert]:
    """Evaluate each source and open / refresh / clear its incident. Returns
    the incidents OPENED by this call (announcing them is the caller's job)."""
    opened: list[SourceAlert] = []
    for source in dict.fromkeys(sources):
        verdict = evaluate(source, store.health_history(source, ZERO_LOOKBACK + 1))
        if verdict.action == "clear":
            store.clear_alert(source)
        elif verdict.action == "raise":
            alert, new = store.raise_alert(source, verdict.kind or "", verdict.reason)
            if new:
                opened.append(alert)
    return opened


def alert_sources(store: Store, ran: Iterable[str]) -> list[str]:
    """The sources to evaluate after a run: the ones that ran plus every
    internal row. A source that did not run keeps its incident unchanged."""
    ran = list(ran)
    internal = [s for s in store.latest_health() if is_internal(s)]
    return list(dict.fromkeys([*ran, *internal]))


def alert_text(alert: SourceAlert) -> str:
    """The push text for one incident: source name and alert kind ONLY."""
    return f"{alert.source}: {alert.kind}"

"""``Scheduler`` — background thread running a collection every N minutes.

One run at a time (a lock), ``trigger_now()`` for "collect now", ``stop()``
for shutdown and tests. The job is any zero-argument callable;
``Scheduler.for_collection`` builds the standard one, which reloads the
profile from disk on every run so profile edits take effect without a
restart.
"""

from __future__ import annotations

import logging
import threading
from collections.abc import Callable, Sequence
from pathlib import Path
from typing import TYPE_CHECKING, Any

from house_finder.collector.collector import run_collection
from house_finder.profile.profile import load_profile

if TYPE_CHECKING:
    from house_finder.sources.base import SourceAdapter
    from house_finder.store.db import Store

log = logging.getLogger(__name__)

DEFAULT_INTERVAL_MINUTES = 30.0


class Scheduler:
    """Runs ``job`` every ``interval_minutes`` on a daemon thread.

    ``run_immediately`` makes the first run happen right after ``start()``.
    ``trigger_now()`` wakes the thread for an extra run; triggers arriving
    while a run is in progress coalesce into one follow-up run. Exceptions
    from ``job`` are logged and kept in ``last_error``; the thread keeps going.
    """

    def __init__(
        self,
        job: Callable[[], Any],
        interval_minutes: float = DEFAULT_INTERVAL_MINUTES,
        *,
        run_immediately: bool = True,
    ) -> None:
        if interval_minutes <= 0:
            raise ValueError("interval_minutes must be > 0")
        self.job = job
        self.interval_seconds = float(interval_minutes) * 60.0
        self.run_immediately = run_immediately
        self.last_result: Any = None
        self.last_error: BaseException | None = None
        self.runs = 0
        self._run_lock = threading.Lock()
        self._wake = threading.Event()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    @classmethod
    def for_collection(
        cls,
        store: Store,
        adapters: Sequence[SourceAdapter] | Callable[[], Sequence[SourceAdapter]],
        profile_path: Path | str | None = None,
        interval_minutes: float = DEFAULT_INTERVAL_MINUTES,
        *,
        after: Callable[[Any, Any], None] | None = None,
        **kwargs: Any,
    ) -> "Scheduler":
        """A scheduler whose job is ``run_collection(store, load_profile(path), adapters)``.
        ``adapters`` may be a factory: it is then called on every run
        (``serve`` rebuilds the adapter list per run).

        ``after(report, profile)`` runs after each collection — ``serve``
        passes ``notify.make_after_collection(...)`` (new-match
        notifications), which never raises. Kept as a callable so the
        collector never imports matching.
        """

        def job() -> Any:
            profile = load_profile(profile_path)
            report = run_collection(store, profile, adapters)
            if after is not None:
                after(report, profile)
            return report

        return cls(job, interval_minutes, **kwargs)

    # ---------------------------------------------------------------- control

    @property
    def is_alive(self) -> bool:
        """True while the background thread runs."""
        return self._thread is not None and self._thread.is_alive()

    @property
    def is_running_job(self) -> bool:
        """True while a job run is in progress."""
        return self._run_lock.locked()

    def start(self) -> None:
        """Start the background thread (no-op if already started)."""
        if self.is_alive:
            return
        self._stop.clear()
        if self.run_immediately:
            self._wake.set()
        self._thread = threading.Thread(target=self._loop, name="collector-scheduler", daemon=True)
        self._thread.start()

    def stop(self, timeout: float | None = 10.0) -> None:
        """Stop the thread, waiting up to ``timeout`` s for a running job."""
        self._stop.set()
        self._wake.set()
        if self._thread is not None:
            self._thread.join(timeout)
            self._thread = None

    def trigger_now(self) -> None:
        """Request a run now. With the thread started this returns at once and
        the run happens in the background; without it, the job runs
        synchronously in the caller's thread."""
        if self.is_alive:
            self._wake.set()
        else:
            self.run_once()

    def run_once(self) -> Any:
        """Run the job in the calling thread (waits for a running job first)."""
        with self._run_lock:
            try:
                self.last_result = self.job()
                self.last_error = None
            except Exception as exc:  # keep the scheduler alive
                log.exception("scheduled collection failed")
                self.last_error = exc
                self.last_result = None
            finally:
                self.runs += 1
            return self.last_result

    # --------------------------------------------------------------- internal

    def _loop(self) -> None:
        while not self._stop.is_set():
            self._wake.wait(self.interval_seconds)
            if self._stop.is_set():
                break
            self._wake.clear()
            self.run_once()

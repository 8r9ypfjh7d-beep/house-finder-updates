"""``run_collection`` — run every adapter in isolation and store the results.

Per adapter: call ``fetch(profile)`` inside its own try/except, upsert the
listings, record one ``source_health`` row (``ok`` with count, ``empty`` for
zero listings unless the adapter set ``expected_empty``, ``error`` with the message; ``error_kind="blocked"`` for
``SourceBlocked``) and log one ``collected`` event
with the new listing ids. One adapter failing never stops the others and
never raises out of ``run_collection`` (VISION priority 3).

Cooldown (secure-sessions stage 2): a ``SourceBlocked`` run starts a
cross-run cooldown for that source (``store.start_cooldown``: 6 h, then
24 h); while it is active the source is skipped — status ``cooldown``, no
fetch, no health row (its last row stays the ``blocked`` one, so the alert
stays open), one ``source_skipped`` event. A healthy run resets it.

Matching is NOT run here: it runs at read time so a profile change re-ranks
instantly (foundation plan, settled defaults).
"""

from __future__ import annotations

import logging
from collections.abc import Callable, Iterable, Sequence
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from house_finder.models import Listing
from house_finder.sources.base import SourceAdapter, SourceBlocked, SourceError
from house_finder.store.db import utc_now_iso

if TYPE_CHECKING:
    from house_finder.profile.profile import SearchProfile
    from house_finder.store.db import Store

log = logging.getLogger(__name__)


@dataclass
class SourceRun:
    """The outcome of one adapter in one collection run."""

    source: str
    status: str  # ok | empty | error | cooldown (skipped after a block)
    count: int = 0
    new_ids: list[str] = field(default_factory=list)
    message: str = ""


@dataclass
class CollectionReport:
    """Everything one ``run_collection`` call did, one ``SourceRun`` per adapter."""

    started_at: str
    finished_at: str = ""
    runs: list[SourceRun] = field(default_factory=list)

    @property
    def new_ids(self) -> list[str]:
        """Ids of listings first seen in this run, all sources."""
        return [i for run in self.runs for i in run.new_ids]

    @property
    def errors(self) -> list[SourceRun]:
        """Runs whose status is ``error``."""
        return [run for run in self.runs if run.status == "error"]


def _error_message(exc: BaseException) -> str:
    if isinstance(exc, SourceBlocked):
        return f"blocked: {exc}"
    if isinstance(exc, SourceError):
        return str(exc)
    return f"{type(exc).__name__}: {exc}"


def _store_listings(store: Store, listings: Iterable[Listing], source: str) -> tuple[int, list[str]]:
    count = 0
    new_ids: list[str] = []
    for listing in listings:
        if not isinstance(listing, Listing):
            raise TypeError(f"{source} returned a {type(listing).__name__}, not a Listing")
        count += 1
        if store.upsert_listing(listing):
            new_ids.append(listing.id)
    return count, new_ids


def run_adapter(store: Store, profile: SearchProfile, adapter: SourceAdapter) -> SourceRun:
    """Run one adapter and record its health row and ``collected`` event.

    Never raises for an adapter failure: any exception from ``fetch`` (or a
    non-list / non-``Listing`` result) becomes an ``error`` run. Listings in
    ``SourceError.partial`` are still stored.
    """
    name = str(getattr(adapter, "name", type(adapter).__name__))
    cooldown = store.active_cooldown(name)
    if cooldown is not None:  # blocked recently: do not touch the site (VISION priority 1)
        message = f"skipped: cooling down after a block until {cooldown.until} (level {cooldown.level})"
        store.log_event("source_skipped", source=name, until=cooldown.until, level=cooldown.level)
        return SourceRun(source=name, status="cooldown", message=message)
    status, message, error_kind = "ok", "", None
    count, new_ids = 0, []
    try:
        listings = adapter.fetch(profile)
        if not isinstance(listings, list):
            raise TypeError(f"fetch() returned {type(listings).__name__}, not a list")
        count, new_ids = _store_listings(store, listings, name)
        if count == 0 and getattr(adapter, "expected_empty", False) is not True:
            # An adapter may say zero is normal for this run (Facebook's
            # rotation read groups without an offer, or its daily limit).
            status = "empty"
    except Exception as exc:  # isolation boundary: one source never stops the others
        log.warning("source %s failed: %s", name, exc, exc_info=not isinstance(exc, SourceError))
        status, message = "error", _error_message(exc)
        error_kind = "blocked" if isinstance(exc, SourceBlocked) else None
        partial = getattr(exc, "partial", None) or []
        try:
            count, new_ids = _store_listings(store, partial, name)
        except Exception as store_exc:  # a bad partial must not mask the original error
            message += f"; partial listings not stored: {store_exc}"
        if count:
            message += f" ({count} listings stored before the failure)"

    warnings = [str(w) for w in (getattr(adapter, "warnings", None) or [])]
    if warnings:
        message = "; ".join(filter(None, [message, *warnings]))

    if error_kind == "blocked":
        store.start_cooldown(name, message)
    elif status in ("ok", "empty"):
        store.reset_cooldown(name)
    store.record_health(name, status, count=count, message=message, error_kind=error_kind)
    store.log_event(
        "collected", source=name, status=status, count=count, new_ids=new_ids, message=message
    )
    return SourceRun(source=name, status=status, count=count, new_ids=new_ids, message=message)


AdapterSource = Iterable[SourceAdapter] | Callable[[], Sequence[SourceAdapter]]


def resolve_adapters(adapters: AdapterSource) -> list[SourceAdapter]:
    """The adapter list for one run: ``adapters`` itself, or — when it is a
    factory (``serve`` passes one) — a freshly built list, so a group joined
    or a login done while ``serve`` runs is picked up without a restart."""
    if callable(adapters):
        return list(adapters())
    return list(adapters)


def run_collection(
    store: Store, profile: SearchProfile, adapters: AdapterSource
) -> CollectionReport:
    """Run every adapter once, each isolated; return a ``CollectionReport``.
    ``adapters`` may be a list or a factory called once per run."""
    report = CollectionReport(started_at=utc_now_iso())
    for adapter in resolve_adapters(adapters):
        report.runs.append(run_adapter(store, profile, adapter))
    report.finished_at = utc_now_iso()
    return report

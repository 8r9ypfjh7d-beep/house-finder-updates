"""Collection runs and their schedule — see ``collector.md``."""

from house_finder.collector.collector import (
    AdapterSource,
    CollectionReport,
    SourceRun,
    resolve_adapters,
    run_adapter,
    run_collection,
)
from house_finder.collector.health import (
    CONSECUTIVE_ERRORS,
    HEALTH_ALERTS,
    HISTORY_LIMIT,
    KIND_LABELS,
    ZERO_LOOKBACK,
    Verdict,
    alert_sources,
    alert_text,
    evaluate,
    is_internal,
    update_alerts,
)
from house_finder.collector.scheduler import DEFAULT_INTERVAL_MINUTES, Scheduler

__all__ = [
    "CONSECUTIVE_ERRORS",
    "HEALTH_ALERTS",
    "HISTORY_LIMIT",
    "KIND_LABELS",
    "ZERO_LOOKBACK",
    "Verdict",
    "alert_sources",
    "alert_text",
    "evaluate",
    "is_internal",
    "update_alerts",
    "DEFAULT_INTERVAL_MINUTES",
    "AdapterSource",
    "CollectionReport",
    "Scheduler",
    "resolve_adapters",
    "SourceRun",
    "run_adapter",
    "run_collection",
]

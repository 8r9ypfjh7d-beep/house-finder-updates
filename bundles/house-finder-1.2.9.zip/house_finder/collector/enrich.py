"""yad2 ad-details enrichment: the ad's text and facts the map API lacks.

After each collection (``make_enrich_after``, chained after the notify hook
by ``serve``) up to ``ENRICH_PER_RUN`` yad2 listings without details are
fetched (``sources.yad2_details``) through the SAME ``ThrottledClient`` as
the map (its yad2 spacing applies), best match first. ``DetailsFetcher``
does the same for one listing on demand (the Review / message page), on a
background thread. Neither ever raises into collection or a page.

Ranking needs ``matching``; it is imported inside ``rank_order`` only, so
``collector.py`` / ``scheduler.py`` stay free of matching imports.
"""

from __future__ import annotations

import logging
import threading
from collections.abc import Callable, Iterable, Sequence
from dataclasses import dataclass, field
from datetime import date
from typing import TYPE_CHECKING, Any

from house_finder.sources.base import SourceBlocked
from house_finder.sources.yad2_details import fetch_item, parse_item

if TYPE_CHECKING:
    from house_finder.collector.collector import CollectionReport
    from house_finder.models import Listing
    from house_finder.net import ThrottledClient
    from house_finder.profile.profile import LocationArea, SearchProfile
    from house_finder.store import Store

log = logging.getLogger(__name__)

SOURCE = "yad2"
ENRICH_PER_RUN = 25  # ~25 requests x 10-12.5 s: a run adds at most ~5 minutes
MAX_DETAIL_ATTEMPTS = 3  # an ad whose details keep failing is left alone after this

Order = Callable[[list["Listing"], "SearchProfile"], list["Listing"]]


@dataclass
class EnrichReport:
    """What one enrichment pass did."""

    fetched: list[str] = field(default_factory=list)
    gone: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    blocked: str | None = None
    skipped: str | None = None


def rank_order(listings: list[Listing], profile: SearchProfile) -> list[Listing]:
    """Listings passing the owner's hard filters, best rank first. A failing
    listing is left out: details only fill unknown facts, so they can never
    make a present-and-failing fact pass."""
    from house_finder.matching import rank

    return [listing for listing, _ in rank(listings, profile)]


def fetch_details(store: Store, client: ThrottledClient, listing: Listing, *,
                  today: date | None = None, locations: Iterable[LocationArea] = ()) -> str:
    """Fetch and store one listing's ad details; returns the stored status
    (``ok`` / ``gone`` / ``error``). ``SourceBlocked`` is recorded as an
    ``error`` attempt, starts the yad2 cooldown and is re-raised (the caller
    stops); every other failure is recorded and returned as ``error``."""
    try:
        payload = fetch_item(client, listing.source_id)
        if payload is None:
            store.record_listing_details(listing.id, "gone", error="the ad was removed (HTTP 404)")
            return "gone"
        fields = parse_item(payload, listing.source_id, today=today, locations=locations)
    except SourceBlocked as exc:
        store.record_listing_details(listing.id, "error", error=f"blocked: {exc}")
        store.start_cooldown(SOURCE, f"ad details: {exc}")
        raise
    except Exception as exc:  # SourceError, an unknown shape, a parser bug: recorded, never raised
        store.record_listing_details(listing.id, "error", error=f"{type(exc).__name__}: {exc}"[:500])
        return "error"
    store.record_listing_details(listing.id, "ok", fields)
    return "ok"


def enrich_yad2(store: Store, client: ThrottledClient, profile: SearchProfile, *,
                order: Order = rank_order, limit: int = ENRICH_PER_RUN,
                today: date | None = None) -> EnrichReport:
    """Fetch details for up to ``limit`` yad2 listings that lack them, in
    ``order(candidates, profile)``. Stops at a block (and the yad2 cooldown
    it starts); skipped entirely while yad2 is cooling down."""
    report = EnrichReport()
    if (cooldown := store.active_cooldown(SOURCE)) is not None:
        report.skipped = f"yad2 is cooling down until {cooldown.until}"
        return report
    candidates = store.listings_needing_details(SOURCE, max_attempts=MAX_DETAIL_ATTEMPTS)
    for listing in order(candidates, profile)[: max(0, limit)]:
        try:
            status = fetch_details(store, client, listing, today=today, locations=profile.locations)
        except SourceBlocked as exc:
            report.blocked = str(exc)
            break
        {"ok": report.fetched, "gone": report.gone}.get(status, report.errors).append(listing.id)
    store.log_event("details_run", source=SOURCE, fetched=len(report.fetched), gone=len(report.gone),
                    errors=len(report.errors), blocked=report.blocked, skipped=report.skipped)
    return report


def make_enrich_after(store: Store, client: ThrottledClient, *, order: Order = rank_order,
                      limit: int = ENRICH_PER_RUN) -> Callable[[CollectionReport, SearchProfile], None]:
    """The post-collection step: enrich when yad2 ran (not cooling down).
    Never raises — a failure is logged, the collection is unaffected."""

    def after(report: CollectionReport, profile: SearchProfile) -> None:
        try:
            if any(r.source == SOURCE and r.status != "cooldown" for r in report.runs):
                enrich_yad2(store, client, profile, order=order, limit=limit)
        except Exception:  # never into collection
            log.exception("yad2 ad-details enrichment failed")

    return after


def chain_after(*hooks: Callable[[CollectionReport, SearchProfile], None] | None
                ) -> Callable[[CollectionReport, SearchProfile], None]:
    """Run several post-collection hooks in order; one raising never stops
    the next."""
    active: Sequence[Callable[..., None]] = [h for h in hooks if h is not None]

    def after(report: CollectionReport, profile: SearchProfile) -> None:
        for hook in active:
            try:
                hook(report, profile)
            except Exception:
                log.exception("post-collection hook failed")

    return after


class DetailsFetcher:
    """On-demand ad details for the page being viewed: ``request(listing)``
    starts ONE background fetch per listing per process (never twice), only
    for a yad2 listing without a details row while yad2 is not cooling down;
    ``pending(id)`` is True while it runs. The page never waits for it."""

    def __init__(self, store: Store, client: ThrottledClient, *,
                 locations: Callable[[], Iterable[LocationArea]] | None = None) -> None:
        self.store = store
        self.client = client
        self._locations = locations
        self._lock = threading.Lock()
        self._requested: set[str] = set()
        self._running: set[str] = set()
        self._threads: list[threading.Thread] = []

    def wanted(self, listing: Listing) -> bool:
        """True when this listing could use an on-demand fetch."""
        return (listing.source == SOURCE and self.store.listing_details(listing.id) is None
                and self.store.active_cooldown(SOURCE) is None)

    def request(self, listing: Listing) -> bool:
        """Start the background fetch; False when not needed or already asked."""
        if not self.wanted(listing):
            return False
        with self._lock:
            if listing.id in self._requested:
                return False
            self._requested.add(listing.id)
            self._running.add(listing.id)
        thread = threading.Thread(target=self._run, args=(listing,), name="yad2-details", daemon=True)
        self._threads.append(thread)
        thread.start()
        return True

    def pending(self, listing_id: str) -> bool:
        with self._lock:
            return listing_id in self._running

    def wait(self, timeout: float | None = None) -> None:
        """Wait for the started fetches (tests)."""
        for thread in list(self._threads):
            thread.join(timeout)

    def _run(self, listing: Listing) -> None:
        try:
            locations: Any = self._locations() if self._locations is not None else ()
            fetch_details(self.store, self.client, listing, locations=locations)
        except Exception as exc:  # SourceBlocked (already recorded) or a store failure
            log.warning("on-demand yad2 details for %s failed: %s", listing.id, exc)
        finally:
            with self._lock:
                self._running.discard(listing.id)

"""Scam and stale flags (hardening plan, stage 2).

``flags_for(listing, profile, area_stats)`` returns the warnings the review
card and the message page show, each with a reason and the evidence it came
from (VISION priority 2 / BRIEF N4: every flag explains itself). Computed at
READ time from the listing, the profile and the stored listings — nothing is
persisted, so a profile edit or a new collection changes the flags at once.

- ``payment_before_viewing`` — money asked before the apartment is seen:
  earnest money / a viewing fee, untraceable payment (Western Union,
  MoneyGram, crypto, gift cards), a payment word next to a before-viewing
  phrase, payment before the keys with no contract signing mentioned, keys
  sent by mail/courier, or "I am abroad" together with keys / payment /
  sending.
- ``off_platform_payment`` — payment through a channel outside normal rental
  practice (PayPal, a payment link, Airbnb/Booking payment or escrow, an
  account abroad, an international/SWIFT transfer).
- ``too_good_price`` — price under 60% of the median of stored listings in
  the same canonical city with the same rooms (≥ 5 other apartments).
- ``stale`` — the newest stated ``posted_at`` of the cluster is older than
  ``profile.max_listing_age_days``. No posting time → not stale (unknown).

Normal Israeli rental practice never flags: a deposit / guarantee / cheques
/ rent in advance at contract signing, Bit/PayBox on their own, payment
before moving in. A negated phrase ("לא צריך מקדמה", "no deposit before
viewing") never flags.

``payment_details_problem(text)`` is the guard the draft path uses: the tool
never sends payment details (VISION hard constraint), so a draft holding an
IBAN, a card-like number or a bank account number is refused with a reason.
"""

from __future__ import annotations

import re
import statistics
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Literal

from house_finder.models import Listing
from house_finder.text import canonical_city
from house_finder.textparse.context import HE_PREFIX, negator_before, prepare

if TYPE_CHECKING:
    from house_finder.profile.profile import SearchProfile
    from house_finder.store import Store

FlagKind = Literal["payment_before_viewing", "off_platform_payment", "too_good_price", "stale"]
Severity = Literal["danger", "warning", "info"]

SCAM_KINDS: frozenset[str] = frozenset({"payment_before_viewing", "off_platform_payment", "too_good_price"})
TOO_GOOD_RATIO = 0.6  # price below 60% of the area median
MIN_SAMPLES = 5  # other apartments needed before a median is trusted
NEAR_WORDS = 8  # payment word and before-viewing phrase at most 8 words apart
NEGATION_WINDOW = 3  # "לא צריך מקדמה", "we never ask for a deposit"
EVIDENCE_MAX = 160


@dataclass(frozen=True)
class Flag:
    """One warning: what, how bad, why, and the text it was read from."""

    kind: FlagKind
    severity: Severity
    reason: str
    evidence: str

    @property
    def is_scam(self) -> bool:
        return self.kind in SCAM_KINDS


# ------------------------------------------------------------------ patterns


def _he(words: str) -> str:
    return rf"(?<!\w){HE_PREFIX}(?:{words})(?!\w)"


def _en(words: str) -> str:
    return rf"(?<![a-z0-9])(?:{words})(?![a-z0-9])"


def _c(*parts: str) -> re.Pattern[str]:
    return re.compile("|".join(parts), re.IGNORECASE)


_ABROAD_HE = r'(?:חו"ל|חו\'ל|חוץ\s+לארץ)'
_VIEW_HE = r"צפי(?:י)?ה|ביקור|פגישה"

# Untraceable or earnest money: a scam sign on its own.
_STRONG = _c(
    _he(r"דמי\s+רצינות|דמי\s+צפי(?:י)?ה|ווסטרן\s+יוניון|מאני\s*גרם|ביטקוין|ביט\s+קוין|קריפטו"
        r"|כרטיס(?:י)?\s+(?:מתנה|גיפט)|גיפט\s*קארד\w*"),
    _en(r"earnest\s+money|good[\s-]faith\s+(?:deposit|payment|money)|viewing\s+fee"
        r"|western\s*union|money\s*gram|bitcoins?|btc|crypto\w*|usdt|tether|ethereum"
        r"|(?:gift|itunes|google\s+play|steam|amazon)\s*cards?"),
)

# A request for money (payment, transfer, deposit, advance, Bit/PayBox).
_PAY = _c(
    _he(r"העבר[הת]|העבירו|העביר|תעביר[וי]?|אעביר|נעביר|מקדמ(?:ה|ות|ת)|פי?קדון|תשלום|תשלמו|לשלם|שלמו|שלם|תשלם"
        r"|כסף|ביט|פיי\s?בוקס|פייבוקס"),
    _en(r"transfer\w*|wire\w*|deposit\w*|pay|paying|payment\w*|paid|money|advance|fee|paybox"),
)

# "before the viewing": the money comes before the owner sees the flat.
_BEFORE_VIEW = _c(
    _he(rf"לפני\s+(?:ש|ה)?(?:{_VIEW_HE}|תרא\w*|רוא\w*|ראי(?:ית|יה)\w*|נפגש\w*)"
        rf"|(?:בלי|ללא)\s+(?:ל?ראות|לבקר|{_VIEW_HE})"
        rf"|ל(?:תאם|קבוע|שריין)\s+(?:את\s+)?ה?(?:{_VIEW_HE})"
        r"|(?:כדי|על\s+מנת)\s+(?:לראות|לבקר|שתרא\w*)"),
    _en(r"(?:before|prior\s+to)\s+(?:(?:the|a|any|you|we|i|it|my)\s+){0,2}(?:view\w*|see\w*|visit\w*|showing|meet\w*|tour\w*)"
        r"|without\s+(?:(?:a|the|any)\s+)?(?:view\w*|see\w*|visit\w*|showing)"
        r"|(?:arrange|book|schedule|reserve|secure|set\s+up)\s+(?:(?:a|the|your)\s+)?(?:view\w*|visit|showing|tour)"
        r"|in\s+order\s+to\s+(?:see|view|visit)"),
)

# "pay to hold the flat": money to reserve / secure an apartment nobody has seen
# (a scam sign only when no contract signing is mentioned in the sentence).
_RESERVE = _c(
    _he(r"להבטחת|להבטיח|לשריין|לשמור|שריון"),
    _en(r"(?:to|and)\s+(?:secure|reserve|hold|lock)\s+(?:in\s+)?(?:the|this|your|an?)?\s*(?:apartment|flat|place|unit|home|rental)"
        r"|(?:secure|reserve|hold)\s+(?:the|this|your)\s+(?:apartment|flat|place|unit)"),
)
_RESERVE_OBJ = _c(_he(r"דירה|הדירה|דירת|הנכס|יחידה"), _en(r"apartment|flat|place|unit|home|rental"))

# "before the keys": a scam sign only when no contract signing is mentioned
# (rent is normally paid at signing, before the keys).
_BEFORE_KEYS = _c(
    _he(r"לפני\s+(?:קבלת\s+)?(?:ה)?מפתח(?:ות)?|כדי\s+לקבל\s+(?:את\s+)?ה?מפתח\w*"),
    _en(r"before\s+(?:(?:you|we|i)\s+)?(?:(?:get|receive|getting|receiving|hand\w*\s+over|send\w*|giv\w*)\s+(?:you\s+)?)?(?:the\s+)?keys?"
        r"|(?:to|in\s+order\s+to)\s+(?:get|receive)\s+(?:the\s+)?keys"),
)
_SIGNING = _c(_he(r"חוזה|חוזים|חתימ\w*|לחתום|נחתום"), _en(r"contract\w*|sign\w*|lease\s+agreement"))

# "pay first, then you see it / get the keys": the order IS the scam sign
# (a scam only when no contract signing is mentioned in the sentence).
_PAY_THEN = _c(
    _he(r"(?:שלם|תשלם|תשלמו|לשלם|שלמו)\s+(?:קודם|ראשון|בהתחלה)"
        r"|(?:ו?תקבל(?:ו|י)?|ו?תוכל(?:ו|י)?\s+לקבל)\s+(?:את\s+)?ה?מפתח\w*"
        r"|אחר\s+כך\s+(?:תוכל\w*\s+)?(?:ל?ראות|לבקר|תרא\w*|נתאם)"
        r"|(?:ועוד|ואז|ואחר\s+כך)\s+נתאם\s+(?:\w+\s+)?(?:סיור|צפי(?:י)?ה|ביקור|פגישה)"),
    _en(r"pay\s+first|(?:then|and)\s+(?:you\s+can|you'?ll|you\s+will|we'?ll|we\s+will)\s+"
        r"(?:see|view|visit|get\s+the\s+keys|receive\s+the\s+keys|arrange\s+a\s+(?:viewing|visit|showing))"
        r"|(?:you'?ll|you\s+will)\s+(?:get|receive)\s+(?:the\s+)?keys"
        r"|(?:arrange|schedule)\s+a\s+(?:viewing|visit|showing)\s+(?:later|afterwards|after)"),
)

# A third party abroad: "the owner is abroad" (with money/keys, like _ABROAD).
_OWNER_ABROAD = _c(
    _he(rf"בעל(?:ת)?\s+(?:ה)?(?:דירה|בית|נכס)\s+(?:נמצא\w*\s+|גר\w*\s+|שוהה\s+)?ב{_ABROAD_HE}"),
    _en(r"(?:the\s+)?(?:owner|landlord|landlady)\s+(?:is|lives|is\s+living|is\s+currently)\s+"
        r"(?:abroad|overseas|out\s+of\s+(?:the\s+)?country)"),
)

# Keys by mail / courier: the "landlord" will never meet you.
_KEYS_BY_MAIL = _c(
    _he(r"(?:אשלח|נשלח|לשלוח|שליחת|ישלחו|יישלחו|ישלח|שולח)\s+(?:לך\s+|לכם\s+|אליך\s+|אליכם\s+)?(?:את\s+)?ה?מפתח\w*"
        r"|מפתח\w*\s+(?:יישלחו|ישלחו|יגיעו|יימסרו)\s+(?:אליך\s+|לך\s+)?ב(?:דואר|שליח)"),
    _en(r"(?:send|mail|post|ship|courier)\w*\s+(?:you\s+)?(?:the\s+)?keys"
        r"|keys\s+(?:will\s+be\s+)?(?:sent|mailed|posted|shipped|delivered)\s+(?:to\s+you\s+)?(?:by|via|through)\s+\w+"),
)

# "I am abroad" (first person / presence, not "a family living abroad").
_ABROAD = _c(
    _he(rf"(?:אני|אנחנו|אנו|נמצא|נמצאת|נמצאים|גר|גרה|גרים|שוהה|שוהים|עברתי|עברנו)"
        rf"(?:\s+(?:כרגע|עכשיו|נמצא\w*|גר\w*|שוהה|עובד\w*))?\s+ב{_ABROAD_HE}"),
    _en(r"(?:i\s*'\s*m|i\s+am|we\s*'\s*re|we\s+are|currently|now)\s+(?:(?:currently|now|living|working|staying)\s+)?"
        r"(?:abroad|overseas|out\s+of\s+(?:the\s+)?country|outside\s+(?:of\s+)?israel|out\s+of\s+israel)"
        r"|(?:i|we)\s+(?:live|living|moved|relocated|work|working)\s+(?:\w+\s+)?(?:abroad|overseas)"),
)
# What "I am abroad" must come with: keys, a deposit / transfer, or sending
# by mail or courier ("send me a message" alone is not it).
_ABROAD_WITH = _c(
    _he(r"מפתח\w*|שליח|דואר(?!\s+אלקטרוני)|מקדמ(?:ה|ות|ת)|פי?קדון|העבר[הת]|העבירו|העביר|תעביר[וי]?|כסף"),
    _en(r"keys?|courier|by\s+(?:mail|post)|deposit\w*|transfer\w*|wire\w*|advance|money"),
)

_OFF_PLATFORM = _c(
    _he(rf"פייפאל|פיי\s?פאל|(?:קישור|לינק)\s+(?:ל|ה)?תשלום|חשבון\s+(?:בנק\s+)?ב{_ABROAD_HE}"
        rf"|בנק\s+ב{_ABROAD_HE}|העברה\s+בינלאומית|סוויפט"),
    _en(r"pay\s?pal|payment\s+link|link\s+to\s+pay|escrow|transferwise"
        r"|pay(?:ment)?\s+(?:via|through|on|using)\s+(?:airbnb|booking(?:\.com)?)"
        r"|(?:airbnb|booking\.com)\s+(?:payment|deposit)"
        r"|(?:account|bank)\s+(?:abroad|overseas)"
        r"|international\s+(?:wire|transfer|bank\s+transfer)|swift\s+(?:transfer|code|payment)"),
)

# A sentence ends at ! ? ; a line break, or a full stop that is not a decimal point.
_SENT_END = re.compile(r"[!?;\n]|\.(?![0-9])")


# ----------------------------------------------------------------- helpers


def _snippet(src: str, a: int, b: int, pad: int = 30) -> str:
    """The original text around ``[a, b)``, whitespace collapsed, clipped."""
    start = max(0, a - pad)
    end = min(len(src), b + pad)
    text = " ".join(src[start:end].split())
    if len(text) > EVIDENCE_MAX:
        text = text[: EVIDENCE_MAX - 1] + "…"
    prefix = "…" if start > 0 else ""
    suffix = "…" if end < len(src) and not text.endswith("…") else ""
    return f"{prefix}{text}{suffix}"


def _sentence(work: str, pos: int) -> tuple[int, int]:
    start = 0
    for m in _SENT_END.finditer(work, 0, pos):
        start = m.end()
    m = _SENT_END.search(work, pos)
    return start, (m.start() if m else len(work))


def _live(pattern: re.Pattern[str], work: str) -> list[re.Match[str]]:
    """Matches of ``pattern`` that no negator governs ("לא צריך מקדמה")."""
    return [m for m in pattern.finditer(work) if negator_before(work, m.start(), NEGATION_WINDOW) is None]


def _words_between(work: str, a: re.Match[str], b: re.Match[str]) -> int:
    lo, hi = sorted((a, b), key=lambda m: m.start())
    return len(work[lo.end():hi.start()].split()) if hi.start() > lo.end() else 0


def _near(work: str, pays: list[re.Match[str]], marks: Iterable[re.Match[str]]) -> tuple[int, int] | None:
    """Span of the first (payment word, marker) pair in one sentence, ≤ NEAR_WORDS apart."""
    for mark in marks:
        s0, s1 = _sentence(work, mark.start())
        for pay in pays:
            if s0 <= pay.start() < s1 and _words_between(work, pay, mark) <= NEAR_WORDS:
                return min(pay.start(), mark.start()), max(pay.end(), mark.end())
    return None


# ------------------------------------------------------------ text checks


def payment_flags(text: str | None) -> list[Flag]:
    """``payment_before_viewing`` / ``off_platform_payment`` flags for one
    free text (at most one of each kind, the first hit). Pure."""
    src, work = prepare(text)
    if not work.strip():
        return []
    out: list[Flag] = []
    before = _payment_before_viewing(src, work)
    if before is not None:
        out.append(before)
    off = _live(_OFF_PLATFORM, work)
    if off:
        m = off[0]
        out.append(Flag("off_platform_payment", "danger",
                        f"asks for payment through “{src[m.start():m.end()]}” — outside normal rental "
                        "payment (bank transfer, cheques or Bit/PayBox to the landlord at signing)",
                        _snippet(src, m.start(), m.end())))
    return out


def _payment_before_viewing(src: str, work: str) -> Flag | None:
    def flag(reason: str, a: int, b: int) -> Flag:
        return Flag("payment_before_viewing", "danger", reason, _snippet(src, a, b))

    strong = _live(_STRONG, work)
    if strong:
        m = strong[0]
        return flag(f"asks for “{src[m.start():m.end()]}” — earnest money, a viewing fee or "
                    "untraceable payment is a common rental scam", m.start(), m.end())
    pays = _live(_PAY, work)
    if not pays:
        return None
    span = _near(work, pays, _BEFORE_VIEW.finditer(work))
    if span is not None:
        return flag("asks for payment before a viewing", *span)
    reserve = [m for m in _RESERVE.finditer(work)
               if _RESERVE_OBJ.search(work, m.start(), _sentence(work, m.start())[1])
               and not _SIGNING.search(work, *_sentence(work, m.start()))]
    span = _near(work, pays, reserve)
    if span is not None:
        return flag("asks for money to reserve the apartment before it is seen or a contract is signed", *span)
    unsigned = [m for m in _BEFORE_KEYS.finditer(work)
                if not _SIGNING.search(work, *_sentence(work, m.start()))]
    span = _near(work, pays, unsigned)
    if span is not None:
        return flag("asks for payment before handing over the keys, with no contract signing mentioned", *span)
    then = [m for m in _PAY_THEN.finditer(work)
            if not _SIGNING.search(work, *_sentence(work, m.start()))]
    span = _near(work, pays, then)
    if span is not None:
        return flag("asks for payment first and only then a viewing or the keys, "
                    "with no contract signing mentioned", *span)
    mail = _KEYS_BY_MAIL.search(work)
    if mail is not None:
        return flag("asks for payment and sends the keys by mail or courier — you would never meet the landlord",
                    mail.start(), mail.end())
    return None


def _abroad_flag(src: str, work: str) -> Flag | None:
    abroad = _ABROAD.search(work) or _OWNER_ABROAD.search(work)
    if abroad is None:
        return None
    rest = work[: abroad.start()] + " " * (abroad.end() - abroad.start()) + work[abroad.end():]
    other = next(iter(_live(_ABROAD_WITH, rest)), None)
    if other is None:
        return None
    return Flag("payment_before_viewing", "danger",
                f"poster says they are abroad and mentions “{src[other.start():other.end()]}” — "
                "“I am abroad, I will send the keys after you pay” is a common rental scam",
                f"{_snippet(src, abroad.start(), abroad.end())} / {_snippet(src, other.start(), other.end(), pad=15)}")


def text_flags(text: str | None) -> list[Flag]:
    """Every text-based flag of one free text: payment before viewing (incl.
    the "I am abroad" pattern) and off-platform payment. Pure."""
    flags = payment_flags(text)
    if not any(f.kind == "payment_before_viewing" for f in flags):
        src, work = prepare(text)
        abroad = _abroad_flag(src, work) if work.strip() else None
        if abroad is not None:
            flags.insert(0, abroad)
    return flags


# ------------------------------------------------------------- price stats


def _utc(value: datetime) -> datetime:
    return value if value.tzinfo else value.replace(tzinfo=timezone.utc)


class AreaStats:
    """Stored asking prices by (canonical city, rooms), one per duplicate
    cluster — the same apartment twice never counts twice."""

    def __init__(self, listings: Iterable[Listing], links: Mapping[str, tuple[str, str]] | None = None):
        self._links = dict(links or {})
        # (city, rooms) -> cluster id -> price (the canonical's when stated)
        self._prices: dict[tuple[str, float], dict[str, int]] = {}
        for lst in listings:
            if lst.price is None or lst.rooms is None or not (lst.city or "").strip():
                continue
            cluster = self.cluster_of(lst.id)
            bucket = self._prices.setdefault((canonical_city(lst.city), float(lst.rooms)), {})
            if cluster not in bucket or lst.id == cluster:
                bucket[cluster] = lst.price

    @classmethod
    def from_store(cls, store: Store) -> AreaStats:
        return cls(store.iter_listings(), store.duplicate_links())

    def cluster_of(self, listing_id: str) -> str:
        link = self._links.get(listing_id)
        return link[0] if link else listing_id

    def median_for(self, city: str, rooms: float, *, exclude: Iterable[str] = ()) -> tuple[float, int] | None:
        """``(median price, sample count)`` of the other clusters in
        ``city`` with ``rooms``; None below ``MIN_SAMPLES``."""
        skip = {self.cluster_of(i) for i in exclude}
        bucket = self._prices.get((canonical_city(city), float(rooms)), {})
        prices = [p for cluster, p in bucket.items() if cluster not in skip]
        if len(prices) < MIN_SAMPLES:
            return None
        return float(statistics.median(prices)), len(prices)


def too_good_price_flag(listing: Listing, stats: AreaStats, *, exclude: Iterable[str] = ()) -> Flag | None:
    """``too_good_price`` when the price is under 60% of the area median."""
    if listing.price is None or listing.rooms is None or not (listing.city or "").strip():
        return None
    found = stats.median_for(listing.city, listing.rooms, exclude=[listing.id, *exclude])  # type: ignore[arg-type]
    if found is None:
        return None
    median, n = found
    if listing.price >= TOO_GOOD_RATIO * median:
        return None
    share = listing.price / median * 100
    return Flag("too_good_price", "warning",
                f"₪{listing.price:,} is {share:.0f}% of the median ₪{median:,.0f} for {listing.rooms:g} rooms in "
                f"{listing.city} ({n} other stored listings) — a price far below the market is a common scam bait",
                f"₪{listing.price:,}")


def stale_flag(listing: Listing, profile: SearchProfile, *, duplicates: Iterable[Listing] = (),
               now: datetime | None = None) -> Flag | None:
    """``stale`` when the NEWEST stated ``posted_at`` of the listing and its
    duplicates is older than ``profile.max_listing_age_days`` (a fresh repost
    keeps the apartment fresh). No posting time anywhere → None (unknown)."""
    times = [_utc(lst.posted_at) for lst in (listing, *duplicates) if lst.posted_at is not None]
    if not times:
        return None
    now = _utc(now or datetime.now(timezone.utc))
    newest = max(times)
    age_days = max(0.0, (now - newest).total_seconds() / 86400)
    limit = profile.max_listing_age_days
    if age_days <= limit:
        return None
    return Flag("stale", "info",
                f"posted {age_days:.0f} days ago, older than your limit of {limit} days",
                f"posted {newest.date().isoformat()}")


def flags_for(
    listing: Listing,
    profile: SearchProfile | None,
    area_stats: AreaStats | None = None,
    *,
    duplicates: Iterable[Listing] = (),
    now: datetime | None = None,
) -> list[Flag]:
    """Every flag of a listing (with its duplicate cluster), scams first.

    Text flags read the title and description of the listing AND its
    duplicates (evidence from a duplicate names its source). ``profile`` None
    (broken profile file) → no stale flag; ``area_stats`` None → no price flag.
    """
    dups = list(duplicates)
    found: dict[str, Flag] = {}
    for member in (listing, *dups):
        text = "\n".join(s for s in (member.title, member.description) if s)
        for f in text_flags(text):
            if f.kind not in found:
                evidence = f.evidence if member is listing else f"({member.source}) {f.evidence}"
                found[f.kind] = Flag(f.kind, f.severity, f.reason, evidence)
    flags = [found[k] for k in ("payment_before_viewing", "off_platform_payment") if k in found]
    if area_stats is not None:
        price = too_good_price_flag(listing, area_stats, exclude=[d.id for d in dups])
        if price is not None:
            flags.append(price)
    if profile is not None:
        stale = stale_flag(listing, profile, duplicates=dups, now=now)
        if stale is not None:
            flags.append(stale)
    return flags


def is_stale(flags: Iterable[Flag]) -> bool:
    return any(f.kind == "stale" for f in flags)


# ------------------------------------------------------- payment details


_IBAN = re.compile(r"(?<![A-Za-z0-9])[A-Z]{2}[0-9]{2}(?:[ ]?[A-Z0-9]){11,30}(?![A-Za-z0-9])")
_IBAN_WORD = re.compile(r"(?<![a-z])iban(?![a-z])|איבאן|אייבן", re.IGNORECASE)
_LONG_NUMBER = re.compile(r"(?<![0-9])[0-9](?:[ -]?[0-9]){12,18}(?![0-9])")
_PHONE = re.compile(r"(?<![0-9])(?:\+?972[ -]?|0)[0-9]{1,2}[ -]?[0-9]{3}[ -]?[0-9]{4}(?![0-9])")
_ACCOUNT = re.compile(
    r"(?:(?<![a-z])(?:account|acct|a/c|routing|sort\s+code|swift|bic|cvv|card\s+(?:number|no)|credit\s+card)(?![a-z])"
    r"|(?<!\w)" + HE_PREFIX + r"(?:חשבון|ח-ן|ח\"ן|סניף|כרטיס\s+אשראי|אשראי|מספר\s+כרטיס))"
    r"[^0-9\n,]{0,25}([0-9][0-9 -]{3,}[0-9])",
    re.IGNORECASE,
)


def payment_details_problem(text: str | None) -> str | None:
    """Why ``text`` looks like it carries payment details (IBAN, a card-like
    13–19 digit number, a bank account / card number after its label), or
    None. The number is never echoed in full."""
    _, work = prepare(text)
    work_no_phones = _PHONE.sub(" ", work)
    if _IBAN_WORD.search(work) or _IBAN.search(work):
        return "it contains an IBAN — the tool never sends payment details"
    if _LONG_NUMBER.search(work_no_phones):
        return "it contains a card-like number (13–19 digits) — the tool never sends payment details"
    for m in _ACCOUNT.finditer(work):
        if sum(c.isdigit() for c in m.group(1)) >= 4:
            return "it contains a bank account or card number — the tool never sends payment details"
    return None


__all__ = [
    "MIN_SAMPLES",
    "SCAM_KINDS",
    "TOO_GOOD_RATIO",
    "AreaStats",
    "Flag",
    "flags_for",
    "is_stale",
    "payment_details_problem",
    "payment_flags",
    "stale_flag",
    "text_flags",
    "too_good_price_flag",
]

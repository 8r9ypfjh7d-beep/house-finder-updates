"""Cross-source deduplication (hardening plan, stage 1).

Two halves:

- **Pure** (no I/O): ``fingerprint(listing)`` reduces a listing to the
  signals that identify an apartment; ``conflicts(a, b)`` names the facts
  that prove two listings are DIFFERENT apartments; ``duplicate_reason(a, b)``
  says why two listings are the same apartment, or None.
- **The runner** ``dedup_new(store, new_ids)``: after each collection, links
  each new listing to the cluster of an earlier, recent one. The store holds
  the links (``duplicates`` table); the earliest seen listing is canonical.

Merging two different apartments hides a real match (VISION priority 2), so
every rule prefers NOT merging: any conflicting fact vetoes, an ambiguous
match (two clusters) is left alone, and a shared phone alone is never enough
(an agent posts many apartments with one number).
"""

from __future__ import annotations

import re
from collections.abc import Iterable
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import PurePosixPath
from typing import TYPE_CHECKING
from urllib.parse import urlsplit

from house_finder.matching import MatchResult, rank
from house_finder.models import Listing
from house_finder.text import canonical_city, normalize_place, safe_url
from house_finder.textparse.phones import find_phones

if TYPE_CHECKING:
    from house_finder.profile.profile import SearchProfile
    from house_finder.store import Store

PRICE_TOLERANCE = 0.03  # price within ±3% of the larger price
SQM_TOLERANCE = 0.05  # sqm within ±5%
TEXT_SIMILARITY = 0.8  # token Jaccard of the descriptions
MIN_TEXT_TOKENS = 6  # a shorter description is too generic to compare
MIN_PHOTO_STEM = 8  # "1.jpg" / "image.jpg" are not identifying
MIN_PHOTO_CORE = 4  # ... nor is "image_0001": generic words and short digit runs are discounted
WINDOW_DAYS = 60  # new listings are compared with listings seen in the last 60 days

REASON_ADDRESS = "same address, price and rooms"
REASON_PHONE = "same phone, price and rooms"
REASON_PHONE_IDENTITY = "same phone and {what}"
REASON_TEXT = "near-identical text and price"

_TOKEN = re.compile(r"\w+")
_GENERIC_PHOTO = re.compile(
    r"image|img|photo|pic|picture|default|placeholder|noimage|no|available|thumb|thumbnail|"
    r"main|listing|apartment|large|small|medium|full|original|[^a-z0-9]|\d{1,5}")
_TRAILING_NUMBER = re.compile(r"^(.*?)\s+(\d+)\s*([a-zא-ת]?)$")


@dataclass(frozen=True)
class Fingerprint:
    """The identifying signals of one listing. ``None`` / empty = not stated."""

    id: str
    street: str | None
    house_number: str | None
    city: str | None
    phones: frozenset[str]
    price: int | None
    rooms: float | None
    sqm: int | None
    floor: int | None
    photos: frozenset[str]
    tokens: frozenset[str]


# ------------------------------------------------------------------ pure


def _street_and_number(listing: Listing) -> tuple[str | None, str | None]:
    if not listing.street or not listing.street.strip():
        return None, None
    street = normalize_place(listing.street)
    m = _TRAILING_NUMBER.match(street)
    if m:
        return m.group(1), m.group(2) + m.group(3)
    # yad2 keeps the house number out of `street`; its title reads "<street> <n>".
    if listing.title:
        found = re.search(rf"(?:^|\s){re.escape(street)}\s+(\d+)(?!\d)", normalize_place(listing.title))
        if found:
            return street, found.group(1)
    return street, None


def _phones(listing: Listing) -> frozenset[str]:
    texts = [listing.contact.phone] if listing.contact and listing.contact.phone else []
    texts.append(listing.description or "")
    return frozenset(digits for text in texts for digits, _, _ in find_phones(text))


def _photo_keys(listing: Listing) -> frozenset[str]:
    keys = set()
    for url in listing.photos:
        href = safe_url(url)
        if not href:
            continue
        name = PurePosixPath(urlsplit(href).path).name.casefold()
        stem = name.rsplit(".", 1)[0]
        if len(stem) >= MIN_PHOTO_STEM and len(_GENERIC_PHOTO.sub("", stem)) >= MIN_PHOTO_CORE:
            keys.add(name)
    return frozenset(keys)


def text_tokens(text: str) -> frozenset[str]:
    """Normalised word set (casefold, niqqud and quote marks removed)."""
    return frozenset(_TOKEN.findall(normalize_place(text or "")))


def fingerprint(listing: Listing) -> Fingerprint:
    """The signals ``duplicate_reason`` compares. Pure."""
    street, number = _street_and_number(listing)
    return Fingerprint(
        id=listing.id,
        street=street or None,
        house_number=number,
        city=canonical_city(listing.city) if listing.city and listing.city.strip() else None,
        phones=_phones(listing),
        price=listing.price,
        rooms=listing.rooms,
        sqm=listing.sqm,
        floor=listing.floor,
        photos=_photo_keys(listing),
        tokens=text_tokens(listing.description),
    )


def _close(a: float, b: float, tolerance: float) -> bool:
    return abs(a - b) <= tolerance * max(abs(a), abs(b))


def price_close(a: Fingerprint, b: Fingerprint) -> bool:
    """Both prices stated and within ±3%."""
    return a.price is not None and b.price is not None and _close(a.price, b.price, PRICE_TOLERANCE)


def rooms_equal(a: Fingerprint, b: Fingerprint) -> bool:
    """Both room counts stated and equal."""
    return a.rooms is not None and b.rooms is not None and a.rooms == b.rooms


def same_address(a: Fingerprint, b: Fingerprint) -> bool:
    """Same street AND the same house number, both stated."""
    return (a.street is not None and a.street == b.street
            and a.house_number is not None and a.house_number == b.house_number)


def text_similarity(a: Fingerprint, b: Fingerprint) -> float:
    """Token Jaccard of the descriptions; 0 when either is too short."""
    if len(a.tokens) < MIN_TEXT_TOKENS or len(b.tokens) < MIN_TEXT_TOKENS:
        return 0.0
    if any(any(c.isdigit() for c in t) for t in a.tokens ^ b.tokens):
        return 0.0  # a template reused for another flat differs in a number (street, floor, rooms)
    return len(a.tokens & b.tokens) / len(a.tokens | b.tokens)


def physical_agreement(a: Fingerprint, b: Fingerprint) -> str | None:
    """A fact about the apartment ITSELF, stated on both sides and equal:
    floor, size (±5%) or street + house number. Phone, price, rooms and text
    are shared by an agent's or a template's many flats; these are not."""
    if a.floor is not None and a.floor == b.floor:
        return "floor"
    if a.sqm is not None and b.sqm is not None and _close(a.sqm, b.sqm, SQM_TOLERANCE):
        return "size"
    if same_address(a, b):
        return "address"
    return None


def conflicts(a: Fingerprint, b: Fingerprint) -> list[str]:
    """Facts stated on BOTH sides that differ — each proves two different
    apartments (same building, other floor/rooms is not a duplicate). A fact
    missing on either side never conflicts."""
    found: list[str] = []
    if a.rooms is not None and b.rooms is not None and a.rooms != b.rooms:
        found.append("rooms differ")
    if a.floor is not None and b.floor is not None and a.floor != b.floor:
        found.append("floor differs")
    if a.sqm is not None and b.sqm is not None and not _close(a.sqm, b.sqm, SQM_TOLERANCE):
        found.append("size differs")
    if a.price is not None and b.price is not None and not price_close(a, b):
        found.append("price differs")
    if a.city is not None and b.city is not None and a.city != b.city:
        found.append("city differs")
    if a.street is not None and b.street is not None and a.street != b.street:
        found.append("street differs")
    if a.house_number is not None and b.house_number is not None and a.house_number != b.house_number:
        found.append("house number differs")
    return found


def duplicate_reason(a: Fingerprint, b: Fingerprint) -> str | None:
    """Why ``a`` and ``b`` are the same apartment, or None. Pure.

    Never when they are the same listing or any fact conflicts. Then, first
    match wins:

    1. same address (street + house number) AND price ±3% AND rooms equal;
    2. same phone AND price ±3% AND rooms equal (both stated on both) AND a
       physical agreement (floor, size or address — ``physical_agreement``);
    3. same phone AND an identity signal: same address, a shared photo, or
       near-identical text — a phone alone is never enough;
    4. near-identical description (token Jaccard ≥ 0.8) AND price ±3% AND
       rooms equal or a physical agreement.

    Rules 2 and 4 need the extra fact because one agent (one phone) or one
    template (one text) covers many flats at the same price: merging two
    DIFFERENT apartments hides a real match (VISION priority 2).
    """
    if a.id == b.id or conflicts(a, b):
        return None
    if same_address(a, b) and price_close(a, b) and rooms_equal(a, b):
        return REASON_ADDRESS
    similar = text_similarity(a, b) >= TEXT_SIMILARITY
    if a.phones & b.phones:
        if price_close(a, b) and rooms_equal(a, b) and physical_agreement(a, b):
            return REASON_PHONE
        what = ("address" if same_address(a, b) else "photo" if a.photos & b.photos
                else "text" if similar else None)
        if what:
            return REASON_PHONE_IDENTITY.format(what=what)
    if similar and price_close(a, b) and (rooms_equal(a, b) or physical_agreement(a, b)):
        return REASON_TEXT
    return None


# ---------------------------------------------------------------- runner


@dataclass(frozen=True)
class DuplicateLink:
    """One link written by ``dedup_new``."""

    listing_id: str
    canonical_id: str
    reason: str


def dedup_new(
    store: Store, new_ids: Iterable[str], *, now: datetime | None = None, window_days: int = WINDOW_DAYS
) -> list[DuplicateLink]:
    """Link each of ``new_ids`` to the cluster of an earlier listing seen in
    the last ``window_days``; returns the links written.

    - Only listings seen EARLIER (``first_seen``, then id) are candidates, so
      the canonical is always the earliest seen; a duplicate links to its
      match's canonical (no chains).
    - The new listing must conflict with NO member of that cluster.
    - Matches in two different clusters are ambiguous: nothing is linked.
    - Idempotent: an id already linked, or already a canonical, is skipped.
    """
    now = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    since = (now - timedelta(days=window_days)).isoformat(timespec="microseconds")
    pool = store.recent_listings(since)
    order = {listing.id: i for i, (listing, _) in enumerate(pool)}
    prints = {listing.id: fingerprint(listing) for listing, _ in pool}
    links = {dup: canon for dup, (canon, _) in store.duplicate_links().items()}

    def print_of(listing_id: str) -> Fingerprint | None:
        if listing_id not in prints:
            listing = store.get_listing(listing_id)
            if listing is None:
                return None
            prints[listing_id] = fingerprint(listing)
        return prints[listing_id]

    def members(canonical: str) -> list[str]:
        return [canonical] + [d for d, c in links.items() if c == canonical]

    written: list[DuplicateLink] = []
    for new_id in sorted({i for i in new_ids if i in order}, key=order.__getitem__):
        if new_id in links or new_id in links.values():
            continue
        mine = prints[new_id]
        matches: dict[str, str] = {}  # canonical -> reason
        for listing, _ in pool[: order[new_id]]:
            reason = duplicate_reason(mine, prints[listing.id])
            if reason is None:
                continue
            canonical = links.get(listing.id, listing.id)
            matches.setdefault(canonical, reason)
        if len(matches) != 1:
            continue  # no match, or ambiguous between clusters: leave it shown
        canonical, reason = next(iter(matches.items()))
        cluster = [p for p in (print_of(m) for m in members(canonical)) if p is not None]
        if any(conflicts(mine, other) for other in cluster):
            continue
        if store.link_duplicate(new_id, canonical, reason):
            links[new_id] = canonical
            written.append(DuplicateLink(new_id, canonical, reason))
    return written


# ---------------------------------------------------------- review queue


@dataclass(frozen=True)
class ClusterMatch:
    """One cluster in the review queue: the listing shown, its result, and
    the other members as ``(listing, reason)`` — "Also on: <source> (<reason>)"."""

    listing: Listing
    result: MatchResult
    also_on: list[tuple[Listing, str]]


def rank_clusters(
    canonicals: Iterable[Listing],
    duplicates: dict[str, list[tuple[Listing, str]]],
    profile: SearchProfile,
    now: datetime | None = None,
) -> list[ClusterMatch]:
    """Rank one entry per cluster, best first. Pure.

    The entry is the canonical when it passes the profile; otherwise the
    best passing duplicate (a cluster is hidden only when NO member passes —
    a duplicate never hides a match, VISION priority 2). ``duplicates`` maps
    a canonical id to its ``(duplicate, reason)`` pairs.
    """
    chosen: dict[str, tuple[Listing, list[tuple[Listing, str]]]] = {}
    for canonical in canonicals:
        dups = duplicates.get(canonical.id, [])
        passing = rank([canonical] + [d for d, _ in dups], profile, now)
        if not passing:
            continue
        shown = next((lst for lst, _ in passing if lst.id == canonical.id), passing[0][0])
        if shown.id == canonical.id:
            others = list(dups)
        else:
            reason = next(r for d, r in dups if d.id == shown.id)
            others = [(canonical, reason)] + [(d, r) for d, r in dups if d.id != shown.id]
        chosen[shown.id] = (shown, others)
    return [ClusterMatch(lst, res, chosen[lst.id][1])
            for lst, res in rank([c[0] for c in chosen.values()], profile, now)]

# quality — listing quality (deduplication, scam and stale flags)

Recognises the same apartment listed twice (yad2 and a Facebook group, two
groups, a repost) so the owner reviews it once (hardening plan stage 1,
BRIEF M4), and flags scams and stale listings with a reason and evidence
(stage 2; BRIEF §12 risks, VISION hard constraint on payment).

**Never merge two different apartments**: a merged real match is a hidden
match (VISION priority 2). Every rule prefers showing a duplicate twice over
hiding an apartment.

## Code Files

- `dedup.py` — pure: `Fingerprint`, `fingerprint()`, `conflicts()`, `duplicate_reason()`, `price_close()`, `rooms_equal()`, `same_address()`, `text_similarity()`, `text_tokens()`, `rank_clusters()` + `ClusterMatch`; runner: `dedup_new()` + `DuplicateLink`; constants `PRICE_TOLERANCE`, `SQM_TOLERANCE`, `TEXT_SIMILARITY`, `MIN_TEXT_TOKENS`, `MIN_PHOTO_STEM`, `WINDOW_DAYS`
- `flags.py` — pure: `Flag` (+ `is_scam`), `flags_for()`, `text_flags()`, `payment_flags()`, `too_good_price_flag()` + `AreaStats`, `stale_flag()`, `is_stale()`, `payment_details_problem()`; constants `SCAM_KINDS`, `TOO_GOOD_RATIO`, `MIN_SAMPLES`, `NEAR_WORDS`, `NEGATION_WINDOW`
- `__init__.py` — re-exports

## The rule

`fingerprint(listing)` (no I/O): street (`text.normalize_place`) + house
number (trailing number of `street`, else `<street> <n>` in the title —
yad2's shape), city (`text.canonical_city`), phones (`textparse.find_phones`
over `contact.phone` and the description — national ASCII digits), price,
rooms, sqm, floor, photo file names (stem ≥ 8 chars, via `safe_url`),
description word set.

`conflicts(a, b)` — a fact stated on BOTH sides that differs: rooms, floor,
sqm beyond ±5%, price beyond ±3%, city, street, house number. Missing on
either side never conflicts.

`duplicate_reason(a, b)` — None for the same listing or any conflict; else
the first that holds:

| Reason | Needs |
|---|---|
| `same address, price and rooms` | street + house number equal (both stated) AND price ±3% AND rooms equal |
| `same phone, price and rooms` | a shared phone AND price ±3% AND rooms equal (both stated on both) AND a physical agreement: floor equal, size ±5%, or street + house number equal |
| `same phone and address/photo/text` | a shared phone AND same address, a shared photo, or near-identical text |
| `near-identical text and price` | description token Jaccard ≥ 0.8 (each ≥ 6 words, and the differing words contain no digit: a reused template for another flat differs in a number) AND price ±3% AND (rooms equal OR a physical agreement) |

A phone alone never merges: an agent posts many apartments with one number.
The same agent (one phone) or one template (one text) also covers many flats
at the SAME price and rooms, so those two rules additionally need a fact about
the flat itself (`physical_agreement`). Decided 2026-10-10 from VISION
priority 2 after a checker built two such false merges.

## Runner: `dedup_new(store, new_ids, *, now=None, window_days=60)`

Called by the post-collection hook (`notify.run_dedup`) BEFORE notifying.
For each new id, in `first_seen` order, compared with every listing last
seen in the window and seen EARLIER:

- the match's canonical (`store.canonical_of`) is the target — the earliest
  seen listing is canonical, and links never chain;
- matches in two different clusters → nothing linked (ambiguous);
- the new listing must conflict with no member of the target cluster;
- an id already linked or already a canonical is skipped (idempotent).

The links live in the store's `duplicates` table (`store.link_duplicate`).

## Review queue: `rank_clusters(canonicals, duplicates, profile)`

One entry per cluster, best first: the canonical when it passes, else the
best passing duplicate. `ClusterMatch.also_on` = the other members with the
reason — the review card's "Also on: <source> (<reason>)".

## Flags: `flags_for(listing, profile, area_stats, *, duplicates=(), now=None)`

Computed at READ time (review card, message page) from the listing, its
duplicate cluster, the profile and the stored listings — nothing is stored,
no migration. Returns `Flag(kind, severity, reason, evidence)`, scams first.
Text flags read title + description of the listing and of each duplicate
(evidence from a duplicate is prefixed `(<source>)`). Evidence is a slice of
the original text (`textparse.context.prepare` keeps offsets). Scam flags
never hide a listing; stale hides it from the queue (web: "Show stale").

| Kind | Severity | Fires on |
|---|---|---|
| `payment_before_viewing` | danger | earnest money / viewing fee (`דמי רצינות`, `דמי צפייה`, `earnest money`, `viewing fee`); untraceable payment (Western Union, MoneyGram, bitcoin/crypto/USDT, gift cards); a payment word (`העברה`, `מקדמה`, `פיקדון`, `תשלום`, `כסף`, `ביט`, `פייבוקס`, `deposit`, `transfer`, `pay`…) within 8 words, same sentence, of a before-viewing phrase (`לפני הצפייה/ביקור/שתראו`, `בלי לראות`, `לתאם צפייה`, `before viewing/seeing`, `without seeing`, `book a viewing`); payment before the keys when that sentence names no contract/signing; money to reserve/secure the flat (`להבטחת הדירה`, `to secure the apartment`) with no signing in the sentence; "pay first, then see / get the keys" (`שלם קודם`, `ותקבלו מפתח`, `אחר כך תוכל לראות`, `ועוד נתאם סיור`, `pay first`, `then you can see`, `you'll receive the keys`) near a payment word with no signing in the sentence; keys sent by mail/courier; "I am abroad" (`אני בחו"ל`, `I'm abroad/overseas`) or "the owner is abroad" (`בעל הדירה בחו"ל`, `the landlord is abroad`) with keys / deposit / transfer / mail or courier anywhere in the post |
| `off_platform_payment` | danger | PayPal, payment link, escrow, Airbnb/Booking payment, an account abroad, international / SWIFT transfer |
| `too_good_price` | warning | price < 60% of the median of stored listings with the same `canonical_city` and rooms, ≥ 5 samples; the reason gives the median and the sample count |
| `stale` | info | the newest stated `posted_at` of the cluster is older than `max_listing_age_days` (same "older than" as matching's `recency` reason) |

**Never flags** (normal practice): deposit / guarantee / cheques / rent in
advance at contract signing (`פיקדון בחתימת חוזה`, `deposit at contract
signing`, `ערבות בנקאית`, `שכר דירה מראש`), Bit/PayBox alone, payment before
moving in, payment before the keys next to "contract"/"signing", "I'm
abroad" with only "send me a message". **Negation wins**: a payment phrase
with a negator up to 3 words before it (`textparse.context.negator_before`:
`לא צריך מקדמה`, `ללא דמי רצינות`, `no deposit before viewing`, `we never ask
for payment`) does not flag. Bare `מקדמה` / `send deposit` flag only with a
before-viewing, keys or abroad context.

**Price samples** (`AreaStats`): one price per duplicate cluster (the
canonical's when stated), so the same apartment never counts twice; the
listing's own cluster is excluded. Missing price, city or rooms → no flag.

**No posting time → not stale** (unknown; never hidden for missing data,
VISION priority 2). A fresh duplicate (repost) keeps the cluster fresh.

### Payment-details guard: `payment_details_problem(text) -> str | None`

The reason a text looks like it carries payment details — an IBAN (or the
word), a card-like 13–19 digit number, or an account / card number after
its label (`חשבון`, `סניף`, `account`, `credit card`…) — else None. The
number is never echoed. The web draft path refuses such text (see web.md):
the default templates hold none, but an owner template or a listing field
could. Israeli phone numbers are removed before the number checks, so a
message carrying the owner's phone (or two phones side by side) is never
refused; the account rule needs the number right after its label.

## Optimizations and Features

- Fingerprints are computed once per run for the whole window, not per pair.
- Conflict veto is applied twice: against the matched listing and against
  every member of its cluster, so a link through a member never merges an
  apartment the canonical contradicts.
- A failing canonical never hides a passing duplicate (`rank_clusters`).
- The database refuses self-links, chains, links to unknown listings and
  edits (migration 6 CHECK + triggers), so the invariants hold outside
  this module too.
- Short descriptions (< 6 words) and generic photo names (`1.jpg`, `image_0001.jpg`, `default_image.jpg`) are not
  compared — too common to identify an apartment.
- Flags reuse `textparse.context` (`prepare`, `negator_before`, `HE_PREFIX`),
  so Hebrew prefixes, gershayim (`חו״ל`) and negation behave as in the
  parser.
- The review queue computes only `stale_flag` for every cluster and the full
  `flags_for` for the one card shown.
- Payment before the keys is normal at signing, so the keys rule is muted by
  "contract"/"signing" in the same sentence; a full stop between digits
  (`4.500`) does not end a sentence.

# updater — in-app code updates

The installed app updates its own `house_finder` package: the owner sees
"Update available: version X — Update now", one click downloads a few
hundred KB, and the app restarts itself into the new code. A new installer
is needed only when `MIN_INSTALLER` rises (dependencies, the launcher or the
PyInstaller collection changed). A source checkout never self-updates (git).
Requires [web/web.md](web/web.md) for the banner and routes.

## Code Files

- `house_finder/version.py` — `APP_VERSION` (code version), `MIN_INSTALLER` (oldest installer it runs on); plain literals read by regex in the spec, launcher and builder
- `house_finder/updater.py` — `parse_version()` / `newer()`, `Manifest`, `UpdateInfo`, `parse_manifest()`, `check_for_update()`, `download_bundle()`, `safe_extract()`, `validate_tree()`, `apply_update()`, `switch_to()`, `cleanup()`, `read_state()` / `write_state()`, `is_bad()`, `running_update_version()`, `mark_running_good()`, `installer_version()`, `manifest_url()`, `update_client()`, `UpdateService`, `service()`; `RELEASES_URL`, `DEFAULT_MANIFEST_URL`
- `house_finder/config.py` — `updates_dir()` (`HOUSE_FINDER_UPDATES_DIR`, else frozen → `%LOCALAPPDATA%\HouseFinder\app`, else None = off)
- `house_finder/__main__.py` — `restart_command()`, `restart_app()`, `wait_until_free()` (`app --wait-free`), `confirm_update_when_ready()`, `log_code_version()`; `serve` builds the service, starts its background check and sets `app.state.restart`
- `packaging/update_loader.py` — the frozen launcher's chooser (stdlib only): `select()`, `load()`, `usable()`, `mark_bad()`, `installer_version()`, `updates_root()`
- `packaging/house_finder_app.py` — the launcher: `update_loader.load()` then `run_app()`
- `packaging/house_finder.spec` — writes `installer_version.txt` into the bundle; collects the whole stdlib and every submodule of the runtime dependencies
- `tools/build_update.py` — builds `bundles/house-finder-<version>.zip` + `manifest.json`
- `.github/workflows/windows.yml` — "Smoke - the installed app updates itself"

## Channel

`manifest.json` at `DEFAULT_MANIFEST_URL` (the owner's PUBLIC repo
`8r9ypfjh7d-beep/house-finder-updates`; the source repo is private), or
`HOUSE_FINDER_UPDATE_URL`:

```json
{"version": "1.2.1", "min_installer": "1.2.0", "bundle": "bundles/house-finder-1.2.1.zip",
 "sha256": "<64 lowercase hex>", "size": 123456, "notes": "One line for the banner"}
```

`bundle` is relative to the manifest URL (no scheme, `/`, `..`, `\`; ends
`.zip`). Unknown keys, a bad version, sha or size (≤ 50 MB) → no update and
a warning in the log. 404 → "no channel yet", info only. Network errors →
`UpdateService.error` (shown on `/settings`), the banner keeps its last
state. All HTTP is one `ThrottledClient` (tool's own User-Agent, 1 retry).

## Install (apply_update)

1. Download; size and sha256 must match the manifest.
2. Extract into `<root>/.tmp-<version>-<rand>`: every entry under
   `house_finder/`, no absolute / drive / `..` / backslash / symlink,
   ≤ 200 MB extracted.
3. Validate: `__init__.py` + `__main__.py`, `version.py`'s `APP_VERSION` ==
   manifest version, a `MIN_INSTALLER`, every `.py` compiles.
4. Rename to `<root>/<version>`; `current.json` ←
   `{"version", "status": "pending", "attempts": 0, "previous": <last good>}`
   (atomic temp + `os.replace`).
5. Delete version dirs other than the new one, `previous` and the running one.

`POST /update` runs this as a background job, then `restart_app()`: spawns
`<exe> app --no-browser --wait-free --port P --interval N [--no-scheduler]`
detached (Windows: `DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP |
CREATE_NO_WINDOW`; `PYINSTALLER_RESET_ENVIRONMENT=1`) and calls the
shutdown hook. The new process waits (≤ 60 s) until the old one stops
answering `/ping`, then serves.

## Launch (update_loader)

An update dir is usable when its version is newer than the installer's own
code (`installer_version.txt`), its `MIN_INSTALLER` ≤ the installer, and it
has `house_finder/__init__.py`. `good` runs; `pending` runs while
`attempts < 2` (each launch counts one); then `bad`. Next choice:
`previous`, then the bundled code. An import that raises → that version is
marked bad, its path and `house_finder*` modules are dropped, the next
choice is imported. Once `/ping` answers, `confirm_update_when_ready` marks
a pending running update `good`. A version marked bad is never offered again
(`is_bad`).

## Optimizations and Features

- The launcher never imports `house_finder` before choosing, and is never
  updated itself — a broken update cannot break the fallback path.
- `version.py` values are plain literals so the spec, the launcher and the
  builder read them by regex without importing.
- A newer installer's bundled code always wins over an older update dir
  (`usable` requires newer-than-installer).
- Compile check at install: a syntax error is refused before the switch;
  other import failures are caught by the launcher.
- `cleanup` keeps the running version's dir too, so its templates stay
  readable until the restart.
- The bundle is deterministic (sorted entries, fixed timestamps): the same
  tree gives the same sha256.
- The updating page polls `/update/status` and returns to `/home` once the
  new version answers (a plain meta refresh would stop on the browser's
  "can't connect" page during the restart).

## Known Tasks

### Publish an update

1. Bump `APP_VERSION` in `house_finder/version.py` (and `MIN_INSTALLER` +
   release a new installer when dependencies, `packaging/` or the spec
   changed); run the tests.
2. `python tools/build_update.py --out <clone of house-finder-updates> --notes "What changed"`
3. Commit `manifest.json` + the new bundle in that repo and push. Installed
   apps see it within 6 h (or **Check for updates now** on Settings).

"""The owner's answer bank (``data/about_me.json``): facts about the owner and
answers remembered from past approvals. It is the ONLY information entry
answers may be drafted from (VISION non-goal "Inventing facts").

The file is encrypted with the ``SecretStore`` key of its directory (it may
hold personal facts; VISION hard constraint "encrypted at rest"). A
plaintext file left by an older version is encrypted in place on load.
"""

from __future__ import annotations

import logging
import re
from pathlib import Path

from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator

from house_finder import config
from house_finder.secrets import SecretStore, is_encrypted

log = logging.getLogger(__name__)

# Facts with these keys are always asked, whatever their ``sensitive`` flag
# says (VISION hard constraint: ID number, income, employer, phone, ...).
SENSITIVE_KEYS: frozenset[str] = frozenset(
    {"id_number", "income", "salary", "employer", "phone", "email", "address", "bank"}
)

# Keys the drafting rules read, with a label; /about-me offers them as rows.
SUGGESTED_FACTS: tuple[tuple[str, str], ...] = (
    ("name", "Name"),
    ("age", "Age"),
    ("occupation", "Occupation"),
    ("looking_in", "What I'm looking for (where, what)"),
    ("move_in", "When I want to move in"),
    ("is_agent", "Am I an agent? (answer as you would write it)"),
    ("agrees_to_rules", "Do I agree to group rules? (answer as you would write it)"),
)

KEY_PATTERN = re.compile(r"^[a-z0-9_]{1,40}$")


class Fact(BaseModel):
    """One thing the owner told the tool about themselves. ``value`` is used
    verbatim; a sensitive fact (flag, or a key in ``SENSITIVE_KEYS``) is never
    put into a draft."""

    model_config = ConfigDict(frozen=True)

    key: str
    label: str = ""
    value: str = Field(default="", max_length=2000)
    sensitive: bool = False

    @field_validator("key")
    @classmethod
    def _check_key(cls, value: str) -> str:
        key = value.strip().lower()
        if not KEY_PATTERN.match(key):
            raise ValueError(f"fact key {value!r} must be 1-40 of a-z, 0-9, _")
        return key

    @property
    def is_sensitive(self) -> bool:
        return self.sensitive or self.key in SENSITIVE_KEYS


class Remembered(BaseModel):
    """An answer the owner wrote and approved for an entry question, kept to
    reuse for the same question (normalised exact match only)."""

    model_config = ConfigDict(frozen=True)

    question: str = Field(min_length=1, max_length=2000)
    answer: str = Field(min_length=1, max_length=4000)


class AnswerBank(BaseModel):
    """``facts`` (unique keys) + ``remembered`` answers."""

    facts: list[Fact] = Field(default_factory=list)
    remembered: list[Remembered] = Field(default_factory=list)

    @field_validator("facts")
    @classmethod
    def _unique_keys(cls, facts: list[Fact]) -> list[Fact]:
        seen: set[str] = set()
        for fact in facts:
            if fact.key in seen:
                raise ValueError(f"fact key {fact.key!r} appears twice")
            seen.add(fact.key)
        return facts

    def fact(self, key: str) -> Fact | None:
        return next((f for f in self.facts if f.key == key), None)

    def sensitive_values(self) -> list[str]:
        """Values of every sensitive fact (never allowed into a draft)."""
        return [f.value for f in self.facts if f.is_sensitive and f.value.strip()]

    def remember(self, question: str, answer: str) -> "AnswerBank":
        """A copy with ``answer`` remembered for ``question`` (replacing an
        earlier answer to the same normalised question)."""
        from house_finder.answers.drafting import normalize_question

        q, a = question.strip(), answer.strip()
        if not q or not a:
            return self
        key = normalize_question(q)
        kept = [r for r in self.remembered if normalize_question(r.question) != key]
        return self.model_copy(update={"remembered": kept + [Remembered(question=q, answer=a)]})


def _secrets(p: Path, secrets: SecretStore | None) -> SecretStore:
    return secrets if secrets is not None else SecretStore(p.parent)


def _parse(raw: str) -> AnswerBank:
    try:
        return AnswerBank.model_validate_json(raw)
    except ValidationError as exc:
        problems = "; ".join(
            ".".join(str(part) for part in e["loc"]) + (": " if e["loc"] else "")
            + str(e["msg"]).removeprefix("Value error, ")
            for e in exc.errors(include_input=False, include_url=False)
        )
        raise ValueError(f"invalid answer bank: {problems}") from None


def migrate_plaintext_bank(path: Path | str | None = None, *, secrets: SecretStore | None = None) -> bool:
    """Encrypt a plaintext answer bank in place (atomic replace, so the
    plaintext is gone in the same step). True when it did; idempotent. A
    plaintext file that is not a valid bank raises and is left untouched."""
    p = Path(path) if path is not None else config.about_me_path()
    if not p.exists():
        return False
    data = p.read_bytes()
    if is_encrypted(data):
        return False
    bank = _parse(data.decode("utf-8"))
    save_bank(bank, p, secrets=secrets)
    log.info("encrypted the answer bank %s", p.name)
    return True


def load_bank(path: Path | str | None = None, *, secrets: SecretStore | None = None) -> AnswerBank:
    """Load the bank (default ``config.about_me_path()``). Missing file -> an
    empty bank; a broken file raises ``ValueError`` (never silently replaced)
    whose message names the problems but never the file's values — pydantic's
    own message quotes the input, which may be a sensitive fact. A wrong key
    or corrupted encrypted file raises ``SecretStoreError`` (fails closed). A
    plaintext file is encrypted first (``migrate_plaintext_bank``)."""
    p = Path(path) if path is not None else config.about_me_path()
    if not p.exists():
        return AnswerBank()
    store = _secrets(p, secrets)
    migrate_plaintext_bank(p, secrets=store)
    raw = store.decrypt_bytes(p.read_bytes(), p.name)
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        raise ValueError("invalid answer bank: not UTF-8 text") from None
    return _parse(text)


def save_bank(bank: AnswerBank, path: Path | str | None = None, *, secrets: SecretStore | None = None) -> Path:
    """Write the bank encrypted, atomically (temp file in the same dir +
    ``os.replace``). An encrypted file this key cannot read is never
    overwritten (``SecretStoreError``)."""
    p = Path(path) if path is not None else config.about_me_path()
    _secrets(p, secrets).write_encrypted(p, bank.model_dump_json(indent=2).encode("utf-8"), p.name)
    return p

"""``draft_answers``: entry-question answers drafted ONLY from the answer bank.

Deterministic keyword rules (Hebrew + English) map a question to the owner's
facts; a remembered answer is reused only for the same question
(``normalize_question`` equal). Anything else — no rule, several rules, a
missing fact — and anything that touches a sensitive topic or a sensitive
fact is ``needs_input`` with no answer: the owner types it. Nothing is ever
composed from information the owner has not given (VISION non-goal
"Inventing facts", hard constraint "sensitive fields always asked").
"""

from __future__ import annotations

import re
import unicodedata
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from typing import Literal

from house_finder.answers.bank import AnswerBank

DraftSource = Literal["fact", "remembered", "needs_input"]

_NIQQUD_RE = re.compile(r"[֑-ׇ]")
_QUOTES_RE = re.compile(r"[\"'`׳״‘’“”]")
_NON_WORD_RE = re.compile(r"[\W_]+")


def normalize_question(text: str | None) -> str:
    """NFKC (full-width / compatibility forms folded), invisible format
    characters (zero-width, bidi marks) removed, casefolded, niqqud and quote
    marks removed (ת"ז -> תז), every other punctuation/emoji run -> one
    space, trimmed. Two questions are "the same" only when this is equal."""
    if not text:
        return ""
    value = unicodedata.normalize("NFKC", text)
    value = "".join(ch for ch in value if unicodedata.category(ch) != "Cf")
    value = _NIQQUD_RE.sub("", value)
    value = _QUOTES_RE.sub("", value)
    value = _NON_WORD_RE.sub(" ", value.casefold())
    return value.strip()


def _he_word(*words: str) -> str:
    """A Hebrew whole word, optionally with 1-2 prefix letters (ו ה ב ל מ ש)."""
    return r"(?:^| )[והבלמש]{0,2}(?:" + "|".join(words) + r")(?= |$)"


def _compile(patterns: Iterable[str]) -> list[re.Pattern[str]]:
    return [re.compile(p) for p in patterns]


# topic -> patterns over normalize_question(). Matching any -> needs_input,
# even when the bank holds a value (VISION hard constraint).
SENSITIVE_PATTERNS: dict[str, list[re.Pattern[str]]] = {
    "ID number": _compile([
        r"תעודת זהות", r"מספר זהות", r"זהות", _he_word("תז", "ת ז"), r"דרכון",
        r"\bid\b", r"\bidentity\b", r"\bpassport", r"\bssn\b", r"social security",
        r"\bteudat", r"\bzehut", r"\bbirth", r"\bdob\b", r"תאריך לידה",
    ]),
    "income": _compile([
        r"הכנס", r"משכורת", _he_word("שכר", "שכרך", "שכרכם"), r"מרוויח",
        r"\bincome", r"\bsalar", r"\bearn", r"\bwage", r"\bpaycheck",
        r"how much do you (?:make|get)", r"כמה (?:אתה |את |אתם )?(?:מקבל|מרוויח)",
    ]),
    "employer": _compile([
        r"מקום ה?עבוד", r"מעסיק", r"מעביד", r"(?:איפה|היכן|באיזו חברה|באיזה חברה) (?:אתה |את |אתם )?עוב",
        r"\bemployer", r"\bworkplace", r"where (?:do|are) you work", r"which company", r"company do you work",
        r"where you work", r"\bwork (?:at|for)\b", r"(?:איזה|באיזה|באיזו|איזו) (?:מקום|חברה)",
    ]),
    "phone": _compile([
        r"טלפון", r"פלאפון", r"פלא פון", r"נייד", r"סלולר", r"וואטסאפ", r"ווטסאפ", r"ווצאפ",
        r"\bphone", r"\bmobile", r"\bcell\b", r"\bwhats ?app", r"\btelephone",
        # a bare "number" / contact request is treated as a phone request
        r"מספר", r"\bnumber", r"\btel\b", r"קשר", r"\bcontact", r"\breach you",
    ]),
    "contact / online profile": _compile([
        r"\blinked ?in", r"\binstagram", r"\bfacebook", r"\btelegram", r"\bsignal\b", r"\btwitter",
        r"\bprofile", r"\bhandle\b", r"\blink\b", r"\burl\b", r"\bgmail",
        r"פרופיל", r"לינק", r"קישור", r"אינסטגרם", r"פייסבוק", r"טלגרם", r"לינקדאין",
    ]),
    "email": _compile([
        r"מייל", r"דואל", r"דואר אלקטרוני",
        r"\bemail", r"\be mail\b", r"\bmail\b",
    ]),
    "address": _compile([
        r"כתובת", r"\baddress", r"\blive\b", r"\bliving\b", r"\breside", r"מתגורר", r"מגורי",
        _he_word("גר", "גרה", "גרים", "גרות"),
    ]),
    "bank / payment": _compile([
        r"בנק", r"חשבון", r"אשראי", r"כרטיס",
        r"\bbank", r"account number", r"credit card", r"card number", r"\biban\b",
    ]),
}


@dataclass(frozen=True)
class _Rule:
    name: str
    facts: tuple[str, ...]
    patterns: list[re.Pattern[str]]


# Keyword rules: a question matching exactly ONE rule is answered with that
# rule's facts, verbatim. Order does not matter (several matches -> ask).
RULES: tuple[_Rule, ...] = (
    _Rule("agent", ("is_agent",), _compile([
        r"מתווכ", r"מתווך", r"תיווך", r"סוכנ", r"סוכן",
        r"\bagents?\b", r"\brealtor", r"\bbroker", r"real estate", r"\bagency",
    ])),
    _Rule("rules", ("agrees_to_rules",), _compile([
        r"חוקי", r"חוקים", r"כללי", r"תקנון", r"מסכימ", r"מסכים",
        r"\brules?\b", r"\bguidelines", r"\bterms\b", r"\bagree",
    ])),
    _Rule("age", ("age",), _compile([
        _he_word("גיל", "גילך", "גילכם"), r"(?:בן|בת|בנ ת) כמה",
        r"\bage\b", r"how old",
    ])),
    _Rule("occupation", ("occupation",), _compile([
        r"עיסוק", r"עוסק", r"מקצוע", r"מה (?:אתה|את|אתם) עוש", r"סטודנט",
        r"\boccupation", r"\bprofession", r"what do you do", r"\bstudent", r"\bjob\b",
    ])),
    _Rule("name", ("name",), _compile([
        _he_word("שם", "שמך", "שמכם"),
        r"\bname\b",
    ])),
    _Rule("looking", ("looking_in", "move_in"), _compile([
        r"מחפש", r"למה", r"מדוע", r"סיבה", r"סיבת", r"מטרה", r"מטרת", r"מעוניינ",
        r"looking for", r"\bwhy\b", r"\breason", r"\bpurpose", r"\bsearching", r"interested in", r"what brings",
    ])),
)


@dataclass(frozen=True)
class DraftAnswer:
    """A drafted answer. ``answer`` is None exactly when ``source`` is
    ``needs_input``. ``sensitive``: the question touches a sensitive topic or
    fact (never remembered, never filled automatically)."""

    question: str
    answer: str | None
    source: DraftSource
    reason: str
    sensitive: bool = False


def sensitive_topic(question: str, bank: AnswerBank | None = None) -> str | None:
    """The sensitive topic a question asks about (built-in patterns, or a
    sensitive fact's key/label named in it), else None."""
    norm = normalize_question(question)
    for topic, patterns in SENSITIVE_PATTERNS.items():
        if any(p.search(norm) for p in patterns):
            return topic
    if bank is not None:
        for fact in bank.facts:
            if not fact.is_sensitive:
                continue
            for name in (fact.key.replace("_", " "), fact.label):
                needle = normalize_question(name)
                if len(needle) >= 3 and re.search(r"(?:^| )" + re.escape(needle) + r"(?= |$)", norm):
                    return fact.label or fact.key
    return None


# Values shaped like a phone / ID / account number (9+ digits, separators
# allowed) or an email address are sensitive wherever they come from.
_LONG_NUMBER_RE = re.compile(r"\d(?:[\s\-.()+/]*\d){8,}")
_EMAIL_RE = re.compile(r"[^\s@]+@[^\s@]+\.[^\s@]+")


def reveals_sensitive(answer: str, bank: AnswerBank) -> bool:
    """True when ``answer`` contains the value of a sensitive fact, or
    anything shaped like a phone / ID / account number or an email address."""
    folded = unicodedata.normalize("NFKC", answer)
    if _LONG_NUMBER_RE.search(folded) or _EMAIL_RE.search(folded):
        return True
    norm = normalize_question(answer)
    raw = answer.casefold()
    for value in bank.sensitive_values():
        v_norm, v_raw = normalize_question(value), value.strip().casefold()
        if (len(v_norm) >= 2 and v_norm in norm) or (len(v_raw) >= 2 and v_raw in raw):
            return True
    return False


def _needs(question: str, reason: str, sensitive: bool = False) -> DraftAnswer:
    return DraftAnswer(question=question, answer=None, source="needs_input", reason=reason, sensitive=sensitive)


def draft_one(question: str, bank: AnswerBank) -> DraftAnswer:
    """Draft the answer to one question (see ``draft_answers``)."""
    norm = normalize_question(question)
    if not norm:
        return _needs(question, "empty question")
    topic = sensitive_topic(question, bank)
    if topic is not None:
        return _needs(question, f"asks for {topic} — sensitive, always asked", sensitive=True)
    remembered = [r for r in bank.remembered if normalize_question(r.question) == norm]
    if remembered:
        answer = remembered[-1].answer
        if reveals_sensitive(answer, bank):
            return _needs(question, "your remembered answer contains a sensitive fact", sensitive=True)
        return DraftAnswer(question, answer, "remembered", "your answer to this same question before")
    matched = [rule for rule in RULES if any(p.search(norm) for p in rule.patterns)]
    if not matched:
        return _needs(question, "no answer for this in About me")
    if len(matched) > 1:
        return _needs(question, "asks several things (" + ", ".join(r.name for r in matched) + ")")
    rule = matched[0]
    used, values, skipped = [], [], []
    for key in rule.facts:
        fact = bank.fact(key)
        if fact is None or not fact.value.strip():
            continue
        if fact.is_sensitive:
            skipped.append(key)
            continue
        used.append(key)
        values.append(fact.value.strip())
    if not values:
        why = "marked sensitive" if skipped else "not filled in"
        return _needs(question, f"About me: {' / '.join(rule.facts)} {why}", sensitive=bool(skipped))
    answer = "; ".join(values)
    if reveals_sensitive(answer, bank):
        return _needs(question, "the answer would contain a sensitive fact", sensitive=True)
    return DraftAnswer(question, answer, "fact", "from About me: " + ", ".join(used))


def draft_answers(questions: Sequence[str], bank: AnswerBank) -> list[DraftAnswer]:
    """One ``DraftAnswer`` per question, in order. Never composes an answer
    from anything but the bank's non-sensitive fact values (verbatim) or a
    remembered answer to the same normalised question; unknown, ambiguous or
    sensitive -> ``needs_input`` with no answer."""
    return [draft_one(q, bank) for q in questions]

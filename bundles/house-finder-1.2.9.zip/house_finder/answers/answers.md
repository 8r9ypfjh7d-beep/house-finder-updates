# answers — Facebook group entry answers

The owner's answer bank and `draft_answers()`, which drafts answers to a
group's entry questions **only from that bank** (BRIEF §8 "Facebook group
questions", F11; VISION non-goal "Inventing facts", hard constraint
"sensitive fields always asked"). Approval and storage of the answers live
in the store (`fb_group_answers`, see [store.md](../store/store.md)); the
page is `/groups` (see [web.md](../web/web.md)).

## Code Files

- `bank.py` — `Fact`, `Remembered`, `AnswerBank`, `load_bank()`, `save_bank()`, `migrate_plaintext_bank()`, `SENSITIVE_KEYS`, `SUGGESTED_FACTS`
- `drafting.py` — `draft_answers()`, `draft_one()`, `DraftAnswer`, `normalize_question()`, `sensitive_topic()`, `reveals_sensitive()`, `SENSITIVE_PATTERNS`, `RULES`
- `__init__.py` — re-exports the above

## Answer bank (`bank.py`) — `data/about_me.json`

`config.about_me_path()`; edited on `/about-me`. **Encrypted at rest** with
the `SecretStore` key of its directory (requires
[secrets.md](../secrets/secrets.md)); the JSON below is the decrypted
content.

```json
{"facts": [{"key": "age", "label": "Age", "value": "34", "sensitive": false}],
 "remembered": [{"question": "Do you smoke?", "answer": "No"}]}
```

- `Fact(key, label, value, sensitive)` — key `[a-z0-9_]{1,40}` (lower-cased),
  unique in the bank. `value` is used **verbatim**. `is_sensitive` = the flag,
  or the key is in `SENSITIVE_KEYS` (`id_number`, `income`, `salary`,
  `employer`, `phone`, `email`, `address`, `bank`) — always sensitive.
- `Remembered(question, answer)` — an owner-typed answer approved before.
  `bank.remember(q, a)` returns a copy with it added, replacing an earlier
  answer to the same normalised question.
- `load_bank(path, *, secrets=None)` — missing file → empty bank; a broken
  file raises `ValueError` (never reset) whose message lists the problems but
  never the file's values (pydantic's own message quotes the input); a wrong
  key / corrupted encrypted file raises `SecretStoreError` (fails closed). A
  plaintext file is encrypted in place first (`migrate_plaintext_bank`,
  atomic replace — the plaintext is gone in the same step; a broken
  plaintext file is left untouched). `save_bank(bank, path, *, secrets=None)`
  — encrypted, atomic; refuses to overwrite an encrypted file the key cannot
  read. `secrets` defaults to `SecretStore(path.parent)`.
- `SUGGESTED_FACTS` — the keys the rules read (name, age, occupation,
  looking_in, move_in, is_agent, agrees_to_rules), offered as rows on `/about-me`.

## Drafting (`drafting.py`)

`draft_answers(questions, bank) -> list[DraftAnswer(question, answer?, source,
reason, sensitive)]`, one per question, in order. `source` is `fact`,
`remembered` or `needs_input` (`answer` is None exactly for `needs_input`).
Per question, first match wins:

1. Blank → `needs_input`.
2. **Sensitive** (`sensitive_topic`) → `needs_input`, `sensitive=True`, even
   when the bank has a value: the built-in Hebrew + English patterns
   (`SENSITIVE_PATTERNS`, matched on the normalised question):
   ID (incl. passport, SSN, birth date); income (incl. "how much do you
   make"); employer (incl. "which company", "work at/for"); phone (incl. a
   bare "number" / מספר and any contact request: קשר, contact, reach you);
   **contact / online profile** (LinkedIn, Instagram, Facebook, Telegram,
   Signal, profile, link, URL, gmail, פרופיל / לינק / קישור); email;
   address (incl. live / reside / גר / מתגורר); bank / payment (בנק / חשבון
   / אשראי / כרטיס, IBAN, card number) — or the key/label of any sensitive
   fact named as a whole word.
3. **Remembered** — a remembered question whose `normalize_question` is equal
   (NFKC, invisible format characters such as zero-width / bidi marks
   removed, casefold, niqqud and quote marks removed, punctuation → space). No
   fuzzy match: "Do you smoke?" never answers "Do you smoke at home?".
4. **Keyword rules** (`RULES`): exactly one rule must match, else
   `needs_input` ("asks several things" / "no answer for this"):
   `agent` → `is_agent`; `rules` → `agrees_to_rules`; `age` → `age`;
   `occupation` → `occupation`; `name` → `name`; `looking` (why join / what
   are you looking for) → `looking_in` + `move_in` (the non-empty,
   non-sensitive ones joined with `"; "`). A missing or sensitive fact →
   `needs_input`.
5. Final guard (`reveals_sensitive`): an answer (fact or remembered) that
   contains the value of any sensitive fact, or anything shaped like a
   phone / ID / account number (9+ digits, separators allowed) or an email
   address → `needs_input`. `/groups` also uses it to refuse remembering
   such an answer.

## Optimizations and Features

- Sensitive facts are **write-only** on `/about-me` (see
  [web.md](../web/web.md)): once saved the page shows "set", never the
  value — drafting never uses them, so the page has no reason to show them.

- Answers are fact values or remembered answers **verbatim** — no template
  wording is added, so the drafter cannot state anything the owner did not
  write (VISION "Inventing facts").
- The sensitive check runs before the remembered lookup, so a remembered
  answer to a sensitive question is never reused; `/groups` also never
  offers "remember" for a sensitive question, so such answers are not kept
  in `about_me.json` at all.
- Questions are folded with NFKC and stripped of invisible characters
  before matching, so full-width letters or a zero-width space inside
  "ID" / "תעודת זהות" do not slip past the patterns.
- Hebrew whole-word patterns allow 0–2 prefix letters (ו ה ב ל מ ש), e.g.
  `_he_word("שם")` matches "השם" but not "שמח".
- Over-matching a sensitive pattern only costs the owner typing an answer;
  under-matching would leak — the patterns are deliberately broad
  (e.g. "חשבון", "כרטיס", bare "mail").
- An ambiguous question (two rules) is asked, not guessed.

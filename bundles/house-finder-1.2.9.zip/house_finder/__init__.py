"""House Finder Helper — personal rental-search assistant.

See ``house_finder/house_finder.md`` for the package index.
"""

from house_finder.version import APP_VERSION as __version__  # noqa: F401

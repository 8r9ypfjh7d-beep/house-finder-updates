"""Search profile (BRIEF §5 criteria) and owner settings, with their JSON storage."""

from house_finder.profile.profile import (
    EXAMPLE_PROFILE_PATH,
    LocationArea,
    SearchProfile,
    load_profile,
    save_profile,
)
from house_finder.profile.settings import (
    DEFAULT_SEND_MODE,
    OwnerSettings,
    load_settings,
    save_settings,
    validate_ntfy_topic_url,
)

__all__ = [
    "DEFAULT_SEND_MODE",
    "EXAMPLE_PROFILE_PATH",
    "LocationArea",
    "OwnerSettings",
    "SearchProfile",
    "load_profile",
    "load_settings",
    "save_profile",
    "save_settings",
    "validate_ntfy_topic_url",
]

"""``SearchProfile`` — every BRIEF §5 search criterion — and its JSON file.

A profile field left at ``None`` / empty means "no constraint". The profile
is stored as one JSON file in the data dir and written atomically.
"""

from __future__ import annotations

import os
import tempfile
from datetime import date
from pathlib import Path

from pydantic import BaseModel, Field, model_validator

from house_finder import config
from house_finder.models import Attribute, PropertyType

EXAMPLE_PROFILE_PATH = Path(__file__).with_name("example_profile.json")


class LocationArea(BaseModel):
    """One acceptable area: a city, optionally narrowed to neighborhoods or
    widened to a radius around a point.

    ``radius_km`` requires ``lat`` and ``lon``. ``yad2_city_code`` overrides
    the yad2 adapter's built-in city-name map for this area.
    """

    city: str
    neighborhoods: list[str] = Field(default_factory=list)
    radius_km: float | None = Field(default=None, gt=0)
    lat: float | None = None
    lon: float | None = None
    yad2_city_code: int | None = None

    @model_validator(mode="after")
    def _radius_needs_point(self) -> "LocationArea":
        if self.radius_km is not None and (self.lat is None or self.lon is None):
            raise ValueError("radius_km requires both lat and lon")
        return self


class SearchProfile(BaseModel):
    """The owner's search criteria (BRIEF §5).

    Hard filters: price, locations, rooms, sqm, property types (empty = any),
    move-in window, lease length, must-haves, exclusion keywords, agents,
    ground floor. ``nice_to_haves`` only affect ranking.
    ``max_listing_age_days`` limits how old a listing may be.
    """

    price_min: int | None = Field(default=None, ge=0)
    price_max: int | None = Field(default=None, ge=0)
    locations: list[LocationArea] = Field(default_factory=list)
    rooms_min: float | None = Field(default=None, ge=0)
    rooms_max: float | None = Field(default=None, ge=0)
    sqm_min: int | None = Field(default=None, ge=0)
    sqm_max: int | None = Field(default=None, ge=0)
    property_types: set[PropertyType] = Field(default_factory=set)
    move_in_earliest: date | None = None
    move_in_latest: date | None = None
    lease_min_months: int | None = Field(default=None, ge=0)
    lease_max_months: int | None = Field(default=None, ge=0)
    must_haves: set[Attribute] = Field(default_factory=set)
    nice_to_haves: set[Attribute] = Field(default_factory=set)
    exclusion_keywords: list[str] = Field(default_factory=list)
    exclude_agents: bool = False
    exclude_ground_floor: bool = False
    max_listing_age_days: int = Field(default=14, ge=0)


def load_profile(path: Path | str | None = None) -> SearchProfile:
    """Load the profile from ``path`` (default: ``config.profile_path()``).

    A missing file returns a default, empty ``SearchProfile``. A file that
    exists but is invalid raises (pydantic ``ValidationError`` / ``OSError``) —
    a broken profile is never silently replaced by an empty one.
    """
    p = Path(path) if path is not None else config.profile_path()
    if not p.exists():
        return SearchProfile()
    return SearchProfile.model_validate_json(p.read_text(encoding="utf-8"))


def save_profile(profile: SearchProfile, path: Path | str | None = None) -> Path:
    """Write ``profile`` as JSON to ``path`` (default: ``config.profile_path()``)
    atomically: write a temp file in the same directory, then ``os.replace``.

    Creates the parent directory if needed. Returns the path written.
    """
    p = Path(path) if path is not None else config.profile_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    payload = profile.model_dump_json(indent=2)
    fd, tmp_name = tempfile.mkstemp(prefix=f".{p.name}.", suffix=".tmp", dir=p.parent)
    tmp = Path(tmp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(payload)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, p)
    except BaseException:
        tmp.unlink(missing_ok=True)
        raise
    return p

# profile — search profile

The owner's search criteria (BRIEF §5) as a pydantic model, stored as one
JSON file in the data dir.

## Code Files

- `profile.py` — `LocationArea`, `SearchProfile`, `load_profile()`, `save_profile()`, `EXAMPLE_PROFILE_PATH`
- `settings.py` — `OwnerSettings` (+ `ntfy_enabled`, `email_enabled`), `load_settings()`, `save_settings()`, `secrets_for()`, `migrate_plaintext_ntfy_topic()`, `validate_ntfy_topic_url()`, `validate_email_address()`, `DEFAULT_SEND_MODE`, `DEFAULT_SMTP_PORT`, `SendMode`, `SmtpSecurity`, `NotifyChannel`
- `example_profile.json` — a filled-in example profile shipped in the package (stage 4's `house-finder init` copies it into the data dir)
- `__init__.py` — re-exports the above

## Model

`SearchProfile` — every field `None`/empty means "no constraint":

| Field | Meaning |
|---|---|
| `price_min`, `price_max` | ILS/month |
| `locations: list[LocationArea]` | acceptable areas (any one matches) |
| `rooms_min/max`, `sqm_min/max` | size range |
| `property_types: set[PropertyType]` | empty = any type |
| `move_in_earliest/latest` | move-in window |
| `lease_min_months/max_months` | lease length |
| `must_haves: set[Attribute]` | hard filter |
| `nice_to_haves: set[Attribute]` | ranking only |
| `exclusion_keywords: list[str]` | reject if found in title/description |
| `exclude_agents`, `exclude_ground_floor` | boolean exclusions |
| `max_listing_age_days` (14) | age limit on listings |

`LocationArea`: `city`, `neighborhoods` (empty = whole city), optional
`radius_km` + `lat`/`lon` (radius requires both coordinates), optional
`yad2_city_code` (overrides the yad2 adapter's city map).

## API

- `load_profile(path=None) -> SearchProfile` — default path is
  `config.profile_path()`. Missing file → default empty profile. An existing
  but invalid file raises `ValidationError` (never silently reset).
- `save_profile(profile, path=None) -> Path` — JSON (UTF-8, Hebrew kept
  readable), atomic write, creates the parent dir.

## Owner settings (`settings.py`, `data/settings.json`)

Separate from `SearchProfile` (who the owner is, not what to search for):

| Field | Default | Meaning |
|---|---|---|
| `owner_name` | `""` | signs messages (`{name}`); empty → the signature line is dropped |
| `notify_channels` | `["dashboard"]` | `dashboard` (always on regardless) / `ntfy` / `email` |
| `ntfy_topic` | `None` | ntfy topic URL: `https`, host, topic path, no user/password, query or fragment; blank → `None`. **In memory only** — persisted in the `SecretStore` (`Field(exclude=True)`) |
| `smtp_host` | `""` | SMTP server host name |
| `smtp_port` | `587` | 1–65535 |
| `smtp_security` | `starttls` | `starttls` / `ssl` (implicit TLS) — no plain option |
| `smtp_username` | `""` | empty → no login; the password is the `SecretStore` secret `smtp_password`, never in this model |
| `email_from`, `email_to` | `""` | one plain address each (no name, list or line break) |
| `send_mode_per_channel` | `{}` | channel → send mode; `send_mode(channel)` returns `assisted` when unset |
| `show_stale` | `False` | the review queue also shows stale listings (older than `max_listing_age_days`); set by the review page's "Show stale" toggle, kept by the `/settings` form |

`ntfy` in `notify_channels` without a `ntfy_topic` is a `ValidationError`;
so is `email` without `smtp_host`, `email_from` and `email_to`.
`ntfy_enabled` / `email_enabled` are True only when the channel is on and
configured — a third party is OFF unless the owner turned it on. Edited on
`/settings`. Requires [secrets.md](../secrets/secrets.md).

`load_settings(path=None, *, secrets=None)` — missing file → defaults;
invalid file raises (never reset); the topic is read from `secrets`
(default `secrets_for(path)`: the `SecretStore` in the same directory) when
`secrets.enc` exists; an unreadable store raises `SecretStoreError`. A
plaintext `ntfy_topic` in the file (older versions) is migrated first
(`migrate_plaintext_ntfy_topic`: secret stored, then the key removed from
the file). `save_settings(settings, path=None, *, secrets=None)` — topic set
in / removed from the store first, then the file written atomically without
it.

## Optimizations and Features

- `SendMode` is `"assisted"` or `"browser"`, and `browser` only for the
  channels that have an automatic sender (`BROWSER_SEND_CHANNELS`: facebook,
  yad2), so a settings file asking for anything else fails loudly instead of
  being silently ignored or half-honoured.

- The ntfy topic URL is a bearer secret (whoever knows it reads the pushes):
  it never reaches `settings.json`; migration stores the secret BEFORE it
  rewrites the file, so a crash in between leaves it in both, never in
  neither. Settings without secrets never create an encryption key.
- Email addresses must be one plain address — a line break or a list
  could add a header or a recipient.
- The ntfy URL check rejects `http`, credentials in the URL (they belong in
  the encrypted store) and a missing topic, so a typo fails on save instead
  of silently sending to the wrong place.
- Atomic save: temp file in the same directory + `fsync` + `os.replace`
  (works on Windows); the temp file is removed if anything fails, so a crash
  never leaves a half-written profile or stray temp files.
- `LocationArea` rejects `radius_km` without `lat`/`lon` so a radius is never
  silently ignored.
- Numeric bounds are validated `>= 0` and `radius_km > 0`.

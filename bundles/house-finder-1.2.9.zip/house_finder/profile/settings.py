"""``OwnerSettings`` — who the owner is and how the tool may reach out for them.

Separate from ``SearchProfile`` (what to search for): the owner's name used to
sign messages, the notification channels, the ntfy topic, the SMTP account
for email, the send mode per channel, and whether the review queue shows
stale listings. Stored as ``data/settings.json``; a missing file means
defaults. The ntfy topic URL is a bearer secret: it lives in the encrypted
``SecretStore`` of the same directory, never in ``settings.json`` (a
plaintext value left by an older version is moved there on load). The SMTP
password is never part of this model — it is read from the ``SecretStore``
when an email is sent.
"""

from __future__ import annotations

import json
import logging
import os
import re
import tempfile
from pathlib import Path
from typing import Any, Literal

from urllib.parse import urlsplit

from pydantic import BaseModel, Field, ValidationError, ValidationInfo, field_validator, model_validator

from house_finder import config
from house_finder.secrets import NTFY_TOPIC, SecretStore

log = logging.getLogger(__name__)

NotifyChannel = Literal["dashboard", "ntfy", "email"]
# "assisted" (the default) or "browser" — automated sending through the
# logged-in browser (Messenger: secure-sessions stage 2; yad2's chat: the
# yad2-send change), opt-in and for Facebook and yad2 ONLY; a settings file
# asking for anything else fails to load instead of being ignored.
SendMode = Literal["assisted", "browser"]
DEFAULT_SEND_MODE: SendMode = "assisted"
BROWSER_SEND_CHANNELS: tuple[str, ...] = ("facebook", "yad2")
# How the SMTP connection is encrypted. There is no plain option: STARTTLS
# (required, refused if the server does not offer it) or implicit TLS (465).
SmtpSecurity = Literal["starttls", "ssl"]
DEFAULT_SMTP_PORT = 587
_EMAIL_RE = re.compile(r"^[^@\s<>,;\"']+@[^@\s<>,;\"']+\.[^@\s<>,;\"']+$")
_HOST_RE = re.compile(r"^[A-Za-z0-9.-]{1,253}$")


def validate_email_address(value: str, what: str = "email address") -> str:
    """``value`` stripped if it is one plain address (no name, no list, no
    line break — nothing that could add a header), else ``ValueError``."""
    address = value.strip()
    if not _EMAIL_RE.match(address):
        raise ValueError(f"{what} must be one plain address like me@example.com")
    return address


def validate_ntfy_topic_url(value: str) -> str:
    """``value`` stripped if it is a usable ntfy topic URL, else ``ValueError``.

    ntfy is a third party (VISION hard constraint: nothing leaves except to
    the channel the owner configures), so the URL must be ``https`` with a
    host and a topic path, and carry no credentials, query or fragment
    (credentials belong in the encrypted store, ``secure-sessions``).
    """
    url = value.strip()
    try:
        parts = urlsplit(url)
        host = parts.hostname
    except ValueError as exc:
        # Never quote the value: the topic URL is a bearer secret.
        raise ValueError("ntfy topic URL is not a URL") from exc
    if parts.scheme.lower() != "https":
        raise ValueError("ntfy topic URL must start with https://")
    if not host:
        raise ValueError("ntfy topic URL needs a host, e.g. https://ntfy.sh/<topic>")
    if parts.username is not None or parts.password is not None:
        raise ValueError("ntfy topic URL must not contain a user name or password")
    if parts.query or parts.fragment:
        raise ValueError("ntfy topic URL must not have a ?query or #fragment")
    if not parts.path.strip("/"):
        raise ValueError("ntfy topic URL needs a topic, e.g. https://ntfy.sh/<topic>")
    if any(c.isspace() for c in url):
        raise ValueError("ntfy topic URL must not contain spaces")
    return url


class OwnerSettings(BaseModel):
    """The owner's settings. Every field has a safe default.

    ``ntfy_topic`` must be an ``https`` topic URL; ``ntfy`` in
    ``notify_channels`` requires it. ntfy is OFF unless both are set.
    """

    owner_name: str = ""
    notify_channels: list[NotifyChannel] = Field(default_factory=lambda: ["dashboard"])
    # In memory only: persisted in the SecretStore (exclude=True keeps it out
    # of settings.json); repr=False keeps it out of reprs and logs.
    ntfy_topic: str | None = Field(default=None, exclude=True, repr=False)
    # Email (SMTP). The password is a secret: SecretStore "smtp_password".
    smtp_host: str = ""
    smtp_port: int = Field(default=DEFAULT_SMTP_PORT, ge=1, le=65535)
    smtp_security: SmtpSecurity = "starttls"
    smtp_username: str = ""
    email_from: str = ""
    email_to: str = ""
    send_mode_per_channel: dict[str, SendMode] = Field(default_factory=dict)
    # Review queue: show listings older than the profile's max_listing_age_days
    # (hidden by default; the "Show stale" toggle on the review page).
    show_stale: bool = False

    @field_validator("ntfy_topic")
    @classmethod
    def _check_ntfy_topic(cls, value: str | None) -> str | None:
        if value is None or not value.strip():
            return None
        return validate_ntfy_topic_url(value)

    @field_validator("send_mode_per_channel")
    @classmethod
    def _check_send_modes(cls, value: dict[str, str]) -> dict[str, str]:
        for channel, mode in value.items():
            if mode == "browser" and channel not in BROWSER_SEND_CHANNELS:
                raise ValueError(f"browser sending exists only for {', '.join(BROWSER_SEND_CHANNELS)}, "
                                 f"not {channel}")
        return value

    @field_validator("smtp_host")
    @classmethod
    def _check_smtp_host(cls, value: str) -> str:
        host = value.strip()
        if host and not _HOST_RE.match(host):
            raise ValueError("SMTP server must be a host name like smtp.example.com")
        return host

    @field_validator("smtp_username")
    @classmethod
    def _check_smtp_username(cls, value: str) -> str:
        user = value.strip()
        if any(c in user for c in "\r\n"):
            raise ValueError("SMTP user name must be one line")
        return user

    @field_validator("email_from", "email_to")
    @classmethod
    def _check_address(cls, value: str, info: ValidationInfo) -> str:
        what = "From address" if info.field_name == "email_from" else "To address"
        return validate_email_address(value, what) if value.strip() else ""

    @model_validator(mode="after")
    def _ntfy_needs_topic(self) -> "OwnerSettings":
        if "ntfy" in self.notify_channels and not self.ntfy_topic:
            raise ValueError("the ntfy channel is on but no ntfy topic URL is set")
        if "email" in self.notify_channels and not (self.smtp_host and self.email_from and self.email_to):
            raise ValueError("the email channel is on but the SMTP server, From or To address is missing")
        return self

    @property
    def email_enabled(self) -> bool:
        """True only when the owner turned email on (the validator makes sure
        the server and both addresses are then set)."""
        return "email" in self.notify_channels and bool(self.smtp_host and self.email_from and self.email_to)

    @property
    def ntfy_enabled(self) -> bool:
        """True only when the owner turned ntfy on AND set a topic URL."""
        return "ntfy" in self.notify_channels and bool(self.ntfy_topic)

    def send_mode(self, channel: str) -> SendMode:
        """The send mode for ``channel``; ``assisted`` unless set."""
        return self.send_mode_per_channel.get(channel, DEFAULT_SEND_MODE)


def secrets_for(path: Path | str | None = None) -> SecretStore:
    """The ``SecretStore`` that belongs to the settings file ``path`` (the
    one in the same directory — the data dir in production)."""
    p = Path(path) if path is not None else config.settings_path()
    return SecretStore(p.parent)


def _read_raw(p: Path) -> dict[str, Any]:
    data = json.loads(p.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"{p.name} must hold a JSON object")
    return data


def migrate_plaintext_ntfy_topic(path: Path | str | None = None, *, secrets: SecretStore | None = None) -> bool:
    """Move a plaintext ``ntfy_topic`` left in ``settings.json`` by an older
    version into the ``SecretStore`` and remove it from the file. True when
    something was moved; idempotent. The secret is stored BEFORE the file is
    rewritten, so a crash in between leaves the value in both places (the
    next load finishes the move), never in neither."""
    p = Path(path) if path is not None else config.settings_path()
    if not p.exists():
        return False
    data = _read_raw(p)
    if "ntfy_topic" not in data:
        return False
    store = secrets if secrets is not None else secrets_for(p)
    value = data.pop("ntfy_topic")
    if isinstance(value, str) and value.strip():
        store.set(NTFY_TOPIC, validate_ntfy_topic_url(value))
    _write_text_atomic(p, json.dumps(data, indent=2, ensure_ascii=False))
    log.info("moved the ntfy topic URL from %s into the encrypted store", p.name)
    return True


def load_settings(path: Path | str | None = None, *, secrets: SecretStore | None = None) -> OwnerSettings:
    """Load settings from ``path`` (default ``config.settings_path()``) and
    the ntfy topic from the ``SecretStore`` next to it.

    A missing file returns defaults (plus a stored topic); an existing invalid
    file raises — it is never silently replaced. A plaintext topic in the
    file is migrated first. An unreadable ``SecretStore`` (wrong key,
    corrupted) raises ``SecretStoreError``: fails closed.
    """
    p = Path(path) if path is not None else config.settings_path()
    store = secrets if secrets is not None else secrets_for(p)
    data: dict[str, Any] = {}
    if p.exists():
        migrate_plaintext_ntfy_topic(p, secrets=store)
        data = _read_raw(p)
    data.pop("ntfy_topic", None)
    topic = store.get(NTFY_TOPIC) if store.path.exists() else None
    try:
        return OwnerSettings.model_validate({**data, "ntfy_topic": topic})
    except ValidationError as exc:
        # pydantic's own message quotes the input — the whole dict, including
        # the topic URL from the store; name the problems, never the values.
        problems = "; ".join(
            ".".join(str(part) for part in e["loc"]) + (": " if e["loc"] else "")
            + str(e["msg"]).removeprefix("Value error, ")
            for e in exc.errors(include_input=False, include_url=False)
        )
        raise ValueError(f"invalid settings: {problems}") from None


def save_settings(settings: OwnerSettings, path: Path | str | None = None, *,
                  secrets: SecretStore | None = None) -> Path:
    """Write ``settings`` atomically (temp file in the same dir +
    ``os.replace``); the ntfy topic goes to the ``SecretStore`` (set, or
    removed when None) BEFORE the file, so the file never names a channel
    whose secret failed to save."""
    p = Path(path) if path is not None else config.settings_path()
    store = secrets if secrets is not None else secrets_for(p)
    if settings.ntfy_topic:
        store.set(NTFY_TOPIC, settings.ntfy_topic)
    elif store.path.exists():
        store.delete(NTFY_TOPIC)
    _write_text_atomic(p, settings.model_dump_json(indent=2))
    return p


def _write_text_atomic(p: Path, payload: str) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=f".{p.name}.", suffix=".tmp", dir=p.parent)
    tmp = Path(tmp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(payload)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, p)
    except BaseException:
        tmp.unlink(missing_ok=True)
        raise

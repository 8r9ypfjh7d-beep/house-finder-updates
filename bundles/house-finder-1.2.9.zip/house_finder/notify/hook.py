"""The post-collection hook: new passing listings -> notifiers.

Kept out of ``collector`` so collection stays free of matching (matching runs
at read time; ``test_collector_does_not_import_matching``). ``serve`` passes
``make_after_collection(...)`` to ``Scheduler.for_collection(after=...)``;
``collect`` and the web's synchronous "Collect now" call
``collect_and_notify``.

Rules (messaging plan stage 3):

- Only listings FIRST SEEN in this run (``report.new_ids``) are evaluated, so
  a profile change that makes an old listing pass never notifies.
- A passing listing is claimed in the ``notified`` table before any channel
  runs: it notifies once, ever, across runs and restarts.
- Deduplication (``quality.dedup_new``) runs first, and only one listing per
  duplicate cluster notifies — none when another member already did.
- A listing that is ``stale`` (``quality.stale_flag`` over its duplicate
  cluster — the same rule that hides it from the review queue) never
  notifies: a repost of an old flat does not ping the owner.
- A notifier failure never raises into collection: it is recorded as a
  ``source_health`` row ``notify:<channel>`` (status ``error`` — the red
  banner on every page and ``/health``) and a ``notify_failed`` event.
- Source health alerts (hardening stage 3): after every run — new listings
  or not — ``collector.update_alerts`` opens / clears incidents, and each
  newly opened incident is announced ONCE (``store.claim_alert_notifications``)
  through every notifier that has ``notify_alerts``.
"""

from __future__ import annotations

import logging
from collections.abc import Callable, Iterable, Sequence
from pathlib import Path
from typing import TYPE_CHECKING

from house_finder.collector.collector import CollectionReport, run_collection
from house_finder.collector.health import HEALTH_ALERTS, alert_sources, update_alerts
from house_finder.matching import rank
from house_finder.notify.notifier import DashboardNotifier, Match, Notifier, NtfyNotifier
from house_finder.profile.settings import OwnerSettings, load_settings, secrets_for
from house_finder.secrets import SMTP_PASSWORD
from house_finder.quality import dedup_new, stale_flag

if TYPE_CHECKING:
    from house_finder.net import ThrottledClient
    from house_finder.profile.profile import SearchProfile
    from house_finder.secrets import SecretStore
    from house_finder.sources.base import SourceAdapter
    from house_finder.store import SourceAlert, Store

log = logging.getLogger(__name__)

HEALTH_PREFIX = "notify:"
HEALTH_GENERAL = "notify"  # settings unreadable / the hook itself failed
HEALTH_DEDUP = "quality:dedup"  # deduplication failed (run before notifying)
DEFAULT_LOCAL_URL = "http://127.0.0.1:8765/"
EmailFactory = Callable[[OwnerSettings, "SecretStore | None", str], Notifier]


def default_ntfy_client() -> ThrottledClient:
    """The client ntfy pushes go through: no browser-imitating headers (ntfy
    is a third party; it gets the tool's own User-Agent), no retry (a POST is
    sent at most once — a 5xx may still have delivered the push), 10 s
    timeout, so an unreachable ntfy server delays a run by seconds."""
    from house_finder.net import ThrottledClient

    return ThrottledClient(min_interval=1.0, max_retries=0, timeout=10.0, browser_headers=False)


def _safe_health(store: Store, source: str, status: str, count: int = 0, message: str = "") -> None:
    try:
        store.record_health(source, status, count=count, message=message)  # type: ignore[arg-type]
    except Exception:  # never raise into collection
        log.exception("could not record notify health for %s", source)


def new_matches(store: Store, new_ids: Iterable[str], profile: SearchProfile) -> list[Match]:
    """The listings among ``new_ids`` that pass ``profile``, best first."""
    listings = [lst for lst in (store.get_listing(i) for i in dict.fromkeys(new_ids)) if lst is not None]
    return rank(listings, profile)


def _one_per_cluster(store: Store, matches: list[Match]) -> list[Match]:
    """Keep the best match of each duplicate cluster (``quality`` dedup), and
    none of a cluster that already notified: the same apartment from a second
    source never notifies twice."""
    kept: list[Match] = []
    seen: set[str] = set()
    for match in matches:
        cluster = store.cluster_ids(match[0].id)
        if cluster[0] in seen:
            continue
        seen.add(cluster[0])
        if any(store.is_notified(i) for i in cluster if i != match[0].id):
            continue
        kept.append(match)
    return kept


def _not_stale(store: Store, matches: list[Match], profile: SearchProfile) -> list[Match]:
    """Drop matches that are ``stale`` over their duplicate cluster (the
    review queue hides those too): an old flat reposted never notifies."""
    kept: list[Match] = []
    for match in matches:
        listing = match[0]
        others = [lst for lst in (store.get_listing(i) for i in store.cluster_ids(listing.id) if i != listing.id)
                  if lst is not None]
        if stale_flag(listing, profile, duplicates=others) is None:
            kept.append(match)
    return kept


def run_dedup(store: Store, new_ids: Iterable[str]) -> None:
    """``quality.dedup_new`` over the run's new listings; never raises. A
    failure is the health row ``quality:dedup`` (red banner); the next
    successful run retires it."""
    try:
        links = dedup_new(store, new_ids)
    except Exception as exc:  # dedup must never break collection or notification
        log.exception("deduplication failed")
        _safe_health(store, HEALTH_DEDUP, "error", message=f"{type(exc).__name__}: {exc}")
        return
    row = store.latest_health().get(HEALTH_DEDUP)
    if row is not None and row.status == "error":
        _safe_health(store, HEALTH_DEDUP, "ok", count=len(links))


def notify_new_matches(
    store: Store, new_ids: Iterable[str], profile: SearchProfile, notifiers: Sequence[Notifier]
) -> list[Match]:
    """Claim the new passing listings not notified before and hand them to
    every notifier; returns the matches notified. Each notifier is isolated:
    a failure is recorded as health ``notify:<name>`` = ``error`` and logged
    as a ``notify_failed`` event, never raised."""
    matches = _not_stale(store, _one_per_cluster(store, new_matches(store, new_ids, profile)), profile)
    claimed = set(store.claim_notifications([listing.id for listing, _ in matches]))
    matches = [m for m in matches if m[0].id in claimed]
    if not matches:
        return []
    for notifier in notifiers:
        _isolated(store, notifier, lambda notifier=notifier: notifier.notify(matches), len(matches))
    return matches


def _isolated(store: Store, notifier: object, call: Callable[[], None], count: int) -> None:
    name = str(getattr(notifier, "name", type(notifier).__name__))
    try:
        call()
    except Exception as exc:  # isolation boundary: notification never breaks collection
        message = f"{type(exc).__name__}: {exc}"
        log.warning("notifier %s failed: %s", name, message)
        _safe_health(store, HEALTH_PREFIX + name, "error", count=count, message=message)
        try:
            store.log_event("notify_failed", channel=name, error=message, count=count)
        except Exception:
            log.exception("could not log notify_failed")
    else:
        _safe_health(store, HEALTH_PREFIX + name, "ok", count=count)


def run_health_alerts(
    store: Store, report: CollectionReport, notifiers: Callable[[], Sequence[Notifier]]
) -> list[SourceAlert]:
    """Evaluate the run's sources (and the internal ``notify``/``quality``
    rows), then announce every open incident not announced before — once —
    through each notifier with ``notify_alerts``. ``notifiers`` is called only
    when there is something to announce. Never raises: a failure is the
    health row ``health:alerts`` (red banner)."""
    try:
        update_alerts(store, alert_sources(store, [run.source for run in report.runs]))
        alerts = store.claim_alert_notifications()
        if alerts:
            for notifier in notifiers():
                send = getattr(notifier, "notify_alerts", None)
                if send is not None:
                    _isolated(store, notifier, lambda send=send: send(alerts), len(alerts))
    except Exception as exc:  # alerts must never break collection
        log.exception("source health alerts failed")
        _safe_health(store, HEALTH_ALERTS, "error", message=f"{type(exc).__name__}: {exc}")
        return []
    latest = store.latest_health().get(HEALTH_ALERTS)
    if latest is not None and latest.status == "error":
        _safe_health(store, HEALTH_ALERTS, "ok", count=len(alerts))
    return alerts


def default_email_notifier(settings: OwnerSettings, secrets: SecretStore | None, local_url: str) -> Notifier:
    """``EmailNotifier`` over the settings' SMTP account; the password is
    read from ``secrets`` only when a mail is sent."""
    from house_finder.notify.email import EmailNotifier

    def password() -> str | None:
        return secrets.get(SMTP_PASSWORD) if secrets is not None and secrets.path.exists() else None

    return EmailNotifier(settings.smtp_host, settings.smtp_port, settings.smtp_username,
                         settings.email_from, settings.email_to, password=password,
                         local_url=local_url, security=settings.smtp_security)


def build_notifiers(
    store: Store, settings: OwnerSettings | None, *, ntfy_client: ThrottledClient | None, local_url: str,
    secrets: SecretStore | None = None, email_factory: EmailFactory | None = None,
) -> list[Notifier]:
    """Dashboard always; ntfy only when the owner turned it on with a topic
    URL; email only when the owner turned it on with an SMTP server and
    addresses. A notifier that cannot be built is a ``notify:<name>`` error."""
    notifiers: list[Notifier] = [DashboardNotifier(store)]
    if settings is None:
        return notifiers
    if settings.ntfy_enabled and settings.ntfy_topic and ntfy_client is not None:
        notifiers.append(NtfyNotifier(settings.ntfy_topic, ntfy_client, local_url))
    if settings.email_enabled:
        try:
            notifiers.append((email_factory or default_email_notifier)(settings, secrets, local_url))
        except Exception as exc:  # a bad email setup never breaks collection
            _safe_health(store, HEALTH_PREFIX + "email", "error", message=f"{type(exc).__name__}: {exc}")
    return notifiers


def clear_stale_notify_health(store: Store, settings: OwnerSettings | None) -> None:
    """Retire a red ``notify:*`` row the owner has since fixed: settings that
    read again clear ``notify``; a channel turned off clears its own error
    (recorded as ``empty`` "turned off" — never as a fake ``ok``)."""
    latest = store.latest_health()

    def failing(source: str) -> bool:
        row = latest.get(source)
        return row is not None and row.status == "error"

    if settings is not None and failing(HEALTH_GENERAL):
        _safe_health(store, HEALTH_GENERAL, "ok", message="settings readable again; a new failure will show here")
    if settings is not None and not settings.ntfy_enabled and failing(HEALTH_PREFIX + "ntfy"):
        _safe_health(store, HEALTH_PREFIX + "ntfy", "empty", message="ntfy turned off")
    if settings is not None and not settings.email_enabled and failing(HEALTH_PREFIX + "email"):
        _safe_health(store, HEALTH_PREFIX + "email", "empty", message="email turned off")


def make_after_collection(
    store: Store,
    *,
    settings_path: Path | str | None = None,
    local_url: str = DEFAULT_LOCAL_URL,
    ntfy_client: ThrottledClient | None = None,
    secrets: SecretStore | None = None,
    email_factory: EmailFactory | None = None,
) -> Callable[[CollectionReport, SearchProfile], None]:
    """The hook run after each collection. Re-reads the settings every run
    (a settings change applies without a restart); never raises.
    ``secrets`` defaults to the ``SecretStore`` next to the settings file."""
    state: dict[str, ThrottledClient | None] = {"client": ntfy_client}
    secret_store = secrets if secrets is not None else secrets_for(settings_path)

    def client() -> ThrottledClient:
        if state["client"] is None:
            state["client"] = default_ntfy_client()
        return state["client"]  # type: ignore[return-value]

    def after(report: CollectionReport, profile: SearchProfile) -> None:
        held: dict[str, OwnerSettings | None] = {"settings": None}
        built: list[list[Notifier]] = []

        def notifiers() -> list[Notifier]:
            if not built:  # built once per run, and only when something is announced
                settings = held["settings"]
                needs_client = settings is not None and settings.ntfy_enabled
                built.append(build_notifiers(store, settings, local_url=local_url,
                                             ntfy_client=client() if needs_client else None,
                                             secrets=secret_store, email_factory=email_factory))
            return built[0]

        try:
            try:
                held["settings"] = load_settings(settings_path, secrets=secret_store)
            except Exception as exc:  # broken settings: dashboard still works, say so loudly
                _safe_health(store, HEALTH_GENERAL, "error",
                             message=f"settings cannot be read, only the dashboard was notified: {exc}")
            clear_stale_notify_health(store, held["settings"])
            if report.new_ids:
                run_dedup(store, report.new_ids)  # BEFORE notifying: a duplicate never notifies again
                notify_new_matches(store, report.new_ids, profile, notifiers())
        except Exception as exc:  # the hook itself must never break collection
            log.exception("new-match notification failed")
            _safe_health(store, HEALTH_GENERAL, "error", message=f"{type(exc).__name__}: {exc}")
        # Health alerts run after EVERY collection — also one with no new
        # listings, which is exactly the zero-results case — isolated on their own.
        run_health_alerts(store, report, notifiers)

    return after


def collect_and_notify(
    store: Store,
    profile: SearchProfile,
    adapters: Iterable[SourceAdapter],
    *,
    settings_path: Path | str | None = None,
    local_url: str = DEFAULT_LOCAL_URL,
    ntfy_client: ThrottledClient | None = None,
    secrets: SecretStore | None = None,
    email_factory: EmailFactory | None = None,
) -> CollectionReport:
    """``run_collection`` followed by the new-match notification hook."""
    report = run_collection(store, profile, adapters)
    make_after_collection(store, settings_path=settings_path, local_url=local_url,
                          ntfy_client=ntfy_client, secrets=secrets,
                          email_factory=email_factory)(report, profile)
    return report

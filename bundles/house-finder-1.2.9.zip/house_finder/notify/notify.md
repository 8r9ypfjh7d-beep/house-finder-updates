# notify — new-match notifications

After each collection, the listings **first seen in that run** that pass the
profile are announced once: always on the local dashboard ("N new matches"
badge), by push to ntfy and/or by email when the owner turned them on in
`/settings` (BRIEF F9, VISION priority 4 and Direction "Notifications").
Requires [secrets.md](../secrets/secrets.md) (the ntfy topic URL and the
SMTP password live in the encrypted `SecretStore`).

## Code Files

- `notifier.py` — `Notifier` / `AlertNotifier` protocols, `DashboardNotifier`, `NtfyNotifier`, `ntfy_message()`, `ntfy_alert_message()`, `format_price()`, `format_place()`
- `email.py` — `EmailNotifier`, `EmailError` (SMTP over STARTTLS or implicit TLS only)
- `hook.py` — `make_after_collection()`, `collect_and_notify()`, `notify_new_matches()`, `run_dedup()`, `run_health_alerts()`, `new_matches()`, `build_notifiers()`, `default_email_notifier()`, `clear_stale_notify_health()`, `default_ntfy_client()`, `HEALTH_PREFIX`, `HEALTH_GENERAL`, `HEALTH_DEDUP`, `DEFAULT_LOCAL_URL`
- `__init__.py` — re-exports the above

## Flow

```
run_collection ──report.new_ids──> make_after_collection(...)(report, profile)
   load_settings (every run)          broken -> health "notify" error, dashboard only
   run_dedup(new ids)                 quality.dedup_new; error -> health "quality:dedup", never raised
   rank(new listings, profile)        passing only, best first
   one per duplicate cluster          none when another member already notified
   not stale                          quality.stale_flag over the cluster: never notified
   store.claim_notifications(ids)     notified table: ids never claimed before
   for each notifier: notify(matches) error -> health "notify:<name>" error + notify_failed event
                                      ok    -> health "notify:<name>" ok (count)
run_health_alerts (EVERY run)         collector.update_alerts(sources that ran + internal rows)
   store.claim_alert_notifications()  open incidents never announced -> claimed once
   notifier.notify_alerts(alerts)     each notifier that has it; failure -> "notify:<name>" error
                                      evaluation failure -> health "health:alerts" error
```

Callers: `serve` passes the hook to `Scheduler.for_collection(after=...)`;
`house-finder collect` and the web's synchronous **Collect now** (no
scheduler) call `collect_and_notify()`. The hook lives here, not in
`collector/`, so collection never imports matching.

## API

- `Notifier.notify(matches: Sequence[(Listing, MatchResult)]) -> None` — raises on failure.
- `DashboardNotifier(store)` — logs `new_matches` (count, listing ids). The
  badge count is `store.unseen_match_count()` (the claimed rows), cleared by
  viewing the review page.
- `NtfyNotifier(topic_url, client, local_url)` — `client.post(topic_url,
  body)` through `net.ThrottledClient`; headers `Title`, `Tags`, `Click`
  (= local URL). `topic_url` must pass `validate_ntfy_topic_url` (https,
  host, topic path, no credentials / query / fragment).
- `ntfy_message(matches, local_url)` — `"2 new matches — best: ₪5,000 ·
  Florentin, Tel Aviv\nhttp://127.0.0.1:8765/"`; one match → `"1 new match:
  …"`; missing facts → `price not stated` / `place not stated`.
- `build_notifiers(store, settings, *, ntfy_client, local_url, secrets=None,
  email_factory=None)` — dashboard always; ntfy only when
  `settings.ntfy_enabled` ("ntfy" in channels AND a topic URL); email only
  when `settings.email_enabled` (channel on; the settings validator requires
  server, From, To). `make_after_collection` / `collect_and_notify` take the
  same `secrets` (default: the `SecretStore` next to the settings file) and
  `email_factory` (tests inject one with a fake SMTP class).
- `EmailNotifier(smtp_host, port, username, sender, to, *, password,
  local_url, security="starttls", timeout=20, smtp_class, smtp_ssl_class)` —
  `password` is a callable (the `SecretStore` lookup, read only when sending;
  no user name → no login). `security="starttls"`: EHLO, **refuse** when the
  server does not offer STARTTLS, `starttls(context)`, EHLO, login, send.
  `security="ssl"`: `SMTP_SSL` (implicit TLS, port 465). Any other value
  (plain SMTP) raises `EmailError`. Both use `ssl.create_default_context()`
  (certificate + host name verified). Subject `House Finder: N new
  match(es)`, body = `ntfy_message`; alerts: `ntfy_alert_message` + the
  local `/health` URL. User name with no stored password → `EmailError`
  before connecting. **Not through `net.ThrottledClient`**: SMTP is not
  HTTP; the rule "all source HTTP (and the ntfy push) goes through
  `ThrottledClient`" is unchanged.
- `run_health_alerts(store, report, notifiers)` — `notifiers` is a callable,
  built only when there is an incident to announce. Returns the incidents
  announced. Never raises.
- `AlertNotifier.notify_alerts(alerts)` — optional on a notifier.
  Dashboard: logs `source_alert_notified` (source + kind each; the banner on
  every page is the dashboard alert). ntfy: `ntfy_alert_message` —
  `"<source>: <kind>"` per line, Title "House Finder source alert"; never the
  error message (it may echo a URL or page text).
- `clear_stale_notify_health(store, settings)` — readable settings retire a
  red `notify` row; a channel turned off retires its own red row (as
  `empty` "turned off", never a fake `ok`). Run every collection and on
  `/settings` save.

## Optimizations and Features

- **Notify once**: the listing is claimed (`INSERT OR IGNORE` on the
  `notified` primary key) before any channel runs — across runs, restarts
  and concurrent runs. A channel that fails does not get a retry for those
  listings (the dashboard still shows them; the failure is red).
- **Dedup before notify**: `run_dedup` links the run's new listings to
  earlier ones first ([quality.md](../quality/quality.md)); then only the
  best match of each cluster notifies, and none of a cluster another member
  already notified — the same apartment from a second source never pushes
  twice. A dedup failure is the red health row `quality:dedup` (retired by
  the next successful run) and notification still happens.
- **Stale never notifies**: a new passing listing whose cluster is `stale`
  (`quality.stale_flag`, the same rule that hides it from the review queue)
  is not claimed — a repost of an old flat does not ping the owner; a fresh
  repost in the cluster keeps it fresh.
- **Health alerts run even when nothing new arrived** — the zero-results
  run is exactly the one to alert on. One incident = one push
  (`notified_at` claim in the store); a channel failure is not retried.
- **No spam on profile change**: only `report.new_ids` are evaluated, so an
  old listing that newly passes after a profile edit is never pushed (it
  simply appears in the review queue).
- **Fails loudly, never into collection**: each notifier is isolated; the
  failure is a `source_health` row `notify:<channel>` (the red banner on
  every page + `/health`) and a `notify_failed` event. The hook as a whole
  is wrapped too (health `notify`).
- **Privacy**: the ntfy text (and the email body, which is the same text) holds only the count, the best match's price and
  neighborhood/city (one line, ≤ 60 chars) and the local URL — no street,
  title, description, contact name or phone. The topic URL is not written
  to the event log.
- `default_ntfy_client()`: no retry (a POST is sent at most once — a 5xx may
  still have delivered the push), a 10 s timeout so an unreachable ntfy
  server delays a run by seconds, and `browser_headers=False`: ntfy (a third
  party) gets the tool's own User-Agent, never the Chrome imitation sent to
  sources. The scheduler's hook creates it once and reuses it.
- Settings are re-read every run: turning ntfy on/off applies without a
  restart.
- A test parses the package and asserts no `httpx` / `urllib` / `requests` /
  `socket` import — all HTTP goes through `ThrottledClient` — and `smtplib`
  only in `email.py`.
- `EmailNotifier`'s sending method is `_deliver`, not `send`: the package-wide
  AST test allows exactly one `.send(...)` call (messaging `dispatch`).
- A failing email (no STARTTLS, refused login, SMTP error, no password) is the
  `notify:email` health row like any channel; the SMTP login error is
  reduced to its code, so no server text is shown.

"""``EmailNotifier``: new-match and source-alert notifications by email.

SMTP, not HTTP, so it does not go through ``net.ThrottledClient`` (that
client is for source HTTP and the ntfy push). The connection is always
encrypted with certificate checks (``ssl.create_default_context()``):
``starttls`` refuses a server that does not offer STARTTLS, ``ssl`` is
implicit TLS (port 465). There is no plain-SMTP mode.

Content follows ntfy's rule: the count, the best match's price and place
and the local URL (``ntfy_message``) — never contact names, phones, street
or listing text. The password is read from the ``SecretStore`` only when a
mail is sent and is never logged or put in an error message.
"""

from __future__ import annotations

import smtplib
import ssl
from collections.abc import Callable, Sequence
from email.message import EmailMessage
from typing import TYPE_CHECKING, Any

from house_finder.notify.notifier import Match, ntfy_alert_message, ntfy_message
from house_finder.profile.settings import SmtpSecurity, validate_email_address

if TYPE_CHECKING:
    from house_finder.store import SourceAlert

DEFAULT_TIMEOUT = 20.0
SUBJECT_MATCHES = "House Finder: {n} new match{es}"
SUBJECT_ALERT = "House Finder source alert"


class EmailError(RuntimeError):
    """The email could not be sent safely (no TLS, no password, refused)."""


class EmailNotifier:
    """Send the notification text to ``to`` from ``sender`` via SMTP over
    TLS. ``password`` is a callable (the SecretStore lookup) so the secret is
    read only when sending. ``smtp_class`` / ``smtp_ssl_class`` exist for
    tests (a fake SMTP class — never a real network call)."""

    name = "email"

    def __init__(
        self,
        smtp_host: str,
        port: int,
        username: str,
        sender: str,
        to: str,
        *,
        password: Callable[[], str | None],
        local_url: str,
        security: SmtpSecurity = "starttls",
        timeout: float = DEFAULT_TIMEOUT,
        smtp_class: Callable[..., Any] = smtplib.SMTP,
        smtp_ssl_class: Callable[..., Any] = smtplib.SMTP_SSL,
    ) -> None:
        if security not in ("starttls", "ssl"):
            raise EmailError("plain SMTP is refused: use STARTTLS or SSL/TLS")
        if not smtp_host:
            raise EmailError("no SMTP server set")
        self.host = smtp_host
        self.port = port
        self.username = username
        self.sender = validate_email_address(sender, "From address")
        self.to = validate_email_address(to, "To address")
        self.security = security
        self.local_url = local_url
        self.timeout = timeout
        self._password = password
        self._smtp_class = smtp_class
        self._smtp_ssl_class = smtp_ssl_class

    def __repr__(self) -> str:  # never the password
        return f"EmailNotifier({self.host!r}, {self.port}, {self.security})"

    def notify(self, matches: Sequence[Match]) -> None:
        if not matches:
            return
        n = len(matches)
        self._deliver(SUBJECT_MATCHES.format(n=n, es="" if n == 1 else "es"), ntfy_message(matches, self.local_url))

    def notify_alerts(self, alerts: Sequence[SourceAlert]) -> None:
        if not alerts:
            return
        self._deliver(SUBJECT_ALERT, ntfy_alert_message(alerts) + f"\n{self.local_url}health")

    def _deliver(self, subject: str, body: str) -> None:
        msg = EmailMessage()
        msg["Subject"] = subject
        msg["From"] = self.sender
        msg["To"] = self.to
        msg.set_content(body)
        password: str | None = None
        if self.username:
            password = self._password()
            if not password:
                raise EmailError("no SMTP password is stored; set it on /settings")
        context = ssl.create_default_context()  # verifies the certificate and host name
        if self.security == "ssl":
            smtp = self._smtp_ssl_class(self.host, self.port, timeout=self.timeout, context=context)
        else:
            smtp = self._smtp_class(self.host, self.port, timeout=self.timeout)
        try:
            if self.security == "starttls":
                smtp.ehlo()
                if not smtp.has_extn("starttls"):
                    raise EmailError(f"{self.host} does not offer STARTTLS; refusing to send without encryption")
                smtp.starttls(context=context)
                smtp.ehlo()
            if self.username:
                try:
                    smtp.login(self.username, password)
                except smtplib.SMTPAuthenticationError as exc:
                    raise EmailError(f"SMTP login refused ({exc.smtp_code})") from None
            smtp.send_message(msg)
        finally:
            try:
                smtp.quit()
            except Exception:  # connection already gone: nothing to clean up
                pass

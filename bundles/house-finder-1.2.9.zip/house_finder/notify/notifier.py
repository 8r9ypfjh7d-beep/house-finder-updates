"""Notifiers: how the owner hears about new matches (BRIEF F9, VISION priority 4).

``Notifier.notify(matches)`` receives the new passing listings of one
collection run, best first, as ``(Listing, MatchResult)`` pairs. Two exist:

- ``DashboardNotifier`` — always on. The unseen count is the ``notified``
  rows the owner has not viewed (``Store.unseen_match_count``); this notifier
  logs a ``new_matches`` event. The web shows "N new matches" on every page.
- ``NtfyNotifier`` — opt-in push to the ntfy topic URL the owner set (a third
  party: VISION hard constraint "only the notification channel I explicitly
  configure"). The message holds ONLY the count, the best match's price and
  place (neighborhood / city), and the local URL — never contact names,
  phones, titles or descriptions. POSTed through ``net.ThrottledClient``.

The email channel is built in ``secure-sessions`` (it needs stored SMTP
credentials).
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import TYPE_CHECKING, Protocol

from house_finder.profile.settings import validate_ntfy_topic_url

if TYPE_CHECKING:
    from house_finder.matching import MatchResult
    from house_finder.models import Listing
    from house_finder.net import ThrottledClient
    from house_finder.store import SourceAlert, Store

Match = tuple["Listing", "MatchResult"]

PLACE_MAX = 60  # characters of place text sent to ntfy


class Notifier(Protocol):
    """A notification channel. ``notify`` raises on failure; the caller
    (``notify.hook``) records it and never lets it reach collection."""

    name: str

    def notify(self, matches: Sequence[Match]) -> None:
        """Tell the owner about ``matches`` (new passing listings, best first)."""
        ...


class AlertNotifier(Protocol):
    """A channel that also announces source-health incidents. Optional: the
    hook calls ``notify_alerts`` only on notifiers that define it."""

    name: str

    def notify_alerts(self, alerts: Sequence[SourceAlert]) -> None:
        """Tell the owner about newly opened incidents (once each)."""
        ...


class DashboardNotifier:
    """The local dashboard: the badge counts unseen ``notified`` rows; this
    logs one ``new_matches`` event per run with the listing ids."""

    name = "dashboard"

    def __init__(self, store: Store) -> None:
        self.store = store

    def notify(self, matches: Sequence[Match]) -> None:
        if not matches:
            return
        self.store.log_event(
            "new_matches", count=len(matches), listing_ids=[listing.id for listing, _ in matches]
        )

    def notify_alerts(self, alerts: Sequence[SourceAlert]) -> None:
        """The banner on every page is the dashboard's alert; this logs one
        ``source_alert_notified`` event (sources + kinds)."""
        if not alerts:
            return
        self.store.log_event("source_alert_notified",
                             alerts=[{"source": a.source, "kind": a.kind} for a in alerts])


def _one_line(text: str | None) -> str:
    return " ".join((text or "").split())


def format_price(price: int | None) -> str:
    """``₪6,000`` or ``price not stated``."""
    return "price not stated" if price is None else f"₪{price:,}"


def format_place(listing: Listing) -> str:
    """``neighborhood, city`` (whichever are stated), one line, capped; never
    the street, title or contact."""
    parts = [p for p in (_one_line(listing.neighborhood), _one_line(listing.city)) if p]
    place = ", ".join(parts) or "place not stated"
    return place if len(place) <= PLACE_MAX else place[: PLACE_MAX - 1] + "…"


def ntfy_message(matches: Sequence[Match], local_url: str) -> str:
    """The push text: count + best match price/place + the local URL."""
    best, _ = matches[0]
    n = len(matches)
    head = "1 new match" if n == 1 else f"{n} new matches — best"
    return f"{head}: {format_price(best.price)} · {format_place(best)}\n{local_url}"


def ntfy_alert_message(alerts: Sequence[SourceAlert]) -> str:
    """The alert push text: ``<source>: <kind>`` per incident, one per line —
    the source name and the alert kind ONLY (no error message: it may echo a
    URL or page text)."""
    return "\n".join(f"{_one_line(a.source)}: {a.kind}" for a in alerts)


class NtfyNotifier:
    """POST a short text to the owner's ntfy topic URL (https only)."""

    name = "ntfy"

    def __init__(self, topic_url: str, client: ThrottledClient, local_url: str) -> None:
        self.topic_url = validate_ntfy_topic_url(topic_url)
        self.client = client
        self.local_url = local_url

    def notify(self, matches: Sequence[Match]) -> None:
        if not matches:
            return
        body = ntfy_message(matches, self.local_url)
        self.client.post(
            self.topic_url,
            content=body.encode("utf-8"),
            headers={
                "Content-Type": "text/plain; charset=utf-8",
                "Title": "House Finder",
                "Tags": "house",
                "Click": self.local_url,
            },
        )

    def notify_alerts(self, alerts: Sequence[SourceAlert]) -> None:
        if not alerts:
            return
        self.client.post(
            self.topic_url,
            content=ntfy_alert_message(alerts).encode("utf-8"),
            headers={
                "Content-Type": "text/plain; charset=utf-8",
                "Title": "House Finder source alert",
                "Tags": "warning",
                "Click": self.local_url,
            },
        )

"""City and neighborhood from free text, by name lookup only.

Names come from the owner's profile (each area's city and neighborhoods) and
the built-in ``text.CITY_ALIASES``; both sides go through
``text.normalize_place`` / ``canonical_city``, the same functions matching
uses. A name right after a negation or a "near / minutes from / border of"
word is not taken ("לא בתל אביב", "10 דקות מתל אביב"), and the Hebrew prefix
``מ`` ("from") is not accepted on a name.
"""

from __future__ import annotations

import re
from collections.abc import Iterable
from dataclasses import dataclass

from house_finder.profile import LocationArea
from house_finder.text import CITY_ALIASES, canonical_city, normalize_place

_STRIP = "\"'.,;:!?()[]{}*•"
# Prefixes allowed on a place name: and, in, to, that (stacked up to two).
_PLACE_PREFIX = re.compile(r"[ובלש]{1,2}")
_BLOCKERS = frozenset(
    {"לא", "ללא", "אין", "not", "no", "ליד", "קרוב", "קרובה", "near", "close", "nearby",
     "דקות", "דק'", "minutes", "mins", "min", "גבול", "בגבול", "border", "outside", "מחוץ",
     "from", "סמוך", "צמוד", "next",
     # a street named like a city ("רחוב ירושלים 5")
     "רחוב", "רח'", "רח", "שדרות", "שד'", "street", "st", "road", "rd", "avenue", "ave"}
)


@dataclass(frozen=True)
class _Sub:
    word: str
    start: int
    end: int


@dataclass(frozen=True)
class PlaceHit:
    kind: str  # "city" | "neighborhood"
    key: str  # canonical city key, or normalised neighborhood
    display: str
    city_key: str  # for a neighborhood: its area's canonical city
    start: int
    end: int


def _subtokens(s: str) -> list[_Sub]:
    out = []
    for m in re.finditer(r"\S+", s):
        core = m.group().strip(_STRIP)
        if not core:
            continue
        start = m.start() + m.group().index(core)
        for word in normalize_place(core).split():
            out.append(_Sub(word.strip(_STRIP), start, start + len(core)))
    return [t for t in out if t.word]


def _match_at(subs: list[_Sub], i: int, name: list[str]) -> bool:
    if i + len(name) > len(subs):
        return False
    first = subs[i].word
    if first != name[0]:
        if not first.endswith(name[0]) or not _PLACE_PREFIX.fullmatch(first[: -len(name[0])]):
            return False
        if not re.match(r"[א-ת]", name[0]):
            return False  # prefixes are Hebrew only
    return all(subs[i + k].word == name[k] for k in range(1, len(name)))


def _blocked(subs: list[_Sub], i: int) -> bool:
    for tok in subs[max(0, i - 2):i]:
        word = tok.word.removeprefix("ו") if tok.word.startswith("ו") and len(tok.word) > 2 else tok.word
        if tok.word in _BLOCKERS or word in _BLOCKERS:
            return True
    return False


def _names(locations: Iterable[LocationArea]) -> list[tuple[str, str, str, str, str]]:
    """``(kind, normalised name, key, display, city_key)`` for every name to look for."""
    names: list[tuple[str, str, str, str, str]] = []
    area_display: dict[str, str] = {}
    for area in locations:
        key = canonical_city(area.city)
        area_display.setdefault(key, area.city)
        names.append(("city", normalize_place(area.city), key, area.city, key))
        for nb in area.neighborhoods:
            if normalize_place(nb):
                names.append(("neighborhood", normalize_place(nb), normalize_place(nb), nb, key))
    for key, aliases in CITY_ALIASES.items():
        hebrew_name = next((a for a in aliases if re.search(r"[א-ת]", a)), key)
        for alias in (key, *aliases):
            # Shown as the owner wrote it in the profile, else in the post's script.
            shown = hebrew_name if re.search(r"[א-ת]", alias) else key.title()
            names.append(("city", normalize_place(alias), key, area_display.get(key, shown), key))
    return names


def find_places(s: str, locations: Iterable[LocationArea] = ()) -> list[PlaceHit]:
    subs = _subtokens(s)
    hits: list[PlaceHit] = []
    # Longest names first so "תל אביב יפו" wins over "תל אביב" at the same spot.
    names = sorted(_names(locations), key=lambda n: -len(n[1].split()))
    i = 0
    while i < len(subs):
        for kind, name, key, display, city_key in names:
            parts = name.split()
            if parts and _match_at(subs, i, parts):
                if not _blocked(subs, i):
                    end = subs[i + len(parts) - 1].end
                    hits.append(PlaceHit(kind, key, display, city_key, subs[i].start, end))
                i += len(parts) - 1
                break
        i += 1
    return hits

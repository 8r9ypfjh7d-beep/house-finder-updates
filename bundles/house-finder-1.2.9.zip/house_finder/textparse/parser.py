"""``parse_listing_text(text) -> ParsedFields``: a free-text rental post
(Hebrew or English) to listing fields, each with the snippet it came from.

Precision over recall (VISION priority 2, Tradeoff "missing data"): a field
the parser is not sure about stays ``None`` / absent so matching reports it
as ``unknown``; conflicting mentions give ``None`` rather than a pick, and a
negated feature mention always wins over a positive one.
"""

from __future__ import annotations

from collections.abc import Iterable
from datetime import date

from pydantic import BaseModel, Field

from house_finder.messaging.language import detect_language
from house_finder.models import Attribute, PropertyType
from house_finder.profile import LocationArea
from house_finder.textparse.context import mask, prepare
from house_finder.textparse.features import decide, find_agent, find_attributes
from house_finder.textparse.fields import (
    DATE_SPAN,
    Hit,
    agreed,
    find_floors,
    find_lease,
    find_move_in,
    find_prices,
    find_property_types,
    find_rooms,
    find_sqm,
    pick_price,
)
from house_finder.textparse.phones import find_phones
from house_finder.textparse.places import find_places


class ParsedFields(BaseModel):
    """What a post states. ``None`` / absent key / empty list = not stated or
    not certain. Field meanings match ``models.Listing``; ``evidence`` maps a
    field name (``price``, ``rooms``, ``attributes.parking``, ``is_agent``,
    ``phones``, ``city``…) to the text it was read from."""

    price: int | None = None
    rooms: float | None = None
    sqm: int | None = None
    floor: int | None = None
    property_type: PropertyType | None = None
    move_in_date: date | None = None
    move_in_immediate: bool = False
    lease_months: int | None = None
    attributes: dict[Attribute, bool] = Field(default_factory=dict)
    is_agent: bool | None = None
    phones: list[str] = Field(default_factory=list)
    city: str | None = None
    neighborhood: str | None = None
    language: str = "he"
    evidence: dict[str, str] = Field(default_factory=dict)


def parse_listing_text(
    text: str | None,
    *,
    today: date | None = None,
    locations: Iterable[LocationArea] = (),
) -> ParsedFields:
    """Parse a free-text post. ``today`` resolves a move-in day/month without
    a year to its next occurrence (default: the current date — callers that
    need determinism pass it). ``locations`` are the profile's areas: their
    city and neighborhood names are looked up besides the built-in cities."""
    src, s = prepare(text)
    today = today or date.today()
    out = ParsedFields(language=detect_language(src))
    ev = out.evidence

    def snippet(h: Hit) -> str:
        return " ".join(src[h.start:h.end].split())

    phone_hits = find_phones(s)
    for digits, _, _ in phone_hits:
        if digits not in out.phones:
            out.phones.append(digits)
    if phone_hits:
        ev["phones"] = "; ".join(" ".join(src[a:b].split()) for _, a, b in phone_hits)
    no_phones = mask(s, ((a, b) for _, a, b in phone_hits))

    rooms_hits = find_rooms(no_phones)
    sqm_hits = find_sqm(no_phones)
    floor_hits = find_floors(no_phones)
    dates, immediate = find_move_in(no_phones, today)

    if (h := agreed(find_property_types(no_phones))) is not None:
        out.property_type = h.value
        ev["property_type"] = snippet(h)
    if out.property_type is not PropertyType.room and (h := agreed(rooms_hits)) is not None:
        # A room in a shared flat: "4 rooms" describes the flat, not the offer.
        out.rooms = h.value
        ev["rooms"] = snippet(h)
    if out.property_type is PropertyType.studio and out.rooms is None and not rooms_hits:
        out.rooms = 1.0
        ev["rooms"] = ev["property_type"]
    if (h := agreed(sqm_hits)) is not None:
        out.sqm = h.value
        ev["sqm"] = snippet(h)
    if (h := agreed(floor_hits)) is not None:
        out.floor = h.value
        ev["floor"] = snippet(h)
    if (h := agreed(find_lease(no_phones))) is not None:
        out.lease_months = h.value
        ev["lease_months"] = snippet(h)
    if immediate is not None:
        out.move_in_immediate = True
        ev["move_in_immediate"] = snippet(immediate)
    if (h := agreed(dates)) is not None:
        out.move_in_date = h.value
        ev["move_in_date"] = snippet(h)

    # Price: never read a phone, date, room count, area or floor as money.
    numbers_masked = mask(
        no_phones,
        [(m.start(), m.end()) for m in DATE_SPAN.finditer(no_phones)]
        + [(h.start, h.end) for h in (*rooms_hits, *sqm_hits, *floor_hits, *dates)],
    )
    if (h := pick_price(find_prices(numbers_masked))) is not None:
        out.price = h.value
        ev["price"] = snippet(h)

    for attr, hits in find_attributes(no_phones).items():
        if (h := decide(hits)) is not None:
            out.attributes[attr] = h.value
            ev[f"attributes.{attr.value}"] = snippet(h)
    if (h := decide(find_agent(no_phones))) is not None:
        out.is_agent = h.value
        ev["is_agent"] = snippet(h)

    places = find_places(no_phones, locations)
    cities = {p.key: p for p in places if p.kind == "city"}
    if len(cities) == 1:
        p = next(iter(cities.values()))
        out.city = p.display
        ev["city"] = " ".join(src[p.start:p.end].split())
    hoods = {
        p.key: p
        for p in places
        if p.kind == "neighborhood" and (out.city is None or p.city_key in cities)
    }
    if len(hoods) == 1:
        p = next(iter(hoods.values()))
        out.neighborhood = p.display
        ev["neighborhood"] = " ".join(src[p.start:p.end].split())
    return out

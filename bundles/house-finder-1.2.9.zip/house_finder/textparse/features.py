"""Yes/no features (``Attribute``) and agent vs. owner.

Each keyword occurrence votes True or False; a negated occurrence ("ללא
מעלית", "אין חניה", "no pets", "מעלית: אין") votes False and **any False
wins**. An occurrence in a phrase that does not state the feature ("מרפסת
שירות", "חניה ברחוב", "נגישה לתחבורה ציבורית", "partly furnished") does not
vote at all, so the attribute stays unknown.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from house_finder.models import Attribute
from house_finder.textparse.context import (
    HE_PREFIX,
    colon_no_after,
    negator_before,
    postposed_no_after,
    tokens_after,
    tokens_before,
    word_near,
)
from house_finder.textparse.fields import Hit


def _he(words: str) -> str:
    return rf"(?<!\w){HE_PREFIX}(?:{words})(?!\w)"


def _en(words: str) -> str:
    return rf"(?<![a-z0-9])(?:{words})(?![a-z0-9])"


@dataclass(frozen=True)
class _Spec:
    attr: Attribute
    pattern: re.Pattern[str]
    # Occurrence ignored when this matches right after / right before it.
    skip_after: re.Pattern[str] | None = None
    skip_before: re.Pattern[str] | None = None
    # Positive only with one of these words next to it (ambiguous nouns such
    # as "ריהוט" / "pets"); negation still counts without one.
    cue_words: frozenset[str] = field(default_factory=frozenset)
    # Words after the keyword that make it False ("בעלי חיים אסורים").
    no_after: frozenset[str] = field(default_factory=frozenset)


def _c(*parts: str, flags: int = re.IGNORECASE) -> re.Pattern[str]:
    return re.compile("|".join(parts), flags)


_PET_YES = frozenset(
    {"מותר", "מותרים", "מותרות", "מתאים", "מתאימה", "מתקבלים", "בתיאום", "אפשרי",
     "ידידותית", "allowed", "ok", "okay", "welcome", "friendly", "considered"}
)
_PET_NO = frozenset({"אסור", "אסורים", "אסורות", "לא", "no", "not", "prohibited", "forbidden"})
_FURNITURE_YES = frozenset({"כולל", "כוללת", "עם", "including", "incl", "with", "includes"})

SPECS: tuple[_Spec, ...] = (
    _Spec(
        Attribute.parking,
        _c(_he("חני?יה|חניות"), _en("parking|parking\\s+spot|garage")),
        skip_after=re.compile(
            r"\s*(?:ב?רחוב|ציבורית|בשפע|בסביבה|באזור|בכחול\s*לבן|כחול\s*לבן"
            r"|nearby|on\s+the\s+street|in\s+the\s+(?:area|street)|available\s+nearby)(?!\w)",
            re.IGNORECASE,
        ),
        skip_before=re.compile(r"(?:street|public|free)\s*$", re.IGNORECASE),
    ),
    _Spec(Attribute.elevator, _c(_he("מעלית|מעליות"), _en("elevators?|lifts?"))),
    _Spec(
        Attribute.balcony,
        _c(_he("מרפסת|מרפסות"), _en("balcon(?:y|ies)|terraces?")),
        skip_after=re.compile(r"\s*שירות(?!\w)"),
        skip_before=re.compile(r"(?:service|laundry)\s*$", re.IGNORECASE),
    ),
    _Spec(
        Attribute.safe_room,
        _c(_he("ממ\"ד|ממ'ד|ממד|מרחב\\s+מוגן"), _en("mamad|safe\\s*room|protected\\s+room")),
    ),
    _Spec(
        Attribute.furnished,
        _c(_he("מרוהטת|מרוהט|מרוהטים|מרוהטות"), _en("furnished|fully\\s+furnished")),
        skip_after=re.compile(r"\s*(?:חלקית|חלקי|חלקין)(?!\w)"),
        skip_before=re.compile(r"(?:partly|partially|semi|half)[\s-]*$", re.IGNORECASE),
    ),
    _Spec(
        Attribute.furnished,
        _c(_he("ריהוט"), _en("furniture")),
        skip_after=re.compile(r"\s*(?:חלקי|למכירה|for\s+sale)(?!\w)", re.IGNORECASE),
        cue_words=_FURNITURE_YES,
    ),
    _Spec(
        Attribute.air_conditioning,
        _c(
            _he("מזגן|מזגנים|מיזוג"),
            _en("a/c|ac|air[\\s-]?condition(?:ing|ed|er|ers)?|aircon"),
        ),
    ),
    _Spec(Attribute.storage, _c(_he("מחסן|מחסנים"), _en("storage(?:\\s+room)?|storeroom"))),
    _Spec(
        Attribute.renovated,
        _c(
            _he("משופצת|משופץ|משופצים|משופצות|שופצה|שופץ"),
            _en("renovated|refurbished|newly\\s+renovated"),
        ),
        skip_before=re.compile(r"(?<![a-z])be\s*$", re.IGNORECASE),  # "to be renovated"
    ),
    _Spec(
        Attribute.accessible,
        _c(_he("נגישה|נגיש|מונגשת|מונגש|נגישות\\s+לנכים"), _en("wheelchair[\\s-]accessible|accessible")),
        # "נגישה לתחבורה ציבורית", "accessible to the beach": access, not accessibility.
        skip_after=re.compile(r"\s*(?:ל(?!נכים)\w|to|by|from|via)(?![a-z])", re.IGNORECASE),
    ),
    _Spec(
        Attribute.pets_allowed,
        _c(
            _he("בעלי\\s+חיים|חיות\\s+מחמד|חיות|כלב|כלבים|חתול|חתולים"),
            _en("pets?|dogs?|cats?"),
        ),
        cue_words=_PET_YES,
        no_after=_PET_NO,
    ),
)

_UNFURNISHED = re.compile(r"(?<![a-z])un-?furnished(?![a-z])", re.IGNORECASE)


def _vote(s: str, spec: _Spec, m: re.Match[str]) -> Hit | None:
    start, end = m.start(), m.end()
    if spec.skip_after is not None and spec.skip_after.match(s, end):
        return None
    if spec.skip_before is not None and spec.skip_before.search(s, 0, start):
        return None
    if (neg := negator_before(s, start)) is not None:
        return Hit(False, neg, end)
    if (stop := colon_no_after(s, end)) is not None:
        return Hit(False, start, stop)
    if (stop := postposed_no_after(s, end)) is not None:
        return Hit(False, start, stop)
    after = tokens_after(s, end)
    if spec.no_after and (tok := word_near(after, spec.no_after, 2)) is not None:
        return Hit(False, start, tok.end)
    if spec.cue_words:
        if (tok := word_near(after, spec.cue_words, 2)) is not None:
            return Hit(True, start, tok.end)
        if (tok := word_near(tokens_before(s, start), spec.cue_words, 2)) is not None:
            return Hit(True, tok.start, end)
        return None
    return Hit(True, start, end)


def find_attributes(s: str) -> dict[Attribute, list[Hit]]:
    """Every vote per attribute, in no particular order."""
    votes: dict[Attribute, list[Hit]] = {}
    for spec in SPECS:
        for m in spec.pattern.finditer(s):
            if (hit := _vote(s, spec, m)) is not None:
                votes.setdefault(spec.attr, []).append(hit)
    for m in _UNFURNISHED.finditer(s):
        votes.setdefault(Attribute.furnished, []).append(Hit(False, m.start(), m.end()))
    return votes


def decide(hits: list[Hit]) -> Hit | None:
    """Negation wins: the first False vote, else the first True vote."""
    for h in sorted(hits, key=lambda h: h.start):
        if h.value is False:
            return h
    return min(hits, key=lambda h: h.start) if hits else None


# ---------------------------------------------------------------- agent

_AGENT = _c(
    _he("דמי\\s+תיווך|עמלת\\s+תיווך|משרד\\s+תיווך|תיווך|מתווך|מתווכת|מתווכים|מתווכות"),
    _en("agents?|agency\\s+fee|agency|realtors?|brokers?|brokerage"),
)
_OWNER_DIRECT = _c(
    rf"(?<!\w)(?:ישירות\s+)?מ(?:ה)?(?:בעלים|בעל\s+הדירה|בעלת\s+הדירה|בעל\s+הבית)(?!\w)",
    r"(?<!\w)פטור(?:ה)?\s+מ(?:דמי\s+)?תיווך(?!\w)",  # "exempt from agent fee"
    _en("(?:directly\\s+)?from\\s+(?:the\\s+)?owners?|by\\s+owner|owner\\s+direct"),
)
_AGENT_NO_AFTER = frozenset({"לא", "אל", "no", "not", "don't", "dont"})


def find_agent(s: str) -> list[Hit]:
    """True = an agent's listing; False = owner / no agent (wins)."""
    hits = []
    for m in _AGENT.finditer(s):
        start, end = m.start(), m.end()
        if (neg := negator_before(s, start)) is not None:
            hits.append(Hit(False, neg, end))
        elif (stop := colon_no_after(s, end)) is not None:
            hits.append(Hit(False, start, stop))
        elif (tok := word_near(tokens_after(s, end), _AGENT_NO_AFTER, 2)) is not None:
            hits.append(Hit(False, start, tok.end))  # "מתווכים נא לא לפנות"
        else:
            hits.append(Hit(True, start, end))
    for m in _OWNER_DIRECT.finditer(s):
        hits.append(Hit(False, m.start(), m.end()))
    return hits

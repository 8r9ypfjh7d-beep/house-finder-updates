"""Shared helpers for the free-text parser: length-preserving normalisation,
clause-local word context, and the negation / cue checks every extractor uses.

Every helper works on character offsets into the prepared text, which has the
same length as the original, so an evidence snippet is always a slice of what
the poster wrote.
"""

from __future__ import annotations

import re
import unicodedata
from collections.abc import Iterable
from dataclasses import dataclass

# One character in, one character out: offsets stay valid for evidence.
_TRANSLATE = str.maketrans(
    {c: '"' for c in "״“”„‟″"}
    | {c: "'" for c in "׳‘’‚‛´`"}
    | {c: "-" for c in "־‐‑‒–—―−"}
    | {c: " " for c in " ‎‏‪‫‬‭‮⁦⁧⁨⁩"}
)

# Hebrew one-letter prefixes (and, the, in, to, from, that, as), up to three
# stacked ("ובה…"), in front of a keyword.
HE_PREFIX = "[ובהלמשכ]{0,3}"
# ASCII digits only: ``\d`` would also accept Arabic-Indic or full-width digits.
D = "[0-9]"

# A clause ends at sentence punctuation, a comma, a bullet or a line break; a
# negation never reaches across one.
_CLAUSE_END = re.compile(r"[.,;!?\n•|()\[\]{}]")
_WORD = re.compile(r"\S+")
_EDGE_PUNCT = "\"'.,;:!?()[]{}*•-–—_~"

NEGATORS = frozenset(
    {"ללא", "אין", "בלי", "לא", "אסור", "אסורים", "אסורות",
     "אינה", "אינו", "שאינה", "שאינו", "שאין", "אינם", "אינן",
     "no", "not", "without", "w/o", "non", "don't", "dont", "never", "nope"}
)
# A positive cue between a negator and the keyword ends the negation
# ("ללא מעלית עם חניה"), unless the cue is itself negated ("לא כולל חניה").
RESETTERS = frozenset(
    {"עם", "יש", "כולל", "כוללת", "כוללים", "אבל", "אך", "+",
     "with", "has", "have", "incl", "including", "includes", "but", "plus"}
)
# Words skipped when counting the negation window: "ללא מעלית או חניה",
# "no parking or elevator", "without an elevator".
CONJUNCTIONS = frozenset({"או", "ו", "or", "and", "nor", "&", "/", "a", "an", "any"})


def prepare(text: str | None) -> tuple[str, str]:
    """``(source, work)``: the NFC text and the same-length working copy with
    gershayim / typographic quotes -> ``"``, geresh -> ``'``, maqaf and dashes
    -> ``-``, and direction marks / no-break spaces -> space."""
    src = unicodedata.normalize("NFC", text or "")
    return src, src.translate(_TRANSLATE)


def mask(s: str, spans: Iterable[tuple[int, int]]) -> str:
    """``s`` with every ``(start, end)`` span blanked to spaces (same length)."""
    chars = list(s)
    for a, b in spans:
        for i in range(a, b):
            if chars[i] != "\n":
                chars[i] = " "
    return "".join(chars)


@dataclass(frozen=True)
class Token:
    start: int
    end: int
    word: str  # lower-cased, edge punctuation stripped


def _tokens(s: str, a: int, b: int) -> list[Token]:
    out = []
    for m in _WORD.finditer(s, a, b):
        word = m.group().strip(_EDGE_PUNCT).lower()
        if word:
            out.append(Token(m.start(), m.end(), word))
    return out


def clause_start(s: str, pos: int) -> int:
    i = pos - 1
    while i >= 0 and not _CLAUSE_END.match(s, i):
        i -= 1
    return i + 1


def clause_end(s: str, pos: int) -> int:
    m = _CLAUSE_END.search(s, pos)
    return m.start() if m else len(s)


def tokens_before(s: str, pos: int) -> list[Token]:
    """Words of the same clause before ``pos``, nearest first."""
    return list(reversed(_tokens(s, clause_start(s, pos), pos)))


def tokens_after(s: str, pos: int) -> list[Token]:
    """Words of the same clause after ``pos``, nearest first."""
    return _tokens(s, pos, clause_end(s, pos))


def _base(word: str) -> str:
    """``word`` without a leading conjunction ו when that makes it a negator /
    cue ("ואין" -> "אין", "וללא" -> "ללא")."""
    if word.startswith("ו") and (word[1:] in NEGATORS or word[1:] in RESETTERS):
        return word[1:]
    return word


def negator_before(s: str, pos: int, window: int = 2) -> int | None:
    """Start offset of a negator governing the keyword at ``pos``, or None.

    Looks at up to ``window`` words back in the same clause (conjunctions and
    articles not counted). A positive cue (``עם``, ``יש``, ``with``…) on the way
    ends the search, unless the word before the cue is a negator
    (``לא כולל``).
    """
    toks = tokens_before(s, pos)
    counted = 0
    for i, tok in enumerate(toks):
        word = _base(tok.word)
        if word in NEGATORS:
            return tok.start
        if word in RESETTERS:
            if i + 1 < len(toks) and _base(toks[i + 1].word) in NEGATORS:
                return toks[i + 1].start
            return None
        if word in CONJUNCTIONS:
            continue
        counted += 1
        if counted >= window:
            return None
    return None


def word_near(toks: list[Token], words: frozenset[str] | set[str], window: int) -> Token | None:
    """The first of the nearest ``window`` tokens whose word is in ``words``."""
    for tok in toks[:window]:
        if _base(tok.word) in words:
            return tok
    return None


# "מעלית: אין", "parking - no", "pets: no": an explicit answer after a label.
_COLON_NO = re.compile(r"\s*[:\-=]\s*(?:אין|לא|no|none|❌|✗|✖)(?![\w])", re.IGNORECASE)


def colon_no_after(s: str, pos: int) -> int | None:
    """End offset of ``: אין`` / ``- no`` right after ``pos``, or None."""
    m = _COLON_NO.match(s, pos)
    return m.end() if m else None


# "חניה אין", "חניה לא כלולה": a closing answer, only when it ends the clause
# ("יש מעלית אין חניה" - the אין belongs to the next word).
_POSTPOSED_NO = (("אין",), ("אינה",), ("אינו",), ("לא", "כלולה"), ("לא", "כולל"),
                 ("לא", "קיימת"), ("לא", "קיים"))


def postposed_no_after(s: str, pos: int) -> int | None:
    """End offset of a clause-closing ``אין`` / ``לא כלולה`` after ``pos``."""
    toks = tokens_after(s, pos)
    if tuple(t.word for t in toks) in _POSTPOSED_NO:
        return toks[-1].end
    return None

# textparse — free-text listing parser

Turns a free-text rental post (Hebrew or English, e.g. a Facebook group post)
into listing fields, keeping for every field the snippet it was read from so
the UI can show why. Pure functions, no I/O. Used by the Facebook groups
source (facebook plan, stage 2).

**Precision over recall** (VISION priority 2 "no wrong matches"; Tradeoff
"strict filter vs. missing data"): a field the parser is not sure about stays
`None` / absent, so matching shows `unknown` instead of dropping or passing a
listing on a guess.

## Code Files

- `parser.py` — `ParsedFields`, `parse_listing_text()`: runs the extractors, applies the agreement rules, builds evidence
- `fields.py` — `Hit`, `agreed()`; `find_prices()` / `pick_price()`, `find_rooms()`, `find_property_types()`, `find_sqm()`, `find_floors()`, `find_lease()`, `find_move_in()`; `DATE_SPAN`, `PRICE_MIN` / `PRICE_MAX`
- `features.py` — `SPECS` (one per keyword family), `find_attributes()`, `decide()` (negation wins), `find_agent()`
- `phones.py` — `find_phones()`: Israeli mobile / landline / 07X numbers → national digits
- `places.py` — `find_places()`, `PlaceHit`: profile + built-in city names, profile neighborhoods
- `context.py` — `prepare()` (length-preserving normalisation), `mask()`, clause-local `tokens_before/after()`, `negator_before()`, `colon_no_after()`, `word_near()`, `NEGATORS` / `RESETTERS` / `CONJUNCTIONS`, `HE_PREFIX`, `D`
- `__init__.py` — re-exports `ParsedFields`, `parse_listing_text`

## API

`parse_listing_text(text, *, today=None, locations=()) -> ParsedFields`

- `today` resolves a move-in day/month without a year (default
  `date.today()`; pass it for deterministic results).
- `locations` — the profile's `LocationArea`s; their city and neighborhood
  names are looked up in addition to `text.CITY_ALIASES`.

`ParsedFields` mirrors the `Listing` fields it can fill: `price`, `rooms`,
`sqm`, `floor`, `property_type` (`studio` / `room` only), `move_in_date`,
`move_in_immediate`, `lease_months`, `attributes: dict[Attribute, bool]`,
`is_agent`, `phones: list[str]` (national digits, `0541234567`), `city`,
`neighborhood`, `language` (`messaging.language.detect_language`), and
`evidence: dict[str, str]` — field name (`price`, `rooms`, `move_in_date`,
`attributes.parking`, `is_agent`, `phones`, `city`…) → the original text it
came from (whitespace collapsed).

## Rules per field

| Field | Taken when | Never taken from |
|---|---|---|
| price | a number next to a marker: `₪`, `ש"ח`/`ש״ח`/`שח`, `NIS`/`ILS`, `לחודש`/`per month`, label `מחיר`/`שכ"ד`/`שכירות`/`price`/`rent`, or a `k`/`אלף` suffix; 500–60,000 | phones, dates, rooms/sqm/floor spans, a bare number, a year without an adjacent currency, a number after a fee word (`ארנונה`, `ועד`, `פיקדון`, `deposit`…) |
| rooms | `3 חדרים`, `3.5 חד'`, `דירת 3 חד`, `2 וחצי חדרים`, `שלושה חדרים`, `דירת חדר`, `3 rooms`; studio → 1 | `bedrooms`, `חדרי שינה`; a room-in-shared-flat post (rooms stays None) |
| property_type | `סטודיו`/`studio` → studio; `חדר בדירת שותפים` / `חדר להשכרה` / `מחפש שותף` / `roommate` / `room in a shared…` → room | `דירת חדר להשכרה` (a one-room apartment) |
| sqm | `70 מ"ר`, `70 מטר`, `70 sqm`/`m2`; 15–1000 | `200 מטר מהים` (distance), a balcony/garden area |
| floor | `קומה 2`, `קומה 3 מתוך 4`, `קומה שלישית`, `קומת/דירת קרקע` → 0, `2nd floor`, `floor 4 of 6`, `ground floor` | `4 קומות`; a floor above its "of N" |
| move-in | `כניסה מיידית` / `available now` → immediate; a date after `כניסה`/`פנויה`/`החל`/`available`/`from`/`move-in`: `1.11`, `01/11/2026`, `1 בנובמבר`, `November 1`; day-first; no year → next occurrence ≥ `today` | a date without a move-in word (viewing, post date); an invalid date |
| lease | `חוזה לשנה` 12, `(חוזה) לשנתיים` 24, `חוזה ל-18 חודשים`, `12 months lease`, `lease: 12 months`, `2-year lease` | `פיקדון 3 חודשים`, `deposit of 2 months` |
| attributes | see below | |
| is_agent | `תיווך`/`מתווך`/`דמי תיווך`/`realtor`/`broker`/`agent` → True; negated, `מתווכים נא לא לפנות`, `מבעלים`, `from owner` → False | |
| phones | `05X-XXXXXXX` (via `messaging.senders.normalize_il_mobile`), `+972…`, `0X-XXXXXXX`, `07X-XXXXXXX`; ASCII digits only | non-ASCII digits, dates |
| city / neighborhood | a profile city / built-in alias / profile neighborhood, with Hebrew prefixes `ו ב ל ש` | after a negation or near/minutes/border word (`לא בתל אביב`, `10 דקות מתל אביב`, `ליד רמת גן`), the `מ` ("from") prefix |

**Agreement:** every field collects all its mentions; differing values →
`None` (price: the best-marked mentions must agree). A city is never inferred
from a neighborhood alone.

### Attributes and negation

Keyword families (Hebrew with up to three prefix letters `ו ה ב ל מ ש כ`,
e.g. `והמעלית`, `בחניה`; both `ממ"ד`/`ממ״ד` and `ממד`): parking, elevator,
balcony, safe_room, furnished, air_conditioning, storage, renovated,
accessible, pets_allowed.

Each occurrence votes:

- **False** when a negator (`ללא אין בלי לא אסור no not without…`, also with
  `ו`) is within two words before it in the same clause (conjunctions and
  articles `או ו or and a an` not counted): `ללא מעלית וחניה` negates both;
  or when followed by `: אין` / `- no`; pets also by `אסורים` / `not allowed`
  up to two words after; `unfurnished`.
- A positive cue (`עם יש כולל with including but`) between the negator and
  the keyword ends the negation (`ללא מעלית עם חניה` → parking True) unless
  the cue is itself negated (`לא כולל חניה` → False).
- **No vote** for phrases that do not state the feature: `מרפסת שירות`,
  `חניה ברחוב/בשפע/ציבורית`, `street parking`, `מרוהטת חלקית`,
  `partly furnished`, `to be renovated`, `נגישה לתחבורה`, `accessible to…`,
  `ריהוט למכירה`. Ambiguous nouns need a cue to be True: pets (`מותר כלב`,
  `מתאים לבעלי חיים`, `pets allowed`, `pet-friendly`), `ריהוט`/`furniture`
  (`כולל ריהוט`).
- Any False vote wins over True votes.
- Negation also comes AFTER the noun when it ends the clause (`חניה אין`,
  `חניה לא כלולה`), and from the inflected negators `אינה/אינו/שאינה/שאינו/
  שאין/אינם/אינן` (`אינה נגישה`). `יש מעלית אין חניה` still gives elevator True.
- Agent: `פטור מתיווך` / `פטור מדמי תיווך` mean NOT an agent.
- Rooms accept a trailing half (`3 חדרים וחצי` → 3.5); a floor number may end a
  sentence (`קומה 4.`).
- A city name right after a street word (`רחוב`, `רח'`, `שדרות`, `street`…)
  is a street, not a city (`רחוב ירושלים 5` gives no city).
- Known recall gaps (safe — they yield unknown): cities outside the built-in
  alias list and the profile's own locations; `Pets: yes`; `כניסה 1.11 או מיידי`.

## Optimizations and Features

- `prepare()` translates gershayim, geresh, typographic quotes, maqaf/dashes
  and direction marks one character for one character, so every offset in
  the working text is valid in the original and evidence is a slice of what
  the poster wrote (not a normalised copy).
- `mask()` blanks phone numbers before every other extractor, and dates,
  rooms, sqm, floors and move-in spans before the price finder, at the same
  length — offsets never shift. Line breaks survive masking, so they still
  end a clause.
- Every digit class is `[0-9]` (`context.D`), never `\d`, so Arabic-Indic or
  full-width digits are never read as a price or phone.
- Clauses end at `. , ; ! ? ( ) • |` and line breaks; a negation never reaches
  across one (`ללא מעלית, חניה` → parking True).
- Mobile numbers are validated by `messaging.senders.normalize_il_mobile` (one
  rule for the parser and the WhatsApp sender); only landline / 07X numbers
  use the local check. The output (`0541234567`) is accepted by that
  normaliser unchanged.
- Places reuse `text.normalize_place` / `canonical_city` per token, so the
  parser, matching and the yad2 city map agree; longest names are tried
  first (`תל אביב יפו` before `תל אביב`). A built-in city is shown with the
  profile's spelling when the profile has that city, else its Hebrew name
  (Hebrew post) or English title case.
- `rent` directly after `for` is not a price label (`for rent 3 rooms 4500`
  stays unknown).
- `fee` words before a number are ignored when they are themselves negated,
  so `ללא תיווך 5000 ₪` still yields 5000.

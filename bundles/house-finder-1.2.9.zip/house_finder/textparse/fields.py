"""Numeric and dated fields: price, rooms, sqm, floor, property type, lease,
move-in. Each extractor returns ``Hit``s; the parser keeps a value only when
every hit agrees (conflicting values -> unknown, never a pick).
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date
from typing import Any

from house_finder.models import PropertyType
from house_finder.textparse.context import (
    D,
    HE_PREFIX,
    NEGATORS,
    negator_before,
    tokens_after,
    tokens_before,
    word_near,
)


@dataclass(frozen=True)
class Hit:
    value: Any
    start: int
    end: int
    weight: int = 1


def agreed(hits: list[Hit]) -> Hit | None:
    """The first hit when all hits carry the same value, else None."""
    if not hits:
        return None
    if len({h.value for h in hits}) == 1:
        return hits[0]
    return None


# ---------------------------------------------------------------- price

PRICE_MIN, PRICE_MAX = 500, 60_000

_NUM = re.compile(
    rf"(?<![0-9.,]){D}{{1,3}}(?:,{D}{{3}})+(?![0-9])"  # 5,500
    rf"|(?<![0-9.,]){D}{{1,2}}\.{D}{{3}}(?![0-9.,])"  # 5.500 (thousands dot)
    rf"|(?<![0-9.,]){D}+(?:\.{D}+)?(?:\s*(?:[kK](?![a-zA-Z])|אלף(?!\w)))"  # 5.5k, 5 אלף
    rf"|(?<![0-9.,]){D}+(?![0-9]|[.,][0-9])"  # 5500
)
_CURRENCY = r'(?:₪|ש"ח|ש\'\'ח|שח|nis|ils|שקל(?:ים)?|shekels?)'
_CURRENCY_AFTER = re.compile(rf"\s*{_CURRENCY}(?![a-zא-ת])", re.IGNORECASE)
_CURRENCY_BEFORE = re.compile(rf"{_CURRENCY}\s*:?\s*$", re.IGNORECASE)
_MONTH_AFTER = re.compile(
    rf"\s*(?:{_CURRENCY}\s*)?(?:ל?חודש|בחודש|לחו'|/\s*(?:month|mo|חודש)|per\s+month|a\s+month|monthly|p/?m)(?![a-zא-ת])",
    re.IGNORECASE,
)
_LABEL_BEFORE = re.compile(
    r'(?<![\wא-ת])(?:מחיר|שכ"ד|שכ\'\'ד|שכר\s+דירה|שכירות|price|(?<!for\s)rent|cost)(?![a-zא-ת])[^0-9\n.,;!?]{0,15}$',
    re.IGNORECASE
)
# Words that make the number a fee, not the rent.
_FEE_WORDS = frozenset(
    {"ארנונה", "וארנונה", "ועד", "וועד", "פיקדון", "פקדון", "ערבות", "ביטחון", "בטחון",
     "תיווך", "חשמל", "מים", "גז", "אינטרנט", "arnona", "vaad", "deposit", "fee", "fees",
     "bills", "utilities", "tax", "guarantee", "security", "commission"}
)
_YEAR = re.compile(r"(?:19|20)[0-9]{2}")


def _num_value(raw: str) -> int | None:
    raw = raw.strip()
    m = re.fullmatch(rf"({D}+(?:\.{D}+)?)\s*(?:[kK]|אלף)", raw)
    if m:
        return round(float(m.group(1)) * 1000)
    if re.fullmatch(rf"{D}{{1,2}}\.{D}{{3}}", raw):
        return int(raw.replace(".", ""))
    if re.fullmatch(rf"{D}+\.{D}+", raw):
        return None  # a bare decimal is never a monthly rent
    return int(raw.replace(",", ""))


def _is_fee(s: str, pos: int) -> bool:
    """A fee word in the two words before ``pos`` ("ארנונה 400 ₪"), unless
    that word is itself negated ("ללא תיווך 5000 ₪")."""
    toks = tokens_before(s, pos)[:3]
    for i, tok in enumerate(toks[:2]):
        if tok.word in _FEE_WORDS:
            prev = toks[i + 1].word if i + 1 < len(toks) else ""
            return prev.removeprefix("ו") not in NEGATORS
    return False


def find_prices(s: str) -> list[Hit]:
    """Price candidates next to a price marker, weighted by marker count.
    ``s`` must already have phone numbers, dates, sqm and floors masked."""
    hits = []
    for m in _NUM.finditer(s):
        value = _num_value(m.group())
        if value is None or not PRICE_MIN <= value <= PRICE_MAX:
            continue
        start, end = m.start(), m.end()
        weight = 0
        is_k = not m.group()[-1].isdigit()
        if is_k:
            weight += 1
        currency_adjacent = False
        if (c := _CURRENCY_AFTER.match(s, end)) is not None:
            weight += 1
            currency_adjacent = True
            end = c.end()
        before = s[max(0, start - 30):start]
        if (c := _CURRENCY_BEFORE.search(before)) is not None:
            weight += 1
            currency_adjacent = True
            start = start - len(before) + c.start()
        if (c := _MONTH_AFTER.match(s, m.end())) is not None:
            weight += 1
            end = max(end, c.end())
        if (c := _LABEL_BEFORE.search(before)) is not None:
            weight += 1
            if not currency_adjacent or start == m.start():
                start = min(start, m.start() - len(before) + c.start())
        if weight == 0:
            continue
        if _YEAR.fullmatch(m.group()) and not currency_adjacent:
            continue
        if _is_fee(s, start):
            continue
        hits.append(Hit(value, start, end, weight))
    return hits


def pick_price(hits: list[Hit]) -> Hit | None:
    """One value: all candidates agree, or the best-marked ones do; else None."""
    if not hits:
        return None
    if (h := agreed(hits)) is not None:
        return h
    top = max(h.weight for h in hits)
    return agreed([h for h in hits if h.weight == top])


# ---------------------------------------------------------------- rooms

_HE_NUMBERS = {
    "שני": 2, "שניים": 2, "שתי": 2, "שלושה": 3, "שלוש": 3, "ארבעה": 4, "ארבע": 4,
    "חמישה": 5, "חמש": 5, "שישה": 6, "שש": 6,
}
_EN_NUMBERS = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6}
_ROOM_NUM = rf"(?P<n>{D}{{1,2}}(?:[.,]5)?)"
_ROOMS_HE = re.compile(
    rf"(?<![0-9.,]){_ROOM_NUM}\s*-?\s*(?P<half>וחצי\s*)?(?:חדרים|חד'|חד(?!\w)|חדר(?!\w))(?P<half2>\s+וחצי(?!\w))?"
)
_ROOMS_HE_WORD = re.compile(
    rf"(?<!\w)(?P<w>{'|'.join(_HE_NUMBERS)})\s+(?P<half>וחצי\s+)?חדרים(?!\w)"
)
_ROOMS_HE_SPECIAL = re.compile(r"(?<!\w)(?:(?P<oneh>חדר\s+וחצי)|(?P<one>דירת\s+חדר(?!\s+וחצי)))(?!\w)")
_ROOMS_EN = re.compile(
    rf"(?<![0-9.,a-z]){_ROOM_NUM}\s*-?\s*(?:rooms?|rms?)(?![a-z])"
    rf"|(?<![a-z])(?P<w>{'|'.join(_EN_NUMBERS)})[\s-]+(?:rooms?)(?![a-z])",
    re.IGNORECASE,
)


def find_rooms(s: str) -> list[Hit]:
    hits = []
    for m in _ROOMS_HE.finditer(s):
        n = float(m.group("n").replace(",", ".")) + (0.5 if m.group("half") or m.group("half2") else 0)
        hits.append(Hit(n, m.start(), m.end()))
    for m in _ROOMS_HE_WORD.finditer(s):
        n = _HE_NUMBERS[m.group("w")] + (0.5 if m.group("half") else 0)
        hits.append(Hit(float(n), m.start(), m.end()))
    for m in _ROOMS_HE_SPECIAL.finditer(s):
        hits.append(Hit(1.5 if m.group("oneh") else 1.0, m.start(), m.end()))
    for m in _ROOMS_EN.finditer(s):
        if m.group("n"):
            n = float(m.group("n").replace(",", "."))
        else:
            n = float(_EN_NUMBERS[m.group("w").lower()])
        hits.append(Hit(n, m.start(), m.end()))
    return [h for h in hits if 1 <= h.value <= 12]


# ---------------------------------------------------------------- property type

_STUDIO = re.compile(rf"(?<!\w){HE_PREFIX}סטודיו(?!\w)|(?<![a-z])studio(?![a-z])", re.IGNORECASE)
_ROOM_TYPE = re.compile(
    rf"(?<!\w){HE_PREFIX}חדר\s+(?:ב\s*-?\s*דיר(?:ה|ת)|להשכרה|לשותף|לשותפה)(?!\w)"
    rf"|(?<!\w){HE_PREFIX}מחפש(?:ת|ים|ות)?\s+שות(?:ף|פה|פים|פות|ף/ה)(?!\w)"
    r"|(?<![a-z])(?:room\s+in\s+(?:a\s+)?(?:shared|[0-9]+[\s-]*room)|roommates?\s+wanted|looking\s+for\s+(?:a\s+)?(?:roommate|flatmate)|flatmates?\s+wanted|room\s+for\s+rent)(?![a-z])",
    re.IGNORECASE,
)


def find_property_types(s: str) -> list[Hit]:
    hits = []
    for m in _STUDIO.finditer(s):
        if negator_before(s, m.start()) is None:
            hits.append(Hit(PropertyType.studio, m.start(), m.end()))
    for m in _ROOM_TYPE.finditer(s):
        if s[max(0, m.start() - 5):m.start()].rstrip().endswith("דירת"):
            continue  # "דירת חדר להשכרה" is a one-room apartment
        if negator_before(s, m.start()) is None:
            hits.append(Hit(PropertyType.room, m.start(), m.end()))
    return hits


# ---------------------------------------------------------------- sqm

_SQM = re.compile(
    rf"(?<![0-9.,])(?P<n>{D}{{2,4}})\s*(?:"
    r'(?P<unit>מ"ר|מ\'\'ר|מר|sqm|sq\.?\s*m|m2|m²|square\s+met(?:er|re)s?)'
    r"|(?P<meter>מטר(?:ים)?(?:\s+מרובעים)?|met(?:er|re)s?))(?![\wא-ת²])",
    re.IGNORECASE,
)
_SQM_SIDE_WORDS = frozenset(
    {"מרפסת", "גינה", "חצר", "מחסן", "balcony", "garden", "terrace", "yard", "storage"}
)
_DISTANCE_AFTER = re.compile(r"\s*(?:מ|ל)\w|\s*(?:from|to|away|walk)(?![a-z])", re.IGNORECASE)


def find_sqm(s: str) -> list[Hit]:
    hits = []
    for m in _SQM.finditer(s):
        if m.group("meter") and _DISTANCE_AFTER.match(s, m.end()):
            continue  # "200 מטר מהים", "100 meters from the beach"
        before, after = tokens_before(s, m.start()), tokens_after(s, m.end())
        if word_near(before, _SQM_SIDE_WORDS, 1) or word_near(after, _SQM_SIDE_WORDS, 1):
            continue  # balcony / garden area, not the apartment
        n = int(m.group("n"))
        if 15 <= n <= 1000:
            hits.append(Hit(n, m.start(), m.end()))
    return hits


# ---------------------------------------------------------------- floor

_HE_ORDINALS = {"ראשונה": 1, "שנייה": 2, "שניה": 2, "שלישית": 3, "רביעית": 4, "חמישית": 5, "שישית": 6}
_EN_ORDINALS = {"first": 1, "second": 2, "third": 3, "fourth": 4, "fifth": 5, "sixth": 6}
_FLOOR_HE = re.compile(
    rf"(?<!\w)[ובהל]{{0,2}}קומ(?:ה|ת)\s*:?\s*(?:ה\s*-?\s*)?(?P<n>-?{D}{{1,2}})(?![0-9]|[.,][0-9])"
    rf"(?:\s*(?:מתוך|/)\s*(?P<of>{D}{{1,2}})(?![0-9]))?"
)
_FLOOR_HE_WORD = re.compile(rf"(?<!\w)[ובהל]{{0,2}}קומה\s+(?P<w>{'|'.join(_HE_ORDINALS)})(?!\w)")
_GROUND = re.compile(
    r"(?<!\w)[ובהל]{0,2}(?:קומת\s+קרקע|קומה\s*:?\s*קרקע|דירת\s+קרקע)(?!\w)|(?<![a-z])ground\s+floor(?![a-z])",
    re.IGNORECASE,
)
_FLOOR_EN = re.compile(
    rf"(?<![0-9a-z])(?P<n>{D}{{1,2}})(?:st|nd|rd|th)\s+floor(?![a-z])"
    rf"|(?<![a-z])floor\s*:?\s*(?P<n2>{D}{{1,2}})(?![0-9]|[.,][0-9])(?:\s*(?:of|out\s+of|/)\s*(?P<of>{D}{{1,2}}))?"
    rf"|(?<![a-z])(?P<w>{'|'.join(_EN_ORDINALS)})\s+floor(?![a-z])",
    re.IGNORECASE,
)


def find_floors(s: str) -> list[Hit]:
    hits = []
    for m in _FLOOR_HE.finditer(s):
        n, of = int(m.group("n")), m.group("of")
        if of is not None and n > int(of):
            continue
        hits.append(Hit(n, m.start(), m.end()))
    for m in _FLOOR_HE_WORD.finditer(s):
        hits.append(Hit(_HE_ORDINALS[m.group("w")], m.start(), m.end()))
    for m in _GROUND.finditer(s):
        if negator_before(s, m.start()) is None:
            hits.append(Hit(0, m.start(), m.end()))
    for m in _FLOOR_EN.finditer(s):
        if m.group("w"):
            n = _EN_ORDINALS[m.group("w").lower()]
        else:
            n = int(m.group("n") or m.group("n2"))
            if m.group("of") is not None and n > int(m.group("of")):
                continue
        hits.append(Hit(n, m.start(), m.end()))
    return [h for h in hits if -3 <= h.value <= 60]


# ---------------------------------------------------------------- lease

_LEASE_HE = re.compile(
    r"(?<!\w)[ובהל]{0,2}(?:חוזה|שכירות|השכרה|להשכרה)\s*(?:של\s*)?(?:ל\s*-?\s*)?"
    rf"(?:(?P<y1>שנה)|(?P<y2>שנתיים)|(?P<n>{D}{{1,2}})\s*(?P<u>שנים|חודשים))(?!\w)"
    r"|(?<!\w)[ובהל]{0,2}חוזה\s+(?P<annual>שנתי)(?!\w)"
    r"|(?<!\w)(?P<bare2>לשנתיים)(?!\w)"
)
_LEASE_EN = re.compile(
    rf"(?<![a-z0-9])(?P<n>{D}{{1,2}}|one|two|three)[\s-]*(?P<u>years?|months?)[\s-]+(?:lease|contract)(?![a-z])"
    rf"|(?<![a-z])(?:lease|contract)\s*(?:of|for|:|-)?\s*(?P<n2>{D}{{1,2}}|one|two|three)[\s-]*(?P<u2>years?|months?)(?![a-z])"
    r"|(?<![a-z])(?P<annual>year|yearly|annual)[\s-]+(?:lease|contract)(?![a-z])",
    re.IGNORECASE,
)
_WORD_NUM = {"one": 1, "two": 2, "three": 3}
_DEPOSIT_WORDS = frozenset({"פיקדון", "פקדון", "ערבות", "מראש", "deposit", "advance", "guarantee"})


def find_lease(s: str) -> list[Hit]:
    hits = []
    for m in _LEASE_HE.finditer(s):
        if m.group("y1") or m.group("annual"):
            months = 12
        elif m.group("y2") or m.group("bare2"):
            months = 24
        else:
            months = int(m.group("n")) * (12 if m.group("u") == "שנים" else 1)
        hits.append(Hit(months, m.start(), m.end()))
    for m in _LEASE_EN.finditer(s):
        if m.group("annual"):
            months = 12
        else:
            raw = (m.group("n") or m.group("n2")).lower()
            unit = (m.group("u") or m.group("u2")).lower()
            n = _WORD_NUM.get(raw) or int(raw)
            months = n * (12 if unit.startswith("year") else 1)
        hits.append(Hit(months, m.start(), m.end()))
    out = []
    for h in hits:
        near = tokens_before(s, h.start)[:4] + tokens_after(s, h.end)[:2]
        if word_near(near, _DEPOSIT_WORDS, len(near)):
            continue
        if 1 <= h.value <= 60:
            out.append(h)
    return out


# ---------------------------------------------------------------- move-in

_MONTHS_HE = {
    "ינואר": 1, "פברואר": 2, "מרץ": 3, "מרס": 3, "אפריל": 4, "מאי": 5, "יוני": 6,
    "יולי": 7, "אוגוסט": 8, "ספטמבר": 9, "אוקטובר": 10, "נובמבר": 11, "דצמבר": 12,
}
_MONTHS_EN = {
    "january": 1, "february": 2, "march": 3, "april": 4, "may": 5, "june": 6, "july": 7,
    "august": 8, "september": 9, "october": 10, "november": 11, "december": 12,
    "jan": 1, "feb": 2, "mar": 3, "apr": 4, "jun": 6, "jul": 7, "aug": 8, "sep": 9,
    "sept": 9, "oct": 10, "nov": 11, "dec": 12,
}
_EN_MONTH_RE = "|".join(sorted(_MONTHS_EN, key=len, reverse=True))
_HE_MONTH_RE = "|".join(_MONTHS_HE)
_DATE = (
    rf"(?:(?P<d>{D}{{1,2}})[./](?P<m>{D}{{1,2}})(?:[./](?P<y>{D}{{4}}|{D}{{2}}))?(?![0-9])"
    rf"|(?P<hd>{D}{{1,2}})\s*(?:ב|ל)?\s*-?\s*(?P<hm>{_HE_MONTH_RE})(?!\w)(?:\s*(?P<hy>{D}{{4}}))?"
    rf"|(?P<em>{_EN_MONTH_RE})\.?\s+(?P<ed>{D}{{1,2}})(?:st|nd|rd|th)?(?![0-9a-z])(?:,?\s*(?P<ey>{D}{{4}}))?"
    rf"|(?P<ed2>{D}{{1,2}})(?:st|nd|rd|th)?\s+(?:of\s+)?(?P<em2>{_EN_MONTH_RE})(?![a-z])(?:,?\s*(?P<ey2>{D}{{4}}))?)"
)
_MOVE_IN_DATE = re.compile(
    rf"(?<![\wא-ת])(?:{HE_PREFIX}(?:כניסה|פנוי|פנויה|החל|מתאריך)|available|from|starting|move[\s-]?in|entry)"
    rf"(?![a-zא-ת])[^0-9\n]{{0,14}}?{_DATE}",
    re.IGNORECASE,
)
_ALT_DATE = re.compile(rf"\s*(?:או|עד|or|to|-|/)\s*{_DATE}", re.IGNORECASE)
_IMMEDIATE = re.compile(
    r"(?<!\w)(?:כניסה|פנוי|פנויה)\s*:?\s*(?:מי?י?דית|מיידי|מידי|מיד|עכשיו)(?!\w)"
    r"|(?<![a-z])(?:immediate(?:ly)?\s+(?:entry|move[\s-]?in|occupancy|availability|available)"
    r"|available\s+(?:now|immediately|right\s+away)|move[\s-]?in\s+(?:now|immediately))(?![a-z])",
    re.IGNORECASE,
)


def _resolve(day: int, month: int, year: int | None, today: date) -> date | None:
    try:
        if year is not None:
            return date(year + 2000 if year < 100 else year, month, day)
        d = date(today.year, month, day)
        if d < today:
            d = date(today.year + 1, month, day)
        return d
    except ValueError:
        return None


def find_move_in(s: str, today: date) -> tuple[list[Hit], Hit | None]:
    """``(dated hits, immediate hit)``. Only a date introduced by a move-in
    word counts; a bare date (a viewing, the post date) does not."""
    dates = []
    matches: list[re.Match[str]] = []
    for m in _MOVE_IN_DATE.finditer(s):
        matches.append(m)
        # "כניסה 1.11 או 1.12", "from 1.11 to 1.12": every date of the
        # alternative counts, so they conflict and the field stays unknown.
        while (alt := _ALT_DATE.match(s, matches[-1].end())) is not None:
            matches.append(alt)
    for m in matches:
        g = m.groupdict()
        if g["d"]:
            day, month, year = int(g["d"]), int(g["m"]), g["y"]
        elif g["hd"]:
            day, month, year = int(g["hd"]), _MONTHS_HE[g["hm"]], g["hy"]
        elif g["em"]:
            day, month, year = int(g["ed"]), _MONTHS_EN[g["em"].lower()], g["ey"]
        else:
            day, month, year = int(g["ed2"]), _MONTHS_EN[g["em2"].lower()], g["ey2"]
        d = _resolve(day, month, int(year) if year else None, today)
        if d is not None:
            dates.append(Hit(d, m.start(), m.end()))
    imm = _IMMEDIATE.search(s)
    return dates, (Hit(True, imm.start(), imm.end()) if imm else None)


# Spans the price finder must not read as numbers.
DATE_SPAN = re.compile(
    rf"(?<![0-9]){D}{{1,2}}[./]{D}{{1,2}}(?:[./](?:{D}{{4}}|{D}{{2}}))?(?![0-9])(?!\s*(?:[kK]|אלף))"
)

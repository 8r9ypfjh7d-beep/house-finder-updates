"""Israeli phone numbers in free text -> national digits (``0541234567``,
``031234567``).

Mobiles are validated with ``messaging.senders.normalize_il_mobile`` (the
same rule the WhatsApp sender applies later), landlines / 07X numbers with a
local check. ASCII digits only.
"""

from __future__ import annotations

import re

from house_finder.messaging.senders import PhoneError, normalize_il_mobile

_SEP = "[ .-]{0,2}"  # never a line break: two lines are two numbers
_INTL = r"(?:(?:\+|00)?972[ .-]{0,2}(?:\(0\)[ .-]{0,2})?|0)"
_MOBILE = re.compile(rf"(?<![0-9+]){_INTL}5[0-9](?:{_SEP}[0-9]){{7}}(?![0-9])")
_LANDLINE = re.compile(rf"(?<![0-9+]){_INTL}(?:[23489]|7[0-9])(?:{_SEP}[0-9]){{7}}(?![0-9])")


def _landline_digits(raw: str) -> str | None:
    digits = re.sub(r"[^0-9]", "", raw)
    for intl in ("00972", "972"):
        if digits.startswith(intl):
            digits = "0" + digits[len(intl):].removeprefix("0")
            break
    if re.fullmatch(r"0[23489][0-9]{7}|07[0-9]{8}", digits):
        return digits
    return None


def find_phones(s: str) -> list[tuple[str, int, int]]:
    """``(digits, start, end)`` for every Israeli phone number in ``s``, in
    text order (duplicates kept; the caller de-duplicates)."""
    found: list[tuple[str, int, int]] = []
    taken: list[tuple[int, int]] = []
    for m in _MOBILE.finditer(s):
        try:
            intl = normalize_il_mobile(m.group())
        except PhoneError:
            continue
        found.append(("0" + intl[3:], m.start(), m.end()))
        taken.append((m.start(), m.end()))
    for m in _LANDLINE.finditer(s):
        if any(a < m.end() and m.start() < b for a, b in taken):
            continue
        digits = _landline_digits(m.group())
        if digits:
            found.append((digits, m.start(), m.end()))
    found.sort(key=lambda t: t[1])
    return found

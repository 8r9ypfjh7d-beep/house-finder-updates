"""Desktop and Start-menu shortcuts "House Finder" (Windows only).

``python -m house_finder.winshortcut`` (run by ``start-house-finder.bat``
after setup) creates both shortcuts with the WScript.Shell COM object through
PowerShell. They run ``pythonw.exe -m house_finder app`` from the app folder
(no console window) — or, in the installed exe, the exe itself. Off Windows
it does nothing. ``shortcut_spec`` and ``powershell_script`` are pure, so
the target and arguments are tested on any OS.
"""

from __future__ import annotations

import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path, PureWindowsPath

SHORTCUT_NAME = "House Finder"
APP_ARGS = "-m house_finder app"
FOLDERS = ("Desktop", "Programs")  # WScript.Shell SpecialFolders: Desktop (OneDrive-aware), Start menu


@dataclass(frozen=True)
class ShortcutSpec:
    target: str
    arguments: str
    working_dir: str
    description: str = "Open House Finder"


def shortcut_spec(python_exe: str | Path, app_dir: str | Path, *, frozen: bool = False) -> ShortcutSpec:
    """What the shortcut runs: ``pythonw.exe`` next to ``python_exe`` with
    ``-m house_finder app`` in ``app_dir``; a frozen exe runs itself."""
    exe = PureWindowsPath(str(python_exe))
    folder = str(PureWindowsPath(str(app_dir)))
    if frozen:
        return ShortcutSpec(target=str(exe), arguments="", working_dir=str(exe.parent))
    return ShortcutSpec(target=str(exe.with_name("pythonw.exe")), arguments=APP_ARGS, working_dir=folder)


def _ps_quote(text: str) -> str:
    return "'" + text.replace("'", "''") + "'"


def powershell_script(spec: ShortcutSpec, name: str = SHORTCUT_NAME) -> str:
    """A PowerShell script that writes ``<name>.lnk`` into each of
    ``FOLDERS`` (paths are single-quoted literals: no expansion)."""
    lines = ["$ErrorActionPreference = 'Stop'", "$shell = New-Object -ComObject WScript.Shell"]
    for folder in FOLDERS:
        lines += [
            f"$dir = $shell.SpecialFolders({_ps_quote(folder)})",
            f"$lnk = $shell.CreateShortcut((Join-Path $dir {_ps_quote(name + '.lnk')}))",
            f"$lnk.TargetPath = {_ps_quote(spec.target)}",
            f"$lnk.Arguments = {_ps_quote(spec.arguments)}",
            f"$lnk.WorkingDirectory = {_ps_quote(spec.working_dir)}",
            f"$lnk.Description = {_ps_quote(spec.description)}",
            f"$lnk.IconLocation = {_ps_quote(spec.target + ',0')}",
            "$lnk.Save()",
            "Write-Output $lnk.FullName",
        ]
    return "\n".join(lines)


def create_shortcuts(app_dir: str | Path | None = None, *, platform: str | None = None,
                     run=subprocess.run) -> list[str]:
    """Create both shortcuts; the .lnk paths written. A no-op (``[]``) off
    Windows."""
    if (platform or sys.platform) != "win32":
        return []
    frozen = bool(getattr(sys, "frozen", False))
    folder = Path(app_dir) if app_dir is not None else Path.cwd()
    spec = shortcut_spec(sys.executable, folder.resolve(), frozen=frozen)
    result = run(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                  "-Command", powershell_script(spec)],
                 capture_output=True, text=True, check=True)
    return [line.strip() for line in (result.stdout or "").splitlines() if line.strip()]


def main() -> int:
    if sys.platform != "win32":
        print("Shortcuts are created on Windows only; nothing done.")
        return 0
    try:
        made = create_shortcuts()
    except (OSError, subprocess.CalledProcessError) as exc:
        print(f"Could not create the House Finder shortcuts: {exc}")
        return 1
    for path in made:
        print(f"Shortcut: {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

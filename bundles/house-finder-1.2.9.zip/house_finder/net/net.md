# net — throttled HTTP client

Every source HTTP request — and the ntfy push — goes through
`ThrottledClient` (CLAUDE.md rule; BRIEF N2). Adapters and notifiers never
create their own `httpx` client.

## Code Files

- `http.py` — `ThrottledClient`, `BROWSER_HEADERS`, `PLAIN_USER_AGENT`, `CAPTCHA_MARKERS`, `looks_like_html()`, `is_captcha_page()`
- `__init__.py` — re-exports the above

## API

`ThrottledClient(*, min_interval=10.0, host_intervals=None, max_retries=3,
backoff_base=2.0, backoff_max=120.0, retry_after_max=300.0, jitter=0.25,
timeout=30.0, headers=None, transport=None, clock=time.monotonic,
sleep=time.sleep, rng=random.random, dump_dir=None, browser_headers=True)`.
`browser_headers=False` sends `PLAIN_USER_AGENT` instead of the Chrome
imitation — for a third party (the ntfy push), never a source.

- `get(url, *, params=None, headers=None) -> httpx.Response` — a 2xx response or a raise.
- `post(url, *, content=None, headers=None) -> httpx.Response` — same throttling and errors as `get`, but **sent once: never retried** (not on 5xx, 429 or a network error — a POST that reached the server may have been delivered; the ntfy push).
- `get_json(url, *, params=None, headers=None) -> Any` — decoded JSON or a raise.
- `close()`; usable as a context manager.

| Outcome | Result |
|---|---|
| 2xx | returned |
| 403 | `SourceBlocked` at once (no retry) |
| 429 | retried with back-off (GET); after the last retry `SourceBlocked` ("rate limited") |
| 500/502/503/504, transport error | retried with back-off (GET); after the last retry `SourceError` |
| POST, any failure | no retry: the error at once |
| other 4xx | `SourceError` at once |
| `get_json`: HTML with a captcha/bot marker | `SourceBlocked` |
| `get_json`: other HTML, invalid JSON | `SourceError` |

`SourceError` / `SourceBlocked` are defined in `sources/base.py`. An error
from an HTTP response carries its `status` (e.g. 404 — the yad2 ad-details
fetch reads a removed ad from it); a network error has `status` None.

### Debug dump (`--dump`)

`dump_dir=<path>` writes every received response (including captcha pages
and error statuses) as `<utc-stamp>_<seq>_<host>_<status>.json|html` plus a
`.meta.json` with the final URL, status and headers. Stage 4's
`house-finder collect --dump` passes `config.data_dir() / "debug"`.

`last_response` is the last `httpx.Response` received (any status, with its
redirect `history`); `check-yad2` reports its status chain and content type.

## Optimizations and Features

- Throttling is per host and applies to **every attempt**, retries included:
  after a back-off sleep the client still waits out the host interval.
- Back-off delay = `min(backoff_max, backoff_base · 2^attempt) · (1 + jitter · rng())`;
  a numeric `Retry-After` raises the delay (capped at `retry_after_max`).
- One `RLock` serialises all requests through a client, so the scheduler
  thread and an on-demand run never double the request rate.
- `looks_like_html` checks the body's first byte as well as `Content-Type`:
  bot pages are often served as `application/json` or with no type.
- `clock`, `sleep`, `rng` and `transport` are injectable — tests use
  `httpx.MockTransport` and a fake clock, never the network or a real sleep.
- Dump file names contain no `:` (Windows-safe).
- `follow_redirects=True`, so a redirect to a captcha page is detected on
  the final page.
- Browser headers mimic Chrome on Windows with a Hebrew-first
  `Accept-Language`; per-request headers (e.g. yad2's `Referer`) override them.

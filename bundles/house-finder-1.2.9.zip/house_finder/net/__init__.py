"""Throttled HTTP for source adapters — see ``net.md``."""

from house_finder.net.http import (
    BROWSER_HEADERS,
    CAPTCHA_MARKERS,
    DEFAULT_MIN_INTERVAL,
    PLAIN_USER_AGENT,
    ThrottledClient,
    is_captcha_page,
    looks_like_html,
)

__all__ = [
    "BROWSER_HEADERS",
    "CAPTCHA_MARKERS",
    "DEFAULT_MIN_INTERVAL",
    "PLAIN_USER_AGENT",
    "ThrottledClient",
    "is_captcha_page",
    "looks_like_html",
]

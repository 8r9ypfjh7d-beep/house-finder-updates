"""In-app code updates (``updater.md``).

The installed app replaces only its ``house_finder`` package: a small zip
from the owner's public updates repo, described by ``manifest.json``::

    {"version": "1.2.1", "min_installer": "1.2.0",
     "bundle": "bundles/house-finder-1.2.1.zip",   # relative to the manifest URL
     "sha256": "<64 hex>", "size": 123456, "notes": "Fixes the yad2 city list"}

``check_for_update`` reads it (anything malformed: no update, a warning in
the log; a 404 = no updates channel yet, quiet). ``apply_update`` downloads
the bundle, checks size + sha256, extracts it safely into
``<updates root>/<version>/house_finder`` (temp dir + rename), validates it
and switches ``current.json`` (``status: pending``). The frozen launcher
(``packaging/update_loader.py``) runs it from the next start;
``mark_running_good`` confirms it once the new code answers ``/ping``.
All HTTP goes through ``net.ThrottledClient``. ``UpdateService`` is what
the web app holds: the last check result, a background check every 6 h.
"""

from __future__ import annotations

import hashlib
import io
import json
import logging
import os
import re
import shutil
import sys
import threading
import uuid
import zipfile
from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any
from urllib.parse import urljoin, urlsplit

from house_finder import config
from house_finder.version import APP_VERSION

log = logging.getLogger(__name__)

UPDATE_URL_ENV = "HOUSE_FINDER_UPDATE_URL"
DEFAULT_MANIFEST_URL = (
    "https://raw.githubusercontent.com/8r9ypfjh7d-beep/house-finder-updates/main/manifest.json"
)
RELEASES_URL = "https://github.com/8r9ypfjh7d-beep/house-finder-/releases/latest"
STATE_FILENAME = "current.json"  # same file packaging/update_loader.py reads
INSTALLER_VERSION_FILENAME = "installer_version.txt"
PACKAGE = "house_finder"
MAX_BUNDLE_BYTES = 50_000_000
MAX_EXTRACTED_BYTES = 200_000_000
MAX_NOTES = 500
CHECK_INTERVAL = 6 * 3600.0
_VERSION = re.compile(r"^\d+(\.\d+){0,3}$")
_SHA256 = re.compile(r"^[0-9a-f]{64}$")
_LITERAL = r"""^{name}\s*=\s*["']([^"']+)["']"""
MANIFEST_KEYS = {"version", "min_installer", "bundle", "sha256", "size", "notes"}


class UpdateError(Exception):
    """An update that cannot be applied (download, checksum, bundle content)."""


# ------------------------------------------------------------- versions


def parse_version(text: Any) -> tuple[int, ...] | None:
    """``"1.2.10"`` -> ``(1, 2, 10)``; None for anything else."""
    if not isinstance(text, str) or not _VERSION.match(text):
        return None
    return tuple(int(p) for p in text.split("."))


def newer(a: str, b: str) -> bool:
    """Is version ``a`` newer than ``b``? (``1.10`` > ``1.9``; ``1.2`` == ``1.2.0``)."""
    pa, pb = parse_version(a), parse_version(b)
    if pa is None or pb is None:
        raise ValueError(f"not a version: {a!r} / {b!r}")
    width = max(len(pa), len(pb))
    return pa + (0,) * (width - len(pa)) > pb + (0,) * (width - len(pb))


def read_literal(version_py: Path, name: str) -> str | None:
    """``NAME = "x"`` from a ``version.py`` without importing it."""
    try:
        text = version_py.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return None
    match = re.search(_LITERAL.format(name=name), text, re.MULTILINE)
    return match.group(1) if match else None


def installer_version() -> str:
    """The installed app's bundled code version (``installer_version.txt``,
    written by the PyInstaller spec); ``APP_VERSION`` outside the exe."""
    base = getattr(sys, "_MEIPASS", None)
    if getattr(sys, "frozen", False) and base:
        try:
            text = (Path(base) / INSTALLER_VERSION_FILENAME).read_text(encoding="utf-8").strip()
            if parse_version(text):
                return text
        except OSError:
            pass
        return "0"
    return APP_VERSION


def manifest_url() -> str:
    return os.environ.get(UPDATE_URL_ENV, "").strip() or DEFAULT_MANIFEST_URL


# ------------------------------------------------------------- manifest


@dataclass(frozen=True)
class Manifest:
    version: str
    min_installer: str
    bundle: str
    sha256: str
    size: int
    notes: str = ""


@dataclass(frozen=True)
class UpdateInfo:
    """A newer version than the running code. ``needs_installer``: its
    ``min_installer`` is newer than this installer — the page links to the
    new installer instead of "Update now"."""

    manifest: Manifest
    bundle_url: str
    needs_installer: bool

    @property
    def version(self) -> str:
        return self.manifest.version

    @property
    def notes(self) -> str:
        return self.manifest.notes


def parse_manifest(data: Any) -> Manifest:
    """Strict validation; ``UpdateError`` names the first problem."""
    if not isinstance(data, dict):
        raise UpdateError("manifest is not a JSON object")
    missing = {"version", "min_installer", "bundle", "sha256", "size"} - set(data)
    if missing:
        raise UpdateError(f"manifest lacks {', '.join(sorted(missing))}")
    extra = set(data) - MANIFEST_KEYS
    if extra:
        raise UpdateError(f"manifest has unknown keys {', '.join(sorted(extra))}")
    for key in ("version", "min_installer"):
        if parse_version(data[key]) is None:
            raise UpdateError(f"manifest {key} {data[key]!r} is not a version")
    bundle = data["bundle"]
    if (not isinstance(bundle, str) or not bundle or "\\" in bundle or urlsplit(bundle).scheme
            or urlsplit(bundle).netloc or bundle.startswith("/")
            or ".." in PurePosixPath(bundle).parts or not bundle.endswith(".zip")):
        raise UpdateError(f"manifest bundle {bundle!r} is not a relative .zip path")
    if not isinstance(data["sha256"], str) or not _SHA256.match(data["sha256"]):
        raise UpdateError("manifest sha256 is not 64 lowercase hex digits")
    size = data["size"]
    if not isinstance(size, int) or isinstance(size, bool) or not 0 < size <= MAX_BUNDLE_BYTES:
        raise UpdateError(f"manifest size {size!r} is out of range")
    notes = data.get("notes", "")
    if not isinstance(notes, str):
        raise UpdateError("manifest notes is not text")
    return Manifest(version=data["version"], min_installer=data["min_installer"], bundle=bundle,
                    sha256=data["sha256"], size=size, notes=notes.strip()[:MAX_NOTES])


def update_client() -> Any:
    """The ``ThrottledClient`` for the update channel (the tool's own name,
    no browser headers; one retry)."""
    from house_finder.net import ThrottledClient

    return ThrottledClient(min_interval=1.0, max_retries=1, browser_headers=False, timeout=60.0)


def check_for_update(client: Any, url: str, *, current: str = APP_VERSION,
                     installer: str | None = None) -> UpdateInfo | None:
    """The update newer than ``current``, or None (no newer version, no
    channel yet, or a manifest that cannot be trusted — logged). Raises
    ``SourceError`` only for a network failure (the caller logs it)."""
    from house_finder.sources.base import SourceError

    installer = installer or installer_version()
    try:
        data = client.get_json(url)
    except SourceError:
        last = getattr(client, "last_response", None)
        if last is not None and last.status_code == 404:
            log.info("update check: no updates channel yet (%s answers 404)", url)
            return None
        raise
    try:
        manifest = parse_manifest(data)
    except UpdateError as exc:
        log.warning("update check: manifest at %s refused: %s", url, exc)
        return None
    if not newer(manifest.version, current):
        return None
    return UpdateInfo(manifest=manifest, bundle_url=urljoin(url, manifest.bundle),
                      needs_installer=newer(manifest.min_installer, installer))


# ------------------------------------------------------------- bundle


def download_bundle(client: Any, info: UpdateInfo) -> bytes:
    """The bundle bytes, only when size and sha256 match the manifest."""
    data = client.get(info.bundle_url).content
    if len(data) != info.manifest.size:
        raise UpdateError(f"bundle size {len(data)} != manifest {info.manifest.size}")
    digest = hashlib.sha256(data).hexdigest()
    if digest != info.manifest.sha256:
        raise UpdateError("bundle sha256 does not match the manifest")
    return data


_WINDOWS_RESERVED = {"con", "prn", "aux", "nul", *(f"com{i}" for i in range(1, 10)),
                     *(f"lpt{i}" for i in range(1, 10))}


def _unsafe_part(part: str) -> bool:
    """A path part Windows would rewrite or treat as a device: a trailing dot
    or space (``".. "`` can act as ``..``), or a reserved name like ``CON``."""
    return part != part.rstrip(". ") or part.split(".")[0].lower() in _WINDOWS_RESERVED


def safe_extract(data: bytes, dest: Path) -> None:
    """Extract a bundle zip into ``dest``: every entry must be a relative
    path under ``house_finder/`` (no absolute path, drive, ``..``,
    backslash or symlink) and the total size bounded."""
    try:
        archive = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile as exc:
        raise UpdateError(f"bundle is not a zip: {exc}") from exc
    with archive:
        total = 0
        for info in archive.infolist():
            name = info.filename
            parts = PurePosixPath(name).parts
            if (not name or name.startswith("/") or "\\" in name or ":" in name or ".." in parts
                    or not parts or parts[0] != PACKAGE or any(_unsafe_part(p) for p in parts)):
                raise UpdateError(f"bundle entry {name!r} is outside {PACKAGE}/")
            if (info.external_attr >> 16) & 0o170000 == 0o120000:
                raise UpdateError(f"bundle entry {name!r} is a symlink")
            total += info.file_size
            if total > MAX_EXTRACTED_BYTES:
                raise UpdateError("bundle is too large when extracted")
        for info in archive.infolist():
            target = dest.joinpath(*PurePosixPath(info.filename).parts)
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(info) as src, open(target, "wb") as out:
                shutil.copyfileobj(src, out)


def validate_tree(dest: Path, version: str, min_installer: str | None = None) -> None:
    """The extracted tree is a ``house_finder`` package of ``version`` whose
    ``MIN_INSTALLER`` is the manifest's (else the launcher would silently
    skip it while the app kept offering it)."""
    pkg = dest / PACKAGE
    if not (pkg / "__init__.py").is_file() or not (pkg / "__main__.py").is_file():
        raise UpdateError("bundle has no house_finder package")
    found = read_literal(pkg / "version.py", "APP_VERSION")
    if found != version:
        raise UpdateError(f"bundle version.py says {found!r}, manifest says {version!r}")
    bundle_min = read_literal(pkg / "version.py", "MIN_INSTALLER")
    if parse_version(bundle_min) is None:
        raise UpdateError("bundle version.py has no MIN_INSTALLER")
    if min_installer is not None and parse_version(bundle_min) != parse_version(min_installer):
        raise UpdateError(f"bundle MIN_INSTALLER {bundle_min!r} != manifest min_installer {min_installer!r}")
    for source in sorted(pkg.rglob("*.py")):  # a syntax error never gets switched to
        try:
            compile(source.read_bytes(), str(source.relative_to(dest)), "exec", dont_inherit=True)
        except (SyntaxError, ValueError) as exc:
            raise UpdateError(f"bundle file {source.relative_to(dest).as_posix()} does not compile: {exc}") from exc


def is_bad(root: Path, version: str) -> bool:
    """``version`` failed on this machine (the launcher marked it bad)."""
    state = read_state(root) or {}
    return state.get("version") == version and state.get("status") == "bad"


# ------------------------------------------------------------- state


def read_state(root: Path) -> dict[str, Any] | None:
    try:
        state = json.loads((root / STATE_FILENAME).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return state if isinstance(state, dict) else None


def write_state(root: Path, state: dict[str, Any]) -> None:
    """Atomic: temp file + ``os.replace``."""
    root.mkdir(parents=True, exist_ok=True)
    tmp = root / f"{STATE_FILENAME}.{uuid.uuid4().hex}.tmp"
    tmp.write_text(json.dumps(state, indent=2), encoding="utf-8")
    os.replace(tmp, root / STATE_FILENAME)


def switch_to(root: Path, version: str) -> dict[str, Any]:
    """Make ``version`` the next start's code (``pending``); the last good
    version becomes ``previous`` (the launcher's fallback)."""
    old = read_state(root) or {}
    if old.get("status") == "good" and old.get("version") != version:
        previous = old.get("version")
    else:
        previous = old.get("previous")
    if previous == version or not (previous and (root / str(previous) / PACKAGE).is_dir()):
        previous = None
    state = {"version": version, "status": "pending", "attempts": 0, "previous": previous}
    write_state(root, state)
    return state


def cleanup(root: Path, keep: set[str]) -> list[str]:
    """Delete version dirs (and stale temp dirs) not in ``keep``; returns
    what was removed. Errors are logged, never raised."""
    removed = []
    if not root.is_dir():
        return removed
    for child in root.iterdir():
        if not child.is_dir() or child.name in keep:
            continue
        if parse_version(child.name) is None and not child.name.startswith(".tmp-"):
            continue
        try:
            shutil.rmtree(child)
            removed.append(child.name)
        except OSError as exc:
            log.warning("update cleanup: cannot remove %s: %s", child, exc)
    return removed


def running_update_version(root: Path | None) -> str | None:
    """The update version this process runs (``house_finder`` imported from
    ``<root>/<version>/``), or None (bundled / source code)."""
    if root is None:
        return None
    import house_finder

    try:
        rel = Path(house_finder.__file__).resolve().relative_to(root.resolve())
    except (ValueError, OSError):
        return None
    return rel.parts[0] if rel.parts and parse_version(rel.parts[0]) else None


def mark_running_good(root: Path | None) -> bool:
    """The running update answered ``/ping``: ``pending`` -> ``good``."""
    version = running_update_version(root)
    if version is None or root is None:
        return False
    state = read_state(root)
    if not state or state.get("version") != version or state.get("status") != "pending":
        return False
    state.update(status="good", attempts=0)
    write_state(root, state)
    log.info("update %s confirmed good", version)
    return True


def apply_update(client: Any, info: UpdateInfo, root: Path, *,
                 progress: Callable[[str], None] = lambda _t: None) -> str:
    """Download, verify, extract, validate and switch to ``info``'s version
    (effective at the next start). Raises ``UpdateError`` / ``SourceError``;
    nothing is switched on failure."""
    version = info.version
    if info.needs_installer:
        raise UpdateError(f"version {version} needs a new installer")
    progress(f"Downloading version {version}")
    data = download_bundle(client, info)
    progress("Checking and unpacking")
    root.mkdir(parents=True, exist_ok=True)
    tmp = root / f".tmp-{version}-{uuid.uuid4().hex[:8]}"
    try:
        safe_extract(data, tmp)
        validate_tree(tmp, version, info.manifest.min_installer)
        target = root / version
        if target.exists():
            shutil.rmtree(target)
        os.replace(tmp, target)
    finally:
        if tmp.exists():
            shutil.rmtree(tmp, ignore_errors=True)
    state = switch_to(root, version)
    keep = {version, *(v for v in (state.get("previous"), running_update_version(root)) if v)}
    cleanup(root, keep)
    progress(f"Version {version} is ready")
    log.info("update %s installed in %s (previous: %s)", version, root, state.get("previous"))
    return version


# ------------------------------------------------------------- service


class UpdateService:
    """The web app's view of updates: ``check()`` (never raises; keeps
    ``available`` / ``error`` / ``checked_at``), ``apply()``, and a daemon
    thread that checks at start and every ``interval`` seconds."""

    def __init__(self, root: Path, *, url: str | None = None, current: str = APP_VERSION,
                 installer: str | None = None, client_factory: Callable[[], Any] = update_client,
                 interval: float = CHECK_INTERVAL) -> None:
        self.root = root
        self.url = url or manifest_url()
        self.current = current
        self.installer = installer or installer_version()
        self.client_factory = client_factory
        self.interval = interval
        self.available: UpdateInfo | None = None
        self.error: str | None = None
        self.checked_at: str | None = None
        self._lock = threading.Lock()
        self._stop = threading.Event()

    def check(self) -> UpdateInfo | None:
        try:
            client = self.client_factory()
            try:
                info = check_for_update(client, self.url, current=self.current, installer=self.installer)
                if info is not None and is_bad(self.root, info.version):
                    log.warning("update %s failed to start here before; not offered again", info.version)
                    info = None
            finally:
                close = getattr(client, "close", None)
                if close is not None:
                    close()
            error = None
        except Exception as exc:  # never into the app: the banner just stays as it was
            log.warning("update check failed: %s: %s", type(exc).__name__, exc)
            info, error = self.available, f"{type(exc).__name__}: {exc}"
        with self._lock:
            self.available, self.error = info, error
            self.checked_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
        return info

    def apply(self, progress: Callable[[str], None] = lambda _t: None) -> str:
        info = self.available
        if info is None:
            raise UpdateError("no update available")
        client = self.client_factory()
        try:
            return apply_update(client, info, self.root, progress=progress)
        finally:
            close = getattr(client, "close", None)
            if close is not None:
                close()

    def run_forever(self, sleep: Callable[[float], bool] | None = None) -> None:
        """Check now, then every ``interval`` (until ``stop()``)."""
        wait = sleep or self._stop.wait
        while not self._stop.is_set():
            try:
                self.check()
            except Exception:  # pragma: no cover - check() already catches
                log.exception("update check crashed")
            if wait(self.interval):
                return

    def start_background(self) -> threading.Thread:
        thread = threading.Thread(target=self.run_forever, name="update-check", daemon=True)
        thread.start()
        return thread

    def stop(self) -> None:
        self._stop.set()


def service() -> UpdateService | None:
    """The app's ``UpdateService``, or None when updates are off
    (``config.updates_dir()``: a source checkout without the env var)."""
    root = config.updates_dir()
    return None if root is None else UpdateService(root)

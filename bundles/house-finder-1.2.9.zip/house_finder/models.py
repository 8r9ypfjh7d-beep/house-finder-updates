"""Shared data models: the ``Listing`` every source adapter produces, plus the
enums the profile and matching layers use.

Every optional field means "not stated by the source" — matching reports a
missing field as ``unknown`` instead of failing it (VISION Tradeoff Defaults).
"""

from __future__ import annotations

from datetime import date, datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class Attribute(str, Enum):
    """Yes/no apartment features used as must-haves and nice-to-haves."""

    parking = "parking"
    elevator = "elevator"
    balcony = "balcony"
    pets_allowed = "pets_allowed"
    furnished = "furnished"
    air_conditioning = "air_conditioning"
    safe_room = "safe_room"
    storage = "storage"
    accessible = "accessible"
    renovated = "renovated"


class PropertyType(str, Enum):
    """Kind of rental unit."""

    apartment = "apartment"
    studio = "studio"
    room = "room"
    garden_apartment = "garden_apartment"
    penthouse = "penthouse"
    duplex = "duplex"
    house = "house"
    unit = "unit"
    other = "other"


class ContactChannel(str, Enum):
    """How the poster of a listing can be reached."""

    yad2 = "yad2"
    facebook_messenger = "facebook_messenger"
    phone = "phone"
    whatsapp = "whatsapp"
    email = "email"
    other = "other"


class Contact(BaseModel):
    """Contact point for a listing's poster."""

    channel: ContactChannel
    name: str | None = None
    phone: str | None = None
    profile_url: str | None = None


class Listing(BaseModel):
    """One rental listing, normalised from any source.

    ``attributes`` maps an :class:`Attribute` to True/False when the source
    states it; an absent key means unknown. ``price`` is ILS per month.
    ``raw`` keeps the source payload for debugging and re-parsing.
    """

    source: str
    source_id: str
    url: str
    title: str | None = None
    description: str = ""
    price: int | None = None
    city: str | None = None
    neighborhood: str | None = None
    street: str | None = None
    lat: float | None = None
    lon: float | None = None
    rooms: float | None = None
    sqm: int | None = None
    floor: int | None = None
    property_type: PropertyType | None = None
    move_in_date: date | None = None
    move_in_immediate: bool = False
    lease_months: int | None = None
    attributes: dict[Attribute, bool] = Field(default_factory=dict)
    is_agent: bool | None = None
    photos: list[str] = Field(default_factory=list)
    # Videos in the post (Facebook): how many, and their poster images when the
    # page had one. Facebook streams video (blob: / MSE), so it cannot be
    # played locally — the review page links to the post instead. Defaults
    # keep listings stored before these fields loadable (JSON column, no migration).
    video_count: int = Field(default=0, ge=0)
    video_posters: list[str] = Field(default_factory=list)
    posted_at: datetime | None = None
    fetched_at: datetime
    contact: Contact | None = None
    language: str | None = None
    raw: dict[str, Any] = Field(default_factory=dict)

    @property
    def id(self) -> str:
        """Globally unique id: ``"<source>:<source_id>"``."""
        return f"{self.source}:{self.source_id}"


def fill_unknown(listing: Listing, fields: dict[str, Any]) -> Listing:
    """``listing`` with ``fields`` (JSON-able ``Listing`` field values, e.g. a
    yad2 ad's details) filled in **only where the listing does not state the
    fact**: a ``None`` / empty field, an absent attribute key, a move-in with
    neither date nor "immediate". A value the listing already has always wins.
    ``fields["evidence"]`` (field -> snippet, from ``textparse``) is copied
    into ``raw["evidence"]`` for each field it actually filled."""
    data = listing.model_dump(mode="json")
    filled: list[str] = []
    for key, value in fields.items():
        if key == "evidence" or key not in data or value is None:
            continue
        if key == "attributes":
            attrs = data["attributes"]
            for attr, flag in dict(value).items():
                if attr not in attrs:
                    attrs[attr] = flag
                    filled.append(f"attributes.{attr}")
        elif key in ("move_in_date", "move_in_immediate"):
            if data["move_in_date"] is None and not data["move_in_immediate"]:
                data[key] = value
                filled.append(key)
        elif data[key] in (None, "", [], {}):
            data[key] = value
            filled.append(key)
    evidence = fields.get("evidence") or {}
    if any(k in evidence for k in filled):
        raw = dict(data.get("raw") or {})
        ev = dict(raw.get("evidence") or {})
        for k in filled:
            if k in evidence and k not in ev:
                ev[k] = evidence[k]
        raw["evidence"] = ev
        data["raw"] = raw
    return Listing.model_validate(data)

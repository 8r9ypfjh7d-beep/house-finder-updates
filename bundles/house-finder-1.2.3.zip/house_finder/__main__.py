"""Command-line entry point (``house-finder`` / ``python -m house_finder``).

Sub-commands:

- ``init`` — create the data dir and copy the example profile into it (never
  overwrites an existing profile).
- ``serve [--port 8765] [--no-scheduler] [--interval 30]`` — start the
  background collector and the web UI on **127.0.0.1 only**.
- ``app [--port 8765] [--no-browser]`` — the owner's entry point (desktop
  shortcut, installed exe; ``run_app()``): when our server already answers
  ``/ping``, open the browser there and exit; else ``init`` + serve with no
  console (logs to ``<data>/logs/house-finder.log``) and open the browser
  once it answers. ``HOUSE_FINDER_NO_BROWSER=1`` = never open a browser (CI).
- ``collect [--source X] [--dump]`` — run one collection now (then notify
  new matches); ``--dump`` writes every raw source response to
  ``<data>/debug/``.
- ``fb-login [--timeout 600]`` — open the tool's browser on facebook.com and
  wait while the owner logs in BY HAND (the code never types credentials).
- ``fb-check [--group ID] [--posts 5]`` — dry run: read ONE group with the
  browser and print what was extracted; stores nothing, sends nothing.
- ``check-yad2 [--headless] [--captcha-wait 120]`` — one live yad2 check
  (plain HTTP, then the browser fallback) for the first profile city,
  written to ``<data>/debug/yad2-report.txt`` (structure only) for the owner
  to send back. Exit 0 even when blocked: the report is the output.

``build_adapters()`` is the single place sources are registered.
"""

from __future__ import annotations

import argparse
import logging
import os
import shutil
import subprocess
import sys
import threading
import time
import webbrowser
from collections.abc import Sequence
from pathlib import Path
from typing import Any

from house_finder import config

HOST = "127.0.0.1"  # never 0.0.0.0: the app is for this machine only
DEFAULT_PORT = 8765
YAD2_HOST = "gw.yad2.co.il"
YAD2_MIN_INTERVAL = 10.0
FB_FIXTURES_DIRNAME = "fb_fixtures"  # dev-only Facebook snapshots under the data dir
NO_BROWSER_ENV = "HOUSE_FINDER_NO_BROWSER"  # `app` serves but never opens a web browser (CI smoke)
APP_MARKER_KEY, APP_MARKER_VALUE = "app", "house-finder"  # GET /ping (web.app.APP_MARKER)
READY_TIMEOUT = 90.0  # seconds `app` waits for its own server before giving up on the browser
LOG_MAX_BYTES, LOG_BACKUPS = 1_000_000, 3
WAIT_FREE_TIMEOUT = 120.0  # seconds `app --wait-free` waits for the old server to stop (a restart)

log = logging.getLogger("house_finder")
_no_console = False  # set by safe_streams(): _out() then writes to the log file


def http_client(dump_dir: Path | str | None = None) -> Any:
    """The ``ThrottledClient`` every source shares (10 s for yad2)."""
    from house_finder.net import ThrottledClient

    return ThrottledClient(host_intervals={YAD2_HOST: YAD2_MIN_INTERVAL}, dump_dir=dump_dir)


def build_adapters(*, dump_dir: Path | str | None = None, store: Any = None, client: Any = None,
                   fb_provider: Any = None, yad2_browser: Any = None) -> list:
    """Every configured source adapter. Later plans register new sources here.

    ``dump_dir`` makes the shared ``ThrottledClient`` write every raw response
    there (``collect --dump``); ``client`` reuses one (``serve`` rebuilds the
    list per run over the same client, so throttling spans runs). Facebook is
    registered only when a page provider exists AND ``store`` has at least
    one readable group (``store.readable_fb_groups()``: joined, or approved
    and public; none is a configuration state, not a source failure). The provider is ``fb_provider`` (the logged-in browser's
    ``BrowserPageProvider``), else ``facebook_provider()``. ``yad2_browser``
    (``yad2_browser_fetcher()``) is yad2's browser fallback, used only when
    plain HTTP is blocked.
    """
    from house_finder.sources import Yad2Adapter

    adapters: list = [Yad2Adapter(client if client is not None else http_client(dump_dir),
                                  browser_fetcher=yad2_browser,
                                  region_cache=config.data_dir() / "yad2_regions.json")]
    provider = fb_provider if fb_provider is not None else facebook_provider()
    if store is not None and provider is not None and store.readable_fb_groups():
        from house_finder.sources.facebook import FacebookGroupsAdapter

        adapters.append(FacebookGroupsAdapter(provider, store))
    return adapters


def facebook_provider(browser: Any = None) -> Any:
    """The Facebook ``PageProvider``, or None: the logged-in browser's
    provider when ``browser`` is given (``fb-login`` done, playwright
    installed), else a ``FixtureProvider`` over ``<data>/fb_fixtures/`` when
    that folder exists (development only)."""
    if browser is not None:
        return browser.provider
    fixtures = config.data_dir() / FB_FIXTURES_DIRNAME
    if not fixtures.is_dir():
        return None
    from house_finder.sources.facebook import FixtureProvider

    return FixtureProvider(fixtures)


def facebook_browser(store: Any, *, headless: bool = False) -> Any:
    """The process's ``FacebookBrowser`` (``browser.open_facebook_browser``),
    or None before ``fb-login`` / without the ``[facebook]`` extra. When one
    exists the browser sender is registered for ``("facebook", "browser")``
    — used only when the owner picks send mode ``browser`` for Facebook."""
    from house_finder.browser import open_facebook_browser, register_browser_sender
    from house_finder.messaging import registry

    browser = open_facebook_browser(store, headless=headless)
    if browser is not None:
        register_browser_sender(registry, session=browser.session, pacer=browser.pacer, store=store)
    return browser


def yad2_browser_fetcher(store: Any, *, headless: bool = False) -> Any:
    """yad2's browser fallback (``browser.open_yad2_browser``: its own profile
    ``<data>/browser-yad2/``, no login), or None without the ``[facebook]``
    extra. Chromium starts only when plain HTTP is blocked."""
    from house_finder.browser import open_yad2_browser

    return open_yad2_browser(store, headless=headless)


def local_url(port: int = DEFAULT_PORT) -> str:
    """The app's own URL, put in notifications (``http://127.0.0.1:<port>/``)."""
    return f"http://{HOST}:{port}/"


def server_config(app: object, port: int = DEFAULT_PORT, *, windowless: bool = False):
    """The uvicorn config used by ``serve`` — always bound to 127.0.0.1.
    ``windowless`` (``app``): no uvicorn logging config — its console
    handlers need a real stdout/stderr; its loggers then propagate to the
    root file log (``setup_logging``)."""
    import uvicorn

    if windowless:
        return uvicorn.Config(app, host=HOST, port=port, log_level="info", log_config=None)
    return uvicorn.Config(app, host=HOST, port=port, log_level="info")


def _out(text: str) -> None:
    stream = sys.stdout
    if stream is None or _no_console:  # pythonw / the installed exe: the log file instead
        log.info("%s", text)
        return
    stream.write(text + "\n")
    stream.flush()


def safe_streams() -> None:
    """Give a console-less process (pythonw, a windowed exe: ``sys.stdout``
    / ``sys.stderr`` are None) harmless streams, so a stray print or a
    library writing to stderr never crashes the app."""
    global _no_console
    for name in ("stdout", "stderr"):
        if getattr(sys, name) is None:
            setattr(sys, name, open(os.devnull, "w", encoding="utf-8"))  # noqa: SIM115 (process lifetime)
            _no_console = True


def setup_logging(*, console: bool) -> Path:
    """Root logging to ``<data>/logs/house-finder.log`` (rotating, UTF-8),
    plus stderr when there is a console. Idempotent (replaces its own
    handlers). Returns the log path."""
    from logging.handlers import RotatingFileHandler

    path = config.log_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    root = logging.getLogger()
    remove_app_logging()
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
    handlers: list[logging.Handler] = [
        RotatingFileHandler(path, maxBytes=LOG_MAX_BYTES, backupCount=LOG_BACKUPS, encoding="utf-8")]
    if console and sys.stderr is not None:
        handlers.append(logging.StreamHandler(sys.stderr))
    for handler in handlers:
        handler.setFormatter(fmt)
        handler._house_finder = True  # type: ignore[attr-defined]
        root.addHandler(handler)
    root.setLevel(logging.INFO)
    return path


def remove_app_logging() -> None:
    """Remove (and close) the handlers ``setup_logging`` added."""
    root = logging.getLogger()
    for handler in list(root.handlers):
        if getattr(handler, "_house_finder", False):
            root.removeHandler(handler)
            handler.close()


def app_running(url: str, *, timeout: float = 2.0) -> bool | None:
    """Is House Finder answering at ``url``? True = ours (``/ping`` marker),
    False = nothing answers, None = another program holds the port. A local
    request to our own server, not source HTTP (no proxy: ``trust_env``
    off)."""
    import httpx

    try:
        resp = httpx.get(url.rstrip("/") + "/ping", timeout=timeout, trust_env=False)
    except httpx.HTTPError:
        return False
    try:
        ours = resp.status_code == 200 and resp.json().get(APP_MARKER_KEY) == APP_MARKER_VALUE
    except (ValueError, AttributeError):
        ours = False
    return True if ours else None


def ping_version(url: str, *, timeout: float = 2.0) -> str | None:
    """The code version the server at ``url`` reports on ``/ping``."""
    import httpx

    try:
        version = httpx.get(url.rstrip("/") + "/ping", timeout=timeout, trust_env=False).json().get("version")
    except (httpx.HTTPError, ValueError, AttributeError):
        return None
    return version if isinstance(version, str) else None


HOME_PATH = "/home"  # the page the app opens on (its getting-started checklist)


def open_in_browser(url: str) -> None:
    """Open the owner's default web browser on the app."""
    log.info("opening %s in the web browser", url)
    try:
        webbrowser.open(url)
    except Exception:  # a missing browser must not stop the server
        log.exception("could not open the web browser")


def open_when_ready(url: str, *, timeout: float = READY_TIMEOUT, poll: float = 0.5) -> bool:
    """Wait until our server answers ``/ping``, then open the browser."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if app_running(url, timeout=poll + 1) is True:
            open_in_browser(url.rstrip("/") + HOME_PATH)
            return True
        time.sleep(poll)
    log.error("the server did not answer within %.0f s; browser not opened", timeout)
    return False


def init_data() -> tuple[bool, Path]:
    """Create the data dir and copy the example profile unless one exists:
    ``(created, profile path)``. Never overwrites."""
    from house_finder.profile import EXAMPLE_PROFILE_PATH

    config.ensure_data_dir()
    target = config.profile_path()
    if target.exists():
        return False, target
    shutil.copyfile(EXAMPLE_PROFILE_PATH, target)
    return True, target


def cmd_init(args: argparse.Namespace) -> int:
    created, target = init_data()
    if created:
        _out(f"Created example profile: {target.resolve()}")
        _out("Edit it at http://127.0.0.1:8765/profile after 'house-finder serve'.")
    else:
        _out(f"Profile already exists, left unchanged: {target.resolve()}")
    _out(f"Data directory: {config.data_dir().resolve()}")
    return 0


def facebook_connector(store: Any, *, headless: bool = False, timeout: float = 600.0):
    """The web app's "Connect Facebook" runner: ``connect(progress, current)
    -> (browser, logged_in)`` — the ``fb-login`` flow (a VISIBLE window on
    facebook.com, the owner logs in by hand, the code only waits for the
    session cookie). It reuses the app's visible browser session (one
    Chromium per profile); a hidden one is closed first and reopened after."""

    def connect(progress: Any, current: Any) -> tuple[Any, bool]:
        from house_finder.browser import BrowserSession, fb_login, make_pacer

        if current is not None and not current.session.headless:
            return current, fb_login(current.session, make_pacer(None), timeout=timeout, out=progress)
        if current is not None:
            current.close()  # a hidden window cannot show the login page
        session = BrowserSession(config.browser_profile_dir(), headless=False)
        try:
            ok = fb_login(session, make_pacer(None), timeout=timeout, out=progress)
        finally:
            session.close()
        return facebook_browser(store, headless=headless), ok

    return connect


def run_yad2_check(client: Any, fetcher: Any, *, out: Any = None) -> tuple[Any, Path]:
    """The ``check-yad2`` report for the first profile city (the example
    profile before ``init``): ``(report, path)``; written to
    ``<data>/debug/yad2-report.txt``. ``out`` gets the RESULT line."""
    from house_finder.profile import load_profile
    from house_finder.profile.profile import EXAMPLE_PROFILE_PATH
    from house_finder.sources.yad2_report import REPORT_FILENAME, run_check

    out = out or _out
    config.ensure_data_dir()
    path = config.profile_path()
    if path.exists():
        profile, note = load_profile(path), "your profile"
    else:
        profile, note = load_profile(EXAMPLE_PROFILE_PATH), "the example profile (no data/profile.json yet)"
    out_path = config.debug_dir() / REPORT_FILENAME
    report = run_check(profile, client=client, fetcher=fetcher, out_path=out_path, profile_note=note)
    out(next((line for line in report.lines if line.startswith("RESULT:")), "RESULT: not run"))
    return report, out_path


def yad2_checker(client: Any, fetcher: Any):
    """The web app's "Check yad2" runner over the server's own client and
    yad2 browser (never a second Chromium on its profile)."""

    def check(progress: Any) -> str:
        report, path = run_yad2_check(client, fetcher, out=progress)
        return f"{report.text()}\n(saved as {path.resolve()})"

    return check


def restart_command(port: int, *, no_scheduler: bool = False, interval: float = 30.0) -> list[str]:
    """The command that starts this app again after an update: the same exe
    (frozen) or ``python -m house_finder``, ``app --no-browser --wait-free``
    on the same port, keeping ``--no-scheduler`` / ``--interval``."""
    args = ["app", "--no-browser", "--wait-free", "--port", str(port), "--interval", f"{interval:g}"]
    if no_scheduler:
        args.append("--no-scheduler")
    if getattr(sys, "frozen", False):
        return [sys.executable, *args]
    return [sys.executable, "-m", "house_finder", *args]


def restart_app(port: int, shutdown: Any, *, no_scheduler: bool = False, interval: float = 30.0,
                popen: Any = subprocess.Popen) -> None:
    """Start a detached copy of the app (it waits until this server stops
    answering ``/ping``), then stop this server (``shutdown``)."""
    cmd = restart_command(port, no_scheduler=no_scheduler, interval=interval)
    env = dict(os.environ, PYINSTALLER_RESET_ENVIRONMENT="1")  # a fresh frozen process, not our child
    kwargs: dict[str, Any] = {"stdin": subprocess.DEVNULL, "stdout": subprocess.DEVNULL,
                              "stderr": subprocess.DEVNULL, "close_fds": True, "env": env}
    if sys.platform == "win32":
        kwargs["creationflags"] = (getattr(subprocess, "DETACHED_PROCESS", 0)
                                   | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
                                   | getattr(subprocess, "CREATE_NO_WINDOW", 0))
    else:
        kwargs["start_new_session"] = True
    log.info("restarting House Finder: %s", cmd)
    popen(cmd, **kwargs)
    shutdown()


def wait_until_free(url: str, *, timeout: float = WAIT_FREE_TIMEOUT, poll: float = 0.5) -> bool:
    """``app --wait-free``: wait until our old server no longer answers
    ``/ping`` (a restart after an update). True when free."""
    deadline = time.monotonic() + timeout
    while True:
        if app_running(url, timeout=poll + 1) is not True:
            return True
        if time.monotonic() >= deadline:
            log.error("the old server still answers after %.0f s", timeout)
            return False
        time.sleep(poll)


def confirm_update_when_ready(url: str, *, timeout: float = READY_TIMEOUT, poll: float = 0.5) -> bool:
    """Once our server answers ``/ping``, mark a pending update good (the
    launcher stops counting its attempts)."""
    from house_finder import updater
    from house_finder.version import APP_VERSION

    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if app_running(url, timeout=poll + 1) is True and ping_version(url) == APP_VERSION:
            try:  # our own server answers (not an old one still stopping)
                return updater.mark_running_good(config.updates_dir())
            except OSError as exc:
                log.warning("could not confirm the update: %s", exc)
                return False
        time.sleep(poll)
    return False


def log_code_version() -> None:
    """Which code runs: an update dir or the bundled / source code (a
    version the launcher refused shows up here as "bundled" or "previous")."""
    from house_finder import updater
    from house_finder.version import APP_VERSION

    root = config.updates_dir()
    running = updater.running_update_version(root)
    state = updater.read_state(root) if root is not None else None
    log.info("code version %s (%s)", APP_VERSION, f"update in {root}" if running else "bundled")
    if state and state.get("status") == "bad" and state.get("version") != running:
        log.warning("update %s failed to start and was set aside", state.get("version"))


def serve(*, port: int = DEFAULT_PORT, interval: float = 30.0, no_scheduler: bool = False,
          fb_headless: bool = False, browser_headless: bool = False, windowless: bool = False) -> int:
    """Run the collector + web UI until stopped (Ctrl+C or the Quit button)."""
    import uvicorn

    from house_finder import updater
    from house_finder.browser import playwright_available
    from house_finder.collector import Scheduler
    from house_finder.notify import make_after_collection
    from house_finder.store import Store
    from house_finder.web import create_app

    config.ensure_data_dir()
    store = Store(config.db_path())
    fb_hidden = fb_headless or browser_headless
    browser = facebook_browser(store, headless=fb_hidden)
    yad2_browser = yad2_browser_fetcher(store, headless=browser_headless)
    client = http_client()
    holder: dict[str, Any] = {}

    def adapters() -> list:  # rebuilt every run: a group joined (or Facebook connected) meanwhile is read
        current = holder["app"].state.facebook.browser if "app" in holder else browser
        return build_adapters(store=store, client=client, fb_provider=facebook_provider(current),
                              yad2_browser=yad2_browser)

    scheduler = None
    if not no_scheduler:
        scheduler = Scheduler.for_collection(
            store, adapters, config.profile_path(), interval_minutes=interval,
            after=make_after_collection(store, settings_path=config.settings_path(),
                                        local_url=local_url(port)),
        )
    connect = facebook_connector(store, headless=fb_hidden) if playwright_available() else None
    updates = updater.service()  # None in a source checkout (unless HOUSE_FINDER_UPDATES_DIR)
    app = create_app(store, config.profile_path(), adapters, scheduler, port=port,
                     group_provider=facebook_provider(browser), browser=browser,
                     facebook_connect=connect, yad2_check=yad2_checker(client, yad2_browser),
                     updates=updates)
    holder["app"] = app
    server = uvicorn.Server(server_config(app, port, windowless=windowless))
    app.state.shutdown = lambda: setattr(server, "should_exit", True)  # POST /quit
    app.state.restart = lambda: restart_app(port, app.state.shutdown, no_scheduler=no_scheduler,
                                            interval=interval)  # after POST /update
    _out(f"House Finder on http://{HOST}:{port}  (data: {config.data_dir().resolve()})")
    if updates is not None:
        updates.start_background()
    if scheduler is not None:
        scheduler.start()
    try:
        server.run()
    finally:
        if scheduler is not None:
            scheduler.stop()
        current = app.state.facebook.browser
        if current is not None:
            current.close()
        if browser is not None and browser is not current:
            browser.close()
        if yad2_browser is not None:
            yad2_browser.close()
        store.close()
    log.info("House Finder stopped")
    return 0


def cmd_serve(args: argparse.Namespace) -> int:
    return serve(port=args.port, interval=args.interval, no_scheduler=args.no_scheduler,
                 fb_headless=args.fb_headless, browser_headless=args.browser_headless)


def cmd_app(args: argparse.Namespace) -> int:
    """The owner's entry point: open the running app, or start it windowless
    and open it. Works without a console (pythonw, the installed exe)."""
    safe_streams()
    config.ensure_data_dir()
    path = setup_logging(console=sys.stdout is not None and getattr(sys.stdout, "isatty", lambda: False)())
    url = local_url(args.port)
    want_browser = not args.no_browser and not os.environ.get(NO_BROWSER_ENV, "").strip()
    if getattr(args, "wait_free", False):  # restarted after an update: let the old server stop first
        if not wait_until_free(url):
            # still the old server: it keeps serving; exiting here is safe,
            # carrying on would just see "already runs" and leave a gap
            log.error("restart after the update cancelled: the old server did not stop")
            return 1
    state = app_running(url)
    if state is True:
        log.info("House Finder already runs at %s", url)
        if want_browser:
            open_in_browser(url.rstrip("/") + HOME_PATH)
        return 0
    if state is None:
        log.error("port %s is used by another program; House Finder cannot start", args.port)
        return 1
    created, _ = init_data()
    log.info("starting House Finder at %s (data: %s, log: %s)%s", url, config.data_dir().resolve(), path,
             "; created the example profile" if created else "")
    log_code_version()
    if want_browser:
        threading.Thread(target=open_when_ready, args=(url,), name="open-browser", daemon=True).start()
    if config.updates_dir() is not None:  # the installed app: confirm a pending update once it serves
        threading.Thread(target=confirm_update_when_ready, args=(url,), name="confirm-update",
                         daemon=True).start()
    try:
        return serve(port=args.port, interval=args.interval, windowless=True,
                     no_scheduler=getattr(args, "no_scheduler", False))
    except Exception:
        log.exception("House Finder stopped with an error")
        return 1


def cmd_collect(args: argparse.Namespace) -> int:
    from house_finder.notify import collect_and_notify
    from house_finder.profile import load_profile
    from house_finder.store import Store

    config.ensure_data_dir()
    dump_dir = config.debug_dir() if args.dump else None
    with Store(config.db_path()) as store:
        browser = facebook_browser(store) if args.source in (None, "facebook") else None
        yad2_browser = yad2_browser_fetcher(store) if args.source in (None, "yad2") else None
        adapters = build_adapters(dump_dir=dump_dir, store=store, fb_provider=facebook_provider(browser),
                                  yad2_browser=yad2_browser)
        if args.source:
            names = [a.name for a in adapters]
            adapters = [a for a in adapters if a.name == args.source]
            if not adapters:
                sys.stderr.write(f"unknown source {args.source!r}; configured: {', '.join(names)}\n")
                return 2
        from house_finder.secrets.migrate import migrate_plaintext

        migrate_plaintext(store, settings_path=config.settings_path(), about_me_path=config.about_me_path())
        profile = load_profile(config.profile_path())
        try:
            report = collect_and_notify(store, profile, adapters, settings_path=config.settings_path(),
                                        local_url=local_url(DEFAULT_PORT))
        finally:
            if browser is not None:
                browser.close()
            if yad2_browser is not None:
                yad2_browser.close()
    for run in report.runs:
        line = f"{run.source}: {run.status}, {run.count} listings ({len(run.new_ids)} new)"
        if run.message:
            line += f" — {run.message}"
        _out(line)
    if dump_dir is not None:
        _out(f"Raw responses written to {Path(dump_dir).resolve()}")
    return 1 if report.errors else 0


def cmd_fb_login(args: argparse.Namespace) -> int:
    from house_finder.browser import BrowserSession, BrowserUnavailable, fb_login, make_pacer, playwright_available

    if not playwright_available():
        sys.stderr.write('Facebook needs the optional extra: pip install -e ".[facebook]"\n')
        return 2
    config.ensure_data_dir()
    session = BrowserSession(config.browser_profile_dir(), headless=False)
    try:
        ok = fb_login(session, make_pacer(None), timeout=args.timeout, out=_out)
    except BrowserUnavailable as exc:
        sys.stderr.write(f"{exc}\n")
        return 1
    finally:
        session.close()
    return 0 if ok else 1


def cmd_fb_check(args: argparse.Namespace) -> int:
    from house_finder.browser import playwright_available
    from house_finder.browser.fb_check import check_group
    from house_finder.sources.base import SourceBlocked, SourceError
    from house_finder.store import Store

    if not playwright_available():
        sys.stderr.write('Facebook needs the optional extra: pip install -e ".[facebook]"\n')
        return 2
    config.ensure_data_dir()
    with Store(config.db_path()) as store:
        from house_finder.browser import open_facebook_browser

        browser = open_facebook_browser(store, headless=False)
        if browser is None:
            sys.stderr.write("Not logged in: run `house-finder fb-login` first.\n")
            return 2
        group_id = args.group
        if not group_id:
            joined = store.fb_groups("joined")
            if not joined:
                browser.close()
                sys.stderr.write("No joined group; pass --group <id> to read one group's page.\n")
                return 2
            group_id = joined[0].group_id
        try:
            check_group(browser, group_id, posts=args.posts, out=_out)
        except SourceBlocked as exc:
            store.start_cooldown("facebook", str(exc))
            _out(f"BLOCKED: {exc}\nFacebook actions are stopped for today; use Facebook by hand only.")
            return 1
        except SourceError as exc:
            _out(f"FAILED: {exc}")
            return 1
        finally:
            browser.close()
    return 0


def cmd_check_yad2(args: argparse.Namespace) -> int:
    from house_finder.browser import open_yad2_browser

    _out("Checking yad2: one plain request, then yad2's search page in a browser window.")
    if not args.headless:
        _out(f"If the window shows a captcha, solve it there (waiting up to {args.captcha_wait:g} s).")
    client = http_client()
    fetcher = open_yad2_browser(None, headless=args.headless, captcha_wait=args.captcha_wait)
    try:
        _, out_path = run_yad2_check(client, fetcher)
    finally:
        client.close()
        if fetcher is not None:
            fetcher.close()
    _out(f"Report written to {out_path.resolve()}")
    _out("Please send this file back (it holds no names, phones or addresses).")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="house-finder", description="Personal rental-search assistant."
    )
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("init", help="create the data dir and copy the example profile")
    p.set_defaults(func=cmd_init)
    p = sub.add_parser("serve", help=f"run the local web app on {HOST}")
    p.add_argument("--port", type=int, default=DEFAULT_PORT)
    p.add_argument("--no-scheduler", action="store_true", help="do not collect in the background")
    p.add_argument("--interval", type=float, default=30.0, help="minutes between collections")
    p.add_argument("--fb-headless", action="store_true",
                   help="run the Facebook browser without a window (default: a visible window)")
    p.add_argument("--browser-headless", action="store_true",
                   help="run every browser (Facebook and the yad2 fallback) without a window; "
                        "a yad2 captcha then counts as blocked")
    p.set_defaults(func=cmd_serve)
    p = sub.add_parser("app", help="open House Finder in the web browser (starting it without a console if needed)")
    p.add_argument("--port", type=int, default=DEFAULT_PORT)
    p.add_argument("--interval", type=float, default=30.0, help="minutes between collections")
    p.add_argument("--no-browser", action="store_true",
                   help=f"serve but do not open a web browser (also: {NO_BROWSER_ENV}=1)")
    p.add_argument("--no-scheduler", action="store_true", help="do not collect in the background")
    p.add_argument("--wait-free", action="store_true",
                   help=f"first wait (up to {WAIT_FREE_TIMEOUT:g} s) until the app on the port stops (restart)")
    p.set_defaults(func=cmd_app)
    p = sub.add_parser("install-browser", help="download the browser used for Facebook / yad2 now")
    p.set_defaults(func=cmd_install_browser)
    p = sub.add_parser("collect", help="run one collection now")
    p.add_argument("--source", help="only this source (e.g. yad2)")
    p.add_argument("--dump", action="store_true", help="write raw responses to <data>/debug/")
    p.set_defaults(func=cmd_collect)
    p = sub.add_parser("fb-login", help="log in to Facebook by hand in the tool's browser window")
    p.add_argument("--timeout", type=float, default=600.0, help="seconds to wait for the login")
    p.set_defaults(func=cmd_fb_login)
    p = sub.add_parser("fb-check", help="dry run: read one Facebook group and print what was extracted")
    p.add_argument("--group", help="group id (default: the first joined group)")
    p.add_argument("--posts", type=int, default=5, help="posts to read (default 5)")
    p.set_defaults(func=cmd_fb_check)
    p = sub.add_parser("check-yad2", help="live yad2 check (HTTP, then the browser) -> data/debug/yad2-report.txt")
    p.add_argument("--headless", action="store_true", help="no browser window (a captcha then counts as blocked)")
    p.add_argument("--captcha-wait", type=float, default=120.0,
                   help="seconds to wait for you to solve a captcha in the window (default 120)")
    p.set_defaults(func=cmd_check_yad2)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    """Parse ``argv`` (default ``sys.argv[1:]``) and run the sub-command."""
    config.pin_browsers_path()
    args = build_parser().parse_args(argv)
    return int(args.func(args))


def cmd_install_browser(args: argparse.Namespace) -> int:
    """Download Chromium now (the app otherwise does it on first use), then
    prove it starts: exit 0 only when a headless Chromium launched."""
    from house_finder.browser.session import BrowserUnavailable, ensure_chromium, launch_check

    safe_streams()
    config.ensure_data_dir()
    setup_logging(console=sys.stdout is not None and getattr(sys.stdout, "isatty", lambda: False)())
    try:
        ensure_chromium()
        launch_check()
    except BrowserUnavailable as exc:
        log.error("install-browser: %s", exc)
        print(exc, file=sys.stderr)
        return 1
    log.info("install-browser: Chromium is installed and starts")
    return 0


def run_app(argv: Sequence[str] | None = None) -> int:
    """The installed (frozen) exe's entry point: ``app`` unless ``argv``
    (default ``sys.argv[1:]``) names another sub-command. Relies on no
    ``.venv``, ``pythonw`` or working directory (the data dir rule is in
    ``config``)."""
    args = list(sys.argv[1:] if argv is None else argv)
    commands = {"init", "serve", "collect", "fb-login", "fb-check", "check-yad2", "app",
                "install-browser"}
    if args and args[0] in commands:
        return main(args)
    return main(["app", *args])


if __name__ == "__main__":
    raise SystemExit(main())

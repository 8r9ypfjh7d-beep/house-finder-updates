# house_finder — package index

The `house_finder` Python package: shared models and text helpers at the top
level, one sub-package per component in [architecture.md](../architecture.md).
Start here, then open the doc of the sub-package you are working in.

## Code Files

- `__init__.py` — package marker, `__version__`
- `__main__.py` — CLI entry point `main()` (console script `house-finder`): `init`, `serve`, `app`, `collect`, `fb-login`, `fb-check`, `check-yad2`; `run_app()` (the installed exe's / shortcut's entry: `app` unless another command is named), `serve()` (shared by `serve` and `app`), `app_running(url)` (`/ping` probe: ours / nothing / another program), `setup_logging()` + `safe_streams()` (console-less logging), `facebook_connector()` / `yad2_checker()` (the web app's Connect Facebook / Check yad2 runners), `run_yad2_check()`, `init_data()`; `build_adapters()` (the one place sources are registered; Facebook only with a provider and a joined group; yad2 gets the browser fallback when one is passed), `http_client()` (the shared `ThrottledClient`), `facebook_provider(browser)` (the browser's provider, else dev fixtures, else None), `facebook_browser(store)` (the `FacebookBrowser` after `fb-login`, registering the browser sender), `yad2_browser_fetcher(store)` (yad2's browser fallback when playwright is installed; no login), `server_config()` (127.0.0.1 only), `local_url(port)` (the link put in notifications); updates: `restart_command()` / `restart_app()` / `wait_until_free()` / `confirm_update_when_ready()` / `log_code_version()` (updater.md)
- `version.py` — `APP_VERSION`, `MIN_INSTALLER` (updater.md)
- `updater.py` — in-app code updates: manifest check, verified download, safe extract, `current.json` switch, `UpdateService` (updater.md)
- `config.py` — data dir (`HOUSE_FINDER_DATA`, else `%LOCALAPPDATA%\HouseFinder\data` when frozen, else `./data`), `updates_dir()` (updater.md), `log_path()`, `frozen_data_dir()`, `db_path()`, `profile_path()`, `settings_path()`, `templates_path()`, `about_me_path()`, `debug_dir()`, `browser_profile_dir()`, `pacer_state_path()`, `yad2_browser_profile_dir()`, `yad2_pacer_state_path()`, `ensure_data_dir()`
- `models.py` — `Listing`, `Contact`, and the enums `Attribute`, `PropertyType`, `ContactChannel`
- `text.py` — `normalize_place()`, `canonical_city()`, `CITY_ALIASES`, `safe_url()`, `SAFE_URL_SCHEMES`
- `winshortcut.py` — Desktop + Start-menu shortcut "House Finder" (`pythonw -m house_finder app` in the app folder, or the frozen exe) via PowerShell's WScript.Shell; `shortcut_spec()` / `powershell_script()` pure; `create_shortcuts()` a no-op off Windows. `python -m house_finder.winshortcut` (run by `start-house-finder.bat`)

## File Layout

```
house_finder/
    house_finder.md          - This index
    __init__.py              - Package marker
    __main__.py              - CLI: init | serve | app | collect | fb-login | fb-check | check-yad2; run_app()
    config.py                - Data dir and file paths
    version.py               - APP_VERSION, MIN_INSTALLER
    updater.py               - In-app code updates (updater.md)
    updater.md               - Updater doc
    winshortcut.py           - Windows Desktop / Start-menu shortcut to `app`
    models.py                - Listing + shared enums
    text.py                  - Place-name normalisation, city alias map, safe_url()
    profile/
        profile.py           - SearchProfile, LocationArea, load/save
        settings.py          - OwnerSettings (name, notify channels, SMTP account, send modes), load/save (ntfy topic -> SecretStore)
        example_profile.json - Example profile shipped with the package
        profile.md           - Profile doc
    secrets/
        store.py             - SecretStore: Fernet-encrypted secrets, key in OS keyring or key file, fails closed
        migrate.py           - migrate_plaintext(): plaintext ntfy topic / answer bank -> encrypted, logged
        secrets.md           - Secrets doc
    store/
        db.py                - Store (SQLite) + migrations
        store.md             - Store doc
    matching/
        filters.py           - evaluate(): hard filters -> MatchResult with reasons
        ranking.py           - score + rank(): passing listings, best first
        matching.md          - Matching doc
    net/
        http.py              - ThrottledClient: per-host interval, back-off, captcha detection, --dump hook
        net.md               - Net doc
    sources/
        base.py              - SourceAdapter protocol, SourceError, SourceBlocked
        yad2.py              - Yad2Adapter (current + legacy response shapes)
        yad2_cities.py       - City name -> yad2 code map
        yad2_report.py       - check-yad2: live check -> data/debug/yad2-report.txt (shapes only)
        sources.md           - Sources doc
        facebook/
            snapshots.py     - PostSnapshot, GroupSnapshot (from_raw), GroupSearchResult
            provider.py      - PageProvider protocol, FixtureProvider
            adapter.py       - FacebookGroupsAdapter: readable (joined / approved public) groups' posts -> Listings
            groups.py        - group_stats, classify, discover_groups (candidates only)
            facebook.md      - Facebook source doc
    textparse/
        parser.py            - parse_listing_text() -> ParsedFields (with evidence)
        fields.py            - price, rooms, type, sqm, floor, lease, move-in extractors
        features.py          - attributes + agent, negation wins
        phones.py            - Israeli phone numbers -> national digits
        places.py            - profile / built-in city and neighborhood names
        context.py           - same-length normalisation, masking, negation window
        textparse.md         - Free-text parser doc
    answers/
        bank.py              - Answer bank (data/about_me.json, encrypted): facts, sensitive keys, remembered answers
        drafting.py          - draft_answers(): entry answers from the bank only; sensitive/unknown -> needs input
        answers.md           - Answers doc
    quality/
        dedup.py             - fingerprint() / duplicate_reason() (pure), dedup_new() runner, rank_clusters()
        flags.py             - flags_for(): scam / stale flags with reason + evidence; payment_details_problem()
        quality.md           - Quality doc
    collector/
        collector.py         - run_collection(): isolated adapters, health rows, events
        scheduler.py         - Background schedule (30 min) + trigger_now()
        health.py            - Source health alerts: evaluate() (pure), update_alerts()
        collector.md         - Collector doc
    messaging/
        language.py          - detect_language(): he / en
        templates.py         - default + owner templates, render_template()
        drafts.py            - draft_message(), channel_for_listing()
        senders.py           - Sender protocol, assisted WhatsApp/Facebook/yad2 senders, registry, channel_for()
        dispatch.py          - dispatch(): the single send call site; pending_action()
        messaging.md         - Messaging doc
    notify/
        notifier.py          - Notifier protocol, DashboardNotifier, NtfyNotifier, ntfy_message(), ntfy_alert_message()
        email.py             - EmailNotifier: SMTP over STARTTLS / implicit TLS only
        hook.py              - post-collection hook: new passing non-stale listings -> notifiers, once; health alerts
        notify.md            - Notify doc
    browser/
        session.py           - BrowserSession (one worker thread), check_page (block / logged out), fb_login
        pacer.py             - Pacer: delays >= 8 s, daily caps, stop for the day, cooldown gate
        fb_provider.py       - BrowserPageProvider: search_groups, read_group (in-page extraction)
        fb_actions.py        - join_group (answers approval), FacebookBrowserSender (exact text or nothing)
        runtime.py           - FacebookBrowser, open_facebook_browser (only after fb-login)
        fb_check.py          - check_group(): read-only group test (fb-check, /health)
        yad2_page.py         - Yad2BrowserFetcher: yad2 search page in a browser when HTTP is blocked
        browser.md           - Browser doc
    web/
        app.py               - create_app(): review, profile, shortlist, message, contacted, settings, groups, about-me, log, health, collect, ping, quit, facebook/login, checks
        guard.py             - LocalOriginGuard: Host + Origin checks on every request
        jobs.py              - BackgroundJob: one job per slot (Facebook; yad2 check), latest result per kind
        templates/*.html     - Jinja2 pages
        static/style.css     - Stylesheet
        web.md               - Web UI doc
```

## Documentation Files

### [updater.md](updater.md)

In-app code updates: the manifest channel, verified download + safe
extract, `current.json` (pending / good / bad, previous), the frozen
launcher's fallback (`packaging/update_loader.py`), the restart, and the
Known Task "Publish an update".
**Read when:** Touching versions, updates, the launcher, the PyInstaller
spec, or publishing a fix to installed apps.

### [profile/profile.md](profile/profile.md)

The `SearchProfile` model (every BRIEF §5 criterion), `LocationArea`,
`OwnerSettings` (`data/settings.json`: notification channels, SMTP account;
the ntfy topic in the `SecretStore`), and the atomic JSON load/save.
**Read when:** Reading or changing search criteria, or the profile file format.

### [secrets/secrets.md](secrets/secrets.md)

`SecretStore`: the SMTP password and ntfy topic URL encrypted with Fernet
(`data/secrets.enc`); the key in the OS keyring, else an owner-only key file
(the weaker mode `/settings` warns about); fails closed on a wrong key or a
corrupted file; plaintext migration. Also the key of the encrypted answer bank.
**Read when:** Storing a credential, touching encryption or the key, or a
"cannot be decrypted" error.

### [store/store.md](store/store.md)

The SQLite `Store`: tables, migrations, and the listings / decisions / events /
source-health (history, alert incidents) / duplicates API.
**Read when:** Persisting or querying anything, or adding a table/migration.

### [matching/matching.md](matching/matching.md)

Hard filters and ranking: `evaluate(listing, profile) -> MatchResult` with a
Reason per criterion (met / missed / unknown), `rank()` best-first.
**Read when:** Changing what counts as a match, the score, or the reasons shown.

### [net/net.md](net/net.md)

`ThrottledClient`: every source HTTP request goes through it (rate limit,
back-off, bot-page detection, raw-response dumping).
**Read when:** Making any HTTP request to a source, or tuning rate limits.

### [sources/sources.md](sources/sources.md)

The adapter interface and the yad2 adapter; how unknown response shapes fail
loudly; which parts are unverified against live yad2.
**Read when:** Adding or fixing a source adapter.

### [sources/facebook/facebook.md](sources/facebook/facebook.md)

Facebook groups source: snapshot models (untrusted, validated per post), the
`PageProvider` / `FixtureProvider`, the adapter (joined groups only,
discussion skipped, failed groups named, city-from-group rule), group stats
and discovery that only ever stores candidates.
**Read when:** Touching Facebook group reading, discovery, or group stats.

### [textparse/textparse.md](textparse/textparse.md)

Free-text post (Hebrew/English) → listing fields, each with its evidence
snippet; negation wins; uncertain or conflicting → unknown.
**Read when:** Parsing free-text listings (Facebook posts) or changing what a
keyword / number in a post is read as.

### [answers/answers.md](answers/answers.md)

The owner's answer bank (`data/about_me.json`: facts with sensitive flags,
remembered answers) and `draft_answers()` — entry-question answers drafted
only from the bank; unknown, ambiguous or sensitive → needs your input.
**Read when:** Changing how group entry answers are drafted or what counts
as sensitive.

### [quality/quality.md](quality/quality.md)

Cross-source deduplication: the fingerprint, the exact duplicate rule
(conflicts veto; a phone alone never merges), the runner after each
collection (canonical = earliest seen, no chains), one review card per
cluster. Scam and stale flags computed at read time (payment before
viewing, off-platform payment, too-good price vs. the area median, stale),
each with reason + evidence; the payment-details guard for drafts.
**Read when:** Changing what counts as the same apartment, how duplicates
show in the queue, or what is flagged as a scam / stale.

### [collector/collector.md](collector/collector.md)

`run_collection` (one failing adapter never stops the others), the
scheduler, and source health alerts (`blocked`, `consecutive_errors`,
`zero_unexpected`; one incident per source until an `ok` run).
**Read when:** Changing how/when collection runs or how health is recorded.

### [messaging/messaging.md](messaging/messaging.md)

Interested-message drafts in the listing's language, the template syntax,
the message life cycle, the approval gate, the assisted senders and their
registry, and `dispatch()` — the one place a sender is called.
**Read when:** Changing message text, templates, language detection, or
anything on the path from approval to sending.

### [notify/notify.md](notify/notify.md)

New-match notifications after each collection: dashboard badge always, ntfy
push and email (SMTP, TLS only) opt-in; notify once (`notified` table); stale listings never notify;
source-alert incidents announced once; failures recorded on `/health`
as `notify:<channel>`, never raised into collection.
**Read when:** Changing what notifies, the ntfy message, or adding a channel.

### [browser/browser.md](browser/browser.md)

The Facebook browser session: manual `fb-login`, the `Pacer` (delays, daily
caps, stop for the day), the read-only `BrowserPageProvider`, `join_group`
and the opt-in `FacebookBrowserSender`. Real Facebook DOM unverified
(`fb-check`). Also yad2's browser fallback (`Yad2BrowserFetcher`, own
profile and pacer).
**Read when:** Touching anything that drives a browser (Facebook or yad2).

### [web/web.md](web/web.md)

The local web UI: routes, the review page (ranking at read time, `shown`
events), profile form validation, un-save as a `skip`, the error banner,
write-only secret fields on `/settings` and `/about-me`.
**Read when:** Changing any page, form or route.

## Shared modules

### `models.py`

`Listing` is what every source adapter returns. Optional fields mean "the
source did not say"; `attributes: dict[Attribute, bool]` with an absent key
means unknown. `Listing.id` is `"<source>:<source_id>"`. `raw` keeps the
source payload. `price` is ILS/month. `photos` holds EVERY photo of the
listing (yad2 `coverImage` + `metaData.images`, Facebook all post images);
`video_count` / `video_posters` (default 0 / empty, so listings stored
before v1.2.2 load unchanged — JSON column, no migration) describe a
Facebook post's videos, which play only on Facebook.

`text.clean_group_name(name)` drops an image-label prefix ("Profile photo
of …", "Cover photo of …", "תמונת הפרופיל של …") from a scraped Facebook
group name; used at extraction, storage and display.

### `text.py`

`normalize_place(s)` strips, casefolds, removes Hebrew niqqud and
quote/geresh/gershayim marks, turns hyphens (incl. maqaf) into spaces and
collapses whitespace. `canonical_city(s)` maps known aliases (Tel Aviv /
תל אביב / Tel Aviv-Yafo / תל אביב יפו / ת"א; Jerusalem / ירושלים; Haifa /
חיפה; Ramat Gan / רמת גן; Givatayim / גבעתיים) to a canonical English key and
returns `normalize_place(s)` for anything else. Matching and the yad2 city map
must use these — never a private copy.

`safe_url(value)` returns the stripped value only for an absolute
`http`/`https` URL with a host, else `""`. It is the one check for
listing-derived URLs: the web `safe_url` filter and every sender use it.

### `config.py`

`settings_path()` / `templates_path()` / `about_me_path()` are
`settings.json` / `templates.json` / `about_me.json` (encrypted) in the data
dir; `secrets.enc` and, in the weaker mode, `secret.key` sit beside them
(`secrets/`). Paths are recomputed on every call from `HOUSE_FINDER_DATA`, so tests can
redirect them with an env var. Without it, the installed (frozen,
`sys.frozen`) app uses `%LOCALAPPDATA%\HouseFinder\data` — never its install
folder or the working directory; unfrozen it is `./data`. `log_path()` is
`<data>/logs/house-finder.log` (the `app` command's rotating log). `debug_dir()` (`<data>/debug`) receives the
raw responses of `collect --dump`. `browser_profile_dir()`
(`<data>/browser-profile`) is the Facebook Chromium profile and
`pacer_state_path()` (`<data>/browser-pacer.json`) the pacer's daily counts;
`yad2_browser_profile_dir()` (`<data>/browser-yad2`) and
`yad2_pacer_state_path()` (`<data>/browser-yad2-pacer.json`) are the yad2
fallback's own profile and pacer, never shared with Facebook.

### `__main__.py`

| Command | Does |
|---|---|
| `init` | creates the data dir; copies `profile/example_profile.json` to `profile.json` unless one exists |
| `serve [--port 8765] [--no-scheduler] [--interval 30] [--fb-headless] [--browser-headless]` | `facebook_browser(store)` and `yad2_browser_fetcher(store)` (`--fb-headless` hides Facebook's window, `--browser-headless` both; a hidden yad2 window cannot show a captcha, so it counts as blocked); `Scheduler.for_collection(store, <adapter factory>, after=notify.make_after_collection(...))` (unless `--no-scheduler`) — the adapter list is rebuilt every run over one shared client; uvicorn on `127.0.0.1`; passes the web app its runners (`facebook_connector` when playwright is installed, `yad2_checker` over the same client and yad2 fetcher), `updater.service()` (its background check started; None in a source checkout), `app.state.shutdown` (sets `server.should_exit`: the Quit button) and `app.state.restart` (`restart_app`, after **Update now**); the adapter factory reads `app.state.facebook`, so a browser connected in the app is read from the next run; closes the browsers on exit |
| `app [--port 8765] [--interval 30] [--no-browser] [--no-scheduler] [--wait-free]` | the owner's entry point (shortcut / installed exe via `run_app()`). `safe_streams()` (pythonw / a windowed exe have `sys.stdout` = None), `setup_logging()` → `<data>/logs/house-finder.log` (rotating 1 MB × 3, plus stderr with a console). `app_running(url)` GETs `/ping` (no proxy): ours → open the default browser there and exit 0 (no second server); another program on the port → log it, exit 1; nothing → `init_data()`, a thread that opens the browser once `/ping` answers (≤ 90 s), and `serve(windowless=True)` (uvicorn with `log_config=None`, so its loggers go to the file). `--no-browser` / `HOUSE_FINDER_NO_BROWSER=1`: never open a browser (CI). `--wait-free`: first wait ≤ 60 s until the old server stops answering (the restart after an update). Logs the running code version; with updates on, marks a pending update good once `/ping` answers |
| `collect [--source X] [--dump]` | `secrets.migrate_plaintext` (logged), then one `notify.collect_and_notify` now (collection, then new-match notifications); prints one line per source (`cooldown` for a paused one); exit 1 if any source errored, 2 for an unknown `--source` |
| `check-yad2 [--headless] [--captcha-wait 120]` | one plain-HTTP request for the first profile city (example profile if none), then the browser fallback in a visible window; writes `<data>/debug/yad2-report.txt` (`sources/yad2_report.run_check`: status codes, redacted URLs, JSON keys/types, listing count, first 3 price/rooms/city). Always exit 0. The app's **Check yad2** button runs the same check (`run_yad2_check`) |
| `fb-login [--timeout 600]` | headed browser on facebook.com; waits while the owner logs in by hand (`browser.fb_login`); writes the login marker. 2 without the `[facebook]` extra |
| `fb-check [--group ID] [--posts 5]` | dry run (`browser.fb_check.check_group`, also the app's **Test reading this group**): reads ONE group (first joined, or `--group`) through the browser provider and prints group head, each post (id, author, time, link, parsed price/rooms/city, text start) and today's pacer counts. Stores nothing, sends nothing. 2 when not logged in / no group; 1 on a failure (a block also starts the `facebook` cooldown) |

`build_adapters(*, dump_dir=None, store=None, client=None, fb_provider=None, yad2_browser=None)`
builds every adapter over one shared `ThrottledClient` (10 s interval for
`gw.yad2.co.il`); later plans add sources there. Facebook is added only
when a page provider exists (`fb_provider`, else `facebook_provider()`)
and `store` has a `joined` group.

## Optimizations and Features

- `text.py` builds the alias lookup by passing every alias through
  `normalize_place()`, so aliases can be written naturally (with hyphens,
  quotes) and still match.
- `normalize_place` removes quote marks rather than replacing them with a
  space: they sit inside Hebrew abbreviations (`ת"א` → `תא`). Hyphens become a
  space (`tel aviv-yafo` → `tel aviv yafo`).
- `config` paths are not cached — required for test isolation via the env var.
- `app` never starts a second server: it probes `/ping` first and only
  opens the browser when its own server already answers; the console-less
  path swaps `None` streams for `os.devnull` and drops uvicorn's console
  logging config, so nothing writes to a missing stream.
- `__main__` imports heavy modules (uvicorn, FastAPI, httpx) inside each
  command, so `house-finder init` / `--help` start fast.
- One `ThrottledClient` is shared by all adapters — also across `serve`'s
  per-run rebuilds — so its lock and last-request times keep the scheduler
  and an on-demand run from doubling the request rate.

## Known Tasks

### Run the app

```bash
house-finder init
house-finder serve            # http://127.0.0.1:8765
house-finder app              # the owner's way: open it (start it windowless if needed)
```

### Run the tests

```bash
python -m pytest -q
```

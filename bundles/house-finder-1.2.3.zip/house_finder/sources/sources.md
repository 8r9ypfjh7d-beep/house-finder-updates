# sources — source adapters

One adapter per site, all behind one interface. An adapter turns a site into
`Listing` objects or raises — **never an empty list for a response it did not
understand** (VISION priority 3). All HTTP goes through `net.ThrottledClient`.

## Code Files

- `base.py` — `SourceAdapter` protocol, `SourceError` (with `partial`), `SourceBlocked`
- `yad2.py` — `Yad2Adapter`, the shape parsers (`detect_shape`, `parse_response`, `parse_marker`, `parse_feed_item`, `find_payloads`), `search_params`, `BrowserFallbackUnavailable`, and field helpers (`parse_price`, `parse_floor`, `parse_entry_date`, `tags_to_attributes`, …)
- `yad2_report.py` — `check-yad2`: `run_check()` (HTTP then browser for one city → `data/debug/yad2-report.txt`), `json_shape()` (keys/types only), `redact_url()`
- `yad2_cities.py` — `YAD2_CITY_CODES`, `yad2_city_code(name)`
- `__init__.py` — re-exports `SourceAdapter`, `SourceError`, `SourceBlocked`, `Yad2Adapter`
- `facebook/` — Facebook groups source: snapshots, `PageProvider` + `FixtureProvider`, `FacebookGroupsAdapter`, group stats + discovery ([facebook/facebook.md](facebook/facebook.md))

## Interface (`base.py`)

```python
class SourceAdapter(Protocol):
    name: str                                   # Listing.source and health key
    def fetch(self, profile) -> list[Listing]   # or raise SourceError / SourceBlocked
```

- `SourceError(message, *, partial=None)` — the source failed. `partial`
  holds listings parsed before the failure; the collector stores them and
  still reports the run as `error`.
- `SourceBlocked(SourceError)` — captcha/bot page, 403, or persistent 429.
- Optional `warnings: list[str]`, reset on each `fetch` — non-fatal notes
  (skipped area, skipped items) the collector appends to the health message.

## yad2 (`yad2.py`)

`Yad2Adapter(client, *, max_pages=3, endpoint="map", now=None, browser_fetcher=None)`, `name = "yad2"`.

- One query per profile city; the code comes from
  `LocationArea.yad2_city_code`, else `yad2_city_code(area.city)`. An area
  with no code is skipped and named in `warnings`; if **no** area has a code,
  or the profile has no locations, `fetch` raises `SourceError`. Areas with
  the same code share one query.
- Query parameters: price and rooms ranges from the profile.
  `endpoint="map"` → `GET https://gw.yad2.co.il/realestate-feed/rent/map`
  with `city`, `minPrice`, `maxPrice`, `minRooms`, `maxRooms` (`page` from 2 on).
  `endpoint="legacy"` → `GET https://gw.yad2.co.il/feed-search-legacy/realestate/rent`
  with `city`, `price=min-max`, `rooms=min-max` (`-1` = open), `page`, `forceLdLoad=true`.
- Pages: continues while the response's `pagination.last_page` (or
  `lastPage` / `total_pages` / `totalPages`) says more exist, up to
  `max_pages`; a response without pagination info is one page.
- Parsing accepts either shape from either endpoint:

| Listing field | current `data.markers[]` | legacy `data.feed.feed_items[]` (`type == "ad"`) |
|---|---|---|
| `source_id` / url token | `token` | `link_token`, else `id` |
| `price` | `price` | `price` (`"5,500 ₪"` → 5500; no digits → None) |
| `city` / `neighborhood` / `street` | `address.{city,neighborhood,street}.text` | `city`, `neighborhood`, `street` |
| `floor` | `address.house.floor` | `Floor_text` (`קומה 2` → 2, `קרקע` → 0, `מרתף` → -1) |
| `lat` / `lon` | `address.coords.{lat,lon}` | `coordinates.{latitude,longitude}` |
| `rooms` (float) / `sqm` | `additionalDetails.{roomsCount,squareMeter}` | `Rooms_text` (else `rooms`), `square_meters` |
| `property_type` | `additionalDetails.property.text` | `HomeTypeID_text` |
| `is_agent` | `adType` `agency` → True, `private` → False | `merchant` |
| `photos` (all, deduplicated) | `metaData.coverImage` + `metaData.images[]` | `images` (list / dict of `{src}`), `images_urls` |
| `attributes` | `tags[]` | `tags[]` |
| `move_in_date` / `move_in_immediate` | — | `date_of_entry` (ISO or `DD/MM/YYYY`; `מיידי` → immediate) |
| `posted_at` | — | `date_added` (Israel local time) |
| `title` | "<property>, <street> <number>" | `title_1` |

  Every listing gets `url = https://www.yad2.co.il/realestate/item/<token>`,
  `language = "he"`, `contact.channel = yad2`, `raw = <the item>`.
- Unknown shape → `SourceError("unrecognized yad2 response shape: <top-level keys>")`.
  A known shape with zero items is a real empty result (`[]`). Items that
  fail to parse are skipped and counted in `warnings`; if **every** item
  fails, `SourceError`.
- A failure in a later city re-raises the same error type, prefixed with the
  city, carrying the earlier cities' listings in `partial`.

### Browser fallback

`browser_fetcher` (`browser.Yad2BrowserFetcher`, see
[browser.md](../browser/browser.md); wired by `build_adapters` whenever
playwright is installed — no login) is used **only after plain HTTP raised
`SourceBlocked`**, for that city and every later city of the run (HTTP is
not asked again after a block). A plain `SourceError` from HTTP (bad
status, unknown shape) never falls back. The fetcher loads the search page
(`SEARCH_URL?city=…&minPrice=…` = `search_params()`, page 1 only) and
returns the listings parsed from the JSON the page loaded.

| Browser outcome | Adapter raises |
|---|---|
| listings (or a known shape with zero items) | — (`warnings`: `"<city>: served by the browser (http blocked)"`) |
| captcha not solved / headless, flat 403 | `SourceBlocked` "<http block>; browser: …" |
| `BrowserFallbackUnavailable` (no Chromium, daily cap used up) | `SourceBlocked` "<http block>; browser fallback unavailable: …" |
| no JSON in a known shape | `SourceError` "http blocked (…); browser: … captured: <urls>" |

With a fetcher configured, an HTTP-served city adds `"<city>: served by
http"` to `warnings`. `find_payloads(value)` finds every known shape inside
a JSON body or `__NEXT_DATA__` — the shape itself, or its `data` part
(`{"markers": …}`) wrapped as `{"data": …}`.

### `check-yad2` report (`yad2_report.py`)

`run_check(profile, client=, fetcher=, out_path=)` — for the first profile
city with a code: one `client.get_json(MAP_URL)` (status chain and
content type from `client.last_response`), then `fetcher.fetch` (its
`last_capture`: page status, final URL, title, captcha seen/solved,
`__NEXT_DATA__` shape, every API response's URL and shape). Writes, per
path, the outcome, parsed listing count, and for the first 3 listings
only `price`, `rooms`, `city`. **Never a value from the JSON**:
`json_shape` keeps keys (7+ digit runs → `<digits>`) and type names;
`redact_url` keeps only search-filter query values (`city`, `minPrice`, …)
and replaces the rest (perfdrive `ss*` tokens) with `…`. Never raises for a
site failure.

### Region (map endpoint)

yad2's map API refuses a query without `region` (HTTP 400 "region is
required"; the API's JSON `message` is shown in the `SourceError`).
`region_for(code)`: the verified table (`yad2_cities._REGIONS`: Tel Aviv
5000 → 3), else `region_cache` (`data/yad2_regions.json`, `{"<city>":
<region>, "misses": {"<city>": "<date>"}}`), else discovery: regions 1..8,
one request each, the first holding a listing whose `address.city.id` is
the city wins and is cached (written atomically, re-read first). No region
with a listing → the city is skipped with a warning (a real empty result,
not an error) and not retried for `REGION_MISS_DAYS` (1). An unrecognized
response during discovery raises like any other.

The map response's rentals are `markers` (private) plus `agencyPromotions`
(adType `commercial` → `is_agent`); `yad1Markers` (new-build projects),
`grayMarkers` (public buildings) and `clusters` are ignored. Parking spots
(`חניה`) are `PropertyType.other`.

**Verified live 2026-10-20** (GitHub Ubuntu runner, the app's own
`ThrottledClient`): the map endpoint returned 298 Tel Aviv listings for the
example profile, `minRooms`/`maxRooms`/`maxPrice` honoured; Ramat Gan's
region was discovered (3) and cached. `tests/fixtures/yad2/map_rent_live_shape.json`
is that real structure with made-up values; the older fixtures are
constructed. The legacy endpoint and the search page get the Radware
captcha from datacenter IPs (Windows runners: a flat 403), hence the
browser fallback and `check-yad2.bat`.

## Facebook groups (`facebook/`)

`FacebookGroupsAdapter`, `name = "facebook"`: reads the owner's `joined`
groups through a `PageProvider` (structured `GroupSnapshot`s — never HTML)
and parses each post with `textparse`; discussion posts are skipped. Failed
groups are named in `warnings`; all failed or none joined → `SourceError`.
Registered by `build_adapters` only when a provider exists and a group is
joined. Details: [facebook/facebook.md](facebook/facebook.md).

## yad2 city codes (`yad2_cities.py`)

yad2 uses Israeli CBS locality codes. Certain: Tel Aviv 5000, Jerusalem
3000, Haifa 4000, Ramat Gan 8600, Givatayim 6300. The others in the map are
marked `# verify`. Keys are `normalize_place()` forms of Hebrew and English
spellings; a name not found directly is retried through `canonical_city()`,
so every alias in `text.py` (e.g. `ת"א`, `Givataim`) works. A profile's
`yad2_city_code` always wins.

## Optimizations and Features

- `yad2.py` imports `ThrottledClient` only under `TYPE_CHECKING`: `net`
  imports the errors from `sources.base`, so a runtime import would be a
  cycle through `sources/__init__.py`.
- Unrecognised property labels map to `None` (unknown), never a guess, so
  matching reports them as unknown instead of failing a property-type filter.
- Tag parsing understands negation (`ללא חניה` → parking False) and both
  Hebrew genders (`משופץ` / `משופצת`).
- `parse_price` returns None for 0 or a no-digit text ("לא צוין מחיר") — a
  missing price is unknown, not free.
- Listings are deduplicated by id across pages and cities (first one wins).
- A city's region is discovered once and cached; a city with no listings
  anywhere is remembered for a day, so it does not cost 8 requests (~96 s at
  the 12 s yad2 spacing) on every run.
- After one `SourceBlocked` the rest of the run goes to the browser
  directly: a blocked HTTP path is not hit once per city.
- `find_payloads` stops descending at a match and looks at most 200 list
  items per level, 8 levels deep — a large `__NEXT_DATA__` stays cheap.
- Israel time for `date_added` uses `zoneinfo`; on Windows without the
  `tzdata` package it falls back to a fixed UTC+2 (≤1 h off in summer,
  harmless for listing age).

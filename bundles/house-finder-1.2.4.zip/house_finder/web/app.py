"""The local web UI: FastAPI + Jinja2 server-rendered pages.

``create_app(store, profile_path, adapters, scheduler=None)`` builds the app.
Pages: ``/home`` (the landing page: checklist, counts, last collections),
``/`` review (one listing at a time), ``/profile``, ``/shortlist``,
``/log``, ``/health``, ``/listing/<id>/message`` (draft + approve),
``/contacted``; ``POST /collect`` runs a collection on demand. An approved
message shows the assisted send screen (open link + copy text) and
"I sent it" / "It failed" (``POST /message/<id>/sent`` / ``/failed``).
``LocalOriginGuard`` wraps every route: foreign ``Host`` -> 403, and a
state-changing request from a foreign (or missing) origin -> 403.
Matching runs here, at read time: the review queue is
``rank_clusters(store.undecided_listings(), duplicates, profile)`` — one
entry per duplicate cluster — so a profile edit re-ranks at once. The server that hosts the app binds 127.0.0.1 only (``__main__.py``).
"""

from __future__ import annotations

import sqlite3
import threading
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from typing import get_args
from datetime import date, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any
from urllib.parse import quote

from fastapi import FastAPI, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, Response
import mimetypes

from fastapi.staticfiles import StaticFiles

from house_finder.version import APP_VERSION

# Windows takes these from the registry, where .js is often "text/plain" —
# a browser then refuses to run the script. Pin them.
mimetypes.add_type("text/javascript", ".js")
mimetypes.add_type("text/css", ".css")


class FreshStaticFiles(StaticFiles):
    """The app's CSS/JS: the browser must ask again every time (``no-cache``;
    an unchanged file is a cheap 304), so an in-app update is never shown
    with the previous version's stylesheet (owner, v1.2.2: the photo gallery
    showed every photo stacked until a hard reload)."""

    def file_response(self, *args, **kwargs):
        response = super().file_response(*args, **kwargs)
        response.headers["Cache-Control"] = "no-cache"
        return response
from fastapi.templating import Jinja2Templates
from pydantic import ValidationError

from house_finder import config
from house_finder.answers import (
    SENSITIVE_KEYS,
    SUGGESTED_FACTS,
    AnswerBank,
    Fact,
    Remembered,
    draft_answers,
    load_bank,
    reveals_sensitive,
    save_bank,
    sensitive_topic,
)
from house_finder.matching import ReasonStatus, evaluate, rank
from house_finder.messaging import (
    DEFAULT_TEMPLATES,
    TemplateError,
    channel_for_listing,
    dispatch,
    draft_message,
    load_templates,
    pending_action,
    registry,
    save_templates,
    validate_template,
)
from house_finder.collector.collector import AdapterSource, resolve_adapters
from house_finder.collector.health import HISTORY_LIMIT, KIND_LABELS
from house_finder.notify import clear_stale_notify_health, collect_and_notify
from house_finder.quality import AreaStats, flags_for, payment_details_problem, rank_clusters, stale_flag
from house_finder.models import Attribute, PropertyType
from house_finder.text import SAFE_URL_SCHEMES, safe_url  # noqa: F401  (re-exported)
from house_finder.profile import (
    LocationArea,
    OwnerSettings,
    SearchProfile,
    load_profile,
    load_settings,
    save_profile,
    save_settings,
)
from house_finder.profile.settings import DEFAULT_SMTP_PORT, SendMode, SmtpSecurity, secrets_for
from house_finder.secrets import NTFY_TOPIC, SMTP_PASSWORD, SecretStore, SecretStoreError
from house_finder.secrets.migrate import migrate_plaintext
from house_finder.sources.base import SourceBlocked, SourceError
from house_finder.sources.facebook.groups import DiscoveryFailed, DiscoveryReport, summarize_issues
from house_finder.updater import RELEASES_URL
from house_finder.version import APP_VERSION
from house_finder.store import (
    DECISION_ACTIONS,
    AnswerItem,
    AnswersStateError,
    MessageStateError,
    StaleApprovalError,
    answers_sha256,
    text_sha256,
)
from house_finder.web.guard import LocalOriginGuard, local_hosts
from house_finder.web.icons import icon
from house_finder.web.jobs import BackgroundJob

if TYPE_CHECKING:
    from house_finder.browser import FacebookBrowser
    from house_finder.collector.scheduler import Scheduler
    from house_finder.sources.facebook import PageProvider
    from house_finder.store import Store

WEB_DIR = Path(__file__).parent
DEFAULT_PORT = 8765  # same as __main__.DEFAULT_PORT; serve passes its --port
UNSAVE_REASON = "unsaved"
EXTRA_LOCATION_ROWS = 2

STATUS_SYMBOL = {ReasonStatus.met: "✓", ReasonStatus.missed: "✗", ReasonStatus.unknown: "?"}
# Review chips: what blocks a listing first, then what is unknown, then what is met.
REASON_ORDER = {ReasonStatus.missed: 0, ReasonStatus.unknown: 1, ReasonStatus.met: 2}

# --------------------------------------------------------------- formatting


def _fmt_num(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float):
        return f"{value:g}"
    return str(value)


def _fmt_price(value: int | None) -> str:
    return "price not stated" if value is None else f"₪{value:,}"


def _fmt_when(value: str | datetime | date | None) -> str:
    """Local-time ``YYYY-MM-DD HH:MM`` for an ISO string or datetime."""
    if value is None or value == "":
        return "—"
    if isinstance(value, str):
        try:
            value = datetime.fromisoformat(value)
        except ValueError:
            return value
    if isinstance(value, datetime):
        if value.tzinfo is not None:
            value = value.astimezone()
        return value.strftime("%Y-%m-%d %H:%M")
    return value.isoformat()


def _classify_ratio(ratio: float | None) -> str:
    from house_finder.sources.facebook import classify

    return classify(ratio)


def _label(value: Any) -> str:
    raw = getattr(value, "value", value)
    return str(raw).replace("_", " ")


class DraftRefused(Exception):
    """A draft that looks like it carries payment details is never stored
    (VISION: the tool never sends payment details); the message is why."""


def normalize_message_text(text: str) -> str:
    """Form text as stored: CRLF -> LF (browsers submit CRLF), trimmed."""
    return text.replace("\r\n", "\n").replace("\r", "\n").strip()


def message_url(listing_id: str) -> str:
    """The message page of a listing (the id is percent-encoded)."""
    return f"/listing/{quote(listing_id, safe=':')}/message"


# ------------------------------------------------------------- profile form

_INT_FIELDS = (
    "price_min", "price_max", "sqm_min", "sqm_max",
    "lease_min_months", "lease_max_months", "max_listing_age_days",
)
_FLOAT_FIELDS = ("rooms_min", "rooms_max")
_DATE_FIELDS = ("move_in_earliest", "move_in_latest")
_SET_FIELDS = ("property_types", "must_haves", "nice_to_haves")
_BOOL_FIELDS = ("exclude_agents", "exclude_ground_floor")
_RANGES = (
    ("price_min", "price_max", "Price"),
    ("rooms_min", "rooms_max", "Rooms"),
    ("sqm_min", "sqm_max", "Size (sqm)"),
    ("lease_min_months", "lease_max_months", "Lease length"),
    ("move_in_earliest", "move_in_latest", "Move-in window"),
)
_LOC_KEYS = ("city", "neighborhoods", "radius_km", "lat", "lon", "yad2_city_code")


def profile_to_form(profile: SearchProfile) -> dict[str, Any]:
    """The profile as the string/set values the form template renders."""
    form: dict[str, Any] = {}
    for name in _INT_FIELDS + _FLOAT_FIELDS:
        form[name] = _fmt_num(getattr(profile, name))
    for name in _DATE_FIELDS:
        value = getattr(profile, name)
        form[name] = value.isoformat() if value else ""
    for name in _SET_FIELDS:
        form[name] = {v.value for v in getattr(profile, name)}
    for name in _BOOL_FIELDS:
        form[name] = getattr(profile, name)
    form["exclusion_keywords"] = "\n".join(profile.exclusion_keywords)
    form["locations"] = [
        {
            "city": a.city,
            "neighborhoods": ", ".join(a.neighborhoods),
            "radius_km": _fmt_num(a.radius_km),
            "lat": _fmt_num(a.lat),
            "lon": _fmt_num(a.lon),
            "yad2_city_code": _fmt_num(a.yad2_city_code),
        }
        for a in profile.locations
    ]
    return form


def form_from_request(data: Any) -> dict[str, Any]:
    """Normalise a submitted multi-dict into the shape ``profile_to_form`` returns."""
    form: dict[str, Any] = {}
    for name in _INT_FIELDS + _FLOAT_FIELDS + _DATE_FIELDS:
        form[name] = str(data.get(name, "")).strip()
    for name in _SET_FIELDS:
        form[name] = {str(v) for v in data.getlist(name)}
    for name in _BOOL_FIELDS:
        form[name] = name in data
    form["exclusion_keywords"] = str(data.get("exclusion_keywords", ""))
    try:
        count = int(data.get("loc_count", 0))
    except ValueError:
        count = 0
    form["locations"] = [
        {key: str(data.get(f"loc_{key}_{i}", "")).strip() for key in _LOC_KEYS}
        for i in range(max(0, min(count, 200)))
    ]
    return form


def parse_profile_form(form: Mapping[str, Any]) -> tuple[SearchProfile | None, list[str]]:
    """Build a ``SearchProfile`` from form values, or return the errors.

    Rejects non-numbers, bad dates, reversed ranges (min > max, earliest >
    latest) and anything ``SearchProfile`` itself rejects. A location row
    with a blank city is ignored.
    """
    errors: list[str] = []
    values: dict[str, Any] = {}

    def num(name: str, text: str, kind: type) -> Any:
        if text == "":
            return None
        try:
            return kind(text)
        except ValueError:
            errors.append(f"{_label(name).capitalize()}: '{text}' is not a {'whole ' if kind is int else ''}number.")
            return None

    for name in _INT_FIELDS:
        values[name] = num(name, form.get(name, ""), int)
    for name in _FLOAT_FIELDS:
        values[name] = num(name, form.get(name, ""), float)
    if values["max_listing_age_days"] is None:
        values.pop("max_listing_age_days")
    for name in _DATE_FIELDS:
        text = form.get(name, "")
        if text == "":
            values[name] = None
            continue
        try:
            values[name] = date.fromisoformat(text)
        except ValueError:
            errors.append(f"{_label(name).capitalize()}: '{text}' is not a date (YYYY-MM-DD).")
            values[name] = None
    for lo, hi, label in _RANGES:
        a, b = values.get(lo), values.get(hi)
        if a is not None and b is not None and a > b:
            errors.append(f"{label}: the minimum ({form.get(lo)}) is greater than the maximum ({form.get(hi)}).")
    for name in _SET_FIELDS:
        values[name] = sorted(form.get(name) or ())
    for name in _BOOL_FIELDS:
        values[name] = bool(form.get(name))
    values["exclusion_keywords"] = [
        line.strip() for line in str(form.get("exclusion_keywords", "")).splitlines() if line.strip()
    ]

    locations: list[LocationArea] = []
    for i, row in enumerate(form.get("locations") or [], start=1):
        city = row.get("city", "").strip()
        if not city:
            continue
        loc: dict[str, Any] = {
            "city": city,
            "neighborhoods": [n.strip() for n in row.get("neighborhoods", "").split(",") if n.strip()],
        }
        bad = False
        for key, kind in (("radius_km", float), ("lat", float), ("lon", float), ("yad2_city_code", int)):
            text = row.get(key, "").strip()
            if text == "":
                loc[key] = None
                continue
            try:
                loc[key] = kind(text)
            except ValueError:
                errors.append(f"Location {i} ({city}): {_label(key)} '{text}' is not a number.")
                bad = True
        if bad:
            continue
        try:
            locations.append(LocationArea(**loc))
        except ValidationError as exc:
            errors.extend(f"Location {i} ({city}): {e['msg']}" for e in exc.errors())
    values["locations"] = locations

    if errors:
        return None, errors
    try:
        return SearchProfile(**values), []
    except ValidationError as exc:
        return None, [
            f"{_label(e['loc'][0]).capitalize() if e['loc'] else 'Profile'}: {e['msg']}" for e in exc.errors()
        ]


# ------------------------------------------------------------ settings form

SEND_MODES: tuple[str, ...] = get_args(SendMode)  # "assisted", "browser" (Facebook and yad2)
FACEBOOK_SOURCE = "facebook"
YAD2_SOURCE = "yad2"


def send_channels() -> list[str]:
    """Channels that have a sender registered (the send-mode rows)."""
    return sorted({channel for channel, _ in registry.keys()})


def send_modes_for(channel: str) -> list[str]:
    """The modes a sender is registered for on ``channel``, ``assisted`` first.
    ``browser`` appears for Facebook once ``fb-login`` was done and for yad2
    once yad2 was connected (the browser sender is registered then)."""
    modes = {mode for ch, mode in registry.keys() if ch == channel} | {"assisted"}
    return sorted(modes, key=lambda m: (m != "assisted", m))


SMTP_SECURITY: tuple[str, ...] = get_args(SmtpSecurity)  # no plain-SMTP option exists


def settings_to_form(settings: OwnerSettings, templates: Mapping[str, str], *,
                     topic_set: bool = False, password_set: bool = False) -> dict[str, Any]:
    """Owner settings + templates as the values the settings form renders.
    Secrets (ntfy topic URL, SMTP password) are write-only: the form only
    says whether one is stored (``*_set``), never its value."""
    return {
        "owner_name": settings.owner_name,
        "ntfy_on": "ntfy" in settings.notify_channels,
        "ntfy_topic": "",
        "ntfy_topic_set": topic_set,
        "ntfy_topic_clear": False,
        "email_on": "email" in settings.notify_channels,
        "smtp_host": settings.smtp_host,
        "smtp_port": str(settings.smtp_port),
        "smtp_security": settings.smtp_security,
        "smtp_username": settings.smtp_username,
        "smtp_password": "",
        "smtp_password_set": password_set,
        "smtp_password_clear": False,
        "email_from": settings.email_from,
        "email_to": settings.email_to,
        "templates": {lang: templates.get(lang, DEFAULT_TEMPLATES[lang]) for lang in DEFAULT_TEMPLATES},
        "send_modes": {ch: settings.send_mode(ch) for ch in send_channels()},
    }


def settings_form_from_request(data: Any) -> dict[str, Any]:
    """Normalise a submitted settings form into the ``settings_to_form`` shape
    (``*_set`` is filled in by the route from the secret store)."""
    return {
        "owner_name": str(data.get("owner_name", "")).strip(),
        "ntfy_on": "notify_ntfy" in data,
        "ntfy_topic": str(data.get("ntfy_topic", "")).strip(),
        "ntfy_topic_set": False,
        "ntfy_topic_clear": "ntfy_topic_clear" in data,
        "email_on": "notify_email" in data,
        "smtp_host": str(data.get("smtp_host", "")).strip(),
        "smtp_port": str(data.get("smtp_port", "")).strip() or str(DEFAULT_SMTP_PORT),
        "smtp_security": str(data.get("smtp_security", "starttls")),
        "smtp_username": str(data.get("smtp_username", "")).strip(),
        "smtp_password": str(data.get("smtp_password", "")),
        "smtp_password_set": False,
        "smtp_password_clear": "smtp_password_clear" in data,
        "email_from": str(data.get("email_from", "")).strip(),
        "email_to": str(data.get("email_to", "")).strip(),
        "templates": {lang: normalize_message_text(str(data.get(f"template_{lang}", "")))
                      for lang in DEFAULT_TEMPLATES},
        "send_modes": {ch: str(data.get(f"send_mode_{ch}", "assisted")) for ch in send_channels()},
    }


def parse_settings_form(
    form: Mapping[str, Any], *, current_topic: str | None = None, password_set: bool = False,
) -> tuple[OwnerSettings | None, dict[str, str] | None, list[str]]:
    """``(settings, owner templates, [])`` or ``(None, None, errors)``.

    Rejects a non-https / malformed ntfy URL, ntfy on without a URL, email on
    without server / addresses (or without a password when a user name is
    set), a send mode other than ``assisted`` and a template that would not
    render. Write-only secrets: an empty box keeps ``current_topic`` /
    the stored password; "clear" removes it. The returned templates are only
    the languages that differ from the defaults.
    """
    errors: list[str] = []
    for channel, mode in form["send_modes"].items():
        allowed = send_modes_for(channel)
        if mode not in allowed:
            hint = (" (browser sending needs Facebook connected: press Connect Facebook; "
                    "developers: `house-finder fb-login`)" if channel == FACEBOOK_SOURCE
                    else " (automatic sending needs yad2 connected: press Connect yad2 above)"
                    if channel == YAD2_SOURCE else "")
            errors.append(f"Send mode for {channel}: only {', '.join(allowed)} is available{hint}.")
    templates: dict[str, str] = {}
    for lang, text in form["templates"].items():
        if not text:
            continue  # empty box = the default template
        try:
            validate_template(text, lang)
        except TemplateError as exc:
            errors.append(f"Template ({lang}): {exc}")
            continue
        if text != DEFAULT_TEMPLATES[lang]:
            templates[lang] = text
    if form["ntfy_topic"] and form["ntfy_topic_clear"]:
        errors.append("ntfy topic URL: type a new one or tick “clear”, not both.")
    if form["smtp_password"] and form["smtp_password_clear"]:
        errors.append("SMTP password: type a new one or tick “clear”, not both.")
    topic = None if form["ntfy_topic_clear"] else (form["ntfy_topic"] or current_topic)
    has_password = bool(form["smtp_password"]) or (password_set and not form["smtp_password_clear"])
    try:
        port = int(form["smtp_port"])
    except ValueError:
        errors.append("SMTP port must be a number.")
        port = DEFAULT_SMTP_PORT
    if form["smtp_security"] not in SMTP_SECURITY:
        errors.append("SMTP encryption must be STARTTLS or SSL/TLS — plain SMTP is not allowed.")
    if form["email_on"] and form["smtp_username"] and not has_password:
        errors.append("Email is on with an SMTP user name but no password is stored — type it.")
    channels = (["dashboard"] + (["ntfy"] if form["ntfy_on"] else [])
                + (["email"] if form["email_on"] else []))
    settings = None
    try:
        settings = OwnerSettings(
            owner_name=form["owner_name"],
            notify_channels=channels,  # type: ignore[arg-type]
            ntfy_topic=topic,
            smtp_host=form["smtp_host"],
            smtp_port=port,
            smtp_security=form["smtp_security"] if form["smtp_security"] in SMTP_SECURITY else "starttls",
            smtp_username=form["smtp_username"],
            email_from=form["email_from"],
            email_to=form["email_to"],
            send_mode_per_channel={ch: m for ch, m in form["send_modes"].items() if m in SEND_MODES},
        )
    except ValidationError as exc:
        errors.extend(str(e["msg"]).removeprefix("Value error, ") for e in exc.errors())
    if errors or settings is None:
        return None, None, errors
    return settings, templates, []


# ------------------------------------------------------- about-me form

EXTRA_FACT_ROWS = 2
FACEBOOK_READ_HINT = ("Facebook listings appear from the groups House Finder reads: public groups you "
                      "approve are read right away; private groups after you join them — press Join. "
                      "Groups you are already in: press “Find groups I’m already in”, then “Use this group”.")

NO_PROVIDER_MESSAGE = (
    "No Facebook page provider is configured, so groups cannot be searched. "
    "Group search needs the logged-in browser session: press Connect Facebook "
    "(developers: `house-finder fb-login`, then restart the app; "
    "or put snapshot fixtures in <data>/fb_fixtures/)."
)
NO_BROWSER_MESSAGE = (
    "Joining needs the logged-in browser session: press Connect Facebook "
    "(developers: `house-finder fb-login`, then restart the app)."
)
NO_CONNECT_MESSAGE = (
    "Connecting Facebook needs the browser part of the app (the [facebook] extra with its Chromium), "
    "which is not installed."
)
NO_YAD2_CHECK_MESSAGE = "The yad2 check is not available in this app instance."
NO_YAD2_CONNECT_MESSAGE = (
    "Connecting yad2 needs the browser part of the app (the [facebook] extra with its Chromium), "
    "which is not installed."
)
APP_MARKER = {"app": "house-finder"}  # GET /ping: `house-finder app` knows the server is ours

# Runner types (injected by ``serve``; tests pass fakes — never a real browser).
FacebookConnect = Callable[[Callable[[str], None], Any], tuple[Any, bool]]
Yad2Check = Callable[[Callable[[str], None]], str]
Yad2Connect = Callable[[Callable[[str], None], Callable[[], bool]], Any]  # -> "cookie" | "owner" | None
GroupCheck = Callable[[Callable[[str], None], Any, str], str]


@dataclass
class FacebookLink:
    """The app's current Facebook browser and group provider. "Connect
    Facebook" replaces them after an in-app login (``app.state.facebook``;
    ``serve``'s adapter factory reads it on every collection run)."""

    browser: Any = None
    provider: Any = None


def default_group_check(progress: Callable[[str], None], browser: Any, group_id: str) -> str:
    """"Test a Facebook group" with the app's own browser (``fb-check``)."""
    from house_finder.browser.fb_check import check_group

    return "\n".join(check_group(browser, group_id, out=progress))


def bank_to_form(bank: AnswerBank) -> dict[str, Any]:
    """The bank as form rows: existing facts, then the suggested keys the
    bank lacks (blank), then blank rows; remembered answers. A sensitive fact
    is write-only: its row says "set" (``secret_set``) and never carries the
    value."""
    facts = [{"key": f.key, "label": f.label, "value": "" if f.is_sensitive else f.value,
              "sensitive": f.sensitive, "secret_set": f.is_sensitive and bool(f.value), "clear": False}
             for f in bank.facts]
    have = {f.key for f in bank.facts}
    facts += [{"key": k, "label": label, "value": "", "sensitive": False, "secret_set": False, "clear": False}
              for k, label in SUGGESTED_FACTS if k not in have]
    facts += [{"key": "", "label": "", "value": "", "sensitive": False, "secret_set": False, "clear": False}
              for _ in range(EXTRA_FACT_ROWS)]
    remembered = [{"question": r.question, "answer": r.answer, "delete": False} for r in bank.remembered]
    return {"facts": facts, "remembered": remembered}


def about_me_form_from_request(data: Any) -> dict[str, Any]:
    """Normalise the submitted /about-me multi-dict into ``bank_to_form``'s shape."""
    def count(name: str) -> int:
        try:
            return max(0, min(int(data.get(name, 0)), 500))
        except ValueError:
            return 0

    facts = [
        {"key": str(data.get(f"fact_key_{i}", "")).strip(),
         "label": str(data.get(f"fact_label_{i}", "")).strip(),
         "value": normalize_message_text(str(data.get(f"fact_value_{i}", ""))),
         "sensitive": f"fact_sensitive_{i}" in data,
         "secret_set": f"fact_set_{i}" in data,
         "clear": f"fact_clear_{i}" in data}
        for i in range(count("fact_count"))
    ]
    remembered = [
        {"question": str(data.get(f"rem_q_{i}", "")).strip(),
         "answer": normalize_message_text(str(data.get(f"rem_a_{i}", ""))),
         "delete": f"rem_delete_{i}" in data}
        for i in range(count("rem_count"))
    ]
    return {"facts": facts, "remembered": remembered}


def parse_about_me_form(form: Mapping[str, Any], current: AnswerBank | None = None,
                        ) -> tuple[AnswerBank | None, list[str]]:
    """Build the ``AnswerBank`` or return the errors. A fact row with a blank
    value is dropped (not provided); a value without a key is an error. A
    write-only sensitive row (``secret_set``) with a blank value keeps the
    stored fact from ``current`` unchanged (value and sensitivity; the label
    may change); "clear" removes it; a typed value replaces it."""
    errors: list[str] = []
    facts: list[Fact] = []
    for row in form["facts"]:
        if row["secret_set"] and not row["value"]:
            if row["clear"]:
                continue
            kept = current.fact(row["key"].strip().lower()) if current is not None else None
            if kept is None or not kept.is_sensitive:
                errors.append(f"The stored value of {row['key'] or 'a sensitive fact'} is no longer there — "
                              "type it again or tick clear.")
                continue
            facts.append(kept.model_copy(update={"label": row["label"]}))
            continue
        if not row["value"]:
            continue
        if not row["key"]:
            errors.append(f"A value ({row['label'] or 'no label'}) has no key.")
            continue
        try:
            facts.append(Fact(key=row["key"], label=row["label"], value=row["value"],
                              sensitive=row["sensitive"]))
        except ValidationError as exc:
            errors.extend(str(e["msg"]).removeprefix("Value error, ") for e in exc.errors())
    remembered: list[Remembered] = []
    for row in form["remembered"]:
        if row["delete"] or not row["question"] or not row["answer"]:
            continue
        try:
            remembered.append(Remembered(question=row["question"], answer=row["answer"]))
        except ValidationError as exc:
            errors.extend(str(e["msg"]) for e in exc.errors())
    if errors:
        return None, errors
    try:
        return AnswerBank(facts=facts, remembered=remembered), []
    except ValidationError as exc:
        return None, [str(e["msg"]).removeprefix("Value error, ") for e in exc.errors()]


# --------------------------------------------------------------------- app


def create_app(
    store: Store,
    profile_path: Path | str,
    adapters: AdapterSource,
    scheduler: Scheduler | None = None,
    *,
    port: int = DEFAULT_PORT,
    allowed_hosts: Sequence[str] | None = None,
    settings_path: Path | str | None = None,
    templates_path: Path | str | None = None,
    about_me_path: Path | str | None = None,
    group_provider: PageProvider | None = None,
    secrets: SecretStore | None = None,
    browser: FacebookBrowser | None = None,
    facebook_connect: FacebookConnect | None = None,
    yad2_check: Yad2Check | None = None,
    yad2_connect: Yad2Connect | None = None,
    group_check: GroupCheck | None = default_group_check,
    shutdown: Callable[[], None] | None = None,
    updates: Any = None,
    restart: Callable[[], None] | None = None,
) -> FastAPI:
    """Build the web app over a store, a profile file and the source adapters.

    ``scheduler`` (optional) serves ``POST /collect`` in the background;
    without it the collection runs synchronously in the request.
    ``allowed_hosts`` defaults to ``127.0.0.1:<port>`` / ``localhost:<port>``
    (tests pass ``("testserver",)``). ``settings_path`` / ``templates_path``
    default to the data-dir files and are re-read on every draft.
    ``about_me_path`` (default ``config.about_me_path()``) is the answer bank;
    ``group_provider`` is the Facebook ``PageProvider`` "Discover groups"
    searches with (None -> the page says none is configured).
    ``adapters`` may be a factory (``serve``: rebuilt per run). ``browser``
    (``fb-login`` done) is the joiner's session and the ``/health`` pacer
    status. Discover and Join run as ONE background job at a time
    (``app.state.jobs``), progress on ``/groups``; "Connect Facebook"
    (``facebook_connect(progress, current_browser) -> (browser, logged_in)``,
    the ``fb-login`` flow) and "Test a Facebook group" (``group_check``) run
    in the same slot, "Check yad2" (``yad2_check(progress) -> report text``)
    in its own (``app.state.yad2_jobs``), with "Connect yad2"
    (``yad2_connect(progress, confirmed) -> "cookie" | "owner" | None``) and
    the automatic yad2 send ("Send now": ``dispatch`` as a job). ``shutdown`` (``app.state.shutdown``,
    set by ``serve``) is what ``POST /quit`` calls. ``GET /ping`` answers
    ``APP_MARKER`` plus the running ``version``.
    ``updates`` (``updater.UpdateService``; None = updates off) feeds the
    "Update available" banner; ``POST /update`` applies it as a background
    job (``app.state.update_jobs``) and then calls ``restart``
    (``app.state.restart``, set by ``serve``: start a new process, stop this
    one).
    ``secrets`` (default: the ``SecretStore`` next to the settings file, the
    data dir in production) holds the ntfy topic URL and SMTP password and
    the key of the encrypted answer bank. Plaintext secrets left by an older
    version are encrypted at startup (``secrets_migrated`` event, names only).
    """
    app = FastAPI(title="House Finder", docs_url=None, redoc_url=None, openapi_url=None)
    app.add_middleware(
        LocalOriginGuard,
        allowed_hosts=tuple(allowed_hosts) if allowed_hosts is not None else local_hosts(port),
    )
    app.mount("/static", FreshStaticFiles(directory=WEB_DIR / "static"), name="static")
    templates = Jinja2Templates(directory=WEB_DIR / "templates")
    env = templates.env
    env.filters["num"] = _fmt_num
    env.filters["price"] = _fmt_price
    env.filters["when"] = _fmt_when
    env.filters["label"] = _label
    env.filters["safe_url"] = safe_url
    env.filters["sha256"] = text_sha256
    env.filters["pathq"] = lambda v: quote(str(v), safe="")
    env.globals["STATUS_SYMBOL"] = STATUS_SYMBOL
    env.globals["icon"] = icon
    env.globals["ASSET_VERSION"] = APP_VERSION  # ?v= on /static URLs: an update never shows stale CSS/JS
    env.globals["classify"] = _classify_ratio
    env.globals["ATTRIBUTES"] = list(Attribute)
    env.globals["PROPERTY_TYPES"] = list(PropertyType)
    profile_file = Path(profile_path)
    settings_file = Path(settings_path) if settings_path is not None else config.settings_path()
    templates_file = Path(templates_path) if templates_path is not None else config.templates_path()
    about_me_file = Path(about_me_path) if about_me_path is not None else config.about_me_path()

    def source_names() -> list[str]:
        return [str(getattr(a, "name", type(a).__name__)) for a in resolve_adapters(adapters)]

    jobs = BackgroundJob()
    app.state.jobs = jobs
    yad2_jobs = BackgroundJob()
    app.state.yad2_jobs = yad2_jobs
    fb = FacebookLink(browser=browser, provider=group_provider)
    app.state.facebook = fb
    app.state.shutdown = shutdown
    app.state.updates = updates
    app.state.restart = restart
    update_jobs = BackgroundJob()
    app.state.update_jobs = update_jobs
    secret_store = secrets if secrets is not None else secrets_for(settings_file)
    bank_secrets = secrets if secrets is not None else SecretStore(about_me_file.parent)
    migrate_plaintext(store, settings_path=settings_file, about_me_path=about_me_file,
                      settings_secrets=secret_store, bank_secrets=bank_secrets)

    def load() -> tuple[SearchProfile | None, str | None]:
        try:
            return load_profile(profile_file), None
        except Exception as exc:  # broken profile file: say so, never reset it
            return None, f"{profile_file}: {exc}"

    def load_messaging() -> tuple[OwnerSettings | None, dict[str, str] | None, str | None]:
        """Owner settings + templates, or the error that stops drafting."""
        try:
            return load_settings(settings_file, secrets=secret_store), load_templates(templates_file), None
        except Exception as exc:  # broken file: report it, never reset it
            return None, None, str(exc)

    def make_draft(listing_id: str) -> str | None:
        """Store a new draft for the listing unless one is open; the error
        message when settings / templates cannot be read."""
        if store.open_message_for(listing_id) is not None:
            return None
        listing = store.get_listing(listing_id)
        if listing is None:
            raise HTTPException(404, f"no listing {listing_id!r}")
        settings, templates, error = load_messaging()
        if error is not None or settings is None:
            return error
        profile, _ = load()
        draft = draft_message(listing, settings, profile=profile, templates=templates)
        problem = payment_details_problem(draft.text)
        if problem is not None:  # e.g. an owner template or listing field with an IBAN
            store.log_event("draft_refused", listing.id, reason=problem)
            raise DraftRefused(f"No draft was created: {problem}. Check your message template on Settings.")
        store.create_draft(listing.id, draft.channel, draft.text, draft.language)
        return None

    def load_show_stale() -> tuple[bool, str | None]:
        """The owner's "show stale" setting; a broken settings file → hidden
        (the default) plus the error to show."""
        try:
            return load_settings(settings_file, secrets=secret_store).show_stale, None
        except Exception as exc:  # broken file: report it, never reset it
            return False, f"{settings_file}: {exc}"

    def listing_flags(listing: Any, profile: SearchProfile | None, duplicates: Sequence[Any] = ()) -> list[Any]:
        """Scam / stale flags at read time (``quality.flags``)."""
        return flags_for(listing, profile, AreaStats.from_store(store), duplicates=duplicates)

    def render(request: Request, name: str, status_code: int = 200, **ctx: Any) -> HTMLResponse:
        health = store.latest_health()
        ctx.setdefault("page", name.removesuffix(".html"))
        ctx["failing_sources"] = [h for h in health.values() if h.status == "error"]
        ctx["source_alerts"] = store.open_alerts()  # incidents, until a healthy run (hardening stage 3)
        ctx["alert_labels"] = KIND_LABELS
        ctx["new_matches"] = store.unseen_match_count()  # the dashboard badge
        ctx["update"] = updates.available if updates is not None else None  # the update banner
        ctx["update_running"] = update_jobs.running() is not None
        ctx["releases_url"] = RELEASES_URL
        return templates.TemplateResponse(request, name, ctx, status_code=status_code)

    def cluster_duplicates() -> dict[str, list[tuple[Any, str]]]:
        """canonical id -> its ``(duplicate listing, reason)`` pairs."""
        grouped: dict[str, list[tuple[Any, str]]] = {}
        for dup_id, (canonical_id, reason) in store.duplicate_links().items():
            dup = store.get_listing(dup_id)
            if dup is not None:
                grouped.setdefault(canonical_id, []).append((dup, reason))
        return grouped

    # ------------------------------------------------------------- review

    def review_queue(profile: SearchProfile) -> dict[str, Any]:
        """The review queue at read time, with no side effects (``/`` and
        ``/home``). ``undecided``: canonicals of undecided clusters;
        ``ranked``: those passing the hard filters; ``queue``: what the owner
        reviews (stale clusters left out unless the owner asked to see them)."""
        undecided = store.undecided_listings()
        ranked = rank_clusters(undecided, cluster_duplicates(), profile)
        show_stale, settings_error = load_show_stale()
        # Stale clusters (newest stated posting older than the profile's
        # limit) leave the queue unless the owner asked to see them.
        stale_ids = {cm.listing.id for cm in ranked
                     if stale_flag(cm.listing, profile, duplicates=[d for d, _ in cm.also_on]) is not None}
        queue = ranked if show_stale else [cm for cm in ranked if cm.listing.id not in stale_ids]
        return {"undecided": undecided, "ranked": ranked, "queue": queue, "stale_ids": stale_ids,
                "show_stale": show_stale, "settings_error": settings_error}

    @app.get("/", response_class=HTMLResponse)
    def review(request: Request, done: str | None = None, id: str | None = None) -> HTMLResponse:
        profile, profile_error = load()
        notice_listing = store.get_listing(id) if id else None
        if profile is None:
            return render(request, "review.html", profile_error=profile_error, item=None,
                          remaining=0, hidden=0, done=done, notice_listing=notice_listing)
        # Viewing the review queue is "viewing the new matches": clear the badge.
        arrived = store.mark_matches_seen()
        q = review_queue(profile)
        queue, stale_ids, show_stale = q["queue"], q["stale_ids"], q["show_stale"]
        item = None
        if queue:
            listing, result = queue[0].listing, queue[0].result
            hard = sorted((r for r in result.reasons if r.hard), key=lambda r: REASON_ORDER[r.status])
            soft = [r for r in result.reasons if not r.hard]
            flags = listing_flags(listing, profile, [d for d, _ in queue[0].also_on])
            item = {"listing": listing, "result": result, "hard": hard, "soft": soft,
                    "also_on": queue[0].also_on, "flags": flags}
            store.log_event("shown", listing.id, score=result.score, page="review",
                            flags=[f.kind for f in flags])
        return render(
            request, "review.html", item=item, remaining=max(0, len(queue) - 1),
            hidden=len(q["undecided"]) - len(q["ranked"]), done=done, notice_listing=notice_listing,
            profile_error=None, has_locations=bool(profile.locations), arrived=arrived,
            show_stale=show_stale, stale_count=len(stale_ids),
            stale_hidden=0 if show_stale else len(stale_ids), settings_error=q["settings_error"],
        )

    # --------------------------------------------------------------- home

    @app.get("/home", response_class=HTMLResponse)
    def home(request: Request) -> HTMLResponse:
        """The landing page: a getting-started checklist computed from real
        state, counts, the last collection per source and "Find new
        listings". Read-only: it neither logs ``shown`` nor clears the badge."""
        profile, profile_error = load()
        to_review = len(review_queue(profile)["queue"]) if profile is not None else 0
        latest = {n: h for n, h in store.latest_health().items() if not n.startswith("notify:")}
        configured = source_names()
        sources = [{"source": n, "row": latest.get(n), "configured": n in configured,
                    "cooldown": store.active_cooldown(n)}
                   for n in dict.fromkeys(configured + list(latest))]
        contacted_items = store.contacted()
        steps = [
            {"key": "search", "done": bool(profile and profile.locations), "href": "/profile",
             "title": "Tell me what you are looking for", "cta": "Set up my search",
             "text": "Pick at least one city, your budget and your must-haves."},
            {"key": "collect", "done": bool(latest), "href": None,
             "title": "Find listings", "cta": "Find new listings",
             "text": "Fetch fresh listings from the sites. While the app is open this also runs by itself."},
            {"key": "review", "done": store.decision_count() > 0, "href": "/",
             "title": "Review your matches", "cta": "Start reviewing",
             "text": "Skip, save, or say you are interested — one listing at a time."},
            {"key": "facebook", "done": bool(store.readable_fb_groups()), "href": "/groups",
             "title": "Add Facebook groups (optional)", "cta": "Open Facebook groups",
             "text": "Find rental groups in your area. Nothing is joined without your OK. Public groups "
                     "you approve are read right away; private groups after you join them — press Join."},
        ]
        counts = {"new": store.unseen_match_count(), "to_review": to_review,
                  "saved": len(store.shortlist()), "contacted": len(contacted_items),
                  "awaiting": sum(1 for _, m in contacted_items if not m.reply_received_at)}
        readable = store.readable_fb_groups()
        return render(request, "home.html", page="home", profile_error=profile_error, steps=steps,
                      steps_done=sum(1 for s in steps if s["done"]), counts=counts, sources=sources,
                      scheduler_on=scheduler is not None, fb_readable=len(readable),
                      fb_hint=FACEBOOK_READ_HINT)

    @app.post("/health/alerts/dismiss")
    def dismiss_alert(source: str = Form(...)) -> Response:
        """The owner closes an open incident by hand — for a source that keeps
        returning nothing or no longer runs. A new failure opens a new one."""
        if store.clear_alert(source, by_owner=True) is None:
            raise HTTPException(404, f"no open alert for {source!r}")
        return RedirectResponse("/health", status_code=303)

    @app.post("/settings/show-stale")
    def set_show_stale(show: str = Form("")) -> Response:
        """The review page's "Show stale" toggle, persisted in settings. A
        broken settings file is never overwritten: 409 with the reason."""
        try:
            current = load_settings(settings_file, secrets=secret_store)
        except Exception as exc:
            raise HTTPException(409, f"Settings file cannot be read, nothing saved: {exc}") from exc
        value = show == "1"
        save_settings(current.model_copy(update={"show_stale": value}), settings_file, secrets=secret_store)
        store.log_event("settings_saved", show_stale=value)
        return RedirectResponse("/", status_code=303)

    @app.post("/decide")
    def decide(
        request: Request, listing_id: str = Form(...), action: str = Form(...), reason: str = Form("")
    ) -> Response:
        if action not in DECISION_ACTIONS:
            raise HTTPException(400, f"unknown action {action!r}")
        if store.get_listing(listing_id) is None:
            raise HTTPException(404, f"no listing {listing_id!r}")
        text = reason.strip() if action == "skip" else ""
        store.record_decision(listing_id, action, text or None)  # type: ignore[arg-type]
        store.log_event("decision", listing_id, action=action, reason=text or None)
        if action == "interested":
            try:
                make_draft(listing_id)  # a broken settings file is shown on the message page
            except DraftRefused as exc:
                return conflict(request, listing_id, str(exc))
            return RedirectResponse(message_url(listing_id), status_code=303)
        return RedirectResponse(f"/?done={action}&id={quote(listing_id, safe='')}", status_code=303)

    # ------------------------------------------------------------ messages

    @app.get("/listing/{listing_id:path}/message", response_class=HTMLResponse)
    def message_page(request: Request, listing_id: str, done: str | None = None) -> HTMLResponse:
        return message_view(request, listing_id, done=done)

    def message_view(request: Request, listing_id: str, done: str | None = None,
                     status_code: int = 200, error: str | None = None) -> HTMLResponse:
        listing = store.get_listing(listing_id)
        if listing is None:
            raise HTTPException(404, f"no listing {listing_id!r}")
        settings, _, settings_error = load_messaging()
        profile, _ = load()
        others = [d for d in (store.get_listing(i) for i in store.cluster_ids(listing_id) if i != listing_id) if d]
        flags = listing_flags(listing, profile, others)
        messages = store.messages_for(listing_id)
        current = next((m for m in messages if m.status in ("draft", "approved")), None)
        auto, auto_ready = yad2_auto(listing, settings)
        # An approved message shows its assisted "ready to send" screen: the
        # same approval gate + sender as dispatch, read-only, assisted only.
        # Automatic yad2 mode: the same screen is the "Send it yourself" fallback.
        assist = (pending_action(store, current.id, settings=assisted_yad2(settings) if auto else settings)
                  if current and current.status == "approved" else None)
        send_job = yad2_jobs.last(f"yad2_send:{listing_id}")
        return render(request, "message.html", status_code=status_code, page="message",
                      listing=listing, flags=flags, current=current,
                      history=[m for m in messages if m is not current],
                      settings_error=settings_error, done=done, error=error, assist=assist,
                      auto_open=done == "needs_owner", message_url=message_url(listing_id),
                      auto=auto, auto_ready=auto_ready, send_job=send_job,
                      sending=send_job is not None and send_job.running,
                      yad2_status=yad2_status() if auto else None, yad2_listing_id=listing_id)

    @app.post("/listing/{listing_id:path}/message")
    def message_new(request: Request, listing_id: str) -> Response:
        try:
            error = make_draft(listing_id)
        except DraftRefused as exc:
            return conflict(request, listing_id, str(exc))
        if error is not None:
            raise HTTPException(500, f"cannot draft a message: {error}")
        return RedirectResponse(message_url(listing_id), status_code=303)

    def message_or_404(message_id: int):
        msg = store.get_message(message_id)
        if msg is None:
            raise HTTPException(404, f"no message {message_id}")
        return msg

    def conflict(request: Request, listing_id: str, error: str) -> HTMLResponse:
        return message_view(request, listing_id, status_code=409, error=error)

    @app.post("/message/{message_id:int}/edit")
    def message_edit(request: Request, message_id: int, text: str = Form("")) -> Response:
        msg = message_or_404(message_id)
        body = normalize_message_text(text)
        if not body:
            return conflict(request, msg.listing_id, "The message is empty — nothing saved.")
        problem = payment_details_problem(body)
        if problem is not None:
            return conflict(request, msg.listing_id, f"Not saved: {problem}.")
        try:
            store.update_draft_text(message_id, body)
        except MessageStateError as exc:
            return conflict(request, msg.listing_id, str(exc))
        return RedirectResponse(f"{message_url(msg.listing_id)}?done=saved", status_code=303)

    @app.post("/message/{message_id:int}/approve")
    def message_approve(
        request: Request, message_id: int, text: str = Form(""), base_sha256: str = Form("")
    ) -> Response:
        """Approve & send: approve the EXACT submitted text, then dispatch.

        ``base_sha256`` is the hash of the stored text the page showed. If the
        owner edited the box, the edit is saved first — but only when the
        stored text is still the one the page showed; otherwise (changed in
        another tab) nothing is approved and the page asks to review again.
        """
        msg = message_or_404(message_id)
        body = normalize_message_text(text)
        if not body:
            return conflict(request, msg.listing_id, "The message is empty — nothing approved.")
        problem = payment_details_problem(body)
        if problem is not None:
            return conflict(request, msg.listing_id, f"Not approved: {problem}.")
        if msg.status not in ("draft", "approved"):
            return conflict(request, msg.listing_id, f"This message is {msg.status}; it cannot be approved.")
        if base_sha256 != text_sha256(msg.text):
            return conflict(request, msg.listing_id,
                            "The message changed since this page was opened. Review it again; nothing was approved.")
        try:
            if body != msg.text:
                store.update_draft_text(message_id, body)
            store.approve(message_id, text_sha256(body))
        except (StaleApprovalError, MessageStateError) as exc:
            return conflict(request, msg.listing_id, f"Not approved: {exc}")
        settings, _, _ = load_messaging()  # broken settings -> default (assisted) modes
        auto, auto_ready = yad2_auto(store.get_listing(msg.listing_id), settings)
        if auto_ready:  # "Send now": the automatic yad2 send runs as a background job
            if not start_yad2_send(message_id, msg.listing_id):
                busy = yad2_jobs.running()
                return conflict(request, msg.listing_id,
                                f"Approved, not sent yet: {busy.label if busy else 'a yad2 job'} is still running. "
                                "Press Send now when it ends.")
            return RedirectResponse(f"{message_url(msg.listing_id)}?done=sending", status_code=303)
        if auto:  # automatic chosen but yad2 not connected: the assisted flow instead
            settings = assisted_yad2(settings)
        result = dispatch(store, message_id, settings=settings)  # the single send call site
        return RedirectResponse(f"{message_url(msg.listing_id)}?done={result.status}", status_code=303)

    @app.post("/message/{message_id:int}/send-now")
    def message_send_now(request: Request, message_id: int, sha256: str = Form("")) -> Response:
        """"Send now" for an already approved yad2 message (automatic mode,
        yad2 connected): only when the approval still holds for the text the
        page showed (``sha256``). Runs ``dispatch`` as the yad2 job."""
        msg = message_or_404(message_id)
        approval = store.approval_for(message_id)
        if approval is None or sha256 != approval.text_sha256:
            return conflict(request, msg.listing_id,
                            "Not sent: the message is not approved for the text this page showed. Review it again.")
        settings, _, _ = load_messaging()
        _, auto_ready = yad2_auto(store.get_listing(msg.listing_id), settings)
        if not auto_ready:
            return conflict(request, msg.listing_id, "Automatic yad2 sending is off or yad2 is not connected; "
                                                     "send it yourself below.")
        if not start_yad2_send(message_id, msg.listing_id):
            busy = yad2_jobs.running()
            return conflict(request, msg.listing_id,
                            f"Busy: {busy.label if busy else 'a yad2 job'} is still running; try again when it ends.")
        return RedirectResponse(f"{message_url(msg.listing_id)}?done=sending", status_code=303)

    @app.post("/message/{message_id:int}/sent")
    def message_sent(request: Request, message_id: int, sha256: str = Form("")) -> Response:
        """Assisted send, "I sent it": the owner sent the approved text by
        hand. Marked sent only with the store's approval token, and only if
        ``sha256`` (the text the page showed) is still the approved text."""
        msg = message_or_404(message_id)
        approval = store.approval_for(message_id)
        if approval is None or sha256 != approval.text_sha256:
            return conflict(request, msg.listing_id,
                            "Not marked sent: the message is not approved for the text this page showed. Review it again.")
        try:
            store.mark_sent(message_id, approval, assisted=True)
        except MessageStateError as exc:
            return conflict(request, msg.listing_id, f"Not marked sent: {exc}")
        return RedirectResponse(f"{message_url(msg.listing_id)}?done=marked_sent", status_code=303)

    @app.post("/message/{message_id:int}/failed")
    def message_failed(
        request: Request, message_id: int, sha256: str = Form(""), error: str = Form("")
    ) -> Response:
        """Assisted send, "It failed": record the failure (approved only), and
        only if ``sha256`` (the text the page showed) is still the approved
        text — a stale tab never fails a message it did not show."""
        msg = message_or_404(message_id)
        approval = store.approval_for(message_id)
        if approval is None or sha256 != approval.text_sha256:
            return conflict(request, msg.listing_id,
                            "Not marked failed: the message is not approved for the text this page showed. Review it again.")
        reason = error.strip() or "the owner reported that sending failed"
        try:
            store.mark_failed(message_id, reason)
        except MessageStateError as exc:
            return conflict(request, msg.listing_id, f"Not marked failed: {exc}")
        return RedirectResponse(f"{message_url(msg.listing_id)}?done=marked_failed", status_code=303)

    @app.post("/message/{message_id:int}/cancel")
    def message_cancel(request: Request, message_id: int) -> Response:
        msg = message_or_404(message_id)
        try:
            store.cancel_message(message_id)
        except MessageStateError as exc:
            return conflict(request, msg.listing_id, str(exc))
        return RedirectResponse(f"{message_url(msg.listing_id)}?done=cancelled", status_code=303)

    @app.get("/contacted", response_class=HTMLResponse)
    def contacted(request: Request) -> HTMLResponse:
        return render(request, "contacted.html", items=store.contacted())

    @app.post("/message/{message_id:int}/reply")
    def message_reply(message_id: int, note: str = Form("")) -> Response:
        message_or_404(message_id)
        try:
            store.record_reply(message_id, note.strip())
        except MessageStateError as exc:
            raise HTTPException(409, str(exc)) from exc
        return RedirectResponse("/contacted", status_code=303)

    # ------------------------------------------------------------ profile

    @app.get("/profile", response_class=HTMLResponse)
    def profile_page(request: Request, saved: int = 0) -> HTMLResponse:
        profile, profile_error = load()
        form = profile_to_form(profile or SearchProfile())
        return render(request, "profile.html", form=form, errors=[], saved=bool(saved),
                      profile_error=profile_error, extra_rows=EXTRA_LOCATION_ROWS)

    @app.post("/profile", response_class=HTMLResponse)
    async def profile_save(request: Request) -> Response:
        form = form_from_request(await request.form())
        profile, errors = parse_profile_form(form)
        if profile is None:
            return render(request, "profile.html", status_code=400, form=form, errors=errors,
                          saved=False, profile_error=None, extra_rows=EXTRA_LOCATION_ROWS)
        save_profile(profile, profile_file)
        store.log_event("profile_saved")
        return RedirectResponse("/profile?saved=1", status_code=303)

    # ---------------------------------------------------------- shortlist

    @app.get("/shortlist", response_class=HTMLResponse)
    def shortlist(request: Request) -> HTMLResponse:
        profile, profile_error = load()
        items = []
        for listing in store.shortlist():
            result = evaluate(listing, profile) if profile is not None else None
            items.append({"listing": listing, "result": result,
                          "decision": store.latest_decision(listing.id)})
        return render(request, "shortlist.html", items=items, profile_error=profile_error)

    @app.post("/unsave")
    def unsave(listing_id: str = Form(...)) -> Response:
        if store.get_listing(listing_id) is None:
            raise HTTPException(404, f"no listing {listing_id!r}")
        # The decisions table allows only skip|save|interested: un-save is a skip.
        store.record_decision(listing_id, "skip", UNSAVE_REASON)
        store.log_event("decision", listing_id, action="skip", reason=UNSAVE_REASON)
        return RedirectResponse("/shortlist", status_code=303)

    # ---------------------------------------------------------- log, health

    @app.get("/log", response_class=HTMLResponse)
    def log_page(request: Request, limit: int = 200) -> HTMLResponse:
        return render(request, "log.html", events=store.events(max(1, min(limit, 2000))))

    @app.get("/health", response_class=HTMLResponse)
    def health(request: Request, collected: int = 0) -> HTMLResponse:
        return health_view(request, collected=bool(collected))

    def health_view(request: Request, *, collected: bool = False, status_code: int = 200,
                    error: str | None = None) -> HTMLResponse:
        latest = store.latest_health()
        configured = source_names()
        names = list(dict.fromkeys(configured + list(latest)))
        histories = store.health_histories(HISTORY_LIMIT)
        alerts = {a.source: a for a in store.open_alerts()}
        cooldowns = {c.source: c for c in store.cooldowns()}
        rows = [{"source": n, "row": latest.get(n), "configured": n in configured,
                 "history": histories.get(n, []), "alert": alerts.get(n), "cooldown": cooldowns.get(n)}
                for n in names]
        cooling = [c for c in cooldowns.values() if c.active()]
        sched = None
        if scheduler is not None:
            sched = {
                "alive": scheduler.is_alive,
                "running": scheduler.is_running_job,
                "interval": scheduler.interval_seconds / 60,
                "runs": scheduler.runs,
                "last_error": scheduler.last_error,
            }
        yad2_job, group_job = yad2_jobs.last("check_yad2"), jobs.last("fb_check")
        return render(request, "health.html", status_code=status_code, rows=rows, scheduler=sched,
                      collected=collected, history_limit=HISTORY_LIMIT, cooling=cooling,
                      pacer=fb.browser.pacer.status() if fb.browser is not None else None,
                      check_error=error, yad2_check_job=yad2_job, yad2_check_ready=yad2_check is not None,
                      group_check_job=group_job,
                      group_check_ready=fb.browser is not None and group_check is not None,
                      joined_groups=store.fb_groups("joined"), fb_busy=jobs.running(),
                      checks_running=bool((yad2_job and yad2_job.running) or (group_job and group_job.running)))

    @app.post("/health/check-yad2", response_class=HTMLResponse)
    def check_yad2(request: Request) -> Response:
        """"Check yad2" (the ``check-yad2`` report: one plain request, then
        the browser fallback; structure only) in the background; the report
        text is shown on ``/health``. One at a time."""
        if yad2_check is None:
            return health_view(request, status_code=503, error=NO_YAD2_CHECK_MESSAGE)
        runner = yad2_check
        if not yad2_jobs.start("check_yad2", "Check yad2", lambda progress: runner(progress)):
            return health_view(request, status_code=409, error="Busy: the yad2 check is still running.")
        store.log_event("check_requested", check="yad2")
        return RedirectResponse("/health#checks", status_code=303)

    @app.post("/health/check-group", response_class=HTMLResponse)
    def check_group_route(request: Request, group_id: str = Form("")) -> Response:
        """"Test a Facebook group" (``fb-check``): read ONE joined group with
        the app's browser and show what was extracted; stores nothing,
        sends nothing. Shares the Facebook job slot."""
        if fb.browser is None or group_check is None:
            return health_view(request, status_code=503,
                               error=NO_BROWSER_MESSAGE.replace("Joining", "Testing a group"))
        group = store.get_fb_group(group_id) if group_id else None
        if group is None or group.status != "joined":
            return health_view(request, status_code=400, error="Pick one of your joined groups to test.")
        cooldown = store.active_cooldown(FACEBOOK_SOURCE)
        if cooldown is not None:
            return health_view(request, status_code=409,
                               error=f"Facebook is cooling down after a block until {cooldown.until}.")
        current, runner = fb.browser, group_check

        def run(progress: Any) -> Any:
            try:
                return runner(progress, current, group.group_id)
            except SourceBlocked as exc:
                store.start_cooldown(FACEBOOK_SOURCE, f"blocked while testing a group: {exc}")
                raise

        if not jobs.start("fb_check", f"Test group {group.name}", run):
            busy = jobs.running()
            return health_view(request, status_code=409,
                               error=f"Busy: {busy.label if busy else 'a Facebook job'} is still running.")
        store.log_event("check_requested", check="fb_group", group_id=group.group_id)
        return RedirectResponse("/health#checks", status_code=303)

    # --------------------------------------------------- app: ping / quit

    @app.get("/ping")
    def ping() -> JSONResponse:
        """``house-finder app`` checks this to know the server is ours; the
        running code's version (a restart after an update checks it)."""
        return JSONResponse({**APP_MARKER, "version": APP_VERSION})

    # ------------------------------------------------------------ updates

    @app.post("/update", response_class=HTMLResponse)
    def update_now(request: Request) -> HTMLResponse:
        """"Update now": download + install the update in the background,
        then restart (``app.state.restart``). Guarded like every POST."""
        info = updates.available if updates is not None else None
        if info is None:
            return HTMLResponse("No update is available.", status_code=409)
        if info.needs_installer:
            return HTMLResponse(f"Version {info.version} needs the new installer: {RELEASES_URL}",
                                status_code=409)

        def run(progress: Callable[[str], None]) -> str:
            version = updates.apply(progress)
            store.log_event("update_installed", version=version)
            hook = app.state.restart
            if hook is not None:
                progress("Restarting")
                hook()
            return version

        if not update_jobs.start("update", f"Update to {info.version}", run):
            return HTMLResponse("An update is already running.", status_code=409)
        store.log_event("update_requested", version=info.version)
        return templates.TemplateResponse(request, "updating.html",
                                          {"target": info.version, "current": APP_VERSION})

    @app.get("/update/status")
    def update_status() -> JSONResponse:
        """The updating page polls this: the running version and the job."""
        job = update_jobs.last("update")
        return JSONResponse({"version": APP_VERSION, "running": bool(job and job.running),
                             "error": job.error if job else None,
                             "progress": job.progress[-1] if job and job.progress else None})

    @app.post("/update/check")
    def update_check() -> Response:
        """Settings' "Check for updates now"."""
        if updates is None:
            return RedirectResponse("/settings?checked=off", status_code=303)
        updates.check()
        return RedirectResponse("/settings?checked=1#version", status_code=303)

    @app.post("/quit", response_class=HTMLResponse)
    def quit_app(request: Request) -> HTMLResponse:
        """The Quit button: stops the server (``app.state.shutdown``, set by
        ``serve``) and says so. Guard-protected like every POST."""
        hook = app.state.shutdown
        if hook is None:
            return HTMLResponse("This House Finder cannot be stopped from the page.", status_code=503)
        store.log_event("quit_requested")
        hook()
        return templates.TemplateResponse(request, "stopped.html", {})

    # ------------------------------------------------ facebook: connect

    def facebook_status() -> dict[str, Any]:
        """For the Connect Facebook box on /groups and /settings."""
        login = jobs.last("fb_login")
        if login is not None and login.running:
            state = "logging in"
        else:
            state = "connected" if fb.browser is not None else "not connected"
        return {"state": state, "available": facebook_connect is not None, "login": login,
                "busy": jobs.running()}

    # ------------------------------------------------ yad2: connect + automatic send

    yad2_confirmed = threading.Event()  # the owner's "I'm logged in" for the running Connect yad2

    def yad2_login_marker() -> dict[str, Any] | None:
        from house_finder.browser.yad2_actions import yad2_login_info

        return yad2_login_info(config.yad2_browser_profile_dir())

    def yad2_status() -> dict[str, Any]:
        """For the Connect yad2 box on /settings and the message page."""
        login = yad2_jobs.last("yad2_login")
        marker = yad2_login_marker()
        if login is not None and login.running:
            state = "logging in"
        else:
            state = "connected" if marker is not None else "not connected"
        return {"state": state, "how": (marker or {}).get("how"), "available": yad2_connect is not None,
                "login": login, "busy": yad2_jobs.running()}

    def yad2_auto(listing: Any, settings: OwnerSettings | None) -> tuple[bool, bool]:
        """(the owner chose automatic sending for this listing's yad2 channel,
        it can run now: the sender is registered and yad2 is connected)."""
        if (listing is None or settings is None or channel_for_listing(listing) != YAD2_SOURCE
                or settings.send_mode(YAD2_SOURCE) != "browser"):
            return False, False
        return True, (YAD2_SOURCE, "browser") in registry.keys() and yad2_login_marker() is not None

    def assisted_yad2(settings: OwnerSettings | None) -> OwnerSettings | None:
        """``settings`` with yad2 in assisted mode: the "Send it yourself"
        fallback of an automatic yad2 message."""
        if settings is None:
            return None
        modes = {**settings.send_mode_per_channel, YAD2_SOURCE: "assisted"}
        return settings.model_copy(update={"send_mode_per_channel": modes})

    def start_yad2_send(message_id: int, listing_id: str) -> bool:
        """The automatic yad2 send as a job in the yad2 slot (one at a time,
        never queued): ``dispatch`` — the single send call site — runs it."""

        def run(progress: Callable[[str], None]) -> Any:
            progress("Sending on yad2 in the tool's browser (a pause of 10–20 s between pages is normal)…")
            settings, _, _ = load_messaging()  # broken settings -> assisted: nothing is sent automatically
            return dispatch(store, message_id, settings=settings)

        return yad2_jobs.start(f"yad2_send:{listing_id}", "Send on yad2", run)

    def yad2_target(listing_id: str) -> str:
        """Where a yad2 box button returns: the listing's message page, else /settings."""
        if listing_id and store.get_listing(listing_id) is not None:
            return message_url(listing_id)
        return "/settings"

    @app.post("/yad2/login", response_class=HTMLResponse)
    def yad2_login_route(request: Request, listing_id: str = Form("")) -> Response:
        """"Connect yad2": a visible window of the yad2 browser profile on
        yad2, where the OWNER logs in (the app never types, sees or stores
        the password); the job waits for a logged-in cookie or "I'm logged
        in". Shares the yad2 slot (Check yad2, automatic sends)."""
        target = yad2_target(listing_id)
        if yad2_connect is None:
            return settings_view(request, errors=[NO_YAD2_CONNECT_MESSAGE], status_code=503)
        runner = yad2_connect
        yad2_confirmed.clear()

        def run(progress: Any) -> str:
            how = runner(progress, yad2_confirmed.is_set)
            store.log_event("yad2_login", logged_in=bool(how), how=how)
            if how == "cookie":
                return "Connected to yad2."
            if how == "owner":
                return "Marked as connected (you confirmed it); the first automatic send checks it."
            return "Not connected: the login did not finish. Press Connect yad2 to try again."

        if not yad2_jobs.start("yad2_login", "Connect yad2", run):
            busy = yad2_jobs.running()
            return settings_view(request, status_code=409, errors=[
                f"Busy: {busy.label if busy else 'a yad2 job'} is still running; try again when it ends."])
        return RedirectResponse(f"{target}?done=yad2_login_started", status_code=303)

    @app.post("/yad2/login/confirm")
    def yad2_login_confirm(listing_id: str = Form("")) -> Response:
        """"I'm logged in": the owner says the login in the yad2 window is
        done (the cookie check is a guess); the next send verifies it."""
        login = yad2_jobs.last("yad2_login")
        if login is None or not login.running:
            raise HTTPException(409, "No yad2 login is waiting; press Connect yad2 first.")
        yad2_confirmed.set()
        return RedirectResponse(yad2_target(listing_id), status_code=303)

    @app.post("/yad2/show")
    def yad2_show(listing_id: str = Form("")) -> Response:
        """"Show the yad2 window": raise the tool's Chromium windows."""
        from house_finder.browser.winfocus import show_tool_windows

        show_tool_windows()
        return RedirectResponse(yad2_target(listing_id), status_code=303)

    @app.post("/health/cooldown/clear")
    def clear_cooldown(source: str = Form(...)) -> Response:
        """The owner ends a source's cooldown: it runs again at the next
        collection (a new block starts the next, longer cooldown). The
        Facebook pacer's stop-for-today is NOT cleared here."""
        if store.clear_cooldown(source) is None:
            raise HTTPException(404, f"no active cooldown for {source!r}")
        return RedirectResponse("/health", status_code=303)

    @app.post("/collect")
    def collect() -> Response:
        store.log_event("collect_requested")
        if scheduler is not None:
            scheduler.trigger_now()
        else:
            profile, profile_error = load()
            if profile is None:
                raise HTTPException(500, f"profile cannot be loaded: {profile_error}")
            collect_and_notify(store, profile, adapters, settings_path=settings_file,
                               local_url=f"http://127.0.0.1:{port}/")
        return RedirectResponse("/health?collected=1", status_code=303)

    # ------------------------------------------------------------ settings

    def secret_status() -> tuple[dict[str, bool], str | None, str | None]:
        """Which secrets are stored (never their values), where the key
        lives, and the error when the store cannot be read."""
        try:
            names = set(secret_store.names()) if secret_store.path.exists() else set()
            return ({"topic": NTFY_TOPIC in names, "password": SMTP_PASSWORD in names},
                    secret_store.key_source(), None)
        except SecretStoreError as exc:
            return {"topic": False, "password": False}, secret_store.key_source(), str(exc)

    def settings_view(request: Request, form: dict[str, Any] | None = None, errors: list[str] | None = None,
                      saved: bool = False, status_code: int = 200, checked: str = "") -> HTMLResponse:
        file_error = None
        status, key_source, secret_error = secret_status()
        if form is None:
            try:
                current = load_settings(settings_file, secrets=secret_store)
            except Exception as exc:  # broken file: say so, never reset it silently
                current, file_error = OwnerSettings(), f"{settings_file}: {exc}"
            try:
                owner_templates = load_templates(templates_file)
            except Exception as exc:
                owner_templates = dict(DEFAULT_TEMPLATES)
                file_error = "; ".join(filter(None, [file_error, f"{templates_file}: {exc}"]))
            form = settings_to_form(current, owner_templates)
        # Write-only: a submitted secret is never echoed back into the page.
        form = {**form, "ntfy_topic": "", "smtp_password": "",
                "ntfy_topic_set": status["topic"], "smtp_password_set": status["password"]}
        mode_options = {ch: list(dict.fromkeys(send_modes_for(ch) + [m])) for ch, m in form["send_modes"].items()}
        return render(request, "settings.html", status_code=status_code, form=form, errors=errors or [],
                      saved=saved, file_error=file_error, send_modes=SEND_MODES, mode_options=mode_options,
                      default_templates=DEFAULT_TEMPLATES, smtp_security=SMTP_SECURITY,
                      key_source=key_source, secret_error=secret_error, fb_status=facebook_status(),
                      yad2_status=yad2_status(), yad2_listing_id="",
                      app_version=APP_VERSION, updates_on=updates is not None, checked=checked,
                      update_error=updates.error if updates is not None else None,
                      update_checked_at=updates.checked_at if updates is not None else None)

    @app.get("/settings", response_class=HTMLResponse)
    def settings_page(request: Request, saved: int = 0, checked: str = "") -> HTMLResponse:
        return settings_view(request, saved=bool(saved), checked=checked)

    @app.post("/settings", response_class=HTMLResponse)
    async def settings_save(request: Request) -> Response:
        form = settings_form_from_request(await request.form())
        try:  # fail closed: an unreadable secret store is never overwritten
            stored = secret_store.names() if secret_store.path.exists() else []
            current_topic = secret_store.get(NTFY_TOPIC) if NTFY_TOPIC in stored else None
        except SecretStoreError as exc:
            return settings_view(request, form=form, status_code=409,
                                 errors=[f"Encrypted settings cannot be read, nothing saved: {exc}"])
        settings, owner_templates, errors = parse_settings_form(
            form, current_topic=current_topic, password_set=SMTP_PASSWORD in stored)
        if settings is None or owner_templates is None:
            return settings_view(request, form=form, errors=errors, status_code=400)
        show_stale, _ = load_show_stale()  # set on the review page, kept here
        changed: list[str] = []
        try:
            if form["smtp_password"]:
                secret_store.set(SMTP_PASSWORD, form["smtp_password"])
                changed.append("smtp_password set")
            elif form["smtp_password_clear"] and secret_store.delete(SMTP_PASSWORD):
                changed.append("smtp_password cleared")
            if form["ntfy_topic"]:
                changed.append("ntfy_topic set")
            elif form["ntfy_topic_clear"] and current_topic:
                changed.append("ntfy_topic cleared")
            save_templates(owner_templates, templates_file)
            save_settings(settings.model_copy(update={"show_stale": show_stale}), settings_file,
                          secrets=secret_store)
        except SecretStoreError as exc:
            return settings_view(request, form=form, status_code=409,
                                 errors=[f"Encrypted settings cannot be written, nothing saved: {exc}"])
        # Names only — never a secret value.
        store.log_event("settings_saved", notify_channels=settings.notify_channels,
                        ntfy=settings.ntfy_enabled, email=settings.email_enabled,
                        templates=sorted(owner_templates), secrets=changed)
        clear_stale_notify_health(store, settings)
        return RedirectResponse("/settings?saved=1", status_code=303)

    # ------------------------------------------------- facebook groups

    def load_answer_bank() -> tuple[AnswerBank, str | None]:
        try:
            return load_bank(about_me_file, secrets=bank_secrets), None
        except Exception as exc:  # broken file: say so, never reset it
            return AnswerBank(), f"{about_me_file}: {exc}"

    def answer_rows(group: Any, bank: AnswerBank) -> tuple[list[dict[str, Any]], Any]:
        """What the page shows for an approved group's questions: the saved
        answers, or fresh drafts from the bank (never stored by a GET)."""
        saved = store.group_answers(group.group_id)
        if saved is not None and [i.question for i in saved.items] == group.questions:
            rows = [{"question": i.question, "answer": i.answer, "source": i.source,
                     "reason": "saved" if i.source == "owner" else f"saved ({i.source})",
                     "sensitive": sensitive_topic(i.question, bank) is not None} for i in saved.items]
            return rows, saved
        rows = [{"question": d.question, "answer": d.answer or "", "source": d.source, "reason": d.reason,
                 "sensitive": d.sensitive} for d in draft_answers(group.questions, bank)]
        return rows, None

    def groups_view(request: Request, status_code: int = 200, error: str | None = None,
                    report: Any = None, submitted: dict[str, list[str]] | None = None,
                    error_group: str | None = None, done: str | None = None) -> HTMLResponse:
        bank, bank_error = load_answer_bank()
        approved = []
        for group in store.fb_groups("approved"):
            rows, saved = answer_rows(group, bank)
            shown_sha = answers_sha256(group.group_id, [(r["question"], r["answer"]) for r in rows])
            if submitted and group.group_id in submitted:
                for row, value in zip(rows, submitted[group.group_id]):
                    row["answer"] = value
            approved.append({"group": group, "rows": rows, "saved": saved, "base_sha256": shown_sha,
                             "ready": store.answers_approval_for(group.group_id) is not None})
        others = [g for g in store.fb_groups() if g.status not in ("candidate", "approved")]
        job = jobs.state()
        if report is None and job is not None and job.name == "discover" and not job.running:
            report = job.result
        membership = None
        if job is not None and job.name == "my_groups" and not job.running:
            membership = job.result
        summary = summarize_issues(report) if isinstance(report, DiscoveryReport) else None
        # Groups the owner's own "Your groups" page listed, not yet in use:
        # their own section ("Use this group"), not the discovery candidates.
        members = [g for g in store.fb_groups() if g.is_member and g.status in ("candidate", "approved")]
        candidates = [g for g in store.fb_groups("candidate") if not g.is_member]
        readable = {g.group_id for g in store.readable_fb_groups()}
        return render(request, "groups.html", status_code=status_code, page="groups",
                      candidates=candidates, approved=approved, others=others, members=members,
                      membership=membership, summary=summary, readable=readable,
                      fb_hint=FACEBOOK_READ_HINT, count=request.query_params.get("n"),
                      bank_error=bank_error, error=error, error_group=error_group, report=report,
                      done=done, provider_configured=fb.provider is not None,
                      joiner_ready=fb.browser is not None, job=job, fb_status=facebook_status(),
                      cooldown=store.active_cooldown(FACEBOOK_SOURCE))

    @app.get("/groups", response_class=HTMLResponse)
    def groups_page(request: Request, done: str | None = None) -> HTMLResponse:
        return groups_view(request, done=done)

    @app.post("/facebook/show")
    def facebook_show(back: str = Form("/groups")) -> Response:
        """"Show the Facebook window": raise the tool's Chromium window (it
        opens behind the owner's browser on Windows). Changes nothing else."""
        from house_finder.browser.winfocus import show_tool_windows

        show_tool_windows()
        target = back if back in ("/groups", "/settings") else "/groups"
        return RedirectResponse(target, status_code=303)

    @app.post("/facebook/login", response_class=HTMLResponse)
    def facebook_login(request: Request, back: str = Form("/groups")) -> Response:
        """"Connect Facebook": the ``fb-login`` flow as a background job — a
        visible browser on facebook.com where the OWNER logs in (the app never
        types, sees or stores the password); it waits for the session cookie.
        Uses the app's own browser session when it has one (never a second
        Chromium on the same profile); shares the Facebook job slot."""
        target = back if back in ("/groups", "/settings") else "/groups"
        if facebook_connect is None:
            return groups_view(request, status_code=503, error=NO_CONNECT_MESSAGE)
        connect = facebook_connect

        def run(progress: Any) -> Any:
            old = fb.browser
            new, logged_in = connect(progress, old)
            if new is not old:
                fb.browser = new
                if new is not None:
                    fb.provider = new.provider
                elif old is not None and fb.provider is old.provider:
                    fb.provider = None
            store.log_event("fb_login", logged_in=bool(logged_in))
            return ("Connected to Facebook." if logged_in
                    else "Not connected: the login did not finish. Press Connect Facebook to try again.")

        if not jobs.start("fb_login", "Connect Facebook", run):
            busy = jobs.running()
            return groups_view(request, status_code=409, error=f"Busy: {busy.label if busy else 'a Facebook job'} "
                                                                 "is still running; try again when it ends.")
        return RedirectResponse(f"{target}?done=fb_login_started", status_code=303)

    def busy_or_cooling(request: Request) -> HTMLResponse | None:
        """409 while a browser job runs or Facebook cools down after a block."""
        job = jobs.state()
        if job is not None and job.running:
            return groups_view(request, status_code=409, error=f"Busy: {job.label} is still running.")
        cooldown = store.active_cooldown(FACEBOOK_SOURCE)
        if cooldown is not None:
            return groups_view(request, status_code=409,
                               error=f"Facebook is cooling down after a block until {cooldown.until}; "
                                     "nothing is sent to Facebook until then (see Health).")
        return None

    @app.post("/groups/discover", response_class=HTMLResponse)
    def groups_discover(request: Request) -> Response:
        """Start "Discover groups" in the background (``discover_groups``
        with the configured provider; progress on ``/groups``). New groups
        are stored as candidates only (never joined)."""
        provider = fb.provider
        if provider is None:
            return groups_view(request, status_code=503, error=NO_PROVIDER_MESSAGE)
        profile, profile_error = load()
        if profile is None:
            return groups_view(request, status_code=500, error=f"Profile cannot be read: {profile_error}")
        refused = busy_or_cooling(request)
        if refused is not None:
            return refused
        from house_finder.sources.facebook import discover_groups

        def run(progress: Any) -> Any:
            try:
                report = discover_groups(provider, profile, store, progress=progress)
            except SourceBlocked as exc:
                store.log_event("fb_discovery", status="blocked", error=str(exc))
                store.start_cooldown(FACEBOOK_SOURCE, f"blocked during group discovery: {exc}")
                raise
            except DiscoveryFailed as exc:
                # Every search failed: show the report's plain summary (a
                # closed window, the daily limit), not a red raw error.
                store.log_event("fb_discovery", status="error", error=str(exc))
                return exc.report
            except SourceError as exc:
                store.log_event("fb_discovery", status="error", error=str(exc))
                raise
            store.log_event("fb_discovery", status="ok", queries=len(report.queries), found=len(report.found),
                            new=len(report.new), failures=report.failures)
            return report

        jobs.start("discover", "Discover groups", run)
        return RedirectResponse("/groups?done=discover_started", status_code=303)

    def group_or_404(group_id: str) -> Any:
        group = store.get_fb_group(group_id)
        if group is None:
            raise HTTPException(404, f"no Facebook group {group_id!r}")
        return group

    @app.post("/groups/my-groups", response_class=HTMLResponse)
    def groups_find_mine(request: Request) -> Response:
        """"Find groups I'm already in": read the owner's own Facebook
        "Your groups" page in the background (one paced page load + a few
        scrolls, its own daily cap) and store each group as a candidate
        marked "already a member". Never approves or joins anything."""
        provider = fb.provider
        if provider is None or not hasattr(provider, "my_groups"):
            return groups_view(request, status_code=503, error=NO_PROVIDER_MESSAGE)
        refused = busy_or_cooling(request)
        if refused is not None:
            return refused
        from house_finder.sources.facebook import import_my_groups

        def run(progress: Any) -> Any:
            try:
                report = import_my_groups(provider, store, progress=progress)
            except SourceBlocked as exc:
                store.log_event("fb_my_groups", status="blocked", error=str(exc))
                store.start_cooldown(FACEBOOK_SOURCE, f"blocked while reading your groups: {exc}")
                raise
            except SourceError as exc:
                store.log_event("fb_my_groups", status="error", error=str(exc))
                raise
            store.log_event("fb_my_groups", status="ok", found=len(report.found), new=len(report.new))
            return report

        if not jobs.start("my_groups", "Find groups I’m already in", run):
            return groups_view(request, status_code=409, error="Busy: another Facebook job is still running.")
        return RedirectResponse("/groups?done=my_groups_started", status_code=303)

    def use_member_group(group: Any) -> None:
        """The owner's "Use this group": a group their own Facebook page lists
        as joined goes candidate -> approved -> joined through the SAME store
        transitions as Approve and "I'm a member now" (the DB still refuses a
        join of a group that is not approved, or one with entry questions and
        no approved answers)."""
        if group.status == "candidate":
            store.set_fb_group_status(group.group_id, "approved")
        store.set_fb_group_status(group.group_id, "joined")

    @app.post("/groups/use-all", response_class=HTMLResponse)
    def groups_use_all(request: Request) -> Response:
        """"Use all": every group the owner is already in (candidate or
        approved, listed by their own memberships page) -> joined."""
        used = 0
        for group in store.fb_groups():
            if group.is_member and group.status in ("candidate", "approved"):
                try:
                    use_member_group(group)
                except sqlite3.IntegrityError:
                    continue  # it has entry questions: answer them and press Join
                used += 1
        return RedirectResponse(f"/groups?done=used_all&n={used}", status_code=303)

    @app.post("/groups/{group_id}/use", response_class=HTMLResponse)
    def group_use(request: Request, group_id: str) -> Response:
        """"Use this group" for one group the owner is already in."""
        group = group_or_404(group_id)
        if not group.is_member or group.status not in ("candidate", "approved"):
            return groups_view(request, status_code=409,
                               error=f"{group.name} is not one of your groups waiting to be used.")
        try:
            use_member_group(group)
        except sqlite3.IntegrityError as exc:
            return groups_view(request, status_code=409, error=f"{group.name}: {exc}", error_group=group_id)
        return RedirectResponse("/groups?done=used", status_code=303)

    @app.post("/groups/approve-all", response_class=HTMLResponse)
    def groups_approve_all(request: Request) -> Response:
        """"Approve all": every discovery candidate -> approved, one by one
        through the same ``set_fb_group_status`` as the single Approve.
        Approving is not joining (Join stays per group)."""
        return bulk_status("approved")

    @app.post("/groups/reject-all", response_class=HTMLResponse)
    def groups_reject_all(request: Request) -> Response:
        """"Reject all": every discovery candidate -> rejected."""
        return bulk_status("rejected")

    def bulk_status(new: str) -> Response:
        changed = 0
        for group in store.fb_groups("candidate"):
            if group.is_member:  # "Groups you're already in" have their own buttons
                continue
            store.set_fb_group_status(group.group_id, new)
            changed += 1
        return RedirectResponse(f"/groups?done={new}_all&n={changed}", status_code=303)

    @app.post("/groups/{group_id}/status", response_class=HTMLResponse)
    def group_status(request: Request, group_id: str, action: str = Form("")) -> Response:
        """Approve / Reject a candidate. Only candidate -> approved | rejected;
        joining is the joiner's (secure-sessions), never this page's."""
        group = group_or_404(group_id)
        new = {"approve": "approved", "reject": "rejected"}.get(action)
        if new is None:
            raise HTTPException(400, f"unknown action {action!r}")
        if group.status != "candidate":
            return groups_view(request, status_code=409,
                               error=f"{group.name} is {group.status}; only a candidate can be approved or rejected.")
        store.set_fb_group_status(group_id, new)
        return RedirectResponse(f"/groups?done={new}", status_code=303)

    @app.post("/groups/{group_id}/join", response_class=HTMLResponse)
    def group_join(request: Request, group_id: str) -> Response:
        """The owner's Join click for an ``approved`` group: starts
        ``browser.join_group`` in the background. It submits only the
        approved answers (re-checked right before Submit); new or changed
        live questions are stored and nothing is submitted."""
        group = group_or_404(group_id)
        if group.status != "approved":
            return groups_view(request, status_code=409,
                               error=f"{group.name} is {group.status}; only an approved group can be joined.")
        browser = fb.browser
        if browser is None:
            return groups_view(request, status_code=503, error=NO_BROWSER_MESSAGE, error_group=group_id)
        if group.questions and store.answers_approval_for(group_id) is None:
            return groups_view(request, status_code=409, error_group=group_id,
                               error="Approve this group's entry answers first; joining uses exactly them.")
        refused = busy_or_cooling(request)
        if refused is not None:
            return refused
        from house_finder.browser import join_group

        def run(progress: Any) -> Any:
            progress(f"joining {group.name}")
            try:
                return join_group(store, browser.session, browser.pacer, group_id)
            except SourceBlocked as exc:
                store.start_cooldown(FACEBOOK_SOURCE, f"blocked while joining a group: {exc}")
                raise

        jobs.start("join", f"Join {group.name}", run)
        return RedirectResponse("/groups?done=join_started", status_code=303)

    @app.post("/groups/{group_id}/joined", response_class=HTMLResponse)
    def group_mark_joined(request: Request, group_id: str) -> Response:
        """The owner says Facebook accepted a pending join request:
        ``pending_join`` -> ``joined`` (then its posts are read). Only from
        ``pending_join``."""
        group = group_or_404(group_id)
        if group.status != "pending_join":
            return groups_view(request, status_code=409,
                               error=f"{group.name} is {group.status}; only a pending join can be marked joined.")
        store.set_fb_group_status(group_id, "joined")
        return RedirectResponse("/groups?done=joined", status_code=303)

    async def submitted_answers(request: Request, group: Any) -> tuple[list[str], set[int], str]:
        data = await request.form()
        answers = [normalize_message_text(str(data.get(f"answer_{i}", ""))) for i in range(len(group.questions))]
        remember = {i for i in range(len(group.questions)) if f"remember_{i}" in data}
        return answers, remember, str(data.get("base_sha256", ""))

    def fresh_rows(group: Any, base_sha256: str, bank: AnswerBank) -> list[dict[str, Any]]:
        """The rows the page showed, if it showed the CURRENT state (group
        approved, same questions, same saved/drafted answers); else
        ``AnswersStateError`` (-> 409)."""
        if group.status != "approved":
            raise AnswersStateError(f"{group.name} is {group.status}; answers are only kept for an approved group.")
        if not group.questions:
            raise AnswersStateError(f"{group.name} has no entry questions.")
        rows, _ = answer_rows(group, bank)
        shown = [(r["question"], r["answer"]) for r in rows]
        if base_sha256 != answers_sha256(group.group_id, shown):
            raise AnswersStateError("The questions or answers changed since this page was opened. "
                                    "Review them again; nothing was saved or approved.")
        return rows

    def save_answers(group: Any, rows: list[dict[str, Any]], answers: list[str]) -> list[str]:
        """Save the submitted answers; returns each answer's source (a drafted
        answer kept as is keeps its source; anything typed is ``owner``)."""
        sources = []
        for row, answer in zip(rows, answers):
            if answer and answer == row["answer"] and row["source"] in ("fact", "remembered", "owner"):
                sources.append(row["source"])
            else:
                sources.append("owner" if answer else "needs_input")
        store.save_group_answers(group.group_id, [AnswerItem(q, a, src) for q, a, src
                                                  in zip(group.questions, answers, sources)])
        return sources

    @app.post("/groups/{group_id}/answers", response_class=HTMLResponse)
    async def group_answers_save(request: Request, group_id: str) -> Response:
        """Save the answers without approving (an approved set that changes
        loses its approval)."""
        group = group_or_404(group_id)
        answers, _, base = await submitted_answers(request, group)
        bank, _ = load_answer_bank()
        try:
            save_answers(group, fresh_rows(group, base, bank), answers)
        except AnswersStateError as exc:
            return groups_view(request, status_code=409, error=str(exc), error_group=group_id)
        return RedirectResponse(f"/groups?done=answers_saved#g-{quote(group_id, safe='')}", status_code=303)

    @app.post("/groups/{group_id}/answers/approve", response_class=HTMLResponse)
    async def group_answers_approve(request: Request, group_id: str) -> Response:
        """Approve the EXACT submitted answers: save them (if the page showed
        the current state), then approve their hash. A blank answer blocks
        approval; owner-typed answers ticked "remember" join the bank."""
        group = group_or_404(group_id)
        answers, remember, base = await submitted_answers(request, group)
        bank, bank_error = load_answer_bank()
        try:
            rows = fresh_rows(group, base, bank)
            if any(not a for a in answers):
                return groups_view(request, status_code=400, error_group=group_id,
                                   submitted={group_id: answers},
                                   error="Every question needs an answer before approval — nothing was approved.")
            sources = save_answers(group, rows, answers)
            store.approve_group_answers(group_id, answers_sha256(group_id, list(zip(group.questions, answers))))
        except AnswersStateError as exc:
            return groups_view(request, status_code=409, error=f"Not approved: {exc}", error_group=group_id)
        done = "answers_approved"
        to_remember = [i for i in sorted(remember)
                       if sources[i] == "owner" and sensitive_topic(group.questions[i], bank) is None
                       and not reveals_sensitive(answers[i], bank)]
        if to_remember:
            if bank_error is not None:
                done = "answers_approved_not_remembered"
            else:
                for i in to_remember:
                    bank = bank.remember(group.questions[i], answers[i])
                save_bank(bank, about_me_file, secrets=bank_secrets)
                store.log_event("answers_remembered", group_id=group_id, count=len(to_remember))
        return RedirectResponse(f"/groups?done={done}#g-{quote(group_id, safe='')}", status_code=303)

    # ------------------------------------------------------------ about me

    def about_me_view(request: Request, form: dict[str, Any] | None = None, errors: list[str] | None = None,
                      saved: bool = False, status_code: int = 200) -> HTMLResponse:
        file_error, locked = None, False
        if form is None:
            bank, file_error = load_answer_bank()
            locked = file_error is not None and bank_locked()
            form = bank_to_form(bank)
        else:
            # Never echo a sensitive value back into the page (write-only).
            form = {**form, "facts": [
                {**row, "value": "" if (row["sensitive"] or row["key"].strip().lower() in SENSITIVE_KEYS)
                 else row["value"]} for row in form["facts"]]}
        return render(request, "about_me.html", status_code=status_code, page="about_me", form=form,
                      errors=errors or [], saved=saved, file_error=file_error, locked=locked,
                      always_sensitive=SENSITIVE_KEYS)

    def bank_locked() -> bool:
        """True when the bank exists but cannot be decrypted (wrong / missing
        key, corrupted): saving must not replace it."""
        try:
            load_bank(about_me_file, secrets=bank_secrets)
        except SecretStoreError:
            return True
        except Exception:
            return False
        return False

    @app.get("/about-me", response_class=HTMLResponse)
    def about_me_page(request: Request, saved: int = 0) -> HTMLResponse:
        return about_me_view(request, saved=bool(saved))

    @app.post("/about-me", response_class=HTMLResponse)
    async def about_me_save(request: Request) -> Response:
        form = about_me_form_from_request(await request.form())
        try:
            current: AnswerBank | None = load_bank(about_me_file, secrets=bank_secrets)
        except SecretStoreError as exc:  # fail closed: never replace a file we cannot read
            return about_me_view(request, form=form, status_code=409,
                                 errors=[f"The encrypted About me file cannot be read, nothing saved: {exc}"])
        except Exception:  # broken (plaintext) file: the form replaces it, as before
            current = None
        bank, errors = parse_about_me_form(form, current)
        if bank is None:
            return about_me_view(request, form=form, errors=errors, status_code=400)
        try:
            save_bank(bank, about_me_file, secrets=bank_secrets)
        except SecretStoreError as exc:
            return about_me_view(request, form=form, status_code=409,
                                 errors=[f"The encrypted About me file cannot be written, nothing saved: {exc}"])
        # No values in the log: some facts are sensitive.
        store.log_event("about_me_saved", facts=[f.key for f in bank.facts], remembered=len(bank.remembered))
        return RedirectResponse("/about-me?saved=1", status_code=303)

    return app

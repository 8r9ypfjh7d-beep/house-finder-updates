# browser — the Facebook browser session (and yad2's browser fallback)

Playwright drives ONE persistent Chromium profile that the owner logged into
by hand. Through it the tool reads groups (`BrowserPageProvider`, the
`PageProvider` of [facebook.md](../sources/facebook/facebook.md)), joins an
approved group with its approved answers (`join_group`), and — only when the
owner picks send mode `browser` for Facebook — sends an approved Messenger
message (`FacebookBrowserSender`). Requires
[facebook.md](../sources/facebook/facebook.md) (snapshots, provider) and
[messaging.md](../messaging/messaging.md) (the approval gate).

The same `BrowserSession` and `Pacer` classes also run yad2's browser
fallback (`yad2_page.py`, [below](#yad2-fallback-yad2_pagepy)) — in its own
profile with its own pacer, never mixed with the Facebook login.

**Real Facebook DOM compatibility is NOT verified.** It was built with no
network access to facebook.com; the tests run real Chromium against local
mock pages (`tests/fixtures/fb_pages/`). The owner's first-run check is
**Test reading this group** on `/health` (`house-finder fb-check`; read-only), and every selector below is a guess at
Facebook's structure until that passes.

## Code Files

- `session.py` — `BrowserSession` (persistent context on one worker thread, `call(fn)`), `check_page()` / `block_reason()` / `BLOCK_MARKERS`, `fb_login()`, login marker (`login_info()`, `write_login_marker()`), `find_chromium()`, `playwright_available()`, `NotLoggedIn`, `BrowserUnavailable`, `FACEBOOK_URL`
- `pacer.py` — `Pacer` (delays, daily caps, stop for the day, gate), `PacerStatus`, `DailyCapReached`, `DEFAULT_CAPS`, `MIN_DELAY_FLOOR`, `YAD2_CAPS` / `YAD2_PAGE` / `YAD2_MIN_DELAY`
- `fb_provider.py` — `BrowserPageProvider`: `search_groups`, `read_group` (in-page extraction -> plain dicts -> pydantic snapshots)
- `fb_actions.py` — `join_group()` + `JoinResult`, `FacebookBrowserSender`, `register_browser_sender()`, `messenger_target()`, `normalize_box_text()`
- `runtime.py` — `FacebookBrowser` (session + pacer + provider), `open_facebook_browser()`, `make_pacer()`, `cooldown_gate()`
- `fb_check.py` — `check_group(browser, group_id, posts=5, out=)`: the read-only group test's lines (group head, each post's link / parsed fields / text start, today's pacer counts); used by `fb-check` and the app's **Test reading this group**
- `yad2_page.py` — `Yad2BrowserFetcher` (+ `Yad2BrowserResult`, `Yad2Capture`, `CapturedJson`), `page_block()`, `make_yad2_pacer()`, `open_yad2_browser()`, `CAPTCHA_MESSAGE`
- `__init__.py` — re-exports; never imports playwright (the worker thread does)

## Session (`session.py`)

- Profile: `data/browser-profile/` (`config.browser_profile_dir()`). Cookies
  stay there, never in SQLite or the code. **N3 (session data encrypted at
  rest)**: on Windows, Chromium encrypts its cookie store with DPAPI under
  the owner's Windows account. On Linux it uses the desktop keyring when
  there is one, else a fixed key (effectively plaintext); on macOS the
  Keychain. Keep the data dir on the owner's own account.
- `fb-login`: a headed window on facebook.com; the owner logs in by hand
  (2-factor included); the code only polls for Facebook's `c_user` cookie,
  then writes `.house-finder-login.json` (a timestamp) into the profile and
  closes. **No code path types credentials.** Without the marker,
  `open_facebook_browser` returns None: no provider, no joiner, no browser
  sender. Run the CLI with `serve` stopped (one Chromium per profile).
- **In-app login** (**Connect Facebook** on `/groups` / `/settings`,
  `POST /facebook/login` → `__main__.facebook_connector`): the same
  `fb_login` as a background job in the web app's Facebook job slot (a
  second Facebook job is refused while it runs). With the app's browser
  open and visible it runs on THAT session (no second Chromium); a hidden
  one (`--fb-headless`) is closed first, a visible `BrowserSession` opens for
  the login and closes, then `open_facebook_browser` reopens with the app's
  headless setting (re-registering the browser sender). Before the first
  login there is no browser: the login window opens, and on success the
  new `FacebookBrowser` becomes the app's (`app.state.facebook`), so
  Discover / Join / reading work without a restart. Its pacer is ungated
  (like the CLI): the cooldown never blocks logging in.
- `BrowserSession(profile_dir, headless=False, base_url=FACEBOOK_URL)`: a
  visible browser by default (`serve --fb-headless` hides it); launched on
  the first call; if the installed playwright expects a different Chromium
  build, `find_chromium()` falls back to one under
  `PLAYWRIGHT_BROWSERS_PATH`. `call(fn)` runs `fn(page)` on the single
  worker thread (Playwright's sync API is thread-bound; this also
  serialises every Facebook action).
- `check_page(page, base_url, pacer)` after every navigation: `/checkpoint`
  URL, a captcha frame/element, or a `BLOCK_MARKERS` text (English/Hebrew
  "temporarily blocked", "security check", "confirm your identity", …) in a
  dialog — or anywhere when the page has no feed — → `pacer.stop_for_today`
  + `SourceBlocked`. A login URL, a password form without a feed, or no
  `c_user` cookie → `NotLoggedIn` (a `SourceError`: loud on /health, not a
  block).

## Pacer (`pacer.py`)

`Pacer(state_path, min_delay=8, max_delay=20, caps=None, gate=None, clock,
sleep, rng, today, base_caps=DEFAULT_CAPS, label="Facebook")`; state in
`data/browser-pacer.json`, re-read before every action (shared by `serve`
and `fb-check`). `base_caps` is the set of action kinds and `label` the
site named in messages (the yad2 pacer passes `YAD2_CAPS`, `"yad2"`).

| Call | Does |
|---|---|
| `page()` | before EVERY navigation and scroll: wait `min + (max-min)·rng()` s since the last load (persisted, so a restart does not reset it) |
| `begin(kind)` | counts one `group_read` / `search` / `join` / `message` BEFORE it runs; at the cap → `DailyCapReached` (a `SourceError`), nothing loaded |
| `stop_for_today(reason)` | every later call raises `SourceBlocked` until the next local day |
| `gate` | asked before every action; the app passes `cooldown_gate(store)` (the store's `facebook` cooldown) |
| `status()` | `PacerStatus` for `/health` and `fb-check` |

Defaults: 20 group reads, 5 searches, 5 joins, 10 messages a day;
`min_delay` below 8 s raises. An unreadable state file raises — counts are
never reset silently.

## Provider (`fb_provider.py`)

`BrowserPageProvider(session, pacer, max_scrolls=3)` — reads only.

- `read_group(id, max_posts)`: `begin("group_read")`, load
  `/groups/<id>/?sorting_setting=CHRONOLOGICAL`, `check_page`, click
  whole-text "See more" buttons (never one that is or holds a link — that
  would be an unpaced navigation), extract, scroll (each through `page()`)
  until `max_posts` or no new articles. No `[role=feed]` → `SourceError`
  (not a member / layout changed), never an empty group.
- Extraction (in page, plain dicts): posts = top-level `[role=feed]
  [role=article]` (nested articles are comments); post id + permalink from
  the first link matching `/groups/<id>/posts/<id>` or `/permalink/<id>`
  (query/hash stripped — no tracking params); author = first `h2–h4 / strong`
  link; text = `[data-ad-preview=message]` else top-level `div[dir=auto]`;
  time = `time[datetime]` / `abbr[data-utime]`; images from photo links.
  An article without a permalink is passed as invalid and counted
  (`rejected_posts`), never invented. Group name = `h1`; members / privacy
  from "N members" / "Private group" text (English and Hebrew).
- `search_groups(query)`: `begin("search")`, `/search/groups/?q=`, group
  links `/groups/<id>/` with their card text; a page that is neither a
  result feed nor a "no results" page → `SourceError`.

## Actions (`fb_actions.py`)

`join_group(store, session, pacer, group_id) -> JoinResult(status, note,
questions)` — the facebook stage 3 contract:

1. Refuses (no page loaded, nothing counted) unless the group is `approved`
   and — when it has stored questions — `store.answers_approval_for` issues
   a token whose hash equals `answers_sha256` of the saved pairs.
2. `begin("join")`, open the group, press the group's OWN Join button (role
   button named Join / הצטרפות… in `[role=main]`, never inside the feed, a
   post, a side column or a dialog — a shared or suggested group has its own
   Join). More than one → `failed`, nothing clicked. Already pending/joined
   (read from the same header buttons) → that status.
3. Questions read from the `[role=dialog]` text boxes (aria-label, label,
   preceding text). Choice questions or a rules checkbox → `unsupported`
   (dialog closed, join by hand). **Live questions ≠ stored** (also the
   first capture) → dialog closed, `set_fb_group_questions(live)` (deletes
   old answers), `questions_changed`.
4. Same questions: type exactly `group_answers(id).pairs`, read every box
   back (`normalize_box_text`), `store.check_group_answers(id, token)`
   immediately before Submit, click Submit, then `pending_join` (`joined`
   when the page shows it). No questions dialog: pressing Join already sent
   the request (the owner's approval of the group covers it); only a
   visible pending/joined state is recorded, else `failed`.
5. Logs `fb_group_join` (status, note, question count — never answers).

`FacebookBrowserSender(listing, session=, pacer=, store=)` — `channel
"facebook"`, `mode "browser"`:

1. `refusal(message, approval)` first (the shared `ApprovalToken` gate).
2. Target from the poster's profile URL (`messenger_target`: group user
   link, `profile.php?id=`, `/people/…/<id>`, `/<username>`; Facebook hosts
   only) → `/messages/t/<id>/`; none → `failed`.
3. `begin("message")`, open the conversation, find `[role=textbox]
   [contenteditable]`; a box that already holds text → `failed`.
4. Type the approved text (lines inserted, line breaks Shift+Enter — a bare
   Enter sends), read the box back: **any difference beyond whitespace →
   the box is cleared and nothing is sent**.
5. Re-check `check_approval(store.get_message(id), token)`; then Enter. The
   box still holding the text afterwards → `failed` "send not confirmed".

Any failure — a reached daily cap, a cooldown, a block (which also starts
the `facebook` cooldown), no box, a mismatch, or any unexpected browser
error (the message MAY have gone: never left `approved` for a second
"Approve & send") — returns `failed` with the reason, so `dispatch` marks the message failed and the owner drafts again
(or switches to assisted). The send runs inside the "Approve & send"
request and waits for the browser thread (a running group read finishes
first).

`register_browser_sender(registry, session=, pacer=, store=)` registers it
for `("facebook", "browser")` (done by `__main__.facebook_browser` only when
`open_facebook_browser` returned a browser). `dispatch` stays its only
caller; the owner's send mode decides whether it is used.

## Runtime (`runtime.py`)

`open_facebook_browser(store, profile_dir=None, pacer=None, headless=False,
base_url=None)` → `FacebookBrowser(session, pacer, provider)` or None
(no playwright, or no login marker). The browser starts lazily.

## yad2 fallback (`yad2_page.py`)

`Yad2BrowserFetcher(session, pacer, search_url=SEARCH_URL,
api_hosts=("gw.yad2.co.il",), captcha_wait=120, poll=2, json_wait=20,
settle=1.5, now, clock, interactive=None)`; `fetch(params)` →
`Yad2BrowserResult(listings, item_count, errors, sources)`. Used by
`Yad2Adapter` only after plain HTTP was blocked
([sources.md](../sources/sources.md#browser-fallback)).

1. `pacer.begin("yad2_page")` (cap reached → `BrowserFallbackUnavailable`,
   nothing loaded), then on the browser thread `pacer.page()` and ONE
   `goto` of `https://www.yad2.co.il/realestate/rent?city=…&minPrice=…`.
   **Read-only: no click, no typing, no scroll.**
2. `page.on("response")` keeps responses from `api_hosts`; their bodies are
   read (≤ 5 MB, ≤ 30 responses) and `__NEXT_DATA__` is read when present.
   It waits until a known shape arrived plus `settle` s, or `json_wait` s.
3. `page_block(url, title, text, status, have_json)`: a perfdrive /
   shieldsquare host or a captcha title → `captcha`; a 403 without
   challenge words → `forbidden` (`SourceBlocked` at once); page text is
   searched only when no known JSON arrived.
4. Captcha + `interactive` (default: the session is not headless): bring
   the window to front and re-check every `poll` s for up to
   `captcha_wait` s while the **owner** solves it; then re-load the search
   page once (paced) if the challenge left it elsewhere. Headless or
   unsolved → `SourceBlocked(CAPTCHA_MESSAGE)` "yad2: captcha in the
   browser — solve it in the House Finder browser window, or try later".
   The tool never solves or clicks a challenge itself.
5. Every body goes through `yad2.find_payloads` + `parse_response`. None in
   a known shape → `SourceError` naming the captured (redacted) URLs. No
   Chromium (`BrowserUnavailable`) → `BrowserFallbackUnavailable`; any other
   browser error → `SourceError`.
6. `last_capture` (`Yad2Capture`) keeps page status, final URL, title,
   captcha seen/solved, shapes — structure only, for `check-yad2`.

`open_yad2_browser(store, headless=False, …)` → fetcher or None (no
playwright). Its `BrowserSession` uses `data/browser-yad2/` (a solved
captcha's cookie stays there) and `base_url` yad2; its pacer
(`make_yad2_pacer`) is `data/browser-yad2-pacer.json`: 10–20 s between
loads, **30** loads a day, gated by the store's `yad2` cooldown. Visible by
default; `serve --browser-headless` hides it (then a captcha is a block).

## Optimizations and Features

- **One browser folder in the installed app** (`config.pin_browsers_path()`,
  called first in `main()`): frozen, playwright's own launch defaults to
  `<install dir>\\…\\.local-browsers` while `playwright install` downloads to
  `%LOCALAPPDATA%\\ms-playwright`, so a downloaded Chromium was never found
  (owner's "Executable doesn't exist", v1.1.0). The variable is now pinned to
  `ms-playwright` for both. `ensure_chromium()` downloads before the first
  launch when the exact executable playwright will start is missing, and
  fails loudly if it is still missing after; `install-browser` also launches
  a headless Chromium as proof (the CI installer smoke runs it).

- Every navigation, scroll and action goes through the `Pacer`; caps are
  counted before the action, so a crash mid-action still counts it.
- Selectors are roles, aria labels and link patterns — never Facebook's
  hashed class names (the mock pages use random class names on purpose).
- Extraction returns plain data validated by the existing pydantic
  snapshots, so the Facebook source never sees HTML.
- One worker thread owns Playwright: the scheduler and web threads can never
  drive the browser concurrently.
- Text markers are searched in the page body only when there is no feed, so
  a rental post that says "captcha" never stops the day.
- `fb-check` and `serve` share the pacer file: a manual check counts
  against the same daily caps. The app's group test reads through the
  app's own browser (and pacer), never a second session.
- Join / membership read only the group header's buttons (`_own_buttons`):
  a feed post sharing another group carries a real Join button.
- Logged out is `NotLoggedIn` (red on /health, press Connect Facebook), not a block,
  so it does not start a cooldown.
- The yad2 fallback reuses `BrowserSession` (worker thread, executable
  fallback) with its own profile and pacer: a yad2 captcha never stops
  Facebook for the day, and a yad2 cookie never sits next to the Facebook
  login. Its first block check reads only URL, title and status, so a
  listing that mentions "captcha" cannot look like a challenge.
- Responses are collected in the event handler and their bodies read in
  the wait loop (not inside the handler), the safe pattern for the sync API.

"""The code version of this ``house_finder`` package (``updater.md``).

``APP_VERSION`` — the version of this code; an update bundle's
``version.py`` must carry the manifest's version.
``MIN_INSTALLER`` — the oldest installer (bundled Python + dependencies +
launcher) this code runs on. Bump it whenever a dependency, the launcher
(``packaging/``) or the PyInstaller collection changes, and release a new
installer. Both are plain string literals: the launcher and the PyInstaller
spec read them by regex without importing the package.
"""

APP_VERSION = "1.2.6"
MIN_INSTALLER = "1.2.0"

"""Text helpers shared across the package.

``normalize_place`` makes Hebrew and English place names comparable;
``canonical_city`` additionally folds known aliases of major cities
(Hebrew/English spellings, "Tel Aviv-Yafo" etc.) onto one canonical key.
``safe_url`` is the one check that a listing-derived URL is http(s) before it
becomes a link or is handed to the browser (web pages and senders).
"""

from __future__ import annotations

import re
import unicodedata
from typing import Any
from urllib.parse import urlsplit

# Hebrew points and cantillation marks (niqqud, dagesh, te'amim): U+0591–U+05C7
# except the punctuation characters maqaf (U+05BE), paseq (U+05C0),
# sof pasuq (U+05C3) and nun hafukha (U+05C6), which are handled separately.
_NIQQUD_RE = re.compile("[֑-ׇֽֿׁׂׅׄ]")
# Quote-like characters removed outright (they sit inside abbreviations such
# as ת"א or ב'): ASCII quotes, geresh, gershayim, typographic quotes, backtick.
_QUOTES_RE = re.compile("[\"'`׳״‘’‚‛“”„‟´]")
# Hyphen-like characters become a space: ASCII hyphen, maqaf, dashes.
_HYPHENS_RE = re.compile("[-־‐‑‒–—―−]")
_SPACES_RE = re.compile(r"\s+")


def normalize_place(s: str | None) -> str:
    """Normalise a place name for comparison.

    Strips, casefolds, removes Hebrew niqqud and quote/geresh/gershayim marks,
    turns hyphens (including the Hebrew maqaf) into spaces and collapses runs
    of whitespace. ``None`` or blank input gives ``""``.

    >>> normalize_place("  Tel-Aviv   Yafo ")
    'tel aviv yafo'
    """
    if not s:
        return ""
    text = unicodedata.normalize("NFC", s)
    text = _NIQQUD_RE.sub("", text)
    text = _QUOTES_RE.sub("", text)
    text = _HYPHENS_RE.sub(" ", text)
    text = text.casefold()
    return _SPACES_RE.sub(" ", text).strip()


# canonical key -> spellings. Every spelling is passed through
# normalize_place() when the lookup table is built, so write them naturally.
CITY_ALIASES: dict[str, tuple[str, ...]] = {
    "tel aviv": (
        "tel aviv",
        "tel aviv-yafo",
        "tel aviv-jaffa",
        "tel-aviv",
        "תל אביב",
        "תל אביב-יפו",
        "תל אביב יפו",
        'ת"א',
    ),
    "jerusalem": ("jerusalem", "ירושלים"),
    "haifa": ("haifa", "חיפה"),
    "ramat gan": ("ramat gan", "ramat-gan", "רמת גן", "רמת-גן"),
    "givatayim": ("givatayim", "givataim", "גבעתיים", "גבעתים"),
}

_ALIAS_TO_CANONICAL: dict[str, str] = {
    normalize_place(alias): canonical
    for canonical, aliases in CITY_ALIASES.items()
    for alias in (canonical, *aliases)
}


def canonical_city(s: str | None) -> str:
    """Return the canonical key for a city name.

    Known aliases map to their canonical English key (``"תל אביב-יפו"`` ->
    ``"tel aviv"``); any other name is returned as ``normalize_place(s)``, so
    two unknown spellings still compare equal when they normalise equally.
    """
    key = normalize_place(s)
    return _ALIAS_TO_CANONICAL.get(key, key)


SAFE_URL_SCHEMES = ("http", "https")


def safe_url(value: Any) -> str:
    """``value`` (stripped) when it is an absolute http(s) URL, else ``""``.

    Listing URLs come from the source sites (untrusted): a ``javascript:`` or
    ``data:`` URL must never become a link or be opened. Web templates render
    every listing-derived ``href`` through this (the ``safe_url`` filter) and
    the senders pass every URL they hand to the browser through it.
    """
    if not isinstance(value, str) or not value.strip():
        return ""
    try:
        parts = urlsplit(value.strip())
    except ValueError:
        return ""
    if parts.scheme.lower() not in SAFE_URL_SCHEMES or not parts.netloc:
        return ""
    return value.strip()


# Image-label prefixes Facebook puts on a group's photo link ("Profile photo
# of <group>"); a scraped name that starts with one is the photo's aria-label.
IMAGE_LABEL_PREFIXES: tuple[str, ...] = (
    "profile photo of ",
    "profile picture of ",
    "cover photo of ",
    "cover image of ",
    "תמונת הפרופיל של ",
    "תמונת פרופיל של ",
    "תמונת הנושא של ",
    "תמונת נושא של ",
    "תמונת הקאבר של ",
    "תמונת קאבר של ",
)


def clean_group_name(name: Any) -> str:
    """A Facebook group name without an image-label prefix ("Profile photo
    of …", "Cover photo of …" and the Hebrew equivalents), whitespace
    collapsed. Used when a name is extracted, stored and shown, so names
    stored before the fix read cleanly too. A name that is ONLY a prefix is
    returned unchanged (never an empty name)."""
    if not isinstance(name, str):
        return ""
    text = _SPACES_RE.sub(" ", name).strip()
    changed = True
    while changed:
        changed = False
        lowered = text.casefold()
        for prefix in IMAGE_LABEL_PREFIXES:
            if lowered.startswith(prefix) and text[len(prefix):].strip():
                text = text[len(prefix):].strip()
                changed = True
                break
    return text

# sources/facebook — Facebook groups source

Turns posts of the owner's **readable** Facebook groups (joined, or
approved and public) into `Listing`s, and
discovers candidate groups with stats for the owner to approve (BRIEF §9,
F3, F10). Pages arrive as structured snapshots from a `PageProvider` — the
logged-in browser session in production (`BrowserPageProvider`,
[browser.md](../../browser/browser.md)), JSON fixtures in tests and
development. **This package never parses
Facebook HTML, and never joins, posts or messages**: a provider only reads.

## Code Files

- `snapshots.py` — `PostSnapshot`, `GroupSnapshot` (+ `from_raw()`), `GroupSearchResult`; `GROUP_ID_PATTERN`, `POST_ID_PATTERN`
- `provider.py` — `PageProvider` protocol, `FixtureProvider`, `ProviderError`
- `adapter.py` — `FacebookGroupsAdapter`, `group_city()`, `city_from_group()`; rotation: `reading_order()`, `read_interval()`, `profile_places()`, `read_note()`, `MAX_GROUPS_PER_RUN`, `MIN_READ_INTERVAL`, `OTHER_READ_INTERVAL`
- `posts.py` — `post_kind()` (`listing` / `seeking` / `not_listing` / `no_text`), `is_seeking()`, `looks_rental()` (group names), `read_problem()` (one plain phrase per failed read), `POST_KINDS`
- `groups.py` — `is_listing()`, `classify()`, `GroupStats`, `group_stats()`, `discovery_queries()`, `DiscoveryReport` (+ `DiscoveryIssue`, `issue_kind()`), `DiscoveryFailed`, `summarize_issues()` → `IssueSummary`, `discover_groups()`, `MembershipReport`, `import_my_groups()`
- `__init__.py` — re-exports the above (not re-exported from `sources/__init__.py`, which `net` imports)

## Snapshots (`snapshots.py`) — untrusted input

| Model | Fields |
|---|---|
| `PostSnapshot` | `group_id`, `post_id`, `permalink`, `author_name?`, `author_url?`, `text` (≤20,000), `posted_at?`, `image_urls` (≤50), `video_count` (0–50), `video_posters` (≤50), `id_source?` (`permalink` / `query` / `photo_set` / `pfbid` / `content`; `has_post_link` is False for `content`) |
| `GroupSnapshot` | `group_id`, `name`, `url`, `member_count?` (≥0), `privacy?`, `posts`, `rejected_posts`, `rejected_reasons`, `extraction` (how the browser read it: `container`, `containers`, `ids`, `lazy_links`, `expanded` — counts only) |
| `GroupSearchResult` | `group_id`, `name`, `url`, `member_count?`, `description?` |

Pydantic-validated, frozen, unknown keys ignored. Ids must match
`GROUP_ID_PATTERN` / `POST_ID_PATTERN` (letters, digits, `. _ -`, and `:`
in post ids) — never a path. `GroupSnapshot.from_raw(dict)` validates each
post on its own: a malformed post, or one whose `group_id` is another
group's, is skipped and counted with a reason; a bad group head raises.
URLs are NOT checked here — the adapter passes each through `text.safe_url`.

## Provider (`provider.py`)

`PageProvider`: `search_groups(query) -> list[GroupSearchResult]`,
`read_group(group_id, max_posts) -> GroupSnapshot` (raise `SourceError`;
`SourceBlocked` when Facebook refuses us).

`FixtureProvider(root)`: `root/groups/<group_id>.json` (one group snapshot,
through `from_raw`, truncated to `max_posts`) and `root/search.json`
(`{query: [results]}`; an absent query or file = no results), and
optional `root/my_groups.json` (a list of groups for `my_groups()`). Missing,
unreadable or malformed files, an invalid id, or a file describing another
group → `ProviderError` (a `SourceError`). Test fixtures:
`tests/fixtures/facebook/` (hand-written, see its README).

## Adapter (`adapter.py`)

`FacebookGroupsAdapter(provider, store, *, max_posts=30, max_groups=3, today=None, now=utc)`,
`name = "facebook"`.

- Readable groups = `store.readable_fb_groups()`: `joined` ones, and
  `approved` ones discovery saw as **public** (`privacy == "public"`).
  **None → `SourceError("no joined or approved public Facebook groups")`**;
  the CLI therefore registers the adapter only when there is at least one.
- **Rotation** (v1.2.6; owner: every group "daily cap reached: 20/20" and no
  Facebook listing — the 30-minute schedule read every group each run).
  `reading_order(groups, now, places)`: a group is due when never read, or
  read longer ago than `read_interval` — `MIN_READ_INTERVAL` (3 h) for a
  rental-looking name (`looks_rental`, with the profile's places),
  `OTHER_READ_INTERVAL` (24 h) otherwise. Order: never read first, then the
  least recently read; rental-looking first at the same point; ties by
  name. One `fetch` reads at most `max_groups` (3) due groups. None due →
  `[]`, `expected_empty`, note "all N groups were read recently; next read
  in about …".
- Each read is recorded on the group: `store.record_fb_group_read(id,
  status, note=, stats=)` — `ok` / `no_posts` with `read_note(stats)` ("12
  posts: 3 listings, 2 looking for a place, 6 not apartments, 1 without
  text") and the counts + `extraction`; `error` / `blocked` with
  `read_problem(exc)` and the raw message in `stats["detail"]`. Shown on
  `/groups` and `/health`. Never post text or names.
- Each post → `textparse.parse_listing_text(text, today, locations=profile.locations)`,
  then `post_kind(text, parsed)`: only `listing` becomes a `Listing`;
  `seeking`, `not_listing`, `no_text` are counted (`counts["seeking"]`,
  `["discussion"]`, `["no_text"]`).
- Listing: `source="facebook"`, `source_id=post_id`, `url=safe_url(permalink)`
  (unsafe → post dropped, counted `unsafe`), `description` = post text,
  every parsed field (missing price / rooms stay unknown), `posted_at`,
  `photos` = every safe image URL (deduplicated), `video_count` +
  `video_posters` (safe, not also a photo), `contact = Contact(facebook_messenger,
  name=author_name, profile_url=safe_url(author_url) or None, phone = the
  post's phone when it states exactly one)`, `language`, `raw = {group_id,
  group_name, post, post_link, evidence}` — `post_link` False = a
  content-id post: the url is the group page and the review page says
  **Open the Facebook group**.
- **City from the group** (`city_from_group`): only when the post names a
  neighborhood and no city, the group's `discovered_query` names exactly one
  city (read with `textparse`), the neighborhood is listed under that city in
  the profile and under no other profile city. Evidence:
  `raw["evidence"]["city"] = "group search query: <query>"`. Nothing else is
  ever filled in.
- A provider may return a dict instead of a `GroupSnapshot`; it goes through
  `from_raw`. A snapshot for another group id is a group failure.
- Outcomes (`warnings` = ONE short sentence the collector appends to the
  health message; never a per-group wall of text):
  - normal: "read 2 of 17 groups (40 posts, 5 listings)"
    (+ "; 1 group could not be read (page not recognised) — see Facebook
    groups" when one failed); `expected_empty = True`, so zero listings in
    this slice is `ok`, not `empty` (no false "zero unexpected" alert);
  - **daily cap** (`issue_kind == "cap"`, by class name — never imports the
    browser): stop the run, keep what was read, add "daily Facebook reading
    limit reached (40 group reads) — continues tomorrow"; the capped group
    is NOT recorded (it stays first in line);
  - every attempted group failed → `SourceError("Facebook: 3 groups could
    not be read (page not recognised) — see Facebook groups")`;
  - groups read but no post at all → `SourceError("Facebook: no posts could
    be read from N groups (page not recognised?) — …")` — a broken page
    reader must not look like quiet groups;
  - not logged in → `SourceError("Facebook is not logged in in House
    Finder's window — press Connect Facebook")` at once (the group is not
    recorded);
  - `SourceBlocked` stops the run at once (recorded `blocked`), re-raised
    with the listings so far in `partial`.
- `counts`: `groups`, `due`, `read`, `failed_groups`, `posts`, `listings`,
  `discussion`, `seeking`, `no_text`, `rejected`, `unsafe_permalink`.
- Log (INFO) per group read: counts and the extraction's `container` / id
  sources — never text or names.

## Posts and group names (`posts.py`)

- `post_kind(text, parsed)`: empty → `no_text`; `is_seeking` ("מחפש/ת/ים
  דירה", "דרושה דירה", "looking for an apartment" — but "מחפשים שותף /
  דיירים / שוכרים", "looking for a roommate" are offers) → `seeking`; a
  short question ending in "?" without price/rooms → `not_listing`; rooms
  or a property type, an offer word (להשכרה, משכיר/ה, סאבלט, מתפנה, פנויה,
  for rent, sublet, available from…), a price per month (לחודש, per
  month), or a home word (דירה, חדר, סטודיו, apartment…) with a price /
  move-in / sqm → `listing`; else `not_listing` (a ticket sale with a price
  is not an apartment).
- `looks_rental(name, places)`: a rental word (דירות, השכרה, שכירות,
  שותפים, סאבלט, rent, apartment, roommate, sublet, flat…) or a city name
  (`text.CITY_ALIASES` + the profile's cities and neighborhoods). A hint for
  the owner and the reading order only.
- `read_problem(exc)`: "page not recognised", "page not understood",
  "Facebook is not logged in", "the Facebook window was closed", "Facebook
  did not answer in time", "page not found", "unexpected error".

## Groups (`groups.py`)

- `is_listing(parsed, text=None)` — with the text: `post_kind(...) ==
  "listing"`; without it (old callers): price or rooms stated.
  `group_stats` passes the text.
- `group_stats(snapshot, *, locations, today) -> GroupStats(posts_sampled,
  listing_posts, listing_ratio, last_listing_at, classification)` —
  ratio = listing posts / valid posts (None for no posts); last listing =
  newest dated listing post (naive times read as UTC).
- `classify(ratio)`: ≥0.6 `mostly listings`, <0.3 `mostly discussion`, else
  `mixed`; None → `unknown`.
- `discovery_queries(profile)`: per area `דירות להשכרה <city>`,
  `דירות להשכרה <neighborhood>` per neighborhood, `<city> apartments for rent`;
  deduplicated.
- `discover_groups(provider, profile, store, *, max_posts=20, today)` →
  `DiscoveryReport(queries, found, new, failures)`: search every query,
  dedup by group id (first query = `discovered_query`), sample each group
  (except `rejected` ones) with `read_group`, store with
  `store.upsert_fb_group` (new → `candidate`; existing status untouched).
  **Never joins, never calls `set_fb_group_status`.** A failing query or
  sample is listed in `failures` (sample failed → stored without stats); an
  unsafe group URL is stored as `""` and listed. Each failed step is also
  an `issues` entry (`stage` search / sample / url, `kind` from
  `issue_kind`: `cap` = a daily limit, `closed` = the Facebook window was
  closed, `logged_out`, `other`). No locations → `SourceError`; every query
  failed → `DiscoveryFailed` (a `SourceError` carrying `.report`, so the
  page still explains it); `SourceBlocked` is re-raised at once.
- `summarize_issues(report) -> IssueSummary(problems, notes, details)`:
  identical failures become ONE plain sentence ("3 searches and 14 groups
  could not be checked because the Facebook window was closed; they will
  be checked on the next Discover."), a daily cap a calm note ("Daily limit
  reached: 5 searches a day protect your account; the rest search
  tomorrow."), raw messages kept in `details` for "Technical details".
- `import_my_groups(provider, store, progress=)` → `MembershipReport(found,
  new, skipped)`: **Find groups I'm already in**. Calls the provider's
  optional `my_groups()` (the browser reads `/groups/joins/`), upserts each
  group (new → `candidate`, status never touched, unsafe URL → `""`) and
  `store.mark_fb_group_member`. Never approves or joins: the owner's **Use
  this group** does (see [web.md](../../web/web.md)).
  Optional `progress(text)` is told each step (`searching n/N: …`,
  `sampling group n/N: …`) — the web runs discovery in the background and
  shows it on `/groups`.

## Registration (`__main__.build_adapters`)

`build_adapters(store=..., fb_provider=...)` adds the adapter only when a
provider exists AND `store.readable_fb_groups()` is not empty. The provider is the
logged-in browser's `BrowserPageProvider` (after `house-finder fb-login`,
with the `[facebook]` extra), else `FixtureProvider(<data>/fb_fixtures/)`
when that folder exists (development). Zero joined groups is a
configuration state (nothing to read), not a failing source, so no adapter
and no red health row. `serve` rebuilds the list on every collection run,
so a group joined (or marked joined) while it runs is read at the next run.

## Optimizations and Features

- Posts are validated one by one (`from_raw`), so one broken post in a
  scraped page costs that post, not the group; the count and first reasons
  reach `/health`.
- Snapshot ids are pattern-restricted, so a fixture or provider id can never
  become a path (`FixtureProvider` rechecks before opening a file).
- `SourceBlocked` stops all further reads in the run and in discovery
  (account safety, VISION priority 1) instead of being isolated per group.
- Listings are deduplicated by id within a run (first wins).
- **Rotation keeps Facebook usable all day** (v1.2.6): ≤3 groups per
  collection, 3 h / 24 h minimum intervals, never-read and least recently
  read first, so 17 groups no longer spend the daily cap in one run; a
  reached cap is a calm note. Removing it would bring back the owner's
  "every group failed" banner.
- **Offers without price or rooms are listings** (an offer word, a move-in,
  a monthly price): matching shows unknown instead of the post vanishing;
  seeking posts and ticket sales are never listings.
- Per-group read results live on the group row (migration 11), so the
  health message stays ONE sentence and `/groups` explains each group.
- `group_city` reuses `textparse` on the stored query, so "one city only"
  follows the parser's own place rules (prefixes, aliases, negation).
- **Public approved groups are read without joining** (owner: "only
  showing listings from yad2", v1.2.1): approving a public group is enough;
  same provider, same Pacer caps.
- Discovery failures are classified by exception class NAME and message
  (`issue_kind`), so this package never imports the browser layer.
- Discovery samples a group found by several queries once, and skips
  re-sampling groups the owner rejected (fewer page reads).

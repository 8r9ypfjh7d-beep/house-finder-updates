"""``BrowserPageProvider`` — the ``PageProvider`` over the logged-in browser.

Reads only: ``search_groups(query)`` and ``read_group(group_id, max_posts)``.
Extraction runs IN the page and returns plain dicts, which go through the
same pydantic snapshots as fixtures (``GroupSnapshot.from_raw``,
``GroupSearchResult``) — untrusted input, validated post by post.

Selectors are roles, aria and link patterns only — never Facebook's hashed
class names: the feed is ``[role="feed"]``, a post is a top-level
``[role="article"]`` in it, and its id comes from a permalink matching
``/groups/<id>/posts/<id>`` or ``/groups/<id>/permalink/<id>``. **Real
Facebook DOM compatibility is NOT verified** (no network to Facebook where
this was built): ``house-finder fb-check`` is the owner's first-run check.

Every navigation and scroll goes through the ``Pacer`` (delay + daily cap),
and every loaded page through ``session.check_page`` (checkpoint / captcha /
block -> stop for the day + ``SourceBlocked``; logged out -> ``NotLoggedIn``).
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any
from urllib.parse import quote

from pydantic import ValidationError

from house_finder.browser.pacer import GROUP_READ, MY_GROUPS, SEARCH
from house_finder.browser.session import check_page
from house_finder.sources.base import SourceError
from house_finder.sources.facebook.snapshots import GROUP_ID_PATTERN, GroupSearchResult, GroupSnapshot
from house_finder.text import clean_group_name

if TYPE_CHECKING:
    from house_finder.browser.pacer import Pacer
    from house_finder.browser.session import BrowserSession

_GROUP_ID = re.compile(GROUP_ID_PATTERN)
MAX_SCROLLS = 3
MAX_SEARCH_RESULTS = 30

# In-page extraction of a group page. Returns plain data only.
_READ_GROUP_JS = r"""
(args) => {
  const [groupId, maxPosts] = args;
  const PERMALINK = /\/groups\/([^\/?#]+)\/(?:posts|permalink)\/([A-Za-z0-9:._-]+)/;
  const abs = (href) => { try { const u = new URL(href, location.href); u.hash = ""; return u; } catch (e) { return null; } };
  const clean = (u) => u ? (u.origin + u.pathname) : null;
  const feed = document.querySelector('[role="feed"]');
  const h1 = document.querySelector('[role="main"] h1') || document.querySelector('h1');
  let memberCount = null;
  const mainText = (document.querySelector('[role="main"]') || document.body).innerText || "";
  const m = mainText.match(/([\d][\d,.]*)\s*(K|M|אלף)?\s*(members|חברים|חברות)/i);
  if (m) {
    let n = parseFloat(m[1].replace(/,/g, ""));
    if (m[2] && /k|אלף/i.test(m[2])) n *= 1000;
    if (m[2] && /m/i.test(m[2])) n *= 1000000;
    memberCount = Math.round(n);
  }
  let privacy = null;
  // JS \b is ASCII-only (never matches beside Hebrew letters): explicit edges instead
  if (/(^|[^\p{L}])(private group|קבוצה פרטית)(?![\p{L}])/iu.test(mainText)) privacy = "private";
  else if (/(^|[^\p{L}])(public group|קבוצה ציבורית)(?![\p{L}])/iu.test(mainText)) privacy = "public";
  const posts = [];
  const seen = new Set();
  let valid = 0;
  if (feed) {
    for (const art of feed.querySelectorAll('[role="article"]')) {
      if (art.parentElement && art.parentElement.closest('[role="article"]')) continue;  // comments
      let postId = null, permalink = null;
      for (const a of art.querySelectorAll('a[href]')) {
        const u = abs(a.getAttribute("href"));
        const mm = u && u.pathname.match(PERMALINK);
        if (mm) { postId = mm[2]; permalink = clean(u); break; }
      }
      if (!postId) { posts.push({group_id: groupId, post_id: "", permalink: ""}); continue; }
      if (seen.has(postId)) continue;
      seen.add(postId);
      let authorName = null, authorUrl = null;
      const authorLink = art.querySelector('h2 a[href], h3 a[href], h4 a[href], strong a[href]');
      if (authorLink) {
        authorName = (authorLink.innerText || "").trim() || null;
        const u = abs(authorLink.getAttribute("href"));
        authorUrl = u ? clean(u) : null;
      }
      const msg = art.querySelector('[data-ad-preview="message"], [data-ad-comet-preview="message"]');
      let text = "";
      if (msg) text = msg.innerText || "";
      else text = Array.from(art.querySelectorAll('div[dir="auto"]'))
        .filter(d => !d.parentElement.closest('div[dir="auto"]')).map(d => d.innerText || "").join("\n");
      let postedAt = null;
      const t = art.querySelector('time[datetime], abbr[data-utime]');
      if (t) {
        if (t.getAttribute("datetime")) postedAt = t.getAttribute("datetime");
        else postedAt = new Date(parseInt(t.getAttribute("data-utime"), 10) * 1000).toISOString();
      }
      // ALL the post's photos (not comments' — a nested article — nor emoji /
      // avatars: tiny or inside the author heading). Facebook shows at most a
      // few tiles with "+N"; the hidden ones are only on the post itself.
      const own = (el) => el.closest('[role="article"]') === art;
      const httpUrl = (src) => { try { const u = new URL(src, location.href); return /^https?:$/i.test(u.protocol) ? u.href : null; } catch (e) { return null; } };
      const tiny = (img) => { const w = parseInt(img.getAttribute("width") || "0", 10), h = parseInt(img.getAttribute("height") || "0", 10);
                              return (w && w <= 48) || (h && h <= 48) || /emoji|\/rsrc\.php\//i.test(img.getAttribute("src") || ""); };
      const VIDEO_LINK = /\/(videos|watch|reel)(\/|\?|$)/i;
      const images = [], posters = [];
      let videos = 0;
      for (const img of art.querySelectorAll('a[href*="/photo"] img[src], img[src][alt]')) {
        if (!own(img) || tiny(img) || img.closest('h2, h3, h4, strong')) continue;
        const link = img.closest('a[href]');
        if (link && VIDEO_LINK.test(link.getAttribute("href") || "")) continue;  // a video's thumbnail
        const url = httpUrl(img.getAttribute("src"));
        if (url && !images.includes(url)) images.push(url);
        if (images.length >= 50) break;
      }
      // Videos: Facebook streams them (blob:/MSE), so only a poster image is
      // taken; the review page links to the post to watch it there.
      for (const v of art.querySelectorAll('video')) {
        if (!own(v)) continue;
        videos++;
        const url = httpUrl(v.getAttribute("poster") || "");
        if (url && !posters.includes(url)) posters.push(url);
      }
      if (!videos) {
        const seenVideo = new Set();
        for (const a of art.querySelectorAll('a[href]')) {
          if (!own(a) || !VIDEO_LINK.test(a.getAttribute("href") || "")) continue;
          const key = (httpUrl(a.getAttribute("href")) || "").split(/[?#]/)[0];
          if (seenVideo.has(key)) continue;
          seenVideo.add(key);
          videos++;
          const img = a.querySelector('img[src]');
          const url = img ? httpUrl(img.getAttribute("src")) : null;
          if (url && !posters.includes(url)) posters.push(url);
        }
      }
      posts.push({group_id: groupId, post_id: postId, permalink: permalink, author_name: authorName,
                  author_url: authorUrl, text: text.trim().slice(0, 20000), posted_at: postedAt,
                  image_urls: images, video_count: Math.min(videos, 50), video_posters: posters.slice(0, 50)});
      valid++;
      if (valid >= maxPosts) break;
    }
  }
  return {feed: !!feed, group: {group_id: groupId, name: h1 ? (h1.innerText || "").trim() : "",
          url: location.origin + "/groups/" + groupId + "/", member_count: memberCount, privacy: privacy},
          posts: posts, articleCount: feed ? feed.querySelectorAll('[role="article"]').length : 0};
}
"""

# Expand truncated posts: click only a button whose whole text is "See more"
# and that is not a link (a link would navigate: an unpaced page load).
_SEE_MORE_JS = r"""
() => {
  let n = 0;
  for (const b of document.querySelectorAll('[role="feed"] [role="article"] [role="button"]')) {
    if (b.closest('a[href]') || b.querySelector('a[href]')) continue;
    const t = (b.innerText || "").trim().toLowerCase();
    if (t === "see more" || t === "ראה עוד" || t === "הצג עוד") { b.click(); n++; }
    if (n >= 30) break;
  }
  return n;
}
"""

_SEARCH_JS = r"""
() => {
  const GROUP = /^\/groups\/([^\/?#]+)\/?$/;
  const main = document.querySelector('[role="main"]');
  const feed = document.querySelector('[role="feed"]');
  const text = (main || document.body).innerText || "";
  const noResults = /no results|we didn't find any results|we didn’t find any results|לא נמצאו תוצאות|אין תוצאות/i.test(text);
  const out = [];
  const seen = new Set();
  const scope = feed || main;
  if (scope) {
    for (const a of scope.querySelectorAll('a[href]')) {
      let u; try { u = new URL(a.getAttribute("href"), location.href); } catch (e) { continue; }
      const m = u.pathname.match(GROUP);
      if (!m || m[1] === "search" || m[1] === "feed" || m[1] === "discover") continue;
      const shown = (a.innerText || "").trim();
      const name = (shown || a.getAttribute("aria-label") || "").trim();
      if (!name) continue;
      if (seen.has(m[1])) {
        // The first link may be the group's photo (name only in its aria-label):
        // a later link with visible text gives the real name.
        const prev = out.find(r => r.group_id === m[1]);
        if (prev && prev.fromLabel && shown) { prev.name = shown.split("\n")[0].slice(0, 500); prev.fromLabel = false; }
        continue;
      }
      seen.add(m[1]);
      const card = a.closest('[role="article"]') || a.parentElement;
      const cardText = card ? (card.innerText || "") : "";
      let members = null;
      const mm = cardText.match(/([\d][\d,.]*)\s*(K|M|אלף)?\s*(members|חברים|חברות)/i);
      if (mm) {
        let n = parseFloat(mm[1].replace(/,/g, ""));
        if (mm[2] && /k|אלף/i.test(mm[2])) n *= 1000;
        if (mm[2] && /m/i.test(mm[2])) n *= 1000000;
        members = Math.round(n);
      }
      out.push({group_id: m[1], name: name.split("\n")[0].slice(0, 500), url: u.origin + u.pathname,
                member_count: members, description: cardText.slice(0, 2000) || null, fromLabel: !shown});
    }
  }
  return {recognised: !!(feed || noResults), noResults: noResults, results: out};
}
"""

# The owner's own memberships page (/groups/joins/): group links in the main
# column only (the left nav holds "Your feed" / "Discover" / "Your groups").
_MY_GROUPS_JS = r"""
() => {
  const GROUP = /^\/groups\/([^\/?#]+)\/?$/;
  const SKIP = new Set(["feed", "discover", "joins", "search", "create", "notifications", "yours",
                        "your_groups", "browse", "category", "invites", "requests"]);
  const main = document.querySelector('[role="main"]');
  const text = main ? (main.innerText || "") : "";
  const none = /you haven't joined any groups|you haven’t joined any groups|לא הצטרפת לאף קבוצה|אין לך קבוצות/i.test(text);
  const out = [];
  if (main) {
    for (const a of main.querySelectorAll('a[href]')) {
      let u; try { u = new URL(a.getAttribute("href"), location.href); } catch (e) { continue; }
      const m = u.pathname.match(GROUP);
      if (!m || SKIP.has(m[1].toLowerCase())) continue;
      const shown = (a.innerText || "").trim();
      const name = (shown || a.getAttribute("aria-label") || "").trim().split("\n")[0].slice(0, 500);
      const prev = out.find(r => r.group_id === m[1]);
      if (prev) { if (prev.fromLabel && shown) { prev.name = name; prev.fromLabel = false; } continue; }
      if (!name) continue;
      out.push({group_id: m[1], name: name, url: u.origin + u.pathname, fromLabel: !shown});
    }
  }
  return {recognised: !!main && (out.length > 0 || none), none: none, results: out};
}
"""
MY_GROUPS_SCROLLS = 3
MAX_MY_GROUPS = 200


def _valid_count(data: dict[str, Any]) -> int:
    return sum(1 for p in data["posts"] if p.get("post_id"))


class BrowserPageProvider:
    """``PageProvider`` over a ``BrowserSession`` (read-only: no join, post
    or message method — those are in ``fb_actions``)."""

    def __init__(self, session: BrowserSession, pacer: Pacer, *, max_scrolls: int = MAX_SCROLLS) -> None:
        self.session = session
        self.pacer = pacer
        self.base_url = session.base_url
        self.max_scrolls = max(0, int(max_scrolls))

    def search_groups(self, query: str) -> list[GroupSearchResult]:
        """Groups Facebook lists for ``query``. A page that is neither a
        result list nor a "no results" page raises ``SourceError``."""
        self.pacer.begin(SEARCH)

        def run(page: Any) -> dict[str, Any]:
            self.pacer.page()
            page.goto(f"{self.base_url}/search/groups/?q={quote(query)}", wait_until="domcontentloaded")
            check_page(page, base_url=self.base_url, pacer=self.pacer)
            return page.evaluate(_SEARCH_JS)

        data = self.session.call(run)
        if not data.get("recognised"):
            raise SourceError(f"group search page for {query!r} not recognised (layout changed?)")
        results: list[GroupSearchResult] = []
        for raw in data.get("results", [])[:MAX_SEARCH_RESULTS]:
            if isinstance(raw, dict):  # a photo link's aria-label: "Profile photo of <group>"
                raw = {**raw, "name": clean_group_name(raw.get("name"))}
            try:
                results.append(GroupSearchResult.model_validate(raw))
            except ValidationError:
                continue  # one odd link never fails the search
        return results

    def my_groups(self, *, max_scrolls: int = MY_GROUPS_SCROLLS) -> list[GroupSearchResult]:
        """The groups the logged-in owner is already a member of, from
        Facebook's "Your groups" page (``/groups/joins/``): id, name (image
        labels cleaned), url — nothing else. One ``my_groups_read`` against
        the daily cap; the load and each of at most ``max_scrolls`` scrolls
        go through ``pacer.page()``. A page that is neither a group list nor
        a "no groups" page -> ``SourceError`` (never an empty list)."""
        self.pacer.begin(MY_GROUPS)
        limit = max(0, int(max_scrolls))

        def run(page: Any) -> dict[str, Any]:
            self.pacer.page()
            page.goto(f"{self.base_url}/groups/joins/", wait_until="domcontentloaded")
            check_page(page, base_url=self.base_url, pacer=self.pacer)
            data = page.evaluate(_MY_GROUPS_JS)
            data["on_joins_page"] = "/groups/joins" in (page.url or "")
            for _ in range(limit):
                before = len(data["results"])
                self.pacer.page()
                page.mouse.wheel(0, 2500)
                page.wait_for_timeout(1500)
                check_page(page, base_url=self.base_url, pacer=self.pacer)
                data = {**page.evaluate(_MY_GROUPS_JS), "on_joins_page": data["on_joins_page"]}
                if len(data["results"]) == before or len(data["results"]) >= MAX_MY_GROUPS:
                    break
            return data

        data = self.session.call(run)
        if data.get("on_joins_page") is False:  # redirected (e.g. to Discover): those are not your groups
            raise SourceError("Facebook did not open your groups page (it redirected); nothing was listed")
        if not data.get("recognised"):
            raise SourceError("your Facebook groups page was not recognised (layout changed?)")
        results: list[GroupSearchResult] = []
        for raw in data.get("results", [])[:MAX_MY_GROUPS]:
            if not isinstance(raw, dict):
                continue
            raw = {"group_id": raw.get("group_id"), "name": clean_group_name(raw.get("name")), "url": raw.get("url")}
            try:
                results.append(GroupSearchResult.model_validate(raw))
            except ValidationError:
                continue  # one odd link never fails the page
        return results

    def read_group(self, group_id: str, max_posts: int) -> GroupSnapshot:
        """The group's head and up to ``max_posts`` recent posts (newest
        first). No feed on the page -> ``SourceError`` (not a member,
        layout changed) — never an empty group."""
        if not _GROUP_ID.fullmatch(group_id or ""):
            raise SourceError(f"invalid group id {group_id!r}")
        self.pacer.begin(GROUP_READ)
        limit = max(0, int(max_posts))

        def run(page: Any) -> dict[str, Any]:
            self.pacer.page()
            page.goto(f"{self.base_url}/groups/{group_id}/?sorting_setting=CHRONOLOGICAL",
                      wait_until="domcontentloaded")
            check_page(page, base_url=self.base_url, pacer=self.pacer)
            page.evaluate(_SEE_MORE_JS)
            data = page.evaluate(_READ_GROUP_JS, [group_id, limit])
            scrolls = 0
            while data["feed"] and _valid_count(data) < limit and scrolls < self.max_scrolls:
                before = data["articleCount"]
                self.pacer.page()
                page.mouse.wheel(0, 2500)
                page.wait_for_timeout(1500)
                check_page(page, base_url=self.base_url, pacer=self.pacer)
                page.evaluate(_SEE_MORE_JS)
                data = page.evaluate(_READ_GROUP_JS, [group_id, limit])
                scrolls += 1
                if data["articleCount"] == before:
                    break
            return data

        data = self.session.call(run)
        if not data.get("feed"):
            raise SourceError(f"group {group_id}: no feed on the page (not a member, or the layout changed)")
        posts = data["posts"]
        valid = [p for p in posts if p.get("post_id")][:limit]
        raw = {**data["group"], "posts": valid + [p for p in posts if not p.get("post_id")]}
        raw["name"] = clean_group_name(raw.get("name"))
        if not raw.get("name"):
            raw["name"] = f"group {group_id}"
        try:
            return GroupSnapshot.from_raw(raw)
        except (ValidationError, TypeError) as exc:
            raise SourceError(f"group {group_id}: page not understood: {exc}") from None

"""Facebook group discovery and per-group stats (BRIEF §9, F10).

``discover_groups`` searches Facebook (through the provider) with queries
built from the profile's locations, samples each found group's recent posts
for stats, and stores every group as a ``candidate``. **It never joins and
never sets ``approved`` / ``joined`` / ``pending_join``** — the owner
approves a group, and only the joiner (secure-sessions) joins it, after an
approval record (VISION priority 1). The store's ``fb_groups`` triggers
enforce the same rule.
"""

from __future__ import annotations

import re
from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from typing import TYPE_CHECKING

from house_finder.sources.base import SourceBlocked, SourceError
from house_finder.sources.facebook.snapshots import GroupSearchResult, GroupSnapshot
from house_finder.text import safe_url
from house_finder.textparse import ParsedFields, parse_listing_text

if TYPE_CHECKING:
    from house_finder.profile import LocationArea, SearchProfile
    from house_finder.sources.facebook.provider import PageProvider
    from house_finder.store import Store

MOSTLY_LISTINGS = 0.6  # ratio >= this -> "mostly listings"
MOSTLY_DISCUSSION = 0.3  # ratio < this -> "mostly discussion"
DEFAULT_SAMPLE_POSTS = 20


def is_listing(parsed: ParsedFields) -> bool:
    """A post is a listing when it states a price or a room count; anything
    else is discussion (counted for the ratio, never stored as a listing)."""
    return parsed.price is not None or parsed.rooms is not None


def classify(ratio: float | None) -> str:
    """``mostly listings`` (>= 0.6), ``mixed``, ``mostly discussion`` (< 0.3),
    or ``unknown`` when no post was sampled."""
    if ratio is None:
        return "unknown"
    if ratio >= MOSTLY_LISTINGS:
        return "mostly listings"
    if ratio < MOSTLY_DISCUSSION:
        return "mostly discussion"
    return "mixed"


def _utc(value: datetime) -> datetime:
    return value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value.astimezone(timezone.utc)


@dataclass(frozen=True)
class GroupStats:
    """How listing-heavy a group is, from a sample of its recent posts."""

    posts_sampled: int
    listing_posts: int
    listing_ratio: float | None
    last_listing_at: datetime | None
    classification: str


def group_stats(
    snapshot: GroupSnapshot,
    *,
    locations: Iterable[LocationArea] = (),
    today: date | None = None,
) -> GroupStats:
    """Stats over the snapshot's (valid) posts: listing ratio = listing posts
    / posts, the newest dated listing post, and the classification."""
    areas = list(locations)
    total = len(snapshot.posts)
    listing_times: list[datetime] = []
    listings = 0
    for post in snapshot.posts:
        if is_listing(parse_listing_text(post.text, today=today, locations=areas)):
            listings += 1
            if post.posted_at is not None:
                listing_times.append(_utc(post.posted_at))
    ratio = listings / total if total else None
    return GroupStats(
        posts_sampled=total,
        listing_posts=listings,
        listing_ratio=ratio,
        last_listing_at=max(listing_times) if listing_times else None,
        classification=classify(ratio),
    )


def discovery_queries(profile: SearchProfile) -> list[str]:
    """Search queries from the profile's locations, in order, without
    duplicates: ``דירות להשכרה <city>``, ``דירות להשכרה <neighborhood>`` for
    each neighborhood, ``<city> apartments for rent``."""
    queries: list[str] = []
    for area in profile.locations:
        city = " ".join(area.city.split())
        if not city:
            continue
        queries.append(f"דירות להשכרה {city}")
        for hood in area.neighborhoods:
            hood = " ".join(hood.split())
            if hood:
                queries.append(f"דירות להשכרה {hood}")
        queries.append(f"{city} apartments for rent")
    return list(dict.fromkeys(queries))


@dataclass(frozen=True)
class DiscoveryIssue:
    """One failed step of discovery, sorted for the page: ``stage`` is
    ``search`` / ``sample`` / ``url``; ``kind`` is ``cap`` (a daily limit),
    ``closed`` (the Facebook window was closed), ``logged_out`` or ``other``."""

    stage: str
    target: str
    kind: str
    message: str


def issue_kind(exc: BaseException) -> str:
    """``cap`` / ``closed`` / ``logged_out`` / ``other`` for a failed step.
    By class name and message, so this package never imports the browser layer."""
    name = type(exc).__name__
    text = str(exc).lower()
    if name == "DailyCapReached" or "daily cap reached" in text:
        return "cap"
    if name == "TargetClosedError" or "has been closed" in text or "target closed" in text \
            or "browser closed" in text or "browser session is closed" in text:
        return "closed"
    if name == "NotLoggedIn" or "not logged in" in text:
        return "logged_out"
    return "other"


@dataclass
class DiscoveryReport:
    """What one ``discover_groups`` call did. ``failures`` keeps the raw
    messages (event log, "Technical details"); ``issues`` the same steps
    sorted by kind for the plain summary (``summarize_issues``)."""

    queries: list[str] = field(default_factory=list)
    found: list[str] = field(default_factory=list)  # group ids, first-seen order
    new: list[str] = field(default_factory=list)  # group ids stored for the first time
    failures: list[str] = field(default_factory=list)  # failed queries / samples, with reasons
    issues: list[DiscoveryIssue] = field(default_factory=list)

    def add_issue(self, stage: str, target: str, exc: BaseException | str, raw: str) -> None:
        kind = issue_kind(exc) if isinstance(exc, BaseException) else "other"
        self.failures.append(raw)
        self.issues.append(DiscoveryIssue(stage, target, kind, str(exc)))


class DiscoveryFailed(SourceError):
    """Every search failed; ``report`` holds the steps, so the page can say
    why in plain words (a closed window, the daily limit) instead of a raw
    error."""

    def __init__(self, message: str, report: DiscoveryReport) -> None:
        super().__init__(message)
        self.report = report


@dataclass(frozen=True)
class IssueSummary:
    """The discovery report in plain words: ``problems`` (things that went
    wrong, one sentence per kind), ``notes`` (calm: a daily limit protecting
    the account) and ``details`` (the raw messages, for "Technical details")."""

    problems: list[str]
    notes: list[str]
    details: list[str]


def _count(n: int, one: str, many: str) -> str:
    return f"{n} {one if n == 1 else many}"


def _cap_note(issues: list[DiscoveryIssue], stage: str) -> str | None:
    hits = [i for i in issues if i.kind == "cap" and i.stage == stage]
    if not hits:
        return None
    m = re.search(r"(\d+)/(\d+)", hits[0].message)
    cap = m.group(2) if m else None
    if stage == "search":
        limit = f"{cap} searches a day" if cap else "a few searches a day"
        return f"Daily limit reached: {limit} protect your account; the rest search tomorrow."
    limit = f"{cap} group reads a day" if cap else "a few group reads a day"
    return (f"Daily limit reached: {limit} protect your account; "
            f"{_count(len(hits), 'group is', 'groups are')} checked tomorrow.")


def summarize_issues(report: DiscoveryReport) -> IssueSummary:
    """Group identical failures into one plain sentence each (VISION: the
    owner is not technical; red stack-trace lines scare). Raw messages stay
    in ``details``."""
    issues = list(getattr(report, "issues", []) or [])
    problems: list[str] = []
    notes = [n for n in (_cap_note(issues, "search"), _cap_note(issues, "sample")) if n]
    closed_s = sum(1 for i in issues if i.kind == "closed" and i.stage == "search")
    closed_g = sum(1 for i in issues if i.kind == "closed" and i.stage == "sample")
    if closed_s or closed_g:
        parts = []
        if closed_s:
            parts.append(_count(closed_s, "search", "searches"))
        if closed_g:
            parts.append(_count(closed_g, "group", "groups"))
        problems.append(f"{' and '.join(parts)} could not be checked because the Facebook window was closed; "
                        "they will be checked on the next Discover. Keep that window open (you can minimize it).")
    if any(i.kind == "logged_out" for i in issues):
        problems.append("Facebook is not logged in in House Finder's window: press Connect Facebook, then "
                        "Discover again.")
    other_s = sum(1 for i in issues if i.kind == "other" and i.stage == "search")
    other_g = sum(1 for i in issues if i.kind == "other" and i.stage == "sample")
    if other_s:
        problems.append(f"{_count(other_s, 'search', 'searches')} could not be read (Facebook's page "
                        "looked different); they are tried again on the next Discover.")
    if other_g:
        problems.append(f"{_count(other_g, 'group', 'groups')} could not be sampled; "
                        f"{'it is' if other_g == 1 else 'they are'} listed without statistics.")
    urls = sum(1 for i in issues if i.stage == "url")
    if urls:
        problems.append(f"{_count(urls, 'group', 'groups')} had an unusable link (left out of the link).")
    if not issues and report.failures:  # an older report without issues
        problems.append(f"{_count(len(report.failures), 'step', 'steps')} did not work.")
    return IssueSummary(problems=problems, notes=notes, details=list(report.failures))


def discover_groups(
    provider: PageProvider,
    profile: SearchProfile,
    store: Store,
    *,
    max_posts: int = DEFAULT_SAMPLE_POSTS,
    today: date | None = None,
    progress: Callable[[str], None] | None = None,
) -> DiscoveryReport:
    """Search, dedup by group id (the first query that found a group is its
    ``discovered_query``), sample each group's recent posts for stats, and
    store it with ``upsert_fb_group`` — new groups as ``candidate``; an
    existing group's status is never touched. A rejected group is not
    re-sampled.

    One failing query or sample never stops the others (it is listed in
    ``failures``; a group whose sample failed is stored without stats).
    Raises ``SourceError`` when the profile has no locations or every query
    failed, and re-raises ``SourceBlocked`` at once (stop reading a site
    that refuses us; groups stored so far stay stored).
    ``progress(text)`` (optional) is told each step (the web's background
    "Discover groups" shows it on ``/groups``).
    """
    say = progress or (lambda text: None)
    report = DiscoveryReport(queries=discovery_queries(profile))
    if not report.queries:
        raise SourceError("the profile has no locations to search Facebook groups for")
    areas = list(profile.locations)
    found: dict[str, tuple[str, GroupSearchResult]] = {}
    failed_queries = 0
    for n, query in enumerate(report.queries, start=1):
        say(f"searching {n}/{len(report.queries)}: {query}")
        try:
            results = provider.search_groups(query)
        except SourceBlocked:
            raise
        except Exception as exc:  # one failing query never stops the others
            failed_queries += 1
            report.add_issue("search", query, exc, f"search {query!r}: {exc}")
            continue
        for result in results:
            found.setdefault(result.group_id, (query, result))
    if failed_queries == len(report.queries):
        raise DiscoveryFailed("every Facebook group search failed: " + "; ".join(report.failures), report)

    for n, (group_id, (query, result)) in enumerate(found.items(), start=1):
        say(f"sampling group {n}/{len(found)}: {result.name}")
        report.found.append(group_id)
        existing = store.get_fb_group(group_id)
        stats: GroupStats | None = None
        privacy = None
        member_count = result.member_count
        if existing is None or existing.status != "rejected":
            try:
                snapshot = provider.read_group(group_id, max_posts)
            except SourceBlocked:
                raise
            except Exception as exc:
                report.add_issue("sample", group_id, exc, f"sample {group_id}: {exc}")
            else:
                stats = group_stats(snapshot, locations=areas, today=today)
                privacy = snapshot.privacy
                if snapshot.member_count is not None:
                    member_count = snapshot.member_count
        url = safe_url(result.url)
        if result.url and not url:
            report.add_issue("url", group_id, "unsafe URL dropped", f"group {group_id}: unsafe URL dropped")
        is_new = store.upsert_fb_group(
            group_id,
            name=result.name,
            url=url,
            member_count=member_count,
            privacy=privacy,
            discovered_query=query,
            last_listing_at=(stats.last_listing_at.isoformat()
                             if stats and stats.last_listing_at else None),
            listing_ratio=stats.listing_ratio if stats else None,
            posts_sampled=stats.posts_sampled if stats else None,
        )
        if is_new:
            report.new.append(group_id)
    return report


@dataclass
class MembershipReport:
    """What one ``import_my_groups`` call did."""

    found: list[str] = field(default_factory=list)  # group ids on the owner's "Your groups" page
    new: list[str] = field(default_factory=list)  # stored for the first time (as candidates)
    skipped: list[str] = field(default_factory=list)  # unusable entries, with reasons


def import_my_groups(
    provider: PageProvider,
    store: Store,
    *,
    progress: Callable[[str], None] | None = None,
) -> MembershipReport:
    """"Find groups I'm already in": read the owner's own memberships page
    (``provider.my_groups()``), store each group with ``upsert_fb_group``
    (new -> ``candidate``; an existing group's status is never touched) and
    mark it ``member_seen_at``. **Never approves or joins**: the owner's
    "Use this group" click does that (candidate -> approved -> joined).
    ``SourceBlocked`` / ``SourceError`` propagate (fail loudly)."""
    say = progress or (lambda text: None)
    say("reading your Facebook groups page")
    reader = getattr(provider, "my_groups", None)
    if reader is None:
        raise SourceError("this Facebook connection cannot list your groups (connect Facebook first)")
    report = MembershipReport()
    for result in reader():
        if result.group_id in report.found:
            continue
        report.found.append(result.group_id)
        url = safe_url(result.url)
        if result.url and not url:
            report.skipped.append(f"group {result.group_id}: unsafe URL dropped")
        if store.upsert_fb_group(result.group_id, name=result.name, url=url):
            report.new.append(result.group_id)
        store.mark_fb_group_member(result.group_id)
    say(f"found {len(report.found)} group(s) you are in")
    return report

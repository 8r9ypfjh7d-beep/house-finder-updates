"""Facebook groups source — see ``facebook.md``."""

from house_finder.sources.facebook.adapter import FacebookGroupsAdapter, city_from_group, group_city
from house_finder.sources.facebook.groups import (
    DiscoveryFailed,
    DiscoveryIssue,
    DiscoveryReport,
    GroupStats,
    IssueSummary,
    MembershipReport,
    classify,
    discover_groups,
    discovery_queries,
    group_stats,
    import_my_groups,
    is_listing,
    summarize_issues,
)
from house_finder.sources.facebook.provider import FixtureProvider, PageProvider, ProviderError
from house_finder.sources.facebook.snapshots import GroupSearchResult, GroupSnapshot, PostSnapshot

__all__ = [
    "DiscoveryFailed",
    "DiscoveryIssue",
    "DiscoveryReport",
    "FacebookGroupsAdapter",
    "FixtureProvider",
    "GroupSearchResult",
    "GroupSnapshot",
    "GroupStats",
    "IssueSummary",
    "MembershipReport",
    "PageProvider",
    "PostSnapshot",
    "ProviderError",
    "city_from_group",
    "classify",
    "discover_groups",
    "discovery_queries",
    "group_city",
    "group_stats",
    "import_my_groups",
    "is_listing",
    "summarize_issues",
]
